<script type="text/javascript">
const tableConst = {
  PAGE_SIZES: [5, 10, 25, 50],
  PAGE_SIZE: 10
}

const buttonName = {
  SEARCH: '検索',
  RESET: 'リセット',
  INSERT: '新規',
  UPDATE: '更新',
  DELETE: '削除',
  PRINT: '印刷',
  BACK: '戻る',
  EXEC: '実行',
  REDO: '再作成'
}

export default
{
  tableConst,
  buttonName
}
</script>
