<template>
  <div>
    <!--<img src="./assets/logo.png">-->
    <router-view></router-view>
  </div>
</template>

<script>
export default {}
</script>

<style>
*{
  font-family: "Meiryo UI";
}
.el-table .cell, .el-table th div {
  padding-right: 0px;
}
.el-table--mini, .el-table--small th{
  color: black;
  background: #77cad8;
  font-size: 11px;
}
.el-table--mini, .el-table--small{
  font-size: 11px;
}
.el-table thead.is-group th{
  background: #77cad8;
  color: #000000;
  font-size: 11px;
}
.el-submenu__title {
  font-size: 12px;
}
.el-submenu .el-menu-item {
  font-size: 11px;
  min-width: 150px;
  height: 30px;
  line-height: 30px;
}
.el-table--small td, .el-table--small th {
  padding: 1px 2px 1px 2px;
}
.el-button--medium, .el-button--medium.is-round {
  padding: 2px 0px;
}
.el-button--medium {
  font-size: 11px;
}
.el-input-group > .el-input__inner {
  display:inline-block;
  vertical-align:middle;
}
.el-table .cell, .el-table th div, .el-table--border td:first-child .cell, .el-table--border th:first-child .cell {
  padding-left: 2px;
}
.el-input.is-disabled .el-input__inner {
  background-color: #fff;
  cursor: default;
  color: #606266;
}
.el-date-table td {
  padding: 0px;
  height: 14px;
  width: 14px;
}
.el-date-table th {
  padding: 0px;
}
.el-date-table td div {
  padding: 0px;
  height: 20px;
}
.el-date-picker .el-picker-panel__content {
  width: 180px;
}
.el-date-picker__header {
  margin: 2px;
}
.el-date-picker {
  width: 210px;
}
.el-date-picker__header-label {
  font-size: 14px;
  padding: 0px;
}
.el-date-table {
  font-size: 10px;
}
.el-picker-panel__content {
  margin: 5px 15px 5px 15px;
}
.nsd-input-class {
  -webkit-appearance: none;
  background-color: #fff;
  border-radius: 4px;
  border: 1px solid #dcdfe6;
  -webkit-box-sizing: border-box;
  box-sizing: border-box;
  color: #606266;
  display: inline-block;
  font-size: 12px;
  height: 28px;
  line-height: 1;
  outline: 0;
  padding: 0 15px;
  -webkit-transition: border-color .2s cubic-bezier(.645,.045,.355,1);
  transition: border-color .2s cubic-bezier(.645,.045,.355,1);
  width: 100%;
  text-align: right;
}
/*
#app {
  font-family: 'Avenir', Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  margin-top: 60px;
}
*/
</style>