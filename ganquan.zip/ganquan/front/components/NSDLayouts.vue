<template>
  <el-container>
    <el-aside width=200px><nsd-nav></nsd-nav></el-aside>
    <el-main><nsd-content></nsd-content></el-main>
  </el-container>
</template>

<script>
import NSDHeader from '@/components/NSDHeader.vue'
import NSDNav from '@/components/NSDNav.vue'
import NSDContent from '@/components/NSDContent.vue'

export default {
  components: {
    'nsd-header': NSDHeader,
    'nsd-nav': NSDNav,
    'nsd-content': NSDContent
  }
}

pushHistory()

window.addEventListener('popstate', function (e) {
  if (confirm('ブラウザの戻るボタンを押下したら、セッションを切断します。')) {
    alert('セッションを切断しました。')
  } else {
    pushHistory()
  }
}, false)

function pushHistory () {
  var state = {
    title: 'title',
    url: '#'
  }
  window.history.pushState(state, 'title', '#')
}
</script>

<style>
.el-aside {
  height: 620px;
}
</style>