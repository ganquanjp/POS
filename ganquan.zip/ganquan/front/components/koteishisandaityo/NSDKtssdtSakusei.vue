<template>
  <div class="page-style">
    <el-row>
      <el-col>
        <nsd-content-title v-bind:titlename="titlename" v-bind:message="this.$store.state.message"></nsd-content-title>
      </el-col>
    </el-row>
    <el-row>
      <el-col>
        <nsd-lable></nsd-lable>
      </el-col>
    </el-row>
    <el-row>
      <el-col>
        <nsd-button-bar v-bind:buttons="buttonName"></nsd-button-bar>
      </el-col>
    </el-row>
  </div>
</template>

<script>
import NsdContentTitle from '@/components/common/NSDContentTitle.vue'
import NSDLable from '@/components/koteishisandaityo/sakusei/NSDLable.vue'
import NSDButtonBar from '@/components/common/NSDButtonBar.vue'

export default {
  components: {
    'nsd-content-title': NsdContentTitle,
    'nsd-button-bar': NSDButtonBar,
    'nsd-lable': NSDLable
  },
  data () {
    return {
      titlename: '【固定資産台帳出力】作成指示',
      buttonName: [
        {name: '再作成', primary: true, show: true, action: 'post', url: '/koteshisanDaityo-selectByWhere'}
      ]
    }
  }
}
</script>

<style scoped>
.page-style {
  margin-left: 15px;
}
</style>
