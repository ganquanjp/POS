<template>
  <div>
    <el-row>
      <el-col style="width:300px">
        <el-button 
          v-for="(btn, key) in buttons" 
          v-if="btn.show" 
          class="button-style" 
          size="mini" 
          v-bind:type="btn.primary ? 'primary' : '' "
          v-bind:key="key"
          @click="btnClick"
          >
          {{ btn.name }}
        </el-button>
      </el-col>
    </el-row>
  </div>
</template>

<script>
export default {
  data () {
    return {
      buttons: [
        { name: this.$CONST_.buttonName.REDO, primary: true, show: true }
      ]
    }
  },
  methods: {
    btnClick: function () {
      alert('再作成')
    }
  }
}
</script>

<style scoped>
.button-style {
  margin-bottom: 10px;
  margin-left: 10px;
}
</style>
