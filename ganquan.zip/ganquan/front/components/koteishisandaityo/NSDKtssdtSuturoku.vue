<template>
  <div class="page-style">
    <el-row>
      <el-col>
        <nsd-content-title v-bind:titlename="titlename" v-bind:message="message"></nsd-content-title>
      </el-col>
    </el-row>
    <el-row>
      <el-col>
        <nsd-table></nsd-table>
      </el-col>
    </el-row>
  </div>
</template>

<script>
import NsdContentTitle from '@/components/common/NSDContentTitle.vue'
import NSDTable from '@/components/koteishisandaityo/sutoroku/NSDTable.vue'

export default {
  components: {
    'nsd-content-title': NsdContentTitle,
    'nsd-table': NSDTable
  },
  data () {
    return {
      message: ''
    }
  },
  computed: {
    titlename: function () {
      return '【固定資産台帳出力】出力'
    }
  }
}
</script>

<style scoped>
.page-style {
  margin-left: 15px;
}
</style>
