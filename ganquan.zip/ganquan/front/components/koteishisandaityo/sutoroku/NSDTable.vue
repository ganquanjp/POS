<template>
  <div style= "padding-left: 10px; padding-right: 10px; width: 832px;">
    <div style="position: relative;">
     <span style="font-size: 12px;">10件</span>
      <div style="position: absolute; top: -3px; right: 0px;">
        <el-pagination
          @size-change="handleSizeChange"
          @current-change="handleCurrentChange"
          :page-size="50"
          small
          layout="prev, pager, next"
          prev-text="前へ"
          next-text="次へ"
          :total="150">
        </el-pagination>
      </div>
    </div>
    <el-table style= "padding: -50px;" :data="this.$store.state.tableData" border height=235>
      <el-table-column
        prop="rowNo"
        label="No."
        width= "50px"
        header-align=center>
      </el-table-column>
      <el-table-column
        prop="koteisisanDtfile"
        label="固定資産台帳ファイル"
        width= "300px"
        header-align=center>
      </el-table-column>
      <el-table-column header-align=center label="出力日時">
        <el-table-column
          prop="hiduke"
          label="日付"
          width= "120px"
          header-align=center>
        </el-table-column>
        <el-table-column
          prop="time"
          label="時刻"
          width= "120px"
          header-align=center>
        </el-table-column>
      </el-table-column>
      <el-table-column
        prop="kubun"
        label="区分"
        width= "120px"
        header-align=center>
      </el-table-column>
      <el-table-column
        prop="sakusesya"
        label="作成者"
        width= "120px"
        header-align=center>
      </el-table-column>
    </el-table>
  </div>
</template>

<script>
export default {
  created: function () {
    this.$store.state.tableData = ''
  },
  methods: {
    handleSizeChange (val) {
      console.log(`${val} 件/ページ`)
    },
    handleCurrentChange (val) {
      console.log(`${val}ページ目`)
    }
  }
}
</script>

<style scoped>
</style>
