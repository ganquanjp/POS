<template>
  <transition name="modal">
    <div class="modal-mask">
      <div class="modal-wrapper">
        <div class="modal-container">
          <div class="close-btn-style">
            <el-button type="text" @click="$emit('close')" size="mini"><i class="close icon"></i></el-button>
          </div>
          <div>
            <el-row>
              <el-col>
                <nsd-content-title v-bind:titlename="titlename" v-bind:message="message"></nsd-content-title>
              </el-col>
            </el-row>
            <div class="scroll-box">
              <el-row>
                <el-col>
                  <nsd-search-input></nsd-search-input>
                </el-col>
              </el-row>
              <el-row>
                <el-col>
                  <div>
                    <div style="position: relative; padding-top: 10px;">
                     <span style="font-size: 12px;">10件</span>
                      <div style="position: absolute; top: 5px; right: 0px;">
                        <el-pagination
                          @size-change="handleSizeChange"
                          @current-change="handleCurrentChange"
                          :current-page.sync="this.$store.state.currentPage"
                          :page-size="50"
                          small
                          layout="prev, pager, next"
                          prev-text="前へ"
                          next-text="次へ"
                          :total="150">
                        </el-pagination>
                      </div>
                    </div>
                    <el-table style= "padding: -50px;" :data="this.$store.state.tableData" border height=235>
                      <el-table-column 
                        prop="rowNo"
                        sortable
                        label="NO."
                        width="75px">
                      </el-table-column>
                      <el-table-column
                         prop="sechiBashoCd"
                         sortable
                         label="場所コード"
                         width="150px">
                           <template slot-scope="scope">
                             <el-button type="text" size="medium" @click="move(scope.row.rowNo)">{{scope.row.sechiBashoCd}}</el-button>
                           </template>
                      </el-table-column >
                      <el-table-column
                         prop="sechiBashoNm"
                         sortable
                         label="場所名称"
                         width="350px">
                      </el-table-column>
                    </el-table>
                  </div>
                </el-col>
              </el-row>
            </div>
          </div>
        </div>
      </div>
    </div>
  </transition>
</template>

<script scoped>
import NsdContentTitle from '@/components/common/NSDContentTitle.vue'
import NSDSearchInput from '@/components/common/modal/sechibashokensaku/NSDSearchInput.vue'

export default {
  components: {
    'nsd-content-title': NsdContentTitle,
    'nsd-search-input': NSDSearchInput
  },
  data () {
    return {
      titlename: '【設置場所】検索',
      message: ''
    }
  },
  methods: {
    move: function (rowNo) {
      let para = Object.assign({}, this.$store.state.tableData[rowNo - 1])
      this.$emit('backData', para)
      this.$emit('close')
    },
    headerClassName ({row, rowIndex}) {
      return 'class-header'
    },
    handleSizeChange (val) {
      console.log(`每页 ${val} 条`)
    },
    handleCurrentChange (val) {
      console.log(`当前页: ${val}`)
    },
    btnClick: function (item) {
      alert(item + 'ボタンをクリックします。')
    }
  }
}
</script>

<style scoped>
.modal-mask {
  position: fixed;
  z-index: 1;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background-color: rgba(0, 0, 0, .5);
  display: table;
  transition: opacity .3s ease;
}
.modal-wrapper {
  display: table-cell;
  vertical-align: middle;
}
.modal-container {
  position: relative;
  width: 600px;
  height: 500px;
  margin: 0 auto;
  margin-top: 10px;
  padding: 10px 15px;
  background-color: #fff;
  border-radius: 2px;
  box-shadow: 0 2px 8px rgba(0, 0, 0, .33);
  transition: all .3s ease;
}
.modal-leave-active .modal-container {
  -webkit-transform: scale(1.1);
  transform: scale(1.1);
}
.close-btn-style {
  position: absolute;
  right: 0px;
  top: 0px;
  padding: 0px;
}
.scroll-box {
  height: 510px;
  overflow-y: auto;
  margin-bottom: 20px;
}
</style>
