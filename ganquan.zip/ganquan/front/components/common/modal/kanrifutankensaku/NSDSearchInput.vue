<template>
  <div>
    <div class="page-style">
      <el-row class="row-class">
        <el-col style= "width: 170px; background-color: #77cad8;">　管理箇所（コード／名称）</el-col>
        <el-col style= "width: 160px;">
          <el-input v-model="formItem.kanrikasyocd" size="mini" placeholder=""></el-input>
        </el-col>
        <el-col :span="1">　／</el-col>
        <el-col style= "width: 164px; margin-left:-1px;">
          <el-input v-model="formItem.kanrikasyo" size="mini" placeholder=""></el-input>
        </el-col>
      </el-row>
      <el-row class="row-class">
        <el-col style= "width: 170px; background-color: #77cad8;">　負担箇所（コード／名称）</el-col>
        <el-col style= "width: 160px;">
          <el-input v-model="formItem.futankasyocd" size="mini" placeholder=""></el-input>
        </el-col>
        <el-col :span="1">　／</el-col>
        <el-col style= "width: 164px; margin-left:-1px;">
          <el-input v-model="formItem.futankasyo" size="mini" placeholder=""></el-input>
        </el-col>
      </el-row>
      <el-row class="row-class">
        <el-col style= "width: 170px; background-color: #77cad8;">　使用開始年月日</el-col>
        <el-col style= "width: 160px;">
          <el-input v-model="formItem.kaisiymd" size="mini" placeholder=""></el-input>
        </el-col>
      </el-row>
    </div>
    <el-row >
      <el-col>
        <nsd-button-bar v-bind:buttons="buttonName" v-bind:formItem="formItem"></nsd-button-bar>
      </el-col>
    </el-row>
  </div>
</template>

<script>
import NSDButtonBar from '@/components/common/NSDButtonBar.vue'

export default {
  components: {
    'nsd-button-bar': NSDButtonBar
  },
  data () {
    return {
      buttonName: [
        {name: this.$CONST_.buttonName.SEARCH, primary: true, show: true, action: 'post', url: '/sansho-kanrifutanks'},
        {name: this.$CONST_.buttonName.RESET, primary: true, show: true, action: 'clear', url: ''}
      ],
      formItem: {
        kanrikasyocd: '',
        kanrikasyo: '',
        futankasyocd: '',
        futankasyo: '',
        kaisiymd: ''
      }
    }
  }
}
</script>

<style scoped>
.page-style {
  font-size: 12px;
  width: 520px;
  height: 100%;
  margin-left:10px;
  line-height:30px;
  border: 1px solid;
  padding-top: 1px;
  padding-right: 1px;
}
.row-class {
  height: 30px;
  margin-bottom: 1px;
  margin-left: 1px;
  margin-right: 1px;
}
</style>
