<template>
  <transition name="modal">
    <div class="modal-mask">
      <div class="modal-wrapper">
        <div class="modal-container">
          <div class="close-btn-style">
            <el-button type="text" @click="$emit('close')" size="mini"><i class="close icon"></i></el-button>
          </div>
          <div>
            <el-row>
              <el-col>
                <nsd-content-title v-bind:titlename="titlename" v-bind:message="message"></nsd-content-title>
              </el-col>
            </el-row>
            <div class="scroll-box">
              <el-row>
                <el-col>
                  <nsd-search-input></nsd-search-input>
                </el-col>
              </el-row>
              <el-row>
                <el-col>
                  <div>
                    <div style="position: relative; padding-top: 10px;">
                     <span style="font-size: 12px;">10件</span>
                      <div style="position: absolute; top: 5px; right: 0px;">
                        <el-pagination
                          @size-change="handleSizeChange"
                          @current-change="handleCurrentChange"
                          :page-size="50"
                          small
                          layout="prev, pager, next"
                          prev-text="前へ"
                          next-text="次へ"
                          :total="150">
                        </el-pagination>
                      </div>
                    </div>
                    <el-table style= "padding: -50px;" :data="this.$store.state.tableData" border height=235>
                      <el-table-column 
                        prop="rowNo"
                        sortable
                        label="NO."
                        width="75px">
                      </el-table-column>
                      <el-table-column
                         prop="koteiNo"
                         sortable
                         label="固定資産番号"
                         width="100px">
                           <template slot-scope="scope">
                             <el-button type="text" size="medium" @click="move(scope.row.rowNo)">{{scope.row.koteiNo}}</el-button>
                           </template>
                      </el-table-column >
                      <el-table-column
                         prop="koteioyaNo"
                         sortable
                         label="親固定資産番号"
                         width="120px">
                      </el-table-column >
                      <el-table-column
                         prop="edaBan"
                         sortable
                         label="枝番"
                         width="60px">
                      </el-table-column>
                      <el-table-column
                         prop="koteiKnj"
                         sortable
                         label="固定資産名称"
                         width="100px">
                      </el-table-column>
                      <el-table-column
                         prop="getYmd"
                         sortable
                         label="取得年月日"
                         width="100px">
                      </el-table-column>
                      <el-table-column
                         prop="kanriKnj"
                         sortable
                         label="管理箇所名称"
                         width="100px">
                      </el-table-column>
                      <el-table-column
                         prop="syurui"
                         sortable
                         label="種類"
                         width="60px">
                      </el-table-column>
                      <el-table-column
                         prop="kouzo"
                         sortable
                         label="構造"
                         width="60px">
                      </el-table-column>
                      <el-table-column
                         prop="sisanTani"
                         sortable
                         label="資産単位"
                         width="80px">
                      </el-table-column>
                      <el-table-column
                         prop="kamoku1"
                         sortable
                         label="科目1"
                         width="80px">
                      </el-table-column>
                      <el-table-column
                         prop="kamoku2"
                         sortable
                         label="科目2"
                         width="80px">
                      </el-table-column>
                      <el-table-column
                         prop="kamoku3"
                         sortable
                         label="科目3"
                         width="80px">
                      </el-table-column>
                      <el-table-column
                         prop="bashoKnj"
                         sortable
                         label="設置場所名称"
                         width="120px">
                      </el-table-column>
                      <el-table-column
                         prop="tekiyo1"
                         sortable
                         label="摘要1"
                         width="80px">
                      </el-table-column>
                      <el-table-column
                         prop="tekiyo2"
                         sortable
                         label="摘要2"
                         width="80px">
                      </el-table-column>
                      <el-table-column
                         prop="tekiyo3"
                         sortable
                         label="摘要3"
                         width="80px">
                      </el-table-column>
                      <el-table-column
                         prop="tekiyo4"
                         sortable
                         label="摘要4"
                         width="80px">
                      </el-table-column>
                      <el-table-column
                         prop="tekiyo5"
                         sortable
                         label="摘要5"
                         width="80px">
                      </el-table-column>
                      <el-table-column
                         prop="torihikiKnj"
                         sortable
                         label="取引先名称"
                         width="120px">
                      </el-table-column>
                      <el-table-column
                         prop="butuhin"
                         sortable
                         label="物品"
                         width="60px">
                      </el-table-column>
                      <el-table-column
                         prop="kohi"
                         sortable
                         label="工費"
                         width="60px">
                      </el-table-column>
                      <el-table-column
                         prop="sokeh"
                         sortable
                         label="総係費"
                         width="80px">
                      </el-table-column>
                      <el-table-column
                         prop="getkgkYen"
                         sortable
                         label="取得価額"
                         width="90px">
                      </el-table-column>
                      <el-table-column
                         prop="meiSu"
                         sortable
                         label="物品数量"
                         width="90px">
                      </el-table-column>
                      <el-table-column
                         prop="taniKnj"
                         sortable
                         label="単位名称"
                         width="90px">
                      </el-table-column>
                      <el-table-column
                         prop="seisanShoNo"
                         sortable
                         label="精算書番号"
                         width="120px">
                      </el-table-column>
                      <el-table-column
                         prop="soshikiRenNm"
                         sortable
                         label="精算箇所"
                         width="100px">
                      </el-table-column>
                      <el-table-column
                         prop="useYmd"
                         sortable
                         label="使用開始年月日"
                         width="120px">
                      </el-table-column>
                      <el-table-column
                         prop="seisanEntryUserId"
                         sortable
                         label="担当者コード"
                         width="100px">
                      </el-table-column>
                      <el-table-column
                         prop="torokusyaNm"
                         sortable
                         label="登録者氏名"
                         width="100px">
                      </el-table-column>
                      <el-table-column
                         prop="kenmeiCd"
                         sortable
                         label="工事件名コード"
                         width="120px">
                      </el-table-column>
                      <el-table-column
                         prop="kmouwkKnj"
                         sortable
                         label="工事件名"
                         width="100px">
                      </el-table-column>
                      <el-table-column
                         prop="kojiTantokasyo"
                         sortable
                         label="工事担当箇所"
                         width="100px">
                      </el-table-column>
                      <el-table-column
                         prop="kojiTantosya"
                         sortable
                         label="工事担当者"
                         width="100px">
                      </el-table-column>
                    </el-table>
                  </div>
                </el-col>
              </el-row>
            </div>
          </div>
        </div>
      </div>
    </div>
  </transition>
</template>

<script scoped>
import NsdContentTitle from '@/components/common/NSDContentTitle.vue'
import NSDSearchInput from '@/components/common/modal/koteisisankensaku/NSDSearchInput.vue'

export default {
  components: {
    'nsd-content-title': NsdContentTitle,
    'nsd-search-input': NSDSearchInput
  },
  methods: {
    move: function (rowNo) {
      let para = Object.assign({}, this.$store.state.tableData[rowNo - 1])
      this.$emit('backData', para)
      this.$emit('close')
    },
    headerClassName ({row, rowIndex}) {
      return 'class-header'
    },
    handleSizeChange (val) {
      console.log(`每页 ${val} 条`)
    },
    handleCurrentChange (val) {
      console.log(`当前页: ${val}`)
    }
  },
  data () {
    return {
      titlename: '【固定資産】検索',
      message: ''
    }
  }
}
</script>

<style scoped>
.modal-mask {
  position: fixed;
  z-index: 1;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background-color: rgba(0, 0, 0, .5);
  display: table;
  transition: opacity .3s ease;
}
.modal-wrapper {
  display: table-cell;
  vertical-align: middle;
}
.modal-container {
  position: relative;
  width: 1170px;
  height: 595px;
  margin: 0 auto;
  margin-top: 10px;
  padding: 10px 15px;
  background-color: #fff;
  border-radius: 2px;
  box-shadow: 0 2px 8px rgba(0, 0, 0, .33);
  transition: all .3s ease;
}
.modal-leave-active .modal-container {
  -webkit-transform: scale(1.1);
  transform: scale(1.1);
}
.close-btn-style {
  position: absolute;
  right: 0px;
  top: 0px;
  padding: 0px;
}
.scroll-box {
  height: 510px;
  overflow-y: auto;
  margin-bottom: 20px;
}
</style>
