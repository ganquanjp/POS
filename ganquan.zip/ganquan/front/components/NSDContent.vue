<template>
  <div class="page-style">
    <router-view></router-view>
  </div>
</template>

<script>
  export default {}
</script>

<style scoped>
.page-style {
  height: 100%;
  width: 100%;
}
</style>
