<template>
  <div>
    <div class="scroll-box">
      <div class="page-style">
        <el-row class="row-class">
          <el-col class="lab-class">　精算箇所<span class="span-class">（必須）</span></el-col>
          <el-col style= "width: 364px;">
            <el-autocomplete
              style= "width: 364px;"
              v-model="formItem.soshikiRenNm" 
              :fetch-suggestions="querySearchAsyncSoshikiNM"
              @select="handleSelectSoshikiNM"
              id="search_text" 
              size="mini" 
              >
            </el-autocomplete>
          </el-col>
        </el-row>
        <el-row class="row-class">
          <el-col class="lab-class">　除却予定年月<span class="span-class">（必須）</span></el-col>
          <el-col style= "width: 120px;">
            <el-date-picker
              v-model="formItem.jokyakuYoteYmd"
              type="month"
              style="width: 140px;"
              value-format="yyyy/MM/dd"
              size="mini">
            </el-date-picker>
          </el-col>
        </el-row>
        <el-row class="row-class">
          <el-col class="lab-class">　登録者氏名<span class="span-class">（必須）</span></el-col>
          <el-col style= "width: 250px;">
            <el-autocomplete 
            v-model="formItem.seiMei" 
            :fetch-suggestions="querySearchAsyncUserNM"
            @select="handleSelectUserNM"
            id="search_text" 
            size="mini" 
            >
          </el-autocomplete>
          </el-col>
        </el-row>
        <el-row class="row-class">
          <el-col class="lab-class">　摘要</el-col>
          <el-col style= "width: 364px;">
            <el-input v-model="formItem.tekiyo" size="mini" placeholder=""></el-input>
          </el-col>
        </el-row>
        <el-row class="row-class">
          <el-col class="lab-class">　工事件名<span class="span-class">（必須）</span></el-col>
          <el-col style= "width: 170px;">
            <el-autocomplete 
            v-model="formItem.kenmeiNm" 
            :fetch-suggestions="querySearchAsyncKojiNM"
            @select="handleSelectKojiNM"
            id="search_text" 
            size="mini" 
            >
          </el-autocomplete>
          </el-col>
        </el-row>
      </div>
      <div style="padding-top: 10px; padding-left: 10px; width: 1010px;">
        <el-table
          :data="this.$store.state.tableData"
          max-height="275"
          border>
          <el-table-column 
            prop="rowNo"
            label="NO."
            header-align=center
            width="35px">
          </el-table-column>
          <el-table-column
            width="185px"
            header-align=center
            :render-header="renderHeader1">
            <template slot-scope="scope">
              <el-input v-model="scope.row.koteiNo" size="mini"><el-button slot="append" style="position: absolute; top: 20px; left: 10px; padding-top: 5px;" size="mini" @click="popupClick(scope.row.rowNo)">参照</el-button></el-input>
            </template>
          </el-table-column>
          <el-table-column
            width="225px"
            prop="koteiKnj"
            header-align=center
            :render-header="renderHeader2">
          </el-table-column>
          <el-table-column
            width="120px"
            header-align=center
            :render-header="renderHeader3"
            prop="getYmd">
          </el-table-column>
          <el-table-column
            width="130px"
            header-align=center
            :render-header="renderHeader4"
            prop="useYmd">
          </el-table-column>
          <el-table-column
            width="140px"
            header-align=center
            :render-header="renderHeader5"
            prop="koteioyaNo">
          </el-table-column>
          <el-table-column
            header-align=center
            prop="edaBan"
            label="枝番"
            min-width="50px">
          </el-table-column>
        </el-table>
      </div>
      <el-row>
        <el-col>
          <nsd-button-bar v-bind:buttons="buttonName" v-bind:formItem="formItem"></nsd-button-bar>
        </el-col>
      </el-row>
    </div>
    <koteisisanModal v-if="showModal" @close="showModal = false" @backData="backData"></koteisisanModal>
  </div>
</template>

<script>
import NSDButtonBar from '@/components/common/NSDButtonBar.vue'
import modal from '@/components/common/modal/NSDKoteisisankensaku'

export default {
  components: {
    'nsd-button-bar': NSDButtonBar,
    'koteisisanModal': modal
  },
  created: function () {
    this.$store.state.tableData = this.formItem.koteiSisanLst
    for (var i = 0; i < 20; i++) {
      this.$store.state.tableData[i] = new Array(0)
      this.$store.state.tableData[i].rowNo = i + 1
    }
  },
  mounted () {
    this.soshikiRenNm = this.loadSoshikiNM()
    this.kojiName = this.loadKojiNM()
    this.seiMei = this.loadUserNM()
  },
  data () {
    return {
      rowIndex: '',
      showModal: false,
      buttonName: [
        {name: this.$CONST_.buttonName.INSERT, primary: true, show: true, action: 'post', url: '/seisanshoJokyaku-insertInfo'},
        {name: this.$CONST_.buttonName.RESET, primary: true, show: true, action: 'clear', url: ''}
      ],
      formItem: {
        seiMei: '',
        userId: '',
        nyushaYmd: '',
        soshikiRenNm: '',
        seisanSoshikiCd: '',
        tekiyoStartYmd: '',
        jokyakuYoteYmd: '',
        kenmeiNm: '',
        kenmeiCd: '',
        tekiyo: '',
        koteiSisanLst: [{
          rowNo: '',
          koteiNo: '',
          koteiKnj: '',
          getYmd: '',
          useYmd: '',
          koteioyaNo: '',
          edaBan: ''
        }]
      }
    }
  },
  methods: {
    backData (val) {
      this.$store.state.tableData = this.formItem.koteiSisanLst
      this.$store.state.tableData[this.rowIndex] = val
      for (var i = 0; i < 20; i++) {
        this.$store.state.tableData[i].rowNo = i + 1
      }
    },
    popupClick (row) {
      this.rowIndex = row - 1
      this.showModal = true
      this.formItem.koteiSisanLst = this.$store.state.tableData
    },
    renderHeader1 (createElement, { column }) {
      return createElement(
        'label',
        [
          '固定資産番号',
          createElement('span', {style: 'color: red;'}, '　(必須)')
        ]
      )
    },
    renderHeader2 (createElement, { column }) {
      return createElement(
        'label',
        [
          '固定資産名称',
          createElement('span', {style: 'color: red;'}, '　(必須)')
        ]
      )
    },
    renderHeader3 (createElement, { column }) {
      return createElement(
        'label',
        [
          '取得年月日',
          createElement('span', {style: 'color: red;'}, '　(必須)')
        ]
      )
    },
    renderHeader4 (createElement, { column }) {
      return createElement(
        'label',
        [
          '使用開始年月日',
          createElement('span', {style: 'color: red;'}, '　(必須)')
        ]
      )
    },
    renderHeader5 (createElement, { column }) {
      return createElement(
        'label',
        [
          '親固定資産番号',
          createElement('span', {style: 'color: red;'}, '　(必須)')
        ]
      )
    },
    handleSelectKojiNM (item) {
      this.formItem.kenmeiNm = item.value
      this.formItem.kenmeiCd = item.kenmeiCd
      this.formItem.tekiyoStartYmd = item.tekiyoStartYmd
      this.formItem.tekiyoEndYmd = item.tekiyoEndYmd
    },
    loadKojiNM () {
      var items = ['kenmeiNm', 'kenmeiCd', 'tekiyoStartYmd', 'tekiyoEndYmd']
      return this.funcGetDropDownValue('/autocomplete-selectKenmeiMaster', items)
    },
    querySearchAsyncKojiNM (queryString, cb) {
      var kojiName = this.kojiName
      var results = queryString ? kojiName.filter(this.createStateFilter(queryString)) : kojiName
      clearTimeout(this.timeout)
      this.timeout = setTimeout(() => {
        cb(results)
      }, 200 * Math.random())
    },
    loadUserNM () {
      var items = ['seiMei', 'userId', 'sei', 'mei', 'nyushaYmd']
      return this.funcGetDropDownValue('/autocomplete-selectUserMaster', items)
    },
    handleSelectUserNM (item) {
      this.formItem.userId = item.userId
      this.formItem.sei = item.sei
      this.formItem.mei = item.mei
      this.formItem.nyushaYmd = item.nyushaYmd
    },
    querySearchAsyncUserNM (queryString, cb) {
      var seiMei = this.seiMei
      var results = queryString ? seiMei.filter(this.createStateFilter(queryString)) : seiMei
      clearTimeout(this.timeout)
      this.timeout = setTimeout(() => {
        cb(results)
      }, 200 * Math.random())
    },
    loadSoshikiNM () {
      var items = ['soshikiNm', 'soshikiCd', 'tekiyoStartYmd']
      return this.funcGetDropDownValue('/autocomplete-selectSoshikiMaster', items)
    },
    handleSelectSoshikiNM (item) {
      this.formItem.soshikiRenNm = item.value
      this.formItem.seisanSoshikiCd = item.soshikiCd
      this.formItem.tekiyoStartYmd = item.tekiyoStartYmd
    },
    querySearchAsyncSoshikiNM (queryString, cb) {
      var soshikiRenNm = this.soshikiRenNm
      var results = queryString ? soshikiRenNm.filter(this.createStateFilter(queryString)) : soshikiRenNm
      clearTimeout(this.timeout)
      this.timeout = setTimeout(() => {
        cb(results)
      }, 200 * Math.random())
    },
    createStateFilter (queryString) {
      return (state) => {
        return (state.value.toLowerCase().indexOf(queryString.toLowerCase()) >= 0)
      }
    }
  }
}
</script>

<style scoped>
.page-style {
  font-size: 12px;
  width: 537px;
  height: 100%;
  margin-left:10px;
  line-height:30px;
  border: 1px solid;
  padding-top: 1px;
}
.row-class {
  height: 30px;
  margin-bottom: 1px;
  margin-left: 1px;
  margin-right: 1px;
}
.lab-class {
  width: 170px;
  background-color: #77cad8;
  line-height: 30px;
  margin-right: 1px;
}
.span-class {
 color: red;
 float: right;
}
</style>
