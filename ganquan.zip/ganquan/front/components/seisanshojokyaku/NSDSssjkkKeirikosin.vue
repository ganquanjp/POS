<template>
  <div>
    <el-row>
      <el-col>
        <nsd-content-title v-bind:titlename="titlename" v-bind:message="this.$store.state.message"></nsd-content-title>
      </el-col>
    </el-row>
    <el-row>
      <el-col>
        <nsd-search-input></nsd-search-input>
      </el-col>
    </el-row>
    <el-row>
      <el-col>
        <nsd-table></nsd-table>
      </el-col>
    </el-row>
  </div>
</template>

<script>
import NsdContentTitle from '@/components/common/NSDContentTitle.vue'
import NSDTable from '@/components/seisanshojokyaku/keirikosin/NSDTable.vue'

export default {
  components: {
    'nsd-content-title': NsdContentTitle,
    'nsd-table': NSDTable

  },
  created: function () {
    this.$store.state.message = this.message
  },
  data () {
    return {
      titlename: '【除却経理審査/連係】更新',
      message: ''
    }
  }
}
</script>

<style scoped>
</style>