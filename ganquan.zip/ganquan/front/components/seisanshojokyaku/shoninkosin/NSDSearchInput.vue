<template>
  <div class="page-style">
    <el-row class="row-class">
      <el-col style= "width: 474px; background-color: #2053cc; color: white;">　除却資産</el-col>
    </el-row>
    <el-row class="row-class">
      <el-col class="lab-class">　工事件名コード</el-col>
      <el-col style= "width: 303px;">
        <el-input v-model="input2" size="mini"></el-input>
      </el-col>
    </el-row>
    <el-row class="row-class">
      <el-col class="lab-class">　工事件名名称</el-col>
      <el-col style= "width: 303px;">
        <el-input v-model="input3" size="mini"></el-input>
      </el-col>
    </el-row>
    <el-row class="row-class">
      <el-col class="lab-class">　精算書番号</el-col>
      <el-col style= "width: 303px;">
        <el-input v-model="input4" size="mini"></el-input>
      </el-col>
    </el-row>
    <el-row class="row-class">
      <el-col class="lab-class">　処理NO</el-col>
      <el-col style= "width: 303px;">
        <input v-model="input5" size="mini" class="nsd-input-class">
      </el-col>
    </el-row>
    <el-row class="row-class">
      <el-col class="lab-class">　除却年月日</el-col>
      <el-col style= "width: 303px;">
        <el-input v-model="input1" size="mini"></el-input>
      </el-col>
    </el-row>
    <el-row class="row-class">
      <el-col class="lab-class">　除却取得価額合計</el-col>
        <el-col class="input-group" style= "width: 303px">
          <input v-model="input6" size="mini" class="nsd-input-class label-input-class">
            <label class="label-group">円</label>
          </input>
        </el-col>
    </el-row>
    <el-row class="row-class">
      <el-col class="lab-class">　承認状態<span class="span-class">（必須）</span></el-col>
      <el-col style= "width: 303px;">
          <el-select v-model="input7" size="mini" style="width: 303px;">
            <el-option
              v-for="item in options7"
              :key="item.value"
              :label="item.label"
              :value="item.value">
            </el-option>
          </el-select>
      </el-col>
    </el-row>
  </div>
</template>

<script>
export default {
  data () {
    return {
      options7: [{value: '1', label: '未承認'}, {value: '2', label: '承認済'}, {value: '3', label: '経理承認済'}, {value: '4', label: '経理否認'}],
      input1: '',
      input2: '',
      input3: '',
      input4: '',
      input5: '',
      input6: '',
      input7: '1'
    }
  }
}
</script>

<style scoped>
.page-style {
  font-size: 12px;
  width: 476px;
  height: 100%;
  margin:10px;
  line-height:30px;
  border: 1px solid;
  padding-top: 1px;
}
.row-class {
  height: 30px;
  margin-bottom: 1px;
  margin-left: 1px;
  margin-right: 1px;
}
.lab-class {
  width: 170px;
  background-color: #77cad8;
  line-height: 30px;
  margin-right: 1px;
}
.label-group {
  background-color: #f5f7fa;
  color: #909399;
  display: table-cell;
  position: relative;
  border: 1px solid #dcdfe6;
  border-radius: 4px;
  padding: 0 20px;
  width: 1px;
  white-space: nowrap;
  position: relative;
  border-left: 0;
  border-top-left-radius: 0;
  border-bottom-left-radius: 0;
}
.input-group {
  line-height: normal;
  display: inline-table;
  width: 100%;
  border-collapse: separate;
}
.label-input-class {
  border-top-right-radius: 0;
  border-bottom-right-radius: 0;
}
.span-class {
 color: red;
 float: right;
}
</style>
