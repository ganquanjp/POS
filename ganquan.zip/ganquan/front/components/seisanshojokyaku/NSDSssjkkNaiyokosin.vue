<template>
  <div>
    <el-row>
      <el-col>
        <nsd-content-title v-bind:titlename="titlename" v-bind:message="message"></nsd-content-title>
      </el-col>
    </el-row>
    <el-row>
      <el-col>
        <nsd-table></nsd-table>
      </el-col>
    </el-row>
    <el-row>
      <el-col>
        <nsd-button-bar v-bind:buttons="buttonName" v-bind:clicks="btnClick"></nsd-button-bar>
      </el-col>
    </el-row>
  </div>
</template>

<script>
import NsdContentTitle from '@/components/common/NSDContentTitle.vue'
import NSDButtonBar from '@/components/common/NSDButtonBar.vue'
import NSDTable from '@/components/seisanshojokyaku/naiyokosin/NSDTable.vue'

export default {
  components: {
    'nsd-content-title': NsdContentTitle,
    'nsd-button-bar': NSDButtonBar,
    'nsd-table': NSDTable
  },
  data () {
    return {
      message: '　',
      buttonName: [
        {name: this.$CONST_.buttonName.UPDATE, primary: true, show: true, onClick: '更新'},
        {name: this.$CONST_.buttonName.RESET, primary: true, show: true, onClick: 'クリア'},
        {name: this.$CONST_.buttonName.BACK, primary: true, show: true, onClick: '戻る'}
      ]
    }
  },
  computed: {
    titlename: function () {
      return '【除却内容入力】更新'
    }
  },
  methods: {
    btnClick: function (item) {
      alert(item + 'ボタンをクリックします。')
    }
  }
}
</script>

<style scoped>
</style>
