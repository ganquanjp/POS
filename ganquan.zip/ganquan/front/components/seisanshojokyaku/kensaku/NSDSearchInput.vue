<template>
  <div>
    <div class="page-style">
    <el-row class="row-class">
      <el-col class="lab-class">　精算書番号</el-col>
      <el-col style= "width: 300px;">
        <el-input v-model="formItem.jokyakuSeisanShoNo" size="mini" placeholder=""></el-input>
      </el-col>
    </el-row>
    <el-row class="row-class">
      <el-col class="lab-class">　精算箇所</el-col>
      <el-col style= "width: 300px;">
        <el-input v-model="formItem.soshikiRenNm" size="mini"></el-input>
      </el-col>
    </el-row>
    <el-row class="row-class">
      <el-col class="lab-class">　除却予定年月日</el-col>
      <el-col style= "width: 140px;">
        <el-date-picker
          v-model="formItem.jokyakuYoteYmdFrom"
          size="mini"
          style="width: 140px;"
          type="date"
          :editable="true"
          value-format="yyyy-MM-dd">
        </el-date-picker>
      </el-col>
      <el-col :span="1"style="line-height: 25px; margin-left: 5px; margin-right: -5px;">－</el-col>
      <el-col style= "width: 140px;">
        <el-date-picker
          v-model="formItem.jokyakuYoteYmdTo"
          size="mini"
          style="width: 140px;"
          type="date"
          :editable="true"
          value-format="yyyy-MM-dd">
        </el-date-picker>
      </el-col>
    </el-row>
    <el-row class="row-class">
      <el-col class="lab-class">　工事件名</el-col>
      <el-col style= "width: 300px;">
        <el-input v-model="formItem.kenmeiNm" size="mini" placeholder=""></el-input>
      </el-col>
    </el-row>
    </div>
    <el-row>
      <el-col>
        <nsd-button-bar v-bind:buttons="buttonName" v-bind:formItem="formItem"></nsd-button-bar>
      </el-col>
    </el-row>
  </div>
</template>

<script>
import NSDButtonBar from '@/components/common/NSDButtonBar.vue'

export default {
  components: {
    'nsd-button-bar': NSDButtonBar
  },
  data () {
    return {
      buttonName: [
        {name: this.$CONST_.buttonName.SEARCH, primary: true, show: true, action: 'post', url: '/seisanshoJokyaku-selectByWhere'},
        {name: this.$CONST_.buttonName.RESET, primary: true, show: true, action: 'reset', url: ''}
      ],
      formItem: {
        jokyakuSeisanShoNo: '',
        soshikiRenNm: '',
        jokyakuYoteYmdFrom: '',
        jokyakuYoteYmdTo: '',
        kenmeiNm: ''
      }
    }
  }
}
</script>

<style scoped>
.page-style {
  font-size: 12px;
  width: 474px;
  height: 100%;
  margin-left:10px;
  line-height:30px;
  border: 1px solid;
  padding-top: 1px;
}
.row-class {
  height: 30px;
  margin-bottom: 1px;
  margin-left: 1px;
  margin-right: 1px;
}
.lab-class {
  width: 170px;
  background-color: #77cad8;
  line-height: 30px;
  margin-right: 1px;
}
</style>
