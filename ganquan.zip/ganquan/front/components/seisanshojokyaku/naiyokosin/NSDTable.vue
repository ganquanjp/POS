<template>
  <div style= "padding-left: 10px; padding-right: 10px; width: 1039px;" >
    <div class="page-style">
      <el-row class="row-class">
        <el-col class="lab-class">　精算書番号</el-col>
        <el-col style= "width: 640px;">
          <el-input v-model="input1" size="mini" :disabled="true"></el-input>
        </el-col>
      </el-row>
      <el-row class="row-class">
        <el-col class="lab-class">　除却予定年月日</el-col>
        <el-col style= "width: 640px;">
          <el-input v-model="input2" size="mini" :disabled="true"></el-input>
        </el-col>
      </el-row>
      <el-row class="row-class">
        <el-col class="lab-class">　工事件名コード</el-col>
        <el-col style= "width: 640px;">
          <el-input v-model="input3" size="mini" :disabled="true"></el-input>
        </el-col>
      </el-row>
      <el-row class="row-class">
        <el-col class="lab-class">　工事件名名称</el-col>
        <el-col style= "width: 640px;">
          <el-input v-model="input4" size="mini" :disabled="true""></el-input>
        </el-col>
      </el-row>
      <el-row class="row-class">
        <el-col class="lab-class">　精算箇所</el-col>
        <el-col style= "width: 640px;">
          <el-input v-model="input5" size="mini" :disabled="true""></el-input>
        </el-col>
      </el-row>
      <el-row class="row-class">
        <el-col class="lab-class">　摘要</el-col>
        <el-col style= "width: 640px;">
          <el-input v-model="input7" size="mini" :disabled="true"></el-input>
        </el-col>
      </el-row>
    </div>
    <div ref="divScroll" class="scroll-box">
      <div style="position: relative;">
        <span style="font-size: 12px;">10件</span>
      </div>
      <div style="width: 750px;">
        <el-table
          :data="tableData"
          border>
          <el-table-column 
            prop="kouban"
            label="NO."
            width="48px">
          </el-table-column>
          <el-table-column
            label="固定資産番号"
            width="110px">
            <template slot-scope="scope">
              <el-button type="text" @click="">{{scope.row.koteisisanno}}</el-button>
            </template>
          </el-table-column>
          <el-table-column
            prop="koteisisanname"
            label="固定資産名称"
            width="200px">
          </el-table-column>
          <el-table-column
            prop="torihikisakiname"
            label="元_取得価額"
            header-align=left
            align=right
            width="150px">
          </el-table-column >
          <el-table-column
            prop="syutokuymd"
            label="除_取得価額"
            header-align=left
            align=right
            width="140px">
          </el-table-column>
          <el-table-column
            prop="syutokukakaku"
            label="除却種別コード"
            min-width="100px">
          </el-table-column>
        </el-table>
        <div style="margin-top: 10px; border: 1px solid; padding-top: 1px; width: 532px;">
          <el-row class="row-class">
            <el-col class="lab-class">　固定資産番号</el-col>
            <el-col style= "width: 328px">
              <el-input v-model="input8" size="mini" :disabled="true" />
            </el-col>
          </el-row>
          <el-row class="row-class">
            <el-col class="lab-class">　固定資産名称</el-col>
            <el-col style= "width: 328px">
              <el-input v-model="input9" size="mini" :disabled="true" />
            </el-col>
          </el-row>
          <el-row class="row-class">
            <el-col class="lab-class">　取得年月日</el-col>
            <el-col style= "width: 328px">
              <el-input v-model="input10" size="mini" :disabled="true" />
            </el-col>
          </el-row>
          <el-row class="row-class">
            <el-col class="lab-class">　元_数量</el-col>
            <el-col style= "width: 100px">
              <el-input v-model="input11" size="mini" :disabled="true" />
            </el-col>            
            <el-col style="width: 50px; line-height: 30px; background-color: #77cad8; margin-right: 1px; margin-left: 1px;">　単位</el-col>
            <el-col style= "width: 176px">
              <el-input v-model="input12" size="mini" :disabled="true" />
            </el-col>
          </el-row>
          <el-row class="row-class">
            <el-col class="lab-class">　元_取得価額</el-col>
            <el-col class="input-group" style= "width: 200px">
              <input v-model="input13" size="mini" class="nsd-input-class label-input-class" disabled="disabled">
                <label class="label-group">円</label>
              </input>
            </el-col>
          </el-row>
          <el-row class="row-class">
            <el-col class="lab-class">　除却区分<span class="span-class">（必須）</span></el-col>
            <el-col style= "width: 160px;">
              <el-select v-model="input14" size="mini">
                <el-option
                   v-for="item in item1"
                   :key="item.value"
                   :label="item.label"
                   :value="item.value">
                </el-option>
              </el-select>
            </el-col>
          </el-row>
          <el-row class="row-class">
            <el-col class="lab-class">　除却種別コード<span class="span-class">（必須）</span></el-col>
            <el-col style= "width: 160px">
              <el-select v-model="input15" size="mini">
                <el-option
                   v-for="item in item2"
                   :key="item.value"
                   :label="item.label"
                   :value="item.value">
                </el-option>
              </el-select>
            </el-col>
          </el-row>
          <el-row class="row-class">
            <el-col class="lab-class">　除_数量<span class="span-class">（必須）</span></el-col>
            <el-col style= "width: 100px">
              <el-input v-model="input16" size="mini"/>
            </el-col>            
            <el-col style="width: 50px; line-height: 30px; background-color: #77cad8; margin-right: 1px; margin-left: 1px;">　単位</el-col>
            <el-col style= "width: 48px">
              <el-input v-model="input17" size="mini" :disabled="true" />
            </el-col>
            <el-col style= "width: 48px">
              <el-button type="primary" size="mini" style="margin-left: 1px;">取得価格数量按分</el-button>
            </el-col>
          </el-row>
          <el-row class="row-class">
            <el-col class="lab-class">　除_取得価額<span class="span-class">（必須）</span></el-col>
            <el-col class="input-group" style= "width: 208px">
              <input v-model="input18" size="mini" class="nsd-input-class label-input-class">
                <label class="label-group">円</label>
              </input>
            </el-col>
          </el-row>
        </div>
      </div>
    </div>
  </div>
</template>
<script scoped>
  export default {
    methods: {
      textBtn: function () {
      },
      renderHeader (createElement, { column }) {
        return createElement(
          'el-lab',
          [
            '承認状態',
            createElement('span', {style: 'color: red;'}, '　　(必須)')
          ]
        )
      }
    },
    data () {
      return {
        currentPage: 1,
        item1: [{value: '1', label: '全部除却'}],
        item2: [{value: '1', label: 'その他'}],
        input1: '100000000000003',
        input2: '201204',
        input3: '1234567890ABCDE',
        input4: 'ＡＢＣＤＥＦＧＨＩＪＫＬＭＮＯＰＱＲＳＴＵＶＷＸＹＺＡＢＣＤＥＦＧＨＩＪＫＬＭＮＯＰＱＲＳＴＵＶＷＸ',
        input5: 'ＡＢＣＤＥＦＧＨＩＪＫＬＭＮＯＰＱＲＳＴＵＶＷＸＹＺＡＢＣＤＥＦＧＨＩＪＫＬＭＮＯＰＱＲＳＴＵＶＷＸ',
        input6: '鈴木　A太郎',
        input7: '摘要１',
        input8: '300000000018',
        input9: '固定資産名称A18',
        input10: '2012-07-01',
        input11: '55.00',
        input12: '組',
        input13: '2,714,131',
        input14: '全部除却',
        input15: 'その他',
        input16: '55.00',
        input17: '組',
        input18: '2,714,152',
        tableData: [{
          kouban: '1',
          koteisisanno: '300000000011',
          koteisisanname: '固定資産Ａ',
          torihikisakiname: '2,714,131円',
          syutokuymd: '2,714,131円',
          syutokukakaku: 'その他'
        }, {
          kouban: '2',
          koteisisanno: '300000000012',
          koteisisanname: '固定資産Ｂ',
          torihikisakiname: '2,714,131円',
          syutokuymd: '2,714,131円',
          syutokukakaku: 'その他'
        }, {
          kouban: '3',
          koteisisanno: '300000000013',
          koteisisanname: '固定資産Ｂ',
          torihikisakiname: '2,714,131円',
          syutokuymd: '2,714,131円',
          syutokukakaku: 'その他'
        }, {
          kouban: '4',
          koteisisanno: '300000000013',
          koteisisanname: '固定資産Ｂ',
          torihikisakiname: '2,714,131円',
          syutokuymd: '2,714,131円',
          syutokukakaku: 'その他'
        }, {
          kouban: '5',
          koteisisanno: '300000000013',
          koteisisanname: '固定資産Ｂ',
          torihikisakiname: '2,714,131円',
          syutokuymd: '2,714,131円',
          syutokukakaku: 'その他'
        }, {
          kouban: '6',
          koteisisanno: '300000000013',
          koteisisanname: '固定資産Ｂ',
          torihikisakiname: '2,714,131円',
          syutokuymd: '2,714,131円',
          syutokukakaku: 'その他'
        }, {
          kouban: '7',
          koteisisanno: '300000000013',
          koteisisanname: '固定資産Ｂ',
          torihikisakiname: '2,714,131円',
          syutokuymd: '2,714,131円',
          syutokukakaku: 'その他'
        }, {
          kouban: '8',
          koteisisanno: '300000000013',
          koteisisanname: '固定資産Ｂ',
          torihikisakiname: '2,714,131円',
          syutokuymd: '2,714,131円',
          syutokukakaku: 'その他'
        }, {
          kouban: '9',
          koteisisanno: '300000000013',
          koteisisanname: '固定資産Ｂ',
          torihikisakiname: '2,714,131円',
          syutokuymd: '2,714,131円',
          syutokukakaku: 'その他'
        }, {
          kouban: '10',
          koteisisanno: '300000000013',
          koteisisanname: '固定資産Ｂ',
          torihikisakiname: '2,714,131円',
          syutokuymd: '2,714,131円',
          syutokukakaku: 'その他'
        }]
      }
    }
  }
</script>

<style scoped>
.page-style {
  font-size: 12px;
  width: 843px;
  height: 100%;
  line-height:30px;
  border: 1px solid;
  padding-top: 1px;
}
.scroll-box {
  height: 255px;
  overflow-y: auto;
  margin-top: 10px; 
}
.row-class {
  height: 30px;
  margin-bottom: 1px;
  margin-left: 1px;
  margin-right: 1px;
}
.lab-class {
  line-height: 30px;
  width: 200px;
  background-color: #77cad8;
  margin-right: 1px;
}
.span-class {
 color: red;
 float: right;
}
.input-group {
  line-height: normal;
  display: inline-table;
  width: 200px;
  border-collapse: separate;
}
.label-input-class {
  border-top-right-radius: 0;
  border-bottom-right-radius: 0;
}
.label-group {
  background-color: #f5f7fa;
  color: #909399;
  display: table-cell;
  position: relative;
  border: 1px solid #dcdfe6;
  border-radius: 4px;
  padding: 0 20px;
  width: 1px;
  white-space: nowrap;
  position: relative;
  border-left: 0;
  border-top-left-radius: 0;
  border-bottom-left-radius: 0;
}
</style>