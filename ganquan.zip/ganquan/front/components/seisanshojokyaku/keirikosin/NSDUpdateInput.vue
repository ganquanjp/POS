<template>
  <div class="page-style">
    <el-row class="row-class">
      <el-col class="lab-class">　会計整理年月日<span class="span-class">（必須）</span></el-col>
      <el-col style= "width: 120px;">
        <el-select v-model="input1" size="mini">
          <el-option
            v-for="item in item1"
            :key="item.value1"
            :label="item.label1"
            :value="item.value1">
         </el-option>
       </el-select>
      </el-col>
    </el-row>
    <el-row class="row-class">
      <el-col class="lab-class">　パワー経理の発行組織<span class="span-class">（必須）</span></el-col>
      <el-col style= "width: 200px;">
        <el-input v-model="input2" size="mini"></el-input>
      </el-col>
    </el-row>
  </div>
</template>

<script>
export default {
  data () {
    return {
      item1: [{value1: '1', label1: '201109'}, {value1: '2', label1: '201110'}, {value1: '3', label1: '201111'}],
      input1: '1',
      input2: ''
    }
  }
}
</script>

<style scoped>
.page-style {
  font-size: 12px;
  width: 373px;
  height: 100%;
  margin-left:10px;
  line-height:30px;
  border: 1px solid;
  padding-top: 1px;
}
.row-class {
  height: 30px;
  margin-bottom: 1px;
  margin-left: 1px;
  margin-right: 1px;
}
.lab-class {
  width: 170px;
  background-color: #77cad8;
  line-height: 30px;
  margin-right: 1px;
}
.span-class {
 color: red;
 float: right;
}
</style>
