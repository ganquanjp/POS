<template>
  <div style= "padding-left: 10px;">
    <div class="page-style">
      <el-row class="row-class">
        <el-col class="lab-class">　会計整理年月<span class="span-class">（必須）</span></el-col>
        <el-col style= "width: 130px;">
          <el-select v-model="input1" size="mini">
            <el-option
              v-for="item in item1"
              :key="item.value1"
              :label="item.label1"
              :value="item.value1">
           </el-option>
         </el-select>
        </el-col>
      </el-row>
      <el-row class="row-class">
        <el-col class="lab-class">　パワー経理の発行組織<span class="span-class">（必須）</span></el-col>
        <el-col style= "width: 200px;">
          <el-input v-model="input2" size="mini"></el-input>
        </el-col>
      </el-row>
    </div>
    <div style="position: relative;">
     <span style="font-size: 12px;">10件</span>
      <div style="position: absolute; top: -3px; right: 0px;">
        <el-pagination
          @size-change="handleSizeChange"
          @current-change="handleCurrentChange"
          :current-page.sync="currentPage1"
          :page-size="50"
          small
          layout="prev, pager, next"
          prev-text="前へ"
          next-text="次へ"
          :total="150">
        </el-pagination>
      </div>
    </div>
    <el-table
      :data="tableData"
      border>
      <el-table-column 
        prop="kouban"
        label="NO."
        width="48px">
      </el-table-column>
      <el-table-column
        type="selection"
        width= "35px"
        align=center>
      </el-table-column>
      <el-table-column
        prop="kojikenmeino"
        label="工事件名コード"
        width="110px">
      </el-table-column>
      <el-table-column
        prop="kojikenmei"
        label="工事件名"
        width="90px">
      </el-table-column>
      <el-table-column
        prop="seisankasho"
        label="精算箇所"
        width="200px">
      </el-table-column>
      <el-table-column
        prop="seisanshono"
        label="精算書番号"
        width="140px">
      </el-table-column>
      <el-table-column
        prop="shorino"
        label="処理No"
        width="70px">
      </el-table-column>
      <el-table-column
        prop="syutokukagakugokei"
        label="取得除却価額合計"
        width="100px"
        header-align=left
        align=right>
      </el-table-column>
      <el-table-column
        :render-header="renderHeader"
        width="150px">
          <template slot-scope="scope">
            <el-select v-model="scope.row.shoninjyotai" size="mini" style="width: 142px;">
              <el-option
                v-for="item in options"
                :key="item.value"
                :label="item.label"
                :value="item.value">
              </el-option>
            </el-select>
          </template>
      </el-table-column >
      <el-table-column
        label="経理否認理由"
        min-width="100px">
          <template slot-scope="scope">
            <el-input v-model="scope.row.keirihininriyu" size="mini"></el-input>
          </template>
      </el-table-column>
    </el-table>
    <el-row>
      <el-col>
        <nsd-button-bar v-bind:buttons="buttonName" v-bind:formItem="formItem"></nsd-button-bar>
      </el-col>
    </el-row>
  </div>
</template>
<script scoped>
import NSDButtonBar from '@/components/common/NSDButtonBar.vue'

export default {
  components: {
    'nsd-button-bar': NSDButtonBar
  },
  methods: {
    handleSizeChange (val) {
      console.log(`每页 ${val} 条`)
    },
    handleCurrentChange (val) {
      console.log(`当前页: ${val}`)
    },
    renderHeader (createElement, { column }) {
      return createElement(
        'el-lab',
        [
          '承認状態',
          createElement('span', {style: 'color: red;'}, '　　(必須)')
        ]
      )
    }
  },
  data () {
    return {
      buttonName: [
        {name: this.$CONST_.buttonName.UPDATE, primary: true, show: true, action: '', url: ''},
        {name: this.$CONST_.buttonName.RESET, primary: true, show: true, action: 'clear', url: ''},
        {name: this.$CONST_.buttonName.BACK, primary: true, show: true, action: 'back', url: '', backUrl: 'nsdsssjkkkeirikensaku'}
      ],
      options: [{value: '1', label: '未承認'}, {value: '2', label: '承認済'}, {value: '3', label: '経理承認済'}, {value: '4', label: '経理否認'}]
    }
  }
}
</script>
<style scoped>
.page-style {
  font-size: 12px;
  width: 373px;
  height: 100%;
  margin-bottom: 10px;
  line-height:30px;
  border: 1px solid;
  padding-top: 1px;
}
.row-class {
  height: 30px;
  margin-bottom: 1px;
  margin-left: 1px;
  margin-right: 1px;
}
.lab-class {
  width: 170px;
  background-color: #77cad8;
  line-height: 30px;
  margin-right: 1px;
}
.span-class {
 color: red;
 float: right;
}
</style>
