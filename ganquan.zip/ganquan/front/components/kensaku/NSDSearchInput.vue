<template>
  <div class="page-style">
    <el-row>
      <el-col :span="9">精算書番号</el-col>
      <el-col :span="8">
        <el-input v-model="input1" size="mini" placeholder="精算書番号を入力ください"></el-input>
      </el-col>
    </el-row>
    <el-row>
      <el-col :span="9">固定資産番号（番号／名称）</el-col>
      <el-col :span="8">
        <el-input v-model="input2" size="mini" placeholder="固定資産番号を入力ください"></el-input>
      </el-col>
    </el-row>
    <el-row>
      <el-col :span="9">取得年月</el-col>
      <el-col :span="8">
        <el-date-picker
          v-model="date1"
          size="mini"
          type="daterange"
          range-separator="～"
          start-placeholder="開始日付を選択してください"
          end-placeholder="終了日付を選択してください">
        </el-date-picker>
      </el-col>
    </el-row>
    <el-row>
      <el-col :span="9">使用開始年月</el-col>
      <el-col :span="8">
        <el-date-picker
          v-model="date2"
          size="mini"
          type="daterange"
          range-separator="～"
          start-placeholder="開始日付を選択してください"
          end-placeholder="終了日付を選択してください">
        </el-date-picker>
      </el-col>
    </el-row>
    <el-row>
      <el-col :span="9">件名（コード／名称）</el-col>
      <el-col :span="8">
        <el-input v-model="input3" size="mini" placeholder="工事件名を入力ください"></el-input>
      </el-col>
    </el-row>
    <el-row>
      <el-col :span="9">設置場所名称</el-col>
      <el-col :span="8">
        <el-input v-model="input4" size="mini" placeholder="設置場所名称を入力ください"></el-input>
      </el-col>
    </el-row>
  </div>
</template>

<script>
export default {
  data () {
    return {
      input1: '',
      input2: '',
      input3: '',
      input4: '',
      date1: '',
      date2: ''
    }
  }
}
</script>

<style scoped>
.page-style {
  font-size: 12px;
  margin-left:10px;
  line-height:30px;
}
</style>
