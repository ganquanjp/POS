<template>
  <div style= "padding-left: 10px; padding-right: 10px;">
    <div style="position: relative;">
     <span style="font-size: 12px;">{{this.$store.state.tableData.length}}件</span>
      <div style="position: absolute; top: -3px; right: 0px;">
        <el-pagination
          @size-change="handleSizeChange"
          @current-change="handleCurrentChange"
          :current-page.sync="pageData.currentPage"
          :page-sizes="pageData.pageSizeArr"
          :page-size="pageData.pageSizeAct"
          layout="prev, pager, next"
          prev-text="前へ"
          next-text="次へ"
          :total="this.$store.state.tableData.length">
        </el-pagination>
      </div>
    </div>
    <el-table style= "padding: -50px;" :data="this.$store.state.tableData" border height=235>
      <el-table-column
        sortable
        prop="rowNo"
        label="NO."
        min-width="60px">
      </el-table-column>
      <el-table-column
        sortable
        prop="seisanShoNo"
        label="精算書番号"
        min-width="140px">
      </el-table-column>
      <el-table-column
        sortable
        prop="soshikiRenNm"
        label="精算箇所"
        min-width="140px">
      </el-table-column>
      <el-table-column
        sortable
        prop="hansu"
        label="処理No"
        min-width="80px">
      </el-table-column>
      <el-table-column
        sortable
        prop="siyoStartYmd"
        label="使用開始年月日"
        min-width="110px">
      </el-table-column>
      <el-table-column
        sortable
        prop="shutokuKagakuGokei"
        label="取得価額合計"
        min-width="120px">
      </el-table-column>
      <el-table-column
        sortable
        prop="shoninJotai"
        label="承認状態"
        min-width="120px">
      </el-table-column >
      <el-table-column
        sortable
        prop="kenmeiCd"
        label="工事件名コード"
        min-width="120px">
      </el-table-column>
      <el-table-column
        sortable
        prop="kenmeiNm"
        label="工事件名"
        min-width="118px">
      </el-table-column>
    </el-table>
  </div>
</template>
<script scoped>
  export default {
    created: function () {
      this.$store.state.currentPageData = this.tableData
    },
    data () {
      return {
        tableData: [],
        pageData: {
          total: 0,
          pageNum: 0,
          pageSizeArr: [10, 50, 100, 200],
          pageSizeAct: 10,
          currentPage: 1,
          visible: false
        }
      }
    },
    methods: {
      move: function (rowNo) {
        this.funcHttpPost('/seisanshoJokyakuShonin-selectBySeisanShoNo', this.$store.state.currentPageData[rowNo - 1], 'nsdnsssjkkshoninshokai')
      },
      handleSizeChange (index) {
        this.pageData.pageSizeAct = index
        this.initTableList(1)
      },
      handleCurrentChange (index) {
        this.initTableList(index)
      },
      initTableList (index) {
        this._initPageData(index)
        this.getPageData()
      },
      _initPageData (index) {
        this.pageData.pageNum = (index - 1) * this.pageData.pageSizeAct
        this.pageData.currentPage = index
      },
      getPageData () {
        this.$store.state.currentPageData = this.$store.state.tableData.slice(this.pageData.pageSizeAct * (this.pageData.currentPage - 1), this.pageData.pageSizeAct * this.pageData.currentPage)
      }
    }
  }
</script>
<style scoped>
</style>
