<template>
  <div>
    <el-row>
      <el-col>
        <nsd-content-title v-bind:titlename="titlename" v-bind:message="message"></nsd-content-title>
      </el-col>
    </el-row>
    <el-row>
      <el-col>
        <nsd-add-input></nsd-add-input>
      </el-col>
    </el-row>
  </div>
</template>

<script>
import NsdContentTitle from '@/components/common/NSDContentTitle.vue'
import NSDAddInput from '@/components/seisanshoshutoku/shinki/NSDAddInput.vue'

export default {
  components: {
    'nsd-content-title': NsdContentTitle,
    'nsd-add-input': NSDAddInput
  },
  data () {
    return {
      titlename: '【取得】新規登録',
      message: ''
    }
  }
}
</script>

<style scoped>
</style>
