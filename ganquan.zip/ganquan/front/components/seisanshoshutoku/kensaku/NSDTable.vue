<template>
  <div style= "padding-left: 10px; padding-right: 10px;">
    <div style="position: relative;">
     <span style="font-size: 12px;">{{this.$store.state.tableData.length}}件</span>
      <div style="position: absolute; top: -3px; right: 0px;">
        <el-pagination
          background
          @size-change="handleSizeChange"
          @current-change="handleCurrentChange"
          :current-page.sync="pageData.currentPage"
          :page-sizes="this.pageData.pageSizeArr"
          :page-size="this.pageData.pageSizeAct"
          layout="sizes, prev, pager, next"
          prev-text="前へ"
          next-text="次へ"
          :total="this.$store.state.tableData.length">
        </el-pagination>
      </div>
    </div>
    <el-table style= "padding: -50px;" 
      :data="this.$store.state.currentPageData" 
      border 
      height=235
      :span-method="objectSpanMethod" @sort-change="handleSortChange">
      <el-table-column
        prop="rowNo"
        label="NO."
        width="60px">
      </el-table-column>
      <el-table-column
        sortable="custom"
        prop="seisanShoNo"
        label="精算書番号"
        width="120px">
      </el-table-column >
      <el-table-column
        prop="soshikiNm"
        label="精算箇所"
        width="100px">
      </el-table-column>
      <el-table-column
        prop="siyoStartYmdFrom"
        label="使用開始年月日"
        width="120px">
      </el-table-column>
      <el-table-column
        prop="torokushaName"
        label="登録者氏名"
        width="100px">
      </el-table-column>
      <el-table-column
        sortable="custom"
        label="固定資産番号"
        width="105px">
          <template slot-scope="scope">
            <el-button type="text" @click="move(scope.row.rowNo)">{{scope.row.koteiShisanNo}}</el-button>
          </template>
      </el-table-column>
      <el-table-column
        prop="koteiShisanName"
        label="固定資産名称"
        width="225px">
      </el-table-column>
      <el-table-column
        prop="shutokuYmdFrom"
        label="取得年月日"
        width="100px">
      </el-table-column>
      <el-table-column
        prop="sechiBashoName"
        label="設置場所名称"
        width="120px">
      </el-table-column>
      <el-table-column
        prop="kenmeiCd"
        label="工事件名コード"
        width="120px">
      </el-table-column>
      <el-table-column
        prop="kenmeiNm"
        label="工事件名"
        width="100px">
      </el-table-column>
      <el-table-column
        prop="kanriSoshikiCd"
        label="工事担当箇所"
        width="120px">
      </el-table-column>
      <el-table-column
        prop="kojiTantoUserNm"
        label="工事担当者"
        width="100px">
      </el-table-column>
    </el-table>
  </div>
</template>
<script scoped>
export default {
  data () {
    return {
      tableData: [],
      pageData: {
        total: 0,
        pageNum: 0,
        pageSizeArr: this.$CONST_.tableConst.PAGE_SIZES,
        pageSizeAct: this.$CONST_.tableConst.PAGE_SIZE,
        currentPage: 1,
        visible: false
      },
      formItem: {
        seisanShoId: '',
        koteiShisanId: ''
      }
    }
  },
  methods: {
    move: function (row) {
      // 遷移前本画面データ保存
      this.funcDataSave()
      this.formItem.seisanShoId = this.$store.state.tableData[row - 1].seisanShoId
      this.formItem.koteiShisanId = this.$store.state.tableData[row - 1].koteiShisanId
      this.funcHttpPost('/seisanshoShutoku-shokai', this.formItem, 'nsdstkshokai')
    },
    handleSizeChange (index) {
      this.pageData.pageSizeAct = index
      this.initTableList(1)
    },
    handleCurrentChange (index) {
      this.initTableList(index)
    },
    initTableList (index) {
      this._initPageData(index)
      this.getPageData()
    },
    _initPageData (index) {
      this.pageData.pageNum = (index - 1) * this.pageData.pageSizeAct
      this.pageData.currentPage = index
    },
    getPageData () {
      this.$store.state.currentPageData = this.$store.state.tableData.slice(this.pageData.pageSizeAct * (this.pageData.currentPage - 1), this.pageData.pageSizeAct * this.pageData.currentPage)
    },
    // ヘッダーにてソートボタンを押すとソート変更する
    handleSortChange ({ column, prop, order }) {
      if (order === 'ascending') {
        this.$store.state.tableData.sort(function (a, b) {
          if (a[prop] > b[prop]) return 1
          if (a[prop] < b[prop]) return -1
          return 0
        })
      }
      if (order === 'descending') {
        this.$store.state.tableData.sort(function (a, b) {
          if (a[prop] > b[prop]) return -1
          if (a[prop] < b[prop]) return 1
          return 0
        })
      }
      if (order === null) {
        this.$store.state.tableData.sort(function (a, b) {
          if (a.rowNo > b.rowNo) return 1
          if (a.rowNo < b.rowNo) return -1
          return 0
        })
      }
      // ページデータ再設定
      this.getPageData()
    },
    objectSpanMethod ({row, column, rowIndex, columnIndex}) {
      var pageCounts = Math.ceil(this.$store.state.tableData.length / this.pageData.pageSizeAct)
      var max = this.pageData.pageSizeAct * this.pageData.currentPage
      if (this.pageData.currentPage === pageCounts) {
        max = this.$store.state.tableData.length
      }
      var k = this.pageData.pageSizeAct * (this.pageData.currentPage - 1)
      // 指定列の結合セル数を設定する
      if (rowIndex === 0 && columnIndex === 2) {
        while (k < max) {
          this.$store.state.tableData[k].rowspan1 = 1
          for (var i = k + 1; i < max; i++) {
            if (this.$store.state.tableData[k].soshikiNm === this.$store.state.tableData[i].soshikiNm && this.$store.state.tableData[k].soshikiNm !== null) {
              this.$store.state.tableData[k].rowspan1++
              this.$store.state.tableData[i].rowspan1 = 0
            } else {
              break
            }
          }
          k = i
        }
      // 指定列の結合セル数を設定する
      } else if (rowIndex === 0 && columnIndex === 3) {
        var max2 = 1
        while (k < max) {
          this.$store.state.tableData[k].rowspan2 = 1
          // 前の列が結合したの場合、次列を結合する
          if (this.$store.state.tableData[k].rowspan1 !== 1) {
            if (this.$store.state.tableData[k].rowspan1 > 1) {
              max2 = k + this.$store.state.tableData[k].rowspan1
            }
            for (var m = k + 1; m < max2; m++) {
              if (this.$store.state.tableData[k].siyoStartYmdFrom === this.$store.state.tableData[m].siyoStartYmdFrom && this.$store.state.tableData[k].siyoStartYmdFrom !== null) {
                this.$store.state.tableData[k].rowspan2++
                this.$store.state.tableData[m].rowspan2 = 0
              } else {
                break
              }
            }
            k = m
          } else {
            k++
          }
        }
      }
      // セル結合
      if (columnIndex === 2) {
        if (row.rowspan1 > 1) {
          return {
            rowspan: row.rowspan1,
            colspan: 1
          }
        } else if (row.rowspan1 === 0) {
          return {
            rowspan: 0,
            colspan: 0
          }
        } else {
          return {
            rowspan: 1,
            colspan: 1
          }
        }
      } else if (columnIndex === 3) {
        if (row.rowspan2 > 1) {
          return {
            rowspan: row.rowspan2,
            colspan: 1
          }
        } else if (row.rowspan2 === 0) {
          return {
            rowspan: 0,
            colspan: 0
          }
        } else {
          return {
            rowspan: 1,
            colspan: 1
          }
        }
      }
    }
  }
}
</script>
<style scoped>
</style>
