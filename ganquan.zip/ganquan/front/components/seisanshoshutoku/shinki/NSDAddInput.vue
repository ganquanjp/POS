<template>
  <div>
    <div class="scroll-box">
      <div class="page-style">
        <el-row class="row-class">
          <el-col style= "width: 100%; background-color: #2053cc; color: #FFFFFF; line-height: 30px;">　基本情報</el-col>
        </el-row>
        <el-row class="row-class">
          <el-col class="lab-class">　固定資産番号<span class="span-class">（必須）</span></el-col>
          <el-col style= "width: 170px; padding-top: -5px;">
            <el-input v-model="formItem.koteiShisanNo" size="mini">
              <el-button slot="append" style="position: absolute; top: 20px; left: 10px;" size="mini" @click="showModalKotei = true">参照</el-button>
            </el-input>
          </el-col>
        </el-row>
        <el-row class="row-class">
          <el-col class="lab-class">　親固定資産番号<span class="span-class">（必須）</span></el-col>
          <el-col style= "width: 170px">
          <el-input v-model="formItem.oyaKoteiShisanNo" size="mini"></el-input>
          </el-col>
          <el-col style= "width: 60px; background-color: #77cad8; line-height: 30px; margin: 0px 1px 0px 1px;">　枝番</el-col>
          <el-col style= "width: 100px">
            <el-input v-model="formItem.oyaKoteiShisanEda"  size="mini" />
          </el-col>
        </el-row>
        <el-row class="row-class">
          <el-col class="lab-class">　取得年月日<span class="span-class">（必須）</span></el-col>
          <el-col style= "width: 260px">
            <el-date-picker
              v-model="formItem.shutokuYmd"
              size="mini"
              style= "width: 140px;"
              type="date">
            </el-date-picker>
          </el-col>
        </el-row>
        <el-row class="row-class">
          <el-col class="lab-class">　固定資産名称<span class="span-class">（必須）</span></el-col>
          <el-col style= "width: 333px">
            <el-input v-model="formItem.koteiShisanNm"  size="mini" />
          </el-col>
        </el-row>
        <el-row class="row-class">
          <el-col class="lab-class">　種類<span class="span-class">（必須）</span></el-col>
          <el-col style= "width: 333px">
            <el-select v-model="formItem.shuruiCd" size="mini" style="width: 200px;">
              <el-option
                v-for="item in formItem.optionsShurui"
                :key="item.value"
                :label="item.label"
                :value="item.value">
              </el-option>
            </el-select>
          </el-col>
        </el-row>
        <el-row class="row-class">
          <el-col class="lab-class">　構造</el-col>
          <el-col style= "width: 333px">
            <el-select v-model="formItem.kouzouCd" size="mini" style="width: 200px;">
              <el-option
                v-for="item in formItem.optionsKouzou"
                :key="item.value"
                :label="item.label"
                :value="item.value">
              </el-option>
            </el-select>
          </el-col>
        </el-row>
        <el-row class="row-class">
          <el-col class="lab-class">　資産単位</el-col>
          <el-col style= "width: 333px">
            <el-select v-model="formItem.shisanTaniCd" size="mini" style="width: 200px;">
              <el-option
                v-for="item in formItem.optionsShisanTani"
                :key="item.value"
                :label="item.label"
                :value="item.value">
              </el-option>
            </el-select>
          </el-col>
        </el-row>
        <el-row class="row-class">
          <el-col class="lab-class">　科目１</el-col>
          <el-col style= "width: 333px">
            <el-select v-model="formItem.kamokuCd1" size="mini" style="width: 200px;">
              <el-option
                v-for="item in formItem.optionsKamoku1"
                :key="item.value"
                :label="item.label"
                :value="item.value">
              </el-option>
            </el-select>
          </el-col>
        </el-row>
        <el-row class="row-class">
          <el-col class="lab-class">　科目２</el-col>
          <el-col style= "width: 333px">
            <el-select v-model="formItem.kamokuCd2" size="mini" style="width: 200px;">
              <el-option
                v-for="item in formItem.optionsKamoku2"
                :key="item.value"
                :label="item.label"
                :value="item.value">
              </el-option>
            </el-select>
          </el-col>
        </el-row>
        <el-row class="row-class">
          <el-col class="lab-class">　科目３</el-col>
          <el-col style= "width: 333px">
            <el-select v-model="formItem.kamokuCd3" size="mini" style="width: 200px;">
              <el-option
                v-for="item in formItem.optionsKamoku3"
                :key="item.value"
                :label="item.label"
                :value="item.value">
              </el-option>
            </el-select>
          </el-col>
        </el-row>
        <el-row class="row-class">
          <el-col class="lab-class">　耐用年数<span class="span-class">（必須）</span></el-col>
          <el-col style= "width: 50px">
            <input class="nsd-input-class"></input>
          </el-col>
        </el-row>
      </div>
      <div class="page-style" style="margin-top: 10px;">
        <el-row class="row-class">
          <el-col style= "width: 100%; background-color: #2053cc; color: #FFFFFF; line-height: 30px;">　取得情報</el-col>
        </el-row>
        <el-row class="row-class">
          <el-col class="lab-class">　取引先名称</el-col>
          <el-col style= "width: 333px; padding-top: -5px;">
            <el-input v-model="formItem.torihikiSakiNm" size="mini">
              <el-button slot="append" style="position: absolute; top: 20px; left: 10px;" size="mini" @click="showModalTrhks = true">参照</el-button>
            </el-input>
          </el-col>
        </el-row>
        <el-row class="row-class">
          <el-col class="lab-class">　製造会社名称</el-col>
          <el-col style= "width: 333px; padding-top: -5px;">
            <el-input v-model="formItem.seizoKaishaNm" size="mini" />
          </el-col>
        </el-row>
        <el-row class="row-class">
          <el-col class="lab-class">　製造名称</el-col>
          <el-col style= "width: 200px">
            <el-input v-model="formItem.seihinNm"  size="mini" />
          </el-col>
        </el-row>
        <el-row class="row-class">
          <el-col class="lab-class">　型番</el-col>
          <el-col style= "width: 200px">
            <el-input v-model="formItem.kataban"  size="mini" />
          </el-col>
        </el-row>
        <el-row class="row-class">
          <el-col class="lab-class">　物品数量</el-col>
          <el-col style= "width: 200px">
            <el-input v-model="formItem.suryo"  size="mini" />
          </el-col>
        </el-row>
        <el-row class="row-class">
          <el-col class="lab-class">　単位</el-col>
          <el-col style= "width: 200px">
            <el-select v-model="formItem.taniCd" size="mini" style="width: 200px;">
              <el-option
                v-for="item in formItem.optionsTani"
                :key="item.value"
                :label="item.label"
                :value="item.value">
              </el-option>
            </el-select>
          </el-col>
        </el-row>
        <el-row class="row-class">
          <el-col class="lab-class">　物品<span class="span-class">（必須）</span></el-col>
          <el-col class="input-group" style= "width: 200px">
            <input v-model="formItem.bupponGaku" size="mini" class="nsd-input-class label-input-class">
              <label class="label-group">円</label>
            </input>
          </el-col>
        </el-row>
        <el-row class="row-class">
          <el-col class="lab-class">　工費</el-col>
          <el-col class="input-group" style= "width: 200px">
            <input v-model="formItem.kouhiGaku" size="mini" class="nsd-input-class label-input-class">
              <label class="label-group">円</label>
            </input>
          </el-col>
        </el-row>
        <el-row class="row-class">
          <el-col class="lab-class">　総係費</el-col>
          <el-col class="input-group" style= "width: 200px">
            <input v-model="formItem.souKeihiGaku" size="mini" class="nsd-input-class label-input-class">
              <label class="label-group">円</label>
            </input>
          </el-col>
        </el-row>
      </div>
      <div class="page-style" style="margin-top: 10px;">
        <el-row class="row-class">
          <el-col style= "width: 100%; background-color: #2053cc; color: #FFFFFF; line-height: 30px;">　管理情報</el-col>
        </el-row>
        <el-row class="row-class">
          <el-col class="lab-class">　管理箇所名称</el-col>
          <el-col style= "width: 333px; padding-top: -5px;">
            <el-input v-model="formItem.kanriSoshikiNm" size="mini">
              <el-button slot="append" style="position: absolute; top: 20px; left: 10px;" size="mini" @click="showModalKanri = true">参照</el-button>
            </el-input>
          </el-col>
        </el-row>
        <el-row class="row-class">
          <el-col class="lab-class">　負担箇所名称</el-col>
          <el-col style= "width: 333px; padding-top: -5px;">
          <el-input v-model="formItem.futanSoshikiNm" size="mini"></el-input>
          </el-col>
        </el-row>
        <el-row class="row-class">
          <el-col class="lab-class">　設置場所名称</el-col>
          <el-col style= "width: 200px">
            <el-input v-model="formItem.sechiBashoNm" size="mini">
              <el-button slot="append" style="position: absolute; top: 20px; left: 10px;" size="mini" @click="showModalSechi = true">参照</el-button>
            </el-input>
          </el-col>
        </el-row>
        <el-row class="row-class">
          <el-col class="lab-class">　取得事由</el-col>
          <el-col style= "width: 333px">
            <el-select v-model="formItem.shutokuRiyuCd" size="mini" style="width: 200px;">
              <el-option
                v-for="item in formItem.optionsShutokuRiyu"
                :key="item.value"
                :label="item.label"
                :value="item.value">
              </el-option>
            </el-select>
          </el-col>
        </el-row>
      </div>
      <div class="page-style" style="margin-top: 10px;">
        <el-row class="row-class">
          <el-col style= "width: 100%; background-color: #2053cc; color: #FFFFFF; line-height: 30px;">　任意情報</el-col>
        </el-row>
        <el-row class="row-class">
          <el-col class="lab-class">　摘要１</el-col>
          <el-col style= "width: 333px; padding-top: -5px;">
            <el-input v-model="formItem.tekiyo1" size="mini" />
          </el-col>
        </el-row>
        <el-row class="row-class">
          <el-col class="lab-class">　摘要２</el-col>
          <el-col style= "width: 333px; padding-top: -5px;">
            <el-input v-model="formItem.tekiyo2" size="mini" />
          </el-col>
        </el-row>
        <el-row class="row-class">
          <el-col class="lab-class">　摘要３</el-col>
          <el-col style= "width: 333px">
            <el-input v-model="formItem.tekiyo3"  size="mini" />
          </el-col>
        </el-row>
        <el-row class="row-class">
          <el-col class="lab-class">　摘要４</el-col>
          <el-col style= "width: 333px">
            <el-input v-model="formItem.tekiyo4"  size="mini" />
          </el-col>
        </el-row>
        <el-row class="row-class">
          <el-col class="lab-class">　摘要５</el-col>
          <el-col style= "width: 333px">
            <el-input v-model="formItem.tekiyo5"  size="mini" />
          </el-col>
        </el-row>
        <el-row class="row-class">
          <el-col class="lab-class">　工事担当者</el-col>
          <el-col style= "width: 333px">
            <el-input v-model="formItem.kojiTantoUserNm"  size="mini" />
          </el-col>
        </el-row>
        <el-row class="row-class">
          <el-col class="lab-class">　工事精算操作者</el-col>
          <el-col style= "width: 333px">
            <el-input v-model="formItem.kojiSeisanUserNm"  size="mini" />
          </el-col>
        </el-row>
      </div>
    </div>
    <el-row>
      <el-col>
        <nsd-button-bar v-bind:buttons="buttonName" v-bind:formItem="formItem"></nsd-button-bar>
      </el-col>
    </el-row>
    <modal-kotei v-if="showModalKotei" @close="showModalKotei = false" @backData="backDataKotei"></modal-kotei>
    <modal-trhks v-if="showModalTrhks" @close="showModalTrhks = false" @backData="backDataTrhks"></modal-trhks>
    <modal-kanri v-if="showModalKanri" @close="showModalKanri = false" @backData="backDataKanri"></modal-kanri>
    <modal-sechi v-if="showModalSechi" @close="showModalSechi = false" @backData="backDataSechi"></modal-sechi>
  </div>
</template>

<script>
import NSDButtonBar from '@/components/common/NSDButtonBar.vue'
import NSDKanrifutankensaku from '@/components/common/modal/NSDKanrifutankensaku'
import NSDKoteisisankensaku from '@/components/common/modal/NSDKoteisisankensaku'
import NSDSechiBashokensaku from '@/components/common/modal/NSDSechiBashokensaku'
import NSDTorihikiSakikensaku from '@/components/common/modal/NSDTorihikiSakikensaku'

export default {
  components: {
    'nsd-button-bar': NSDButtonBar,
    'modal-kotei': NSDKoteisisankensaku,
    'modal-kanri': NSDKanrifutankensaku,
    'modal-sechi': NSDSechiBashokensaku,
    'modal-trhks': NSDTorihikiSakikensaku
  },
  data () {
    return {
      showModalKotei: false,
      showModalKanri: false,
      showModalSechi: false,
      showModalTrhks: false,
      buttonName: [
        {name: this.$CONST_.buttonName.INSERT, primary: true, show: true, action: 'post', url: '/seisanshoShutoku-insertKss005'},
        {name: this.$CONST_.buttonName.RESET, primary: true, show: true, action: 'reset', url: ''}
      ],
      formItem: {
        koteiShisanNo: '',
        oyaKoteiShisanNo: '',
        oyaKoteiShisanEda: '',
        shutokuYmd: '',
        koteiShisanNm: '',
        shuruiCd: '',
        kouzouCd: '',
        shisanTaniCd: '',
        kamokuCd1: '',
        kamokuCd2: '',
        kamokuCd3: '',
        torihikiSakiCd: '',
        torihikiSakiNm: '',
        seizoKaishaNm: '',
        seihinNm: '',
        kataban: '',
        suryo: '',
        taniCd: '',
        bupponGaku: '',
        kouhiGaku: '',
        souKeihiGaku: '',
        kanriSoshikiCd: '',
        kanriSoshikiNm: '',
        futanSoshikiCd: '',
        futanSoshikiNm: '',
        sechiBashoCd: '',
        sechiBashoNm: '',
        shutokuRiyuCd: '',
        tekiyo1: '',
        tekiyo2: '',
        tekiyo3: '',
        tekiyo4: '',
        tekiyo5: '',
        kojiTantoUserNm: '',
        kojiSeisanUserNm: '',
        optionsShurui: [{value: '1', label: 'リース投資（備品）A'}, {value: '2', label: 'リース投資（備品）B'}],
        optionsKouzou: [{value: '1', label: 'セキュリテイ設備A'}, {value: '2', label: 'セキュリテイ設備B'}],
        optionsShisanTani: [{value: '1', label: 'セキュリテイ設備A'}, {value: '2', label: 'セキュリテイ設備B'}],
        optionsKamoku1: [{value: '1', label: 'リース投資資産A'}, {value: '2', label: 'リース投資資産B'}],
        optionsKamoku2: [{value: '1', label: 'DC設備A'}, {value: '2', label: 'DC設備B'}],
        optionsKamoku3: [{value: '1', label: '一般A'}, {value: '2', label: '一般B'}],
        optionsTani: [{value: '1', label: '式A'}, {value: '2', label: '式B'}],
        optionsShutokuRiyu: [{value: '1', label: '新規A'}, {value: '2', label: '新規B'}],
        sechiBashoList: []
      }
    }
  },
  methods: {
    backDataKotei (val) {
      this.formItem.koteiShisanNo = val['koteiNo']
      this.formItem.oyaKoteiShisanNo = val['koteioyaNo']
      this.formItem.oyaKoteiShisanEda = val['edaBan']
    },
    backDataTrhks (val) {
      this.formItem.torihikiSakiCd = val['abbTorihkCod']
      this.formItem.torihikiSakiNm = val['abbTorihkKnj']
    },
    backDataKanri (val) {
      this.formItem.kanriSoshikiCd = val['kanrikasyocd']
      this.formItem.kanriSoshikiNm = val['kanrikasyo']
      this.formItem.futanSoshikiCd = val['futankasyocd']
      this.formItem.futanSoshikiNm = val['futankasyo']
    },
    backDataSechi (val) {
      this.formItem.sechiBashoCd = val['sechiBashoCd']
      this.formItem.sechiBashoNm = val['sechiBashoNm']
    }
  }
}
</script>

<style scoped>
.page-style {
  font-size: 12px;
  margin-left:10px;
  width: 476px;
  border: 1px solid;
  padding-top: 1px;
}
.row-class {
  height: 30px;
  margin-bottom: 1px;
  margin-left: 1px;
  margin-right: 1px;
}
.lab-class {
  line-height: 30px;
  width: 140px;
  background-color: #77cad8;
  margin-right: 1px;
}
.scroll-box {
  height: 450px;
  overflow-y: auto;
}
.label-group {
  background-color: #f5f7fa;
  color: #909399;
  display: table-cell;
  position: relative;
  border: 1px solid #dcdfe6;
  border-radius: 4px;
  padding: 0 20px;
  width: 1px;
  white-space: nowrap;
  position: relative;
  border-left: 0;
  border-top-left-radius: 0;
  border-bottom-left-radius: 0;
}
.input-group {
  line-height: normal;
  display: inline-table;
  width: 100%;
  border-collapse: separate;
}
.label-input-class {
  border-top-right-radius: 0;
  border-bottom-right-radius: 0;
}
.span-class {
 color: red;
 float: right;
}
</style>
