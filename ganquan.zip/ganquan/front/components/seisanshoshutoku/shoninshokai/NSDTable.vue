<template>
  <div>
    <div style= "padding-left: 10px; padding-top: 10px; padding-right: 10px; width: 850px;">
      <div class="page-style">
        <el-row class="row-class">
          <el-col class="lab-class">　経理否認理由</el-col>
          <el-col style= "width: 237px;">
            <el-input v-model="formItem.riyu" size="mini" :disabled="true" />
          </el-col>
        </el-row>
      </div>
    </div>
    <div style= "padding-left: 10px; padding-top: 20px; padding-right: 10px; width: 850px;">
      <div class="page-style">
        <el-row class="row-class">
          <el-col style= "width: 379px; background-color: #2053cc; color: white;">　取得情報</el-col>
        </el-row>
        <el-row class="row-class">
          <el-col class="lab-class">　精算書番号</el-col>
          <el-col style= "width: 237px;">
            <el-input v-model="formItem.seisanShoNo" size="mini" :disabled="true" />
          </el-col>
        </el-row>
        <el-row class="row-class">
          <el-col class="lab-class">　処理NO</el-col>
          <el-col style= "width: 237px;">
            <input v-model="formItem.hansu" size="mini" class="nsd-input-class" disabled="disabled" style="cursor: default;" />
          </el-col>
        </el-row>
        <el-row class="row-class">
          <el-col class="lab-class">　使用開始年月日</el-col>
          <el-col style= "width: 237px;">
            <el-input v-model="formItem.siyoStartYmd" size="mini" :disabled="true" />
          </el-col>
        </el-row>
        <el-row class="row-class">
          <el-col class="lab-class">　取得価額合計</el-col>
            <el-col class="input-group" style= "width: 237px">
              <input v-model="formItem.shutokuKagakuGoke" size="mini" class="nsd-input-class label-input-class" disabled="disabled" style="cursor: default;" />
              </input>
            </el-col>
        </el-row>
        <el-row class="row-class">
          <el-col class="lab-class">　承認状態</el-col>
          <el-col style= "width: 237px;">
            <el-input v-model="formItem.shoninSattus" size="mini" :disabled="true" />
          </el-col>
        </el-row>
        <el-row class="row-class">
          <el-col class="lab-class">　工事件名</el-col>
          <el-col style= "width: 237px;">
            <el-input v-model="formItem.kenmeiNm" size="mini" :disabled="true" />
          </el-col>
        </el-row>
      </div>
      <div style="position: relative;">
       <span style="font-size: 12px;" v-if="this.$store.state.tableData.shutokuSisanLst.length > 0">{{this.$store.state.tableData.shutokuSisanLst.length}}件</span>
       <span style="font-size: 12px;" v-else>0件</span>
      </div>
      <div style= "padding-top: 1px; width: 850px;">
        <el-table
          :data="this.$store.state.tableData.shutokuSisanLst"
          max-height=300
          border>
          <el-table-column
            sortable
            prop="rowNo"
            label="NO."
            width="70px">
          </el-table-column>
          <el-table-column
            sortable
            prop="koteiShisanNo"
            label="固定資産番号"
            min-width="120px">
          </el-table-column>
          <el-table-column
            sortable
            prop="koteiShisanNm"
            label="固定資産名称"
            width="250px">
          </el-table-column>
          <el-table-column
            sortable
            prop="shutokuYmd"
            label="取得年月日"
            width="120px">
          </el-table-column>
          <el-table-column
            sortable
            prop="shutokuKagaku"
            label="取得価額"
            header-align=left
            align=right
            width="120px">
          </el-table-column >
        </el-table>
      </div>
    </div>
    <el-row>
      <el-col>
        <nsd-button-bar v-bind:buttons="buttonName" v-bind:formItem="formItem"></nsd-button-bar>
      </el-col>
    </el-row>
  </div>
</template>

<script>
import NSDButtonBar from '@/components/common/NSDButtonBar.vue'
export default {
  components: {
    'nsd-button-bar': NSDButtonBar
  },
  created: function () {
    this.formItem = this.$store.state.tableData
    if (this.formItem.shoninSattus === '登録中') {
      this.buttonName[1].disabled = false
    } else if (this.formItem.shoninSattus === '承認済(経理提出)') {
      this.buttonName[1].disabled = false
    } else if (this.formItem.shoninSattus === null) {
      this.buttonName[1].disabled = false
    } else {
      this.buttonName[1].disabled = true
    }
  },
  data () {
    return {
      buttonName: [
        {name: this.$CONST_.buttonName.PRINT, primary: true, show: true, action: 'popup', url: '/seisanshoJokyaku-delByPyKey', backUrl: '', msg: '印刷しますか？'},
        {name: this.$CONST_.buttonName.UPDATE, primary: true, show: true, action: '', url: '', backUrl: '', msg: ''},
        {name: this.$CONST_.buttonName.BACK, primary: true, show: true, action: 'back', url: '', backUrl: 'nsdstkshonin', msg: ''}
      ],
      formItem: ''
    }
  }
}
</script>


<style scoped>
.page-style {
  font-size: 12px;
  width: 381px;
  height: 100%;
  line-height:30px;
  border: 1px solid;
  padding-top: 1px;
  padding-right: 1px;
}
.row-class {
  height: 30px;
  margin-bottom: 1px;
  margin-left: 1px;
  margin-right: 1px;
}
.lab-class {
  line-height: 30px;
  width: 140px;
  background-color: #77cad8;
  margin-right: 1px;
}
</style>
