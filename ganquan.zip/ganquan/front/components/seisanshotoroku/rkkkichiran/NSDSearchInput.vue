<template>
  <div class="page-style">
    <el-row class="row-class">
      <el-col class= "lab-class">　取込日</el-col>
      <el-col style= "width: 140px;">
        <el-date-picker
          v-model="date3"
          size="mini"
          style="width: 140px;"
          type="date">
        </el-date-picker>
      </el-col>
      <el-col :span="1"style="line-height: 25px; margin-left: 5px; margin-right: -5px;">－</el-col>
      <el-col style= "width: 140px;">
        <el-date-picker
          v-model="date4"
          size="mini"
          style="width: 140px;"
          type="date">
        </el-date-picker>
      </el-col>
    </el-row>
    <el-row class="row-class">
      <el-col class= "lab-class">　連係結果</el-col>
      <el-col class="checkbox-class">
        <template>
         <el-checkbox v-model="checked1">結果OK</el-checkbox>
         <el-checkbox v-model="checked2">結果NG</el-checkbox>
       </template>
      </el-col>
    </el-row>
  </div>
</template>

<script>
export default {
  data () {
    return {
      checked1: true,
      checked2: true,
      checked3: true,
      bumen: [],
      input1: '',
      input2: '',
      input3: '',
      input4: '',
      date1: '',
      date2: '',
      timeout: null
    }
  },
  methods: {
    loadAll () {
      return [
        { 'value': '総務部' },
        { 'value': '総務部　一括' },
        { 'value': '財務部' },
        { 'value': '財務部　一括' },
        { 'value': '人事部' },
        { 'value': '人事部　一括' }
      ]
    },
    querySearchAsync (queryString, cb) {
      var bumen = this.bumen
      var results = queryString ? bumen.filter(this.createStateFilter(queryString)) : bumen
      clearTimeout(this.timeout)
      this.timeout = setTimeout(() => {
        cb(results)
      }, 200 * Math.random())
    },
    createStateFilter (queryString) {
      return (state) => {
        return (state.value.toLowerCase().indexOf(queryString.toLowerCase()) === 0)
      }
    },
    handleSelect (item) {
      console.log(item)
    }
  },
  mounted () {
    this.bumen = this.loadAll()
  }
}
</script>

<style scoped>
.page-style {
  font-size: 12px;
  width: 473px;
  height: 100%;
  margin-left:10px;
  border: 1px solid;
  padding-top: 1px;
  padding-right: 1px;
}
.row-class {
  height: 30px;
  margin-bottom: 1px;
  margin-left: 1px;
  margin-right: 1px;
}
.lab-class {
  width: 170px;
  background-color: #77cad8;
  line-height: 30px;
  margin-right: 1px;
}
.checkbox-class {
  width: 250px;
  line-height: 30px;
  margin-left: 2px;
}
</style>
