<template>
  <div>
    <el-button 
      v-for="(btn, key) in buttons" 
      v-if="btn.show" 
      class="button-style" 
      size="mini" 
      v-bind:type="btn.primary ? 'primary' : '' "
      v-bind:key="key"
    >
      {{ btn.name }}
    </el-button>
  </div>
</template>

<script>
export default {
  data () {
    return {
      buttons: [
        { name: '検索', show: true },
        { name: '照会', show: true },
        { name: '新規登録', show: false },
        { name: '参照登録', primary: true, show: true },
        { name: '類似登録', show: false },
        { name: '修正', show: true },
        { name: '削除', show: true },
        { name: '戻る', show: true }
      ]
    }
  }
}
</script>

<style scoped>
.button-style {
  margin-left:10px;
}
</style>
