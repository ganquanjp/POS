<template>
<table>
	<tr>
		<td colspan="6"><div id="app"> {{ actionName }}</div></td>
	</tr>
	<tr>
		<td colspan="6"><hr /></td>
	</tr>
	<tr>
		<td colspan="6">
			<table>
				<tr>
					<td><div id="app"> <input type="button" name="btnExe" value="登録" onclick="btnExe_click()" /></div></td>
					<td><input type="button" name="btnClear" value="クリア" onclick="btnClear_click()" /></td>
					<td width="400px"></td>
					<td><input type="button" name="btnBack" value="戻る" onclick="btnBack_click()" /></td>
				</tr>
			</table>
		</td>
	</tr>
	<tr>
		<td colspan="6">
			<div id="tableDiv" style="height:500px; width:1200px; overflow-y:scroll">
				<table>
					<tr>
						<td>
							<table>
								<tr><td colspan="5" bgcolor="#dcdcdc" align="center">基本情報</td></tr>
								<tr>
									<td bgcolor="#dcdcdc">固定資産番号<span style="color:#ff0000">(必須)</span></td>
									<td ><input id="koteishisanno" type="text" value="300000000063" /></td>
									<td ><input type="button" value="参照" /></td>
									<td colspan="2"></td>
								</tr>
								<tr>
									<td bgcolor="#dcdcdc">親固定資産番号<span style="color:#ff0000">(必須)</span></td>
									<td ><input type="text" value="300000000063" /></td>
									<td ><input type="button" value="参照" /></td>
									<td bgcolor="#dcdcdc">枝番</td>
									<td ><input type="text" value="00002" /></td>
								</tr>
								<tr>
									<td bgcolor="#dcdcdc">取得年月日<span style="color:#ff0000">(必須)</span></td>
									<td ><input type="date" value="2011-09-01" /></td>
									<td ><input type="button" value="日付" /></td>
									<td colspan="2"></td>
								</tr>
								<tr>
									<td bgcolor="#dcdcdc">固定資産名称<span style="color:#ff0000">(必須)</span></td>
									<td ><input type="text" value="固定資産名称テスト" /></td>
									<td colspan="3"></td>
								</tr>
								<tr>
									<td bgcolor="#dcdcdc">種類<span style="color:#ff0000">(必須)</span></td>
									<td >
										<select id="shurui" name="shurui">
											<option value="0"></option>
											<option value="1" selected>リース投資(備品)</option>
											<option value="2">種類2</option>
										</select>
									</td>
									<td colspan="3"></td>
								</tr>
								<tr>
									<td bgcolor="#dcdcdc">構造</td>
									<td >
										<select id="kouzou" name="kouzou">
											<option value="0"></option>
											<option value="1">構造1</option>
											<option value="2">構造2</option>
											<option value="3">構造3</option>
											<option value="4" selected>セキュリティ設備</option>
											<option value="5">構造5</option>
										</select>
									</td>
									<td colspan="3"></td>
								</tr>
								<tr>
									<td bgcolor="#dcdcdc">資産単位</td>
									<td >
										<select id="shisantani" name="shisantani">
											<option value="0"></option>
											<option value="1" selected>セキュリティ設備</option>
											<option value="2">資産単位2</option>
											<option value="3">資産単位3</option>
										</select>
									</td>
									<td colspan="3"></td>
								</tr>
								<tr>
									<td bgcolor="#dcdcdc">科目１</td>
									<td >
										<select id="kamoku1" name="kamoku1">
											<option value="0"></option>
											<option value="1" selected>リース投資(備品)</option>
											<option value="2">科目12</option>
											<option value="3">科目13</option>
										</select>
									</td>
									<td colspan="3"></td>
								</tr>
								<tr>
									<td bgcolor="#dcdcdc">科目２</td>
									<td >
										<select id="kamoku2" name="kamoku2">
											<option value="0"></option>
											<option value="1" selected>ＤＣ設備</option>
											<option value="2">科目22</option>
											<option value="3">科目23</option>
										</select>
									</td>
									<td colspan="3"></td>
								</tr>
								<tr>
									<td bgcolor="#dcdcdc">科目３</td>
									<td >
										<select id="kamoku3" name="kamoku3">
											<option value="0"></option>
											<option value="1" selected>一般</option>
											<option value="2">科目32</option>
											<option value="3">科目33</option>
										</select>
									</td>
									<td colspan="3"></td>
								</tr>
								<tr>
									<td bgcolor="#dcdcdc">耐用月数<span style="color:#ff0000">(必須)</span></td>
									<td ><input type="text" value="20" /></td>
									<td colspan="3"></td>
								</tr>
							</table>
						</td>
					</tr>
					<tr><td height="25px"></td></tr>
					<tr>
						<td>
							<table>
								<tr><td colspan="8" bgcolor="#dcdcdc" align="center">取得情報</td></tr>
								<tr>
									<td bgcolor="#dcdcdc">取引先名称<span style="color:#ff0000">(必須)</span></td>
									<td ><input width="150px" type="text" value="取引先名称" /></td>
									<td ><input type="button" value="参照" /></td>
									<td colspan="5"></td>
								</tr>
								<tr>
									<td bgcolor="#dcdcdc">製造会社名称</td>
									<td ><input type="text" value="製造会社名称" /></td>
									<td colspan="6"></td>
								</tr>
								<tr>
									<td bgcolor="#dcdcdc">製品名称</td>
									<td ><input type="text" value="製品名称" /></td>
									<td bgcolor="#dcdcdc">型番</td>
									<td ><input type="text" value="型番" /></td>
									<td bgcolor="#dcdcdc">物品数量<span style="color:#ff0000">(必須)</span></td>
									<td ><input type="text" value="10.00" /></td>
									<td bgcolor="#dcdcdc">単位<span style="color:#ff0000">(必須)</span></td>
									<td >
										<select id="tani" name="tani">
											<option value="0"></option>
											<option value="1" selected>式</option>
											<option value="2">単位2</option>
											<option value="3">単位3</option>
										</select>
									</td>
									<td></td>
								</tr>
								<tr>
									<td bgcolor="#dcdcdc">物品<span style="color:#ff0000">(必須)</span></td>
									<td><input style="width:130px" type="text" value="20" /> 円</td>
									<td bgcolor="#dcdcdc">工費<span style="color:#ff0000">(必須)</span></td>
									<td><input style="width:130px" type="text" value="30" /> 円</td>
									<td bgcolor="#dcdcdc">総経費</td>
									<td><input style="width:130px" type="text" value="40" /> 円</td>
									<td colspan="2"></td>
								</tr>
							</table>
						</td>
					</tr>
					<tr><td height="25px"></td></tr>
					<tr>
						<td>
							<table>
								<tr><td colspan="3" bgcolor="#dcdcdc" align="center">管理情報</td></tr>
								<tr>
									<td bgcolor="#dcdcdc">管理箇所名称<span style="color:#ff0000">(必須)</span></td>
									<td ><input style="width:400px" type="text" value="本社" /></td>
									<td ><input type="button" value="参照" /></td>
								</tr>
								<tr>
									<td bgcolor="#dcdcdc">負担箇所<span style="color:#ff0000">(必須)</span></td>
									<td ><input style="width:400px" type="text" value="本社" /></td>
									<td ><input type="button" value="参照" /></td>
								</tr>
								<tr>
									<td bgcolor="#dcdcdc">設置場所名称<span style="color:#ff0000">(必須)</span></td>
									<td ><input style="width:400px" type="text" value="ＣＣ１" /></td>
									<td ><input type="button" value="参照" /></td>
								</tr>
								<tr>
									<td bgcolor="#dcdcdc">取得事由<span style="color:#ff0000">(必須)</span></td>
									<td >
										<select id="shutokujiyu" name="shutokujiyu">
											<option value="0"></option>
											<option value="1" selected>新規</option>
											<option value="2">取得事由2</option>
											<option value="3">取得事由3</option>
										</select>
									</td>
								</tr>

							</table>
						</td>
					</tr>
					<tr><td height="25px"></td></tr>
					<tr>
						<td>
							<table>
								<tr><td colspan="10" bgcolor="#dcdcdc" align="center">任意情報</td></tr>
								<tr>
									<td bgcolor="#dcdcdc">摘要１</td>
									<td colspan="4"><input style="width:400px" type="text" value="摘要１" /></td>
									<td bgcolor="#dcdcdc">摘要２</td>
									<td colspan="4"><input style="width:400px" type="text" value="摘要２" /></td>
								</tr>
								<tr>
									<td bgcolor="#dcdcdc">摘要３</td>
									<td ><input type="text" value="摘要３" /></td>
									<td bgcolor="#dcdcdc">摘要４</td>
									<td ><input type="text" value="摘要４" /></td>
									<td bgcolor="#dcdcdc">摘要５</td>
									<td ><input type="text" value="摘要５" /></td>
									<td bgcolor="#dcdcdc">工事担当者</td>
									<td ><input type="text" value="工事担当者" /></td>
									<td bgcolor="#dcdcdc">工事精算操作者</td>
									<td ><input type="text" value="工事精算操作者" /></td>
								</tr>
							</table>
						</td>
					</tr>
				</table>
			</div>
		</td>
	</tr>
	<tr>
		<td colspan="6">
			<table>
				<tr>
					<td><input type="button" name="btnExe2" value="登録" onclick="btnExe_click()" /></td>
					<td width="400px"></td>
					<td><input type="button" name="btnBack" value="戻る" onclick="btnBack_click()" /></td>
				</tr>
			</table>
		</td>
	</tr>
</table>
</template>
