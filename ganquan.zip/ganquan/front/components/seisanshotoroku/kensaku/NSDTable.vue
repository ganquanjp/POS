<template>
  <div style= "padding-left: 10px; padding-right: 10px;">
    <div style="position: relative;">
     <span style="font-size: 12px;">10件</span>
      <div style="position: absolute; top: -3px; right: 0px;">
        <el-pagination
          @size-change="handleSizeChange"
          @current-change="handleCurrentChange"
          :current-page.sync="this.$store.state.currentPage"
          :page-size="50"
          small
          layout="prev, pager, next"
          prev-text="前へ"
          next-text="次へ"
          :total="150">
        </el-pagination>
      </div>
    </div>
    <el-table
      :data="this.$store.state.tableData"
      height=270
      border
      :header-row-class-name="headerClassName">
      <el-table-column 
        prop="rowNo"
        sortable
        label="NO."
        width="80px">
      </el-table-column>
      <el-table-column
        prop="seisanShoNo"
        sortable
        label="精算書番号"
        width="140px">
         <template slot-scope="scope">
          <el-button type="text" @click="move(scope.row.rowNo)">{{scope.row.seisanShoNo}}</el-button>
         </template>
      </el-table-column>
      <el-table-column
        prop="soshikiNm"
        sortable
        label="精算箇所"
        width="100px">
      </el-table-column>
      <el-table-column
        prop="siyoStartYMDFrom"
        sortable
        label="使用開始年月日"
        width="140px">
      </el-table-column>
      <el-table-column
        prop="yoyakusu"
        sortable
        label="予約数"
        width="80px">
      </el-table-column>
      <el-table-column
        prop="torokushaName"
        sortable
        label="登録者氏名"
        width="140px">
      </el-table-column>
      <el-table-column
        prop="kenmeiCd"
        sortable
        label="工事件名コード"
        width="140px">
      </el-table-column >
      <el-table-column
        prop="kenmeiNm"
        sortable
        label="工事件名"
        width="100px">
      </el-table-column>
      <el-table-column
        prop="tekiyoStartYmd"
        sortable
        label="適用開始日"
        width="100px">
      </el-table-column>
      <el-table-column
        prop="tekiyoEndYmd"
        sortable
        label="適用終了日"
        width="100px">
      </el-table-column>
    </el-table>
  </div>
</template>
<script scoped>
  export default {
    data () {
      return {
        formItem: {
          seisanShoId: '',
          koteiShisanId: ''
        }
      }
    },
    methods: {
      move: function (row) {
        this.formItem.seisanShoId = this.$store.state.tableData[row - 1].seisanShoId
        this.formItem.koteiShisanId = this.$store.state.tableData[row - 1].koteiShisanId
        this.funcHttpPost('/seisanshoToroku-shokai', this.formItem, 'nsdssstrkshokai')
      },
      headerClassName ({row, rowIndex}) {
        return 'class-header'
      },
      handleSizeChange (val) {
        console.log(`每页 ${val} 条`)
      },
      handleCurrentChange (val) {
        console.log(`当前页: ${val}`)
      }
    }
  }
</script>
<style scoped>
</style>
