<template>
  <div>
    <el-row>
      <el-col>
        <nsd-content-title v-bind:titlename="titlename" v-bind:message="this.$store.state.message"></nsd-content-title>
      </el-col>
    </el-row>
    <el-row>
      <el-col>
        <nsd-button-bar v-bind:buttons="buttonName"></nsd-button-bar>
      </el-col>
    </el-row>
  </div>
</template>

<script>
import NsdContentTitle from '@/components/common/NSDContentTitle.vue'
import NSDButtonBar from '@/components/common/NSDButtonBar.vue'

export default {
  components: {
    'nsd-content-title': NsdContentTitle,
    'nsd-button-bar': NSDButtonBar

  },
  data () {
    return {
      titlename: '【精算書登録】件名即時反映',
      buttonName: [
        {name: '実　行', primary: true, show: true, action: 'post', url: '/seisanshoTorokuKmskJhe-selectByWhere'}
      ]
    }
  }
}
</script>

<style scoped>

</style>
