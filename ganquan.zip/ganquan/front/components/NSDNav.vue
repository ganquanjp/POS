<template>
  <div class="page-style">
    <el-menu
      default-active="1"
      :router="true"
      :unique-opened="false"
      @open="handleOpen"
      @close="handleClose"
      @select="handleSelect">
      <el-submenu v-for="(category, key) in categorys" :index="category.groupId" :key="category.groupId">
        <template slot="title">
          <span>{{ category.groupName }}</span>
        </template>
        <el-menu-item 
          v-for="(link, key) in category.links"
          :route="{ name: link.routerName, params: { id: link.id }}"
          :index="link.menuId"
          :key="key"
        >
          {{ link.menuLinkNm }}
        </el-menu-item>
      </el-submenu>
    </el-menu>
  </div>
</template>

<script>
export default {
  methods: {
    handleOpen (key, keyPath) {
      // console.log(key, keyPath)
    },
    handleClose (key, keyPath) {
      // console.log(key, keyPath)
    },
    handleSelect (key, keyPath) {
      this.funcClearStoreData()
    }
  },
  created () {
    this.categorys = this.$store.state.tableData
  },
  data () {
    return {
      categorys: []
    }
  }
}
</script>

<style>
</style>