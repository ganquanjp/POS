package jp.co.nsd.nkssweb;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import jp.co.nsd.nkssweb.utils.NSDDateUtils;
import net.sf.jasperreports.engine.JREmptyDataSource;
import net.sf.jasperreports.engine.JasperCompileManager;
import net.sf.jasperreports.engine.JasperExportManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;


public class NSDTest {

	private static final Logger logger = LoggerFactory.getLogger(NSDTest.class);

	public static void main(String[] args) {
		// TODO 自動生成されたメソッド・スタブ
		logger.info("NSDTest.main start!");
		Date date = NSDDateUtils.stringToDate("2018-02-28","yyyy-MM-dd");
		logger.info(NSDDateUtils.dateToString(date, "yyyy-MM-dd"));

		logger.info("aaaaa");
		// createPDF();
	}

	public static final Date stringToDate(String ymd, String format) {
		Date date = new Date();
		System.out.println(date);
		return date;
	}

	public static void createPDF() {

		String path = "C:\\workspace\\nkss\\nkss-web\\src\\main\\resources\\reports\\";
		String jrxmlFile = path.concat("SamplePDF.jrxml");
		String jasperFile = path.concat("SamplePDF.jasper");
		String outputfile = path.concat("SamplePDF.pdf");

		try {
			// InputStream employeeReportStream =
			// getClass().getResourceAsStream(jrxmlFile);
			// JasperReport jasperReport
			// = JasperCompileManager.compileReport(employeeReportStream);
			JasperCompileManager.compileReportToFile(jrxmlFile, jasperFile);
			// JRPdfExporter exporter = new JRPdfExporter();
			JasperPrint jasperPrint = (JasperPrint) JasperFillManager.fillReport(jasperFile, data(),
					new JREmptyDataSource());
			// JasperRunManager.runReportToPdf(jasperFile, data());
			JasperExportManager.exportReportToPdfFile(jasperPrint, outputfile);

		} catch (Exception e) {
			// TODO 自動生成された catch ブロック
			e.printStackTrace();
		}

	}

	public static Map<String, Object> data() {
		Map<String, Object> data = new HashMap<String, Object>();
		data.put("user_id", "0001");
		return data;
	}

}
