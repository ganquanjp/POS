/***********************************************************************
*
*業務名: 工事精算システム
*機能名: 除却（内容入力）(ログ出力処理)
*
*機能概要: 除却情報を処理する。
*
*JavaＶｅｒ：J2SE1.8.0準拠
*
*更新履歴: Ver.1.00 2018/03/06　NSD　新規作成
***********************************************************************/

package jp.co.nsd.nkssweb.controller.seisanshojokyaku;

import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.beanutils.BeanUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import jp.co.nsd.nkssweb.dao.Message;
import jp.co.nsd.nkssweb.dao.SeisanshoJokyakuNaiyo;
import jp.co.nsd.nkssweb.dao.SeisanshoJokyakuNaiyoShokai;
import jp.co.nsd.nkssweb.service.SystemService;
import jp.co.nsd.nkssweb.service.seisanshojokyaku.SeisanshoJokyakuNaiyoService;
import jp.co.nsd.nkssweb.utils.NSDCommUtils;
import jp.co.nsd.nkssweb.utils.NSDConstant;

/**
 * 除却（内容入力）処理
 *
 * @version 1.00
 */
@RestController
public class SeisanshoJokyakuNaiyoController {

	// ログ
	private Logger logger = LoggerFactory.getLogger(this.getClass());

	@Autowired
	private SeisanshoJokyakuNaiyoService seisanshoJokyakuNaiyoService;

	protected SystemService systemService;

	/**
	 * 除却（内容入力）検索処理
	 *
	 * @param reqMap
	 *            INPUTパラメータ
	 * @return 除却情報データ
	 * @exception IllegalAccessException
	 * @exception InvocationTargetException
	 * @version 1.00
	 */
	@RequestMapping(value = "/seisanshoJokyakuNaiyo-selectByWhere", method = RequestMethod.POST)
	public Map<String, Object> selectByWhere(@RequestParam Map<String, Object> reqMap) {

		// 開始ログ
		logger.info("SeisanshoJokyakuNaiyoController.selectByWhere 開始します。");

		Map<String, Object> returnMap = new HashMap<String, Object>();

		Message message = new Message();

		SeisanshoJokyakuNaiyo seisanshoJokyakuNaiyo = new SeisanshoJokyakuNaiyo();

		List<SeisanshoJokyakuNaiyo> sssJkkNyLst = new ArrayList<>();

		// 画面入力した検索条件を取得する
		try {
			// Mapの情報をBeanのプロパティにセット
			BeanUtils.populate(seisanshoJokyakuNaiyo, reqMap);

			// 除却予定年月日（From）と除却予定年月日（To）の大小比較チェック
			if (NSDCommUtils.chkDateFromTo(seisanshoJokyakuNaiyo.getJokyakuYoteYmdFrom(),
					seisanshoJokyakuNaiyo.getJokyakuYoteYmdTo())) {
				// 処理結果データ
				returnMap.put(NSDConstant.RESULT_DATA_LIST_NAME, sssJkkNyLst);
				// メッセージ内容
				message = systemService.getMessage(NSDConstant.MSGID_SYSTEM_ERROR);
				returnMap.put(NSDConstant.RESULT_MSG_NAME, message);

				// 終了ログ
				logger.info("SeisanshoJokyakuNaiyoController.selectByWhere 終了します。");

				return returnMap;
			}
		} catch (IllegalAccessException | InvocationTargetException e) {
			// エーラログ
			logger.info("SeisanshoJokyakuNaiyoController.selectByWhereでエラーが発生しました。");
			e.printStackTrace();
		}

		// サービス呼び出し
		sssJkkNyLst = seisanshoJokyakuNaiyoService.getJokyakuNaiyoInfo(seisanshoJokyakuNaiyo);
		// 処理結果データ
		returnMap.put(NSDConstant.RESULT_DATA_LIST_NAME, sssJkkNyLst);
		// メッセージ内容
		returnMap.put(NSDConstant.RESULT_MSG_NAME, NSDConstant.BLANK_STRING);

		// 終了ログ
		logger.info("SeisanshoJokyakuNaiyoController.selectByWhere 終了します。");

		return returnMap;
	}

	/**
	 * 除却（内容入力）照会処理
	 *
	 * @param reqMap
	 *            INPUTパラメータ
	 * @return 除却情報データ
	 * @exception IllegalAccessException
	 * @exception InvocationTargetException
	 * @version 1.00
	 */
	@RequestMapping(value = "/seisanshoJokyakuNaiyo-selectBySeisanShoNo", method = RequestMethod.POST)
	public Map<String, Object> selectBySeisanShoNo(@RequestParam Map<String, Object> reqMap) {

		// 開始ログ
		logger.info("SeisanshoJokyakuNaiyoController.selectBySeisanShoNo 開始します。");

		Map<String, Object> returnMap = new HashMap<String, Object>();

		SeisanshoJokyakuNaiyoShokai seisanshoJokyakuNaiyoShokai = new SeisanshoJokyakuNaiyoShokai();

		// 精算書より除却情報を取得する
		try {
			// Mapの情報をBeanのプロパティにセット
			BeanUtils.populate(seisanshoJokyakuNaiyoShokai, reqMap);

		} catch (IllegalAccessException | InvocationTargetException e) {
			// エーラログ
			logger.info("SeisanshoJokyakuNaiyoController.selectBySeisanShoNoでエラーが発生しました。");
		}

		// サービス呼び出し
		SeisanshoJokyakuNaiyoShokai sssJkkNySkDto = seisanshoJokyakuNaiyoService
				.getJokyakuInfoBySeisanShoNo(seisanshoJokyakuNaiyoShokai);

		// 処理結果データ
		returnMap.put(NSDConstant.RESULT_DATA_LIST_NAME, sssJkkNySkDto);
		// メッセージ内容
		returnMap.put(NSDConstant.RESULT_MSG_NAME, NSDConstant.BLANK_STRING);

		// 終了ログ
		logger.info("SeisanshoJokyakuNaiyoController.selectBySeisanShoNo 終了します。");

		return returnMap;
	}
}
