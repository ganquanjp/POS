/***********************************************************************
*
*業務名: 工事精算システム
*機能名: 除却（登録・修正・削除）(サービス処理)
*
*機能概要: 除却情報を処理する。
*
*JavaＶｅｒ：J2SE1.8.0準拠
*
*更新履歴: Ver.1.00 2018/03/06　NSD　新規作成
***********************************************************************/
package jp.co.nsd.nkssweb.service.seisanshojokyaku.impl;

import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.beanutils.BeanUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import jp.co.nsd.nkssweb.dao.KoteiSisan;
import jp.co.nsd.nkssweb.dao.SeisanshoJokyakuKoteiSisan;
import jp.co.nsd.nkssweb.dao.SeisanshoJokyakuNaiyo;
import jp.co.nsd.nkssweb.dao.SeisanshoJokyakuNaiyoShokai;
import jp.co.nsd.nkssweb.dao.mapper.SanshoMapper;
import jp.co.nsd.nkssweb.dao.mapper.SeisanshoJokyakuNaiyoMapper;
import jp.co.nsd.nkssweb.service.seisanshojokyaku.SeisanshoJokyakuNaiyoService;
import jp.co.nsd.nkssweb.utils.NSDConstant;

/**
 * 除却（内容入力）処理
 *
 * @see SeisanshoJokyakuNaiyoService
 * @version 1.00
 */
@Service
public class SeisanshoJokyakuNaiyoServiceImpl implements SeisanshoJokyakuNaiyoService {

	// ログ
	private Logger logger = LoggerFactory.getLogger(this.getClass());

	@Autowired
	private SeisanshoJokyakuNaiyoMapper seisanshoJokyakuNaiyoMapper;

	@Autowired
	private SanshoMapper sanshoMapper;

	/**
	 * 除却（内容入力）処理
	 *
	 * @param seisanshoJokyakuNaiyo
	 *            INPUTパラメータ
	 * @return sssJykList 除却情報データリスト
	 * @version 1.00
	 */
	public List<SeisanshoJokyakuNaiyo> getJokyakuNaiyoInfo(SeisanshoJokyakuNaiyo seisanshoJokyakuNaiyo) {

		// 開始ログ
		logger.info("SeisanshoJokyakuNaiyoServiceImpl.getJokyakuNaiyoInfo 開始します。");

		// 除却情報を取得する
		List<SeisanshoJokyakuNaiyo> sssJykNyList = seisanshoJokyakuNaiyoMapper.selectByWhere(seisanshoJokyakuNaiyo);

		for (int i = 1; i <= sssJykNyList.size(); i++) {
			// ROWNOを設定する
			sssJykNyList.get(i - 1).setRowNo(i);
		}

		// 終了ログ
		logger.info("SeisanshoJokyakuNaiyoServiceImpl.getJokyakuNaiyoInfo 終了します。");

		return sssJykNyList;
	}

	/**
	 * 除却内容入力（照会）処理
	 *
	 * @param seisanshoJokyakuNaiyoShokai
	 *            INPUTパラメータ
	 * @return SeisanshoJokyakuNaiyoShokai 除却情報データ
	 * @version 1.00
	 */
	public SeisanshoJokyakuNaiyoShokai getJokyakuInfoBySeisanShoNo(
			SeisanshoJokyakuNaiyoShokai seisanshoJokyakuNaiyoShokai) {

		// 開始ログ
		logger.info("SeisanshoJokyakuNaiyoServiceImpl.getJokyakuInfoBySeisanShoNo 開始します。");

		// 除却情報
		SeisanshoJokyakuNaiyoShokai resultDto = new SeisanshoJokyakuNaiyoShokai();
		// 除却固定資産情報
		SeisanshoJokyakuKoteiSisan sssJykKsDto;

		// 除却資産情報を取得する
		List<SeisanshoJokyakuNaiyoShokai> sssJykNySkList = seisanshoJokyakuNaiyoMapper
				.selectBySeisanShoNo(seisanshoJokyakuNaiyoShokai);

		List<SeisanshoJokyakuKoteiSisan> sssJykKsLst = new ArrayList<>();

		for (int i = 0; i < sssJykNySkList.size(); i++) {
			// 除却資産情報
			SeisanshoJokyakuNaiyoShokai sssJykNySkDto = sssJykNySkList.get(i);

			// Mapの情報をBeanのプロパティにセット
			try {
				BeanUtils.copyProperties(resultDto, sssJykNySkDto);

				KoteiSisan koteiSisan = new KoteiSisan();

				koteiSisan.setKoteiCod(sssJykNySkDto.getMotoKoteiShisanId());
				// 固定資産情報を取得する
				List<KoteiSisan> ksLstDto = sanshoMapper.selectKoteiSisan(koteiSisan);

				// 固定資産情報取得できないの場合
				if (null != ksLstDto && ksLstDto.size() > 0) {
					// 固定資産情報
					KoteiSisan ksDto = ksLstDto.get(0);

					sssJykKsDto = new SeisanshoJokyakuKoteiSisan();
					// ROWNO
					sssJykKsDto.setRowNo(i + 1);
					// 固定資産番号
					sssJykKsDto.setKoteiNo(ksDto.getKoteiNo());
					// 固定資産番号
					sssJykKsDto.setKoteiKnj(ksDto.getKoteiKnj());
					// 取得年月日
					sssJykKsDto.setGetYmd(ksDto.getGetYmd());
					// 元_数量
					sssJykKsDto.setMeiSu(ksDto.getMeiSu());
					// 単位
					sssJykKsDto.setTaniKnj(ksDto.getTaniKnj());
					// 元_取得価額
					sssJykKsDto.setGetkgkYen(ksDto.getGetkgkYen());
					// 除却区分
					sssJykKsDto.setJokyakuKbnNm(sssJykNySkDto.getJokyakuKbnNm());

					// 除却区分
					if (NSDConstant.STRING_0.equals(ksDto.getKoshiKbn())) {
						// 0：全部除却
						sssJykKsDto.setJokyakuKbnNm(NSDConstant.JOKYAKU_KBN_0);
					} else if (NSDConstant.STRING_1.equals(ksDto.getKoshiKbn())) {
						// 1：一部除却
						sssJykKsDto.setJokyakuKbnNm(NSDConstant.JOKYAKU_KBN_1);
					} else {
						// 処理なし
					}

					// 除却種別コード
					sssJykKsDto.setJokyakuShubetsuCd(sssJykNySkDto.getJokyakuShubetsuCd());
					// 除却種別名称
					sssJykKsDto.setJokyakuShubetsuNm(sssJykNySkDto.getJokyakuShubetsuNm());
					// 除_数量
					sssJykKsDto.setJokyakuSuryo(ksDto.getGetkgkYen());
					// 除_取得価額
					sssJykKsDto.setJokyakuGaku(sssJykNySkDto.getJokyakuGaku());
					// 固定資産情報を追加
					sssJykKsLst.add(sssJykKsDto);
				}

			} catch (IllegalAccessException | InvocationTargetException e) {
				// 終了ログ
				logger.info("SeisanshoJokyakuNaiyoServiceImpl.getJokyakuInfoBySeisanShoNo 終了します。");
			}

		}
		// 固定資産情報リスト
		resultDto.setKoteiSisanLst(sssJykKsLst);

		// 終了ログ
		logger.info("SeisanshoJokyakuNaiyoServiceImpl.getJokyakuInfoBySeisanShoNo 終了します。");

		return resultDto;
	}

}
