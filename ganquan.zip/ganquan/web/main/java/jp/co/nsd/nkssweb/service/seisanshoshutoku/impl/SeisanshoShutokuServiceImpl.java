package jp.co.nsd.nkssweb.service.seisanshoshutoku.impl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import jp.co.nsd.nkssweb.dao.Kss005;
import jp.co.nsd.nkssweb.dao.SeisanshoShutokuKensaku;
import jp.co.nsd.nkssweb.dao.SeisanshoShutokuShokai;
import jp.co.nsd.nkssweb.dao.mapper.Kss005Mapper;
import jp.co.nsd.nkssweb.dao.mapper.SeisanshoShutokuMapper;
import jp.co.nsd.nkssweb.service.seisanshoshutoku.SeisanshoShutokuService;

@Service
public class SeisanshoShutokuServiceImpl implements SeisanshoShutokuService {

	@Autowired
	private SeisanshoShutokuMapper seisanshoShutokuMapper;

	@Autowired
	private Kss005Mapper kss005Mapper;

	@Override
	public List<SeisanshoShutokuKensaku> getSeisanshoShutokuKensaku(SeisanshoShutokuKensaku selectCondition) {
		List<SeisanshoShutokuKensaku> sssStkList = new ArrayList<SeisanshoShutokuKensaku>();

		sssStkList = seisanshoShutokuMapper.kensaku(selectCondition);

		for (int i = 1; i <= sssStkList.size(); i++) {
			sssStkList.get(i - 1).setRowNo(i);
		}

		return sssStkList;

	}

	@Override
	public List<SeisanshoShutokuShokai> getSeisanshoShutokuShokai(SeisanshoShutokuShokai selectCondition) {

		List<SeisanshoShutokuShokai> sssStkList = new ArrayList<SeisanshoShutokuShokai>();

		sssStkList = seisanshoShutokuMapper.shokai(selectCondition);

		for (int i = 1; i <= sssStkList.size(); i++) {
			sssStkList.get(i - 1).setRowNo(i);
		}

		return sssStkList;

	}

	@Override
	public void insert(Kss005 record) {

		kss005Mapper.insert(record);

	}

}
