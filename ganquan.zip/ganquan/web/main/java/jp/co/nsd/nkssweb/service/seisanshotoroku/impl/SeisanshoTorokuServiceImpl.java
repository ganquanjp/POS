package jp.co.nsd.nkssweb.service.seisanshotoroku.impl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import jp.co.nsd.nkssweb.dao.Kss002;
import jp.co.nsd.nkssweb.dao.Kss004;
import jp.co.nsd.nkssweb.dao.SeisanshoToroku;
import jp.co.nsd.nkssweb.dao.mapper.Kss002Mapper;
import jp.co.nsd.nkssweb.dao.mapper.Kss004Mapper;
import jp.co.nsd.nkssweb.dao.mapper.SeisanshoTorokuMapper;
import jp.co.nsd.nkssweb.service.seisanshotoroku.SeisanshoTorokuService;

@Service
public class SeisanshoTorokuServiceImpl implements SeisanshoTorokuService {

	@Autowired
	private SeisanshoTorokuMapper sssTrkMapper;

	@Autowired
	private Kss002Mapper kss002Mapper;

	@Autowired
	private Kss004Mapper kss004Mapper;

	@Override
	public List<SeisanshoToroku> getSeisanshoTorokuKensaku(SeisanshoToroku selectCondition) {

		List<SeisanshoToroku> sssTrkList = new ArrayList<SeisanshoToroku>();

		sssTrkList = sssTrkMapper.selectByWhere(selectCondition);

		for (int i = 1; i <= sssTrkList.size(); i++) {
			sssTrkList.get(i - 1).setRowNo(i);
		}

		return sssTrkList;

	}

	@Override
	public List<SeisanshoToroku> getSeisanshoTorokuShokai(SeisanshoToroku selectCondition) {

		List<SeisanshoToroku> sssTrkList = new ArrayList<SeisanshoToroku>();

		sssTrkList = sssTrkMapper.selectByKey(selectCondition);

		for (int i = 1; i <= sssTrkList.size(); i++) {
			sssTrkList.get(i - 1).setRowNo(i);
		}

		return sssTrkList;

	}

	@Override
	public void insertSeisansho(Kss002 kss002, Kss004 kss004) {

		kss002Mapper.insert(kss002);

		kss004Mapper.insert(kss004);

	}

}
