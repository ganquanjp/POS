package jp.co.nsd.nkssweb.controller;


import org.springframework.web.bind.annotation.RestController;
import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import jp.co.nsd.nkssweb.dao.KoteshisanDaityo;
import jp.co.nsd.nkssweb.service.KoteshisanDaityoService;
import jp.co.nsd.nkssweb.service.SystemService;
import jp.co.nsd.nkssweb.utils.NSDConstant;


@RestController
public class KoteshisanDaityoController {
	// ログ
	private Logger logger = LoggerFactory.getLogger(this.getClass());

	@Autowired
	private KoteshisanDaityoService koteshisanDaityoService;

	protected SystemService systemService;

	/*
	 * 精算書登録・件名即時反映
	 */
	@RequestMapping(value = "/koteshisanDaityo-selectByWhere", method = RequestMethod.POST)
	public Map<String, Object> selectByBat(@RequestParam Map<String, Object> reqMap) {

		// 開始ログ
		logger.info("KoteshisanDaityoController.selectByWhere 開始します。");

		Map<String, Object> returnMap = new HashMap<String, Object>();

		KoteshisanDaityo koteshisanDaityo = new KoteshisanDaityo();

		// サービス呼び出し
		koteshisanDaityoService.getKenmeiInfo(koteshisanDaityo);
		// 処理結果データ
		returnMap.put(NSDConstant.RESULT_DATA_LIST_NAME, NSDConstant.BLANK_STRING);
		// メッセージ内容
		returnMap.put(NSDConstant.RESULT_MSG_NAME, NSDConstant.BLANK_STRING);

		// 終了ログ
		logger.info("KoteshisanDaityoController.selectByWhere 終了します。");

		return returnMap;
	}

}
