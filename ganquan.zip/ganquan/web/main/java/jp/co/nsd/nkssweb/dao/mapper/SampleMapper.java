package jp.co.nsd.nkssweb.dao.mapper;

import java.util.List;

import jp.co.nsd.nkssweb.dao.Sample;

public interface SampleMapper {
    int deleteByPrimaryKey(String userId);

    int insert(Sample record);

    int insertSelective(Sample record);

    List<Sample> selectAll();

    List<Sample> selectByWhere(Sample record);

    Sample selectByPrimaryKey(String userId);

    int updateByPrimaryKeySelective(Sample record);

    int updateByPrimaryKey(Sample record);

    void callTestFunction(Sample record);
}