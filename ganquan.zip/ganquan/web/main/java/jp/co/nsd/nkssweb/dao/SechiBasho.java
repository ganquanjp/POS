package jp.co.nsd.nkssweb.dao;

public class SechiBasho {

	// 行番号
	private int rowNo;

	// 設置場所コード
	private String sechiBashoCd;

	// 設置場所名称
	private String sechiBashoNm;

	public int getRowNo() {
		return rowNo;
	}

	public void setRowNo(int rowNo) {
		this.rowNo = rowNo;
	}

	public String getSechiBashoCd() {
		return sechiBashoCd;
	}

	public void setSechiBashoCd(String sechiBashoCd) {
		this.sechiBashoCd = sechiBashoCd;
	}

	public String getSechiBashoNm() {
		return sechiBashoNm;
	}

	public void setSechiBashoNm(String sechiBashoNm) {
		this.sechiBashoNm = sechiBashoNm;
	}

}