package jp.co.nsd.nkssweb.dao;

import java.math.BigDecimal;
import java.util.List;

public class SeisanshoShoninShokai {

	// 行番
	private int rowNo;

	// 経理審査否認理由
	private String riyu;

	// 精算書番号
	private String SeisanShoNo;

	// 処理No
	private BigDecimal hansu;

	// 使用開始年月日
	private String siyoStartYmd;

	// 取得価額合計
	private String shutokuKagakuGoke;

	// 承認ステータス
	private String shoninSattus;

	// 工事件名
	private String kenmeiNm;

	// 固定資産番号
	private String koteiShisanNo;

	// 固定資産名称
	private String koteiShisanNm;

	// 取得年月日
	private String shutokuYmd;

	// 取得価額
	private String shutokuKagaku;

	// 取得資産明細情報
	private List<SeisanshoShoninshutokuSisan> shutokuSisanLst;

	public int getRowNo() {
		return rowNo;
	}

	public void setRowNo(int rowNo) {
		this.rowNo = rowNo;
	}

	public String getRiyu() {
		return riyu;
	}

	public void setRiyu(String riyu) {
		this.riyu = riyu;
	}

	public String getSeisanShoNo() {
		return SeisanShoNo;
	}

	public void setSeisanShoNo(String seisanShoNo) {
		SeisanShoNo = seisanShoNo;
	}

	public BigDecimal getHansu() {
		return hansu;
	}

	public void setHansu(BigDecimal hansu) {
		this.hansu = hansu;
	}

	public String getSiyoStartYmd() {
		return siyoStartYmd;
	}

	public void setSiyoStartYmd(String siyoStartYmd) {
		this.siyoStartYmd = siyoStartYmd;
	}

	public String getShutokuKagakuGoke() {
		return shutokuKagakuGoke;
	}

	public void setShutokuKagakuGoke(String shutokuKagakuGoke) {
		this.shutokuKagakuGoke = shutokuKagakuGoke;
	}

	public String getShoninSattus() {
		return shoninSattus;
	}

	public void setShoninSattus(String shoninSattus) {
		this.shoninSattus = shoninSattus;
	}

	public String getKenmeiNm() {
		return kenmeiNm;
	}

	public void setKenmeiNm(String kenmeiNm) {
		this.kenmeiNm = kenmeiNm;
	}

	public String getKoteiShisanNo() {
		return koteiShisanNo;
	}

	public void setKoteiShisanNo(String koteiShisanNo) {
		this.koteiShisanNo = koteiShisanNo;
	}

	public String getKoteiShisanNm() {
		return koteiShisanNm;
	}

	public void setKoteiShisanNm(String koteiShisanNm) {
		this.koteiShisanNm = koteiShisanNm;
	}

	public String getShutokuYmd() {
		return shutokuYmd;
	}

	public void setShutokuYmd(String shutokuYmd) {
		this.shutokuYmd = shutokuYmd;
	}

	public String getShutokuKagaku() {
		return shutokuKagaku;
	}

	public void setShutokuKagaku(String shutokuKagaku) {
		this.shutokuKagaku = shutokuKagaku;
	}

	public List<SeisanshoShoninshutokuSisan> getShutokuSisanLst() {
		return shutokuSisanLst;
	}

	public void setShutokuSisanLst(List<SeisanshoShoninshutokuSisan> shutokuSisanLst) {
		this.shutokuSisanLst = shutokuSisanLst;
	}






}