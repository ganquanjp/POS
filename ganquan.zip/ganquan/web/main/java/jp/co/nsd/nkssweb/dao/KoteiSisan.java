package jp.co.nsd.nkssweb.dao;

public class KoteiSisan {

	// 行番号
	private int rowNo;

	// 固定資産番号
	private String koteiNo;

	// 親固定資産番号
	private String koteioyaNo;

	// 固定資産名称
	private String koteiKnj;

	// 固定資産ID
	private String koteiCod;

	// 管理箇所名称
	private String kanriKnj;

	// 枝番
	private String edaBan;

	// 摘要１
	private String tekiyo1;

	// 摘要２
	private String tekiyo2;

	// 摘要３
	private String tekiyo3;

	// 摘要４
	private String tekiyo4;

	// 摘要５
	private String tekiyo5;

	// 種類
	private String syurui;

	// 構造
	private String kouzo;

	// 資産単位
	private String sisanTani;

	// 科目１
	private String kamoku1;

	// 科目２
	private String kamoku2;

	// 科目３
	private String kamoku3;

	// 工事担当者
	private String kojiTantosya;

	// 工事担当箇所
	private String kojiTantokasyo;

	// 物品数量
	private String meiSu;

	// 取得価格
	private String getkgkYen;

	// 取得年月日
	private String getYmd;

	// 使用開始年月日
	private String useYmd;

	// 設置場所名称
	private String bashoKnj;

	// 単位名称
	private String taniKnj;

	// 物品
	private String butuhin;

	// 工費
	private String kohi;

	// 総係費
	private String sokeh;

	// 取引先名称
	private String torihikiKnj;

	// 精算書番号
	private String seisanShoNo;

	// 精算箇所
	private String soshikiRenNm;

	// 登録者コード
	private String seisanEntryUserId;

	// 登録者氏名
	private String torokusyaNm;

	// 工事件名コード
	private String kenmeiCd;

	// 工事件名
	private String kmouwkKnj;

	// 使用開始年月日(From)
	private String useYmdFrom;

	// 使用開始年月日(To)
	private String useYmdTo;

	// 取得年月日(From)
	private String getYmdFrom;

	// 取得年月日(To)
	private String getYmdTo;

	// 除却精算制御区分
	private String jkkseiKbn;

	// 子資産残
	private String koshiKbn;

	public int getRowNo() {
		return rowNo;
	}

	public void setRowNo(int rowNo) {
		this.rowNo = rowNo;
	}

	public String getKoteiNo() {
		return koteiNo;
	}

	public void setKoteiNo(String koteiNo) {
		this.koteiNo = koteiNo;
	}

	public String getKoteioyaNo() {
		return koteioyaNo;
	}

	public void setKoteioyaNo(String koteioyaNo) {
		this.koteioyaNo = koteioyaNo;
	}

	public String getKoteiKnj() {
		return koteiKnj;
	}

	public void setKoteiKnj(String koteiKnj) {
		this.koteiKnj = koteiKnj;
	}

	public String getKoteiCod() {
		return koteiCod;
	}

	public void setKoteiCod(String koteiCod) {
		this.koteiCod = koteiCod;
	}

	public String getKanriKnj() {
		return kanriKnj;
	}

	public void setKanriKnj(String kanriKnj) {
		this.kanriKnj = kanriKnj;
	}

	public String getEdaBan() {
		return edaBan;
	}

	public void setEdaBan(String edaBan) {
		this.edaBan = edaBan;
	}

	public String getTekiyo1() {
		return tekiyo1;
	}

	public void setTekiyo1(String tekiyo1) {
		this.tekiyo1 = tekiyo1;
	}

	public String getTekiyo2() {
		return tekiyo2;
	}

	public void setTekiyo2(String tekiyo2) {
		this.tekiyo2 = tekiyo2;
	}

	public String getTekiyo3() {
		return tekiyo3;
	}

	public void setTekiyo3(String tekiyo3) {
		this.tekiyo3 = tekiyo3;
	}

	public String getTekiyo4() {
		return tekiyo4;
	}

	public void setTekiyo4(String tekiyo4) {
		this.tekiyo4 = tekiyo4;
	}

	public String getTekiyo5() {
		return tekiyo5;
	}

	public void setTekiyo5(String tekiyo5) {
		this.tekiyo5 = tekiyo5;
	}

	public String getSyurui() {
		return syurui;
	}

	public void setSyurui(String syurui) {
		this.syurui = syurui;
	}

	public String getKouzo() {
		return kouzo;
	}

	public void setKouzo(String kouzo) {
		this.kouzo = kouzo;
	}

	public String getSisanTani() {
		return sisanTani;
	}

	public void setSisanTani(String sisanTani) {
		this.sisanTani = sisanTani;
	}

	public String getKamoku1() {
		return kamoku1;
	}

	public void setKamoku1(String kamoku1) {
		this.kamoku1 = kamoku1;
	}

	public String getKamoku2() {
		return kamoku2;
	}

	public void setKamoku2(String kamoku2) {
		this.kamoku2 = kamoku2;
	}

	public String getKamoku3() {
		return kamoku3;
	}

	public void setKamoku3(String kamoku3) {
		this.kamoku3 = kamoku3;
	}

	public String getKojiTantosya() {
		return kojiTantosya;
	}

	public void setKojiTantosya(String kojiTantosya) {
		this.kojiTantosya = kojiTantosya;
	}

	public String getKojiTantokasyo() {
		return kojiTantokasyo;
	}

	public void setKojiTantokasyo(String kojiTantokasyo) {
		this.kojiTantokasyo = kojiTantokasyo;
	}

	public String getMeiSu() {
		return meiSu;
	}

	public void setMeiSu(String meiSu) {
		this.meiSu = meiSu;
	}

	public String getGetkgkYen() {
		return getkgkYen;
	}

	public void setGetkgkYen(String getkgkYen) {
		this.getkgkYen = getkgkYen;
	}

	public String getGetYmd() {
		return getYmd;
	}

	public void setGetYmd(String getYmd) {
		this.getYmd = getYmd;
	}

	public String getUseYmd() {
		return useYmd;
	}

	public void setUseYmd(String useYmd) {
		this.useYmd = useYmd;
	}

	public String getBashoKnj() {
		return bashoKnj;
	}

	public void setBashoKnj(String bashoKnj) {
		this.bashoKnj = bashoKnj;
	}

	public String getTaniKnj() {
		return taniKnj;
	}

	public void setTaniKnj(String taniKnj) {
		this.taniKnj = taniKnj;
	}

	public String getButuhin() {
		return butuhin;
	}

	public void setButuhin(String butuhin) {
		this.butuhin = butuhin;
	}

	public String getKohi() {
		return kohi;
	}

	public void setKohi(String kohi) {
		this.kohi = kohi;
	}

	public String getSokeh() {
		return sokeh;
	}

	public void setSokeh(String sokeh) {
		this.sokeh = sokeh;
	}

	public String getTorihikiKnj() {
		return torihikiKnj;
	}

	public void setTorihikiKnj(String torihikiKnj) {
		this.torihikiKnj = torihikiKnj;
	}

	public String getSeisanShoNo() {
		return seisanShoNo;
	}

	public void setSeisanShoNo(String seisanShoNo) {
		this.seisanShoNo = seisanShoNo;
	}

	public String getSoshikiRenNm() {
		return soshikiRenNm;
	}

	public void setSoshikiRenNm(String soshikiRenNm) {
		this.soshikiRenNm = soshikiRenNm;
	}

	public String getSeisanEntryUserId() {
		return seisanEntryUserId;
	}

	public void setSeisanEntryUserId(String seisanEntryUserId) {
		this.seisanEntryUserId = seisanEntryUserId;
	}

	public String getTorokusyaNm() {
		return torokusyaNm;
	}

	public void setTorokusyaNm(String torokusyaNm) {
		this.torokusyaNm = torokusyaNm;
	}

	public String getKenmeiCd() {
		return kenmeiCd;
	}

	public void setKenmeiCd(String kenmeiCd) {
		this.kenmeiCd = kenmeiCd;
	}

	public String getKmouwkKnj() {
		return kmouwkKnj;
	}

	public void setKmouwkKnj(String kmouwkKnj) {
		this.kmouwkKnj = kmouwkKnj;
	}

	public String getUseYmdFrom() {
		return useYmdFrom;
	}

	public void setUseYmdFrom(String useYmdFrom) {
		this.useYmdFrom = useYmdFrom;
	}

	public String getUseYmdTo() {
		return useYmdTo;
	}

	public void setUseYmdTo(String useYmdTo) {
		this.useYmdTo = useYmdTo;
	}

	public String getGetYmdFrom() {
		return getYmdFrom;
	}

	public void setGetYmdFrom(String getYmdFrom) {
		this.getYmdFrom = getYmdFrom;
	}

	public String getGetYmdTo() {
		return getYmdTo;
	}

	public void setGetYmdTo(String getYmdTo) {
		this.getYmdTo = getYmdTo;
	}

	public String getJkkseiKbn() {
		return jkkseiKbn;
	}

	public void setJkkseiKbn(String jkkseiKbn) {
		this.jkkseiKbn = jkkseiKbn;
	}

	public String getKoshiKbn() {
		return koshiKbn;
	}

	public void setKoshiKbn(String koshiKbn) {
		this.koshiKbn = koshiKbn;
	}





}