/***********************************************************************
*
*業務名: 工事精算システム
*機能名: 除却（承認）(サービス処理)
*
*機能概要: 除却（承認）情報を処理する。
*
*JavaＶｅｒ：J2SE1.8.0準拠
*
*更新履歴: Ver.1.00 2018/03/06　NSD　新規作成
***********************************************************************/
package jp.co.nsd.nkssweb.service.seisanshojokyaku.impl;

import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.beanutils.BeanUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import jp.co.nsd.nkssweb.dao.KoteiSisan;
import jp.co.nsd.nkssweb.dao.SeisanshoJokyakuKoteiSisan;
import jp.co.nsd.nkssweb.dao.SeisanshoJokyakuShonin;
import jp.co.nsd.nkssweb.dao.SeisanshoJokyakuShoninShokai;
import jp.co.nsd.nkssweb.dao.mapper.SanshoMapper;
import jp.co.nsd.nkssweb.dao.mapper.SeisanshoJokyakuShoninMapper;
import jp.co.nsd.nkssweb.service.seisanshojokyaku.SeisanshoJokyakuShoninService;
import jp.co.nsd.nkssweb.utils.NSDCommUtils;

/**
 * 除却（承認）処理
 *
 * @see SeisanshoJokyakuShoninService
 * @version 1.00
 */
@Service
public class SeisanshoJokyakuShoninServiceImpl implements SeisanshoJokyakuShoninService {

	// ログ
	private Logger logger = LoggerFactory.getLogger(this.getClass());

	@Autowired
	private SeisanshoJokyakuShoninMapper seisanshoJokyakuShoninMapper;

	@Autowired
	private SanshoMapper sanshoMapper;

	/**
	 * 除却（承認）検索処理
	 *
	 * @param SeisanshoJokyakuShonin
	 *            INPUTパラメータ
	 * @return sssJykList 除却情報データリスト
	 * @version 1.00
	 */
	public List<SeisanshoJokyakuShonin> getJokyakuShoninInfo(SeisanshoJokyakuShonin seisanshoJokyakuShonin) {

		// 開始ログ
		logger.info("SeisanshoJokyakuShoninServiceImpl.getJokyakuSeisaiInfo 開始します。");

		// 除却情報を取得する
		List<SeisanshoJokyakuShonin> sssJykSnList = seisanshoJokyakuShoninMapper.selectByWhere(seisanshoJokyakuShonin);

		for (int i = 0; i < sssJykSnList.size(); i++) {

			SeisanshoJokyakuShonin sssJykSn = sssJykSnList.get(i);

			// ROWNOを設定する
			sssJykSn.setRowNo(i + 1);

			// 承認状態名称
			sssJykSn.setShoninJotai(NSDCommUtils.getShoninJotai(sssJykSn.getShoninSattus()));
		}

		// 終了ログ
		logger.info("SeisanshoJokyakuShoninServiceImpl.getJokyakuSeisaiInfo 終了します。");

		return sssJykSnList;
	}

	/**
	 * 除却承認（照会）処理
	 *
	 * @param seisanshoJokyakuShoninShokai
	 *            INPUTパラメータ
	 * @return SeisanshoJokyakuShoninShokai 除却情報データ
	 * @version 1.00
	 */
	public SeisanshoJokyakuShoninShokai getJokyakuInfoBySeisanShoNo(
			SeisanshoJokyakuShoninShokai seisanshoJokyakuShoninShokai) {
		// 開始ログ
		logger.info("SeisanshoJokyakuShoninServiceImpl.getJokyakuInfoBySeisanShoNo 開始します。");

		// 除却情報
		SeisanshoJokyakuShoninShokai resultDto = new SeisanshoJokyakuShoninShokai();
		// 除却固定資産情報
		SeisanshoJokyakuKoteiSisan sssJykKsDto;

		// 除却資産情報を取得する
		List<SeisanshoJokyakuShoninShokai> sssJykSnSkList = seisanshoJokyakuShoninMapper
				.selectBySeisanShoNo(seisanshoJokyakuShoninShokai);

		List<SeisanshoJokyakuKoteiSisan> sssJykKsLst = new ArrayList<>();

		for (int i = 0; i < sssJykSnSkList.size(); i++) {
			// 除却資産情報
			SeisanshoJokyakuShoninShokai sssJykSnSkDto = sssJykSnSkList.get(i);

			// Mapの情報をBeanのプロパティにセット
			try {
				BeanUtils.copyProperties(resultDto, sssJykSnSkDto);

				// 承認状態名称
				resultDto.setShoninJotai(NSDCommUtils.getShoninJotai(sssJykSnSkDto.getShoninSattus()));

				KoteiSisan koteiSisan = new KoteiSisan();

				koteiSisan.setKoteiCod(sssJykSnSkDto.getMotoKoteiShisanId());
				// 固定資産情報を取得する
				List<KoteiSisan> ksLstDto = sanshoMapper.selectKoteiSisan(koteiSisan);

				// 固定資産情報取得できないの場合
				if (null != ksLstDto && ksLstDto.size() > 0) {
					// 固定資産情報
					KoteiSisan ksDto = ksLstDto.get(0);

					sssJykKsDto = new SeisanshoJokyakuKoteiSisan();
					// ROWNO
					sssJykKsDto.setRowNo(i + 1);
					// 固定資産番号
					sssJykKsDto.setKoteiNo(ksDto.getKoteiNo());
					// 固定資産名称
					sssJykKsDto.setKoteiKnj(ksDto.getKoteiKnj());
					// 取得年月日
					sssJykKsDto.setGetYmd(ksDto.getGetYmd());
					// 使用開始年月日
					sssJykKsDto.setUseYmd(ksDto.getUseYmd());
					// 除_取得価額
					sssJykKsDto.setJokyakuGaku(sssJykSnSkDto.getJokyakuGaku());
					// 固定資産情報を追加
					sssJykKsLst.add(sssJykKsDto);
				}

			} catch (IllegalAccessException | InvocationTargetException e) {
				// 終了ログ
				logger.info("SeisanshoJokyakuShoninServiceImpl.getJokyakuInfoBySeisanShoNo 終了します。");
			}
		}
		// 固定資産情報リスト
		resultDto.setKoteiSisanLst(sssJykKsLst);

		// 終了ログ
		logger.info("SeisanshoJokyakuShoninServiceImpl.getJokyakuInfoBySeisanShoNo 終了します。");

		return resultDto;
	}

}
