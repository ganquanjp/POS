/***********************************************************************
*
*業務名: 参照ボタン処理
*機能名: 参照ボタン処理(サービス処理)
*
*機能概要: 参照ボタンを処理する。
*
*JavaＶｅｒ：J2SE1.8.0準拠
*
*更新履歴: Ver.1.00 2018/03/06　NSD　新規作成
***********************************************************************/
package jp.co.nsd.nkssweb.service.impl;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import jp.co.nsd.nkssweb.dao.KanriFutanks;
import jp.co.nsd.nkssweb.dao.KoteiSisan;
import jp.co.nsd.nkssweb.dao.SechiBasho;
import jp.co.nsd.nkssweb.dao.TorihikiSaki;
import jp.co.nsd.nkssweb.dao.mapper.SanshoMapper;
import jp.co.nsd.nkssweb.service.SanshoService;
import jp.co.nsd.nkssweb.service.seisanshoshutoku.SeisanshoShoninService;

/**
 * 参照ボタン処理用サービス
 *
 * @see SeisanshoShoninService
 * @version 1.00
 */
@Service
public class SanshoServiceImpl implements SanshoService {

	// ログ
	private Logger logger = LoggerFactory.getLogger(this.getClass());

	@Autowired
	private SanshoMapper sanshoMapper;

	/**
	 * 固定資産（検索）処理
	 *
	 * @param koteiSisan
	 *            INPUTパラメータ
	 * @return KSList 固定資産情報データリスト
	 * @version 1.00
	 */
	public List<KoteiSisan> getKoteiSisanInfo(KoteiSisan koteiSisan) {

		// 開始ログ
		logger.info("getKoteiSisanInfo 開始します。");

		// 除却情報を取得する
		List<KoteiSisan> KSList = sanshoMapper.selectKoteiSisan(koteiSisan);

		for (int i = 1; i <= KSList.size(); i++) {
			// ROWNOを設定する
			KSList.get(i - 1).setRowNo(i);
		}

		// 終了ログ
		logger.info("getKoteiSisanInfo 終了します。");

		return KSList;
	}

	/**
	 * 取引先（検索）処理
	 *
	 * @param torihikiSaki
	 * @return
	 */
	public List<TorihikiSaki> getTorihikiSakiInfo(TorihikiSaki torihikiSaki) {

		// 開始ログ
		logger.info("getTorihikiSakiInfo 開始します。");

		// 除却情報を取得する
		List<TorihikiSaki> trhksList = sanshoMapper.selectTorihikiSaki(torihikiSaki);

		for (int i = 1; i <= trhksList.size(); i++) {
			// ROWNOを設定する
			trhksList.get(i - 1).setRowNo(i);
		}

		// 終了ログ
		logger.info("getTorihikiSakiInfo 終了します。");

		return trhksList;
	}

	/**
	 * 管理箇所/負担箇所検索処理
	 *
	 * @param kanriFutanks
	 *            INPUTパラメータ
	 * @return kfhList 管理箇所/負担箇所情報データリスト
	 * @version 1.00
	 */
	public List<KanriFutanks> getKanriFutanInfo (KanriFutanks kanriFutanks) {

		// 開始ログ
		logger.info("getKanriFutanInfo 開始します。");

		// 除却情報を取得する
		List<KanriFutanks> kfhList = sanshoMapper.selectKanriFutanks(kanriFutanks);

		for (int i = 1; i <= kfhList.size(); i++) {
			// ROWNOを設定する
			kfhList.get(i - 1).setRowNo(i);
		}

		// 終了ログ
		logger.info("getKanriFutanInfo 終了します。");

		return kfhList;
	}

	/**
	 * 設置場所（検索）処理
	 *
	 * @param sechiBasho
	 *            INPUTパラメータ
	 * @return KSList 設置場所情報データリスト
	 * @version 1.00
	 */
	public List<SechiBasho> getSechiBashoInfo(SechiBasho sechiBasho) {

		// 開始ログ
		logger.info("getSechiBashoInfo 開始します。");

		// 除却情報を取得する
		List<SechiBasho> scbsList = sanshoMapper.selectSechiBasho(sechiBasho);

		for (int i = 1; i <= scbsList.size(); i++) {
			// ROWNOを設定する
			scbsList.get(i - 1).setRowNo(i);
		}

		// 終了ログ
		logger.info("getSechiBashoInfo 終了します。");

		return scbsList;
	}
}
