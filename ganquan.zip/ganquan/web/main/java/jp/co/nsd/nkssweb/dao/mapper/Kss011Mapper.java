package jp.co.nsd.nkssweb.dao.mapper;

import jp.co.nsd.nkssweb.dao.Kss011;

public interface Kss011Mapper {
    int deleteByPrimaryKey(String soshikiCd);

    int insert(Kss011 record);

    int insertSelective(Kss011 record);

    Kss011 selectByPrimaryKey(String soshikiCd);

    int updateByPrimaryKeySelective(Kss011 record);

    int updateByPrimaryKey(Kss011 record);

}