package jp.co.nsd.nkssweb.dao;

import java.math.BigDecimal;

public class Abda09 {
	//組織定数情報

	// 組織コード
	private String ksSoshikCod;

	// 適用期間(From)
	private String ksTekiyfYmd;

	// 適用期間(To)
	private String ksTekiytYmd;

	// 発行組織フラグ
	private String ksSiyoFlg;

	// 責任組織使用可能フラグ
	private String ksSeksokFlg;

	// 責任組織初期値
	private String ksSeksosDef;

	// 組織名称
	private String ksSoshikKnj;

	// 資金予算代行権限フラグ
	private String ksSydaikFlg;

	// 上位組織コード
	private String ksJoisosCod;

	// 検索可能上位組織コード
	private String ksShuyk1Cod;

	// 管理会計上位組織コード
	private String ksShuyk2Cod;

	// 集約組織コード３
	private String ksShuyk3Cod;

	// 経理審査承認組織コード
	private String ksKsssosCod;

	// 小払精算方法区分
	private String ksKossanCbn;

	// 出納組織区分
	private String ksStsoshCbn;

	// 出納組織コード
	private String ksStsoshCod;

	// 出納先組織使用可能フラグ
	private String ksStssosFlg;

	// 組織区分
	private String ksSoshikKbn;

	// 適用期間(To)無効フラグ
	private String ksTekingFlg;

	// 更新カウンタ
	private BigDecimal ksUpdateCnt;

	// 登録日時
	private String ksTorokDh;

	// 登録者コード
	private String ksTorshaCod;

	// 更新日時
	private String ksUpdateDh;

	// 更新者コード
	private String ksUpdshaCod;

	public String getKsSoshikCod() {
		return ksSoshikCod;
	}

	public void setKsSoshikCod(String ksSoshikCod) {
		this.ksSoshikCod = ksSoshikCod;
	}

	public String getKsTekiyfYmd() {
		return ksTekiyfYmd;
	}

	public void setKsTekiyfYmd(String ksTekiyfYmd) {
		this.ksTekiyfYmd = ksTekiyfYmd;
	}

	public String getKsTekiytYmd() {
		return ksTekiytYmd;
	}

	public void setKsTekiytYmd(String ksTekiytYmd) {
		this.ksTekiytYmd = ksTekiytYmd;
	}

	public String getKsSiyoFlg() {
		return ksSiyoFlg;
	}

	public void setKsSiyoFlg(String ksSiyoFlg) {
		this.ksSiyoFlg = ksSiyoFlg;
	}

	public String getKsSeksokFlg() {
		return ksSeksokFlg;
	}

	public void setKsSeksokFlg(String ksSeksokFlg) {
		this.ksSeksokFlg = ksSeksokFlg;
	}

	public String getKsSeksosDef() {
		return ksSeksosDef;
	}

	public void setKsSeksosDef(String ksSeksosDef) {
		this.ksSeksosDef = ksSeksosDef;
	}

	public String getKsSoshikKnj() {
		return ksSoshikKnj;
	}

	public void setKsSoshikKnj(String ksSoshikKnj) {
		this.ksSoshikKnj = ksSoshikKnj;
	}

	public String getKsSydaikFlg() {
		return ksSydaikFlg;
	}

	public void setKsSydaikFlg(String ksSydaikFlg) {
		this.ksSydaikFlg = ksSydaikFlg;
	}

	public String getKsJoisosCod() {
		return ksJoisosCod;
	}

	public void setKsJoisosCod(String ksJoisosCod) {
		this.ksJoisosCod = ksJoisosCod;
	}

	public String getKsShuyk1Cod() {
		return ksShuyk1Cod;
	}

	public void setKsShuyk1Cod(String ksShuyk1Cod) {
		this.ksShuyk1Cod = ksShuyk1Cod;
	}

	public String getKsShuyk2Cod() {
		return ksShuyk2Cod;
	}

	public void setKsShuyk2Cod(String ksShuyk2Cod) {
		this.ksShuyk2Cod = ksShuyk2Cod;
	}

	public String getKsShuyk3Cod() {
		return ksShuyk3Cod;
	}

	public void setKsShuyk3Cod(String ksShuyk3Cod) {
		this.ksShuyk3Cod = ksShuyk3Cod;
	}

	public String getKsKsssosCod() {
		return ksKsssosCod;
	}

	public void setKsKsssosCod(String ksKsssosCod) {
		this.ksKsssosCod = ksKsssosCod;
	}

	public String getKsKossanCbn() {
		return ksKossanCbn;
	}

	public void setKsKossanCbn(String ksKossanCbn) {
		this.ksKossanCbn = ksKossanCbn;
	}

	public String getKsStsoshCbn() {
		return ksStsoshCbn;
	}

	public void setKsStsoshCbn(String ksStsoshCbn) {
		this.ksStsoshCbn = ksStsoshCbn;
	}

	public String getKsStsoshCod() {
		return ksStsoshCod;
	}

	public void setKsStsoshCod(String ksStsoshCod) {
		this.ksStsoshCod = ksStsoshCod;
	}

	public String getKsStssosFlg() {
		return ksStssosFlg;
	}

	public void setKsStssosFlg(String ksStssosFlg) {
		this.ksStssosFlg = ksStssosFlg;
	}

	public String getKsSoshikKbn() {
		return ksSoshikKbn;
	}

	public void setKsSoshikKbn(String ksSoshikKbn) {
		this.ksSoshikKbn = ksSoshikKbn;
	}

	public String getKsTekingFlg() {
		return ksTekingFlg;
	}

	public void setKsTekingFlg(String ksTekingFlg) {
		this.ksTekingFlg = ksTekingFlg;
	}

	public BigDecimal getKsUpdateCnt() {
		return ksUpdateCnt;
	}

	public void setKsUpdateCnt(BigDecimal ksUpdateCnt) {
		this.ksUpdateCnt = ksUpdateCnt;
	}

	public String getKsTorokDh() {
		return ksTorokDh;
	}

	public void setKsTorokDh(String ksTorokDh) {
		this.ksTorokDh = ksTorokDh;
	}

	public String getKsTorshaCod() {
		return ksTorshaCod;
	}

	public void setKsTorshaCod(String ksTorshaCod) {
		this.ksTorshaCod = ksTorshaCod;
	}

	public String getKsUpdateDh() {
		return ksUpdateDh;
	}

	public void setKsUpdateDh(String ksUpdateDh) {
		this.ksUpdateDh = ksUpdateDh;
	}

	public String getKsUpdshaCod() {
		return ksUpdshaCod;
	}

	public void setKsUpdshaCod(String ksUpdshaCod) {
		this.ksUpdshaCod = ksUpdshaCod;
	}

}