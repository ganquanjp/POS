package jp.co.nsd.nkssweb.service.impl;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import jp.co.nsd.nkssweb.dao.Kss005;
import jp.co.nsd.nkssweb.dao.mapper.Kss005Mapper;
import jp.co.nsd.nkssweb.service.ShutokuShisanMeisaiService;

@Service
public class ShutokuShisanMeisaiServiceImpl implements ShutokuShisanMeisaiService {

	// ログ
	private Logger logger = LoggerFactory.getLogger(this.getClass());

	@Autowired
	private Kss005Mapper kss005Mapper;

	/**
	 * 取得資産明細登録
	 *
	 */
	public void insertKss005(Kss005 record) {

		logger.info("ShutokuShisanMeisaiServiceImpl.insertKss005 開始します。");

		kss005Mapper.insert(record);

		logger.info("ShutokuShisanMeisaiServiceImpl.insertKss005 終了します。");

	}

}
