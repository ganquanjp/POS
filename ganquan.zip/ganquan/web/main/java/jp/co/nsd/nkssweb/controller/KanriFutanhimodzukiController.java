/***********************************************************************
*
*業務名: 工事精算システム
*機能名: 除却（登録・修正・削除）(ログ出力処理)
*
*機能概要: 除却情報を処理する。
*
*JavaＶｅｒ：J2SE1.8.0準拠
*
*更新履歴: Ver.1.00 2018/03/06　NSD　新規作成
***********************************************************************/

package jp.co.nsd.nkssweb.controller;

import java.lang.reflect.InvocationTargetException;
import java.sql.Date;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.ibm.icu.text.SimpleDateFormat;

import jp.co.nsd.nkssweb.dao.KanriFutanhimodzuki;
import jp.co.nsd.nkssweb.dao.Message;
import jp.co.nsd.nkssweb.service.KanriFutanhimodzukiService;
import jp.co.nsd.nkssweb.service.SystemService;
import jp.co.nsd.nkssweb.utils.NSDConstant;

/**
 * 管理箇所/負担箇所紐付（検索）処理
 *
 * @version 1.00
 */
@RestController
public class KanriFutanhimodzukiController {

	// ログ
	private Logger logger = LoggerFactory.getLogger(this.getClass());

	@Autowired
	private KanriFutanhimodzukiService kanriFutanhimodzukiService;

	protected SystemService systemService;

	/**
	 * 管理箇所/負担箇所紐付（検索）処理
	 *
	 * @param reqMap
	 * INPUTパラメータ
	 * @return 管理箇所/負担箇所情報データ
	 * @exception IllegalAccessException
	 * @exception InvocationTargetException
	 * @version 1.00
	 */
	@RequestMapping(value = "/kanriFutanhimodzuki-selectByWhere", method = RequestMethod.POST)
	public Map<String, Object> selectByWhere(@RequestParam Map<String, Object> reqMap) {

		// 開始ログ
		logger.info("KanriFutanhimodzukiController.selectByWhere 開始します。");

		Map<String, Object> returnMap = new HashMap<String, Object>();

		Message message = new Message();

		KanriFutanhimodzuki kanriFutanhimodzuki = new KanriFutanhimodzuki();

		List<KanriFutanhimodzuki> kfhList = new ArrayList<>();

		// 画面入力した検索条件を取得する
		try {
			// Mapの情報をBeanのプロパティにセット
			BeanUtils.populate(kanriFutanhimodzuki, reqMap);

		} catch (IllegalAccessException | InvocationTargetException e) {
			// エーラログ
			logger.info("SeisanshoJokyakuController.selectByWhereでエラーが発生しました。");
			e.printStackTrace();
		}

		// サービス呼び出し
		kfhList = kanriFutanhimodzukiService.getKanriFutanInfo(kanriFutanhimodzuki);
		// 処理結果データ
		returnMap.put(NSDConstant.RESULT_DATA_LIST_NAME, kfhList);
		// メッセージ内容
		message = systemService.getMessage(NSDConstant.MSG_NOT_FOUND_MSGID);
		returnMap.put(NSDConstant.RESULT_MSG_NAME, message);

		// 終了ログ
		logger.info("KanriFutanhimodzukiController.selectByWhere 終了します。");

		return returnMap;
	}

	/**
	 * 管理箇所/負担箇所紐付（新規）処理
	 *
	 * @param reqMap
	 *            INPUTパラメータ
	 * @return 除却情報データ
	 * @exception IllegalAccessException
	 * @exception InvocationTargetException
	 * @version 1.00
	 * @throws ParseException
	 */
	@RequestMapping(value = "/kanriFutanhimodzuki-insertInfo", method = RequestMethod.POST)
	public Map<String, Object> insertInfo(@RequestParam Map<String, Object> reqMap) throws ParseException {

		// 開始ログ
		logger.info("KanriFutanhimodzukiController.insertInfo 開始します。");

		List<KanriFutanhimodzuki> krFtLst = new ArrayList<>();

		Map<String, Object> returnMap = new HashMap<String, Object>();
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd");
		// MapKey
		String key;
		for (int i = 0; i < 20; i++) {

			// 管理箇所KEY
			key = "kanriFutanLst".concat("[" + i + "]").concat("[kanriSoshikiKnj]");
			// 管理箇所が空の場合
			if (StringUtils.isEmpty((String) reqMap.get(key))) {
				continue;
			}

			KanriFutanhimodzuki kanriFutanhimodzuki = new KanriFutanhimodzuki();

			// 管理箇所
			key = "kanriFutanLst".concat("[" + i + "]").concat("[kanriSoshikiCd]");
			kanriFutanhimodzuki.setKanriSoshikiCd((String) reqMap.get(key));

			// 管理箇所適用期間（FROM）
			key = "kanriFutanLst".concat("[" + i + "]").concat("[kanriTekiyoStartYmd]");
			kanriFutanhimodzuki.setKanriTekiyoStartYmd(
					sdf.parse(sdf.format(new Date(Long.parseLong((String) reqMap.get(key))))));

			// 管理箇所適用期間（TO）
			key = "kanriFutanLst".concat("[" + i + "]").concat("[kanriTekiyoEndYmd]");
			kanriFutanhimodzuki.setKanriTekiyoEndYmd(
					sdf.parse(sdf.format(new Date(Long.parseLong((String) reqMap.get(key))))));

			// 負担箇所
			key = "kanriFutanLst".concat("[" + i + "]").concat("[futanSoshikiCd]");
			kanriFutanhimodzuki.setFutanSoshikiCd((String) reqMap.get(key));

			// 負担箇所適用期間（FROM）
			key = "kanriFutanLst".concat("[" + i + "]").concat("[futanTekiyoStartYmd]");
			kanriFutanhimodzuki.setFutanTekiyoStartYmd(
					sdf.parse(sdf.format(new Date(Long.parseLong((String) reqMap.get(key))))));

			// 負担箇所適用期間（TO）
			key = "kanriFutanLst".concat("[" + i + "]").concat("[futanTekiyoEndYmd]");
			kanriFutanhimodzuki.setFutanTekiyoEndYmd(
					sdf.parse(sdf.format(new Date(Long.parseLong((String) reqMap.get(key))))));


			// 除却資産明細
			krFtLst.add(kanriFutanhimodzuki);
		}

		// サービス呼び出し
		kanriFutanhimodzukiService.insertInfo(krFtLst);

		// 処理結果データ
		returnMap.put(NSDConstant.RESULT_DATA_LIST_NAME, NSDConstant.BLANK_STRING);
		// メッセージ内容
		returnMap.put(NSDConstant.RESULT_MSG_NAME, NSDConstant.BLANK_STRING);

		// 終了ログ
		logger.info("SeisanshoJokyakuController.insertInfo 終了します。");

		return returnMap;
	}


}