/***********************************************************************
*
*業務名: 工事精算システム
*機能名: 除却（経理審査/連携）(サービス処理)
*
*機能概要: 除却（経理審査/連携）情報を処理する。
*
*JavaＶｅｒ：J2SE1.8.0準拠
*
*更新履歴: Ver.1.00 2018/03/06　NSD　新規作成
***********************************************************************/
package jp.co.nsd.nkssweb.service.seisanshojokyaku.impl;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import jp.co.nsd.nkssweb.dao.SeisanshoJokyakuKeiri;
import jp.co.nsd.nkssweb.dao.mapper.SeisanshoJokyakuKeiriMapper;
import jp.co.nsd.nkssweb.service.seisanshojokyaku.SeisanshoJokyakuKeiriService;
import jp.co.nsd.nkssweb.utils.NSDCommUtils;

/**
 * 除却（経理審査/連携）処理
 *
 * @see SeisanshoJokyakuKeiriService
 * @version 1.00
 */
@Service
public class SeisanshoJokyakuKeiriServiceImpl implements SeisanshoJokyakuKeiriService {

	// ログ
	private Logger logger = LoggerFactory.getLogger(this.getClass());

	@Autowired
	private SeisanshoJokyakuKeiriMapper seisanshoJokyakuKeiriMapper;

	/**
	 * 除却（承認）検索処理
	 *
	 * @param seisanshoJokyakuKeiri
	 *            INPUTパラメータ
	 * @return sssJykKrList 除却情報データリスト
	 * @version 1.00
	 */
	public List<SeisanshoJokyakuKeiri> getJokyakuKeiriInfo(SeisanshoJokyakuKeiri seisanshoJokyakuKeiri) {

		// 開始ログ
		logger.info("SeisanshoJokyakuKeiriServiceImpl.getJokyakuSeisaiInfo 開始します。");

		// 除却情報を取得する
		List<SeisanshoJokyakuKeiri> sssJykKrList = seisanshoJokyakuKeiriMapper.selectByWhere(seisanshoJokyakuKeiri);

		for (int i = 0; i < sssJykKrList.size(); i++) {

			SeisanshoJokyakuKeiri sssJykSn = sssJykKrList.get(i);

			// ROWNOを設定する
			sssJykSn.setRowNo(i + 1);

			// 承認状態名称
			sssJykSn.setShoninJotai(NSDCommUtils.getShoninJotai(sssJykSn.getShoninSattus()));

		}

		// 終了ログ
		logger.info("SeisanshoJokyakuKeiriServiceImpl.getJokyakuSeisaiInfo 終了します。");

		return sssJykKrList;
	}

	@Override
	public List<SeisanshoJokyakuKeiri> gotoUpdate() {
		// TODO 自動生成されたメソッド・スタブ
		return null;
	}

}
