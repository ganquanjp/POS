package jp.co.nsd.nkssweb.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import jp.co.nsd.nkssweb.dao.Message;
import jp.co.nsd.nkssweb.service.SystemService;
import jp.co.nsd.nkssweb.utils.NSDConstant;

public class BaseController {

	@Autowired
	protected SystemService systemService;

	protected Logger logger = null;

	protected Map<String, Object> resultMap = null;

	protected String methodName = null;

	protected void init (){
		methodName = new String();
		logger = LoggerFactory.getLogger(this.getClass());
		resultMap = new HashMap<String, Object>();
	}

	/**
	 * 返却結果の設定
	 *
	 * @param dataList
	 * @return
	 */
	protected Map<String, Object> setDataToResultMap(List<?> dataList) {

		// 処理結果データ
		resultMap.put(NSDConstant.RESULT_DATA_LIST_NAME, dataList);

		if (dataList.size() == 0) {
			setMsgToResultMap(NSDConstant.MSGID_NOT_FOUND_DATA);
		}

		return resultMap;
	}

	/**
	 * エラーメッセージをログに出力
	 *
	 * @param dataList
	 * @return
	 */
	protected void outputLog(Message message) {

		if (NSDConstant.LOG_LEVEL_ERROR.equals(message.getMsgLevel())) {
			logger.error(message.getContent());
		} else if (NSDConstant.LOG_LEVEL_WARN.equals(message.getMsgLevel())) {
			logger.warn(message.getContent());
		} else if (NSDConstant.LOG_LEVEL_INFO.equals(message.getMsgLevel())) {
			logger.info(message.getContent());
		} else if (NSDConstant.LOG_LEVEL_DEBUG.equals(message.getMsgLevel())) {
			logger.debug(message.getContent());
		} else if (NSDConstant.LOG_LEVEL_TRACE.equals(message.getMsgLevel())) {
			logger.trace(message.getContent());
		} else {
			// 処理なし
		}

	}

	/**
	 * DBよりメッセージを取得し、返却Mapに設定(ログ出力)
	 *
	 * @param msgId
	 * @return
	 */
	protected Map<String, Object> setMsgToResultMap(String msgId) {

		// メッセージを取得する
		Message message = systemService.getMessage(msgId);
		resultMap.put(NSDConstant.RESULT_MSG_NAME, message);

		//ログに出力
		outputLog(message);

		return resultMap;
	}

	/**
	 * DBよりメッセージを取得し、返却Mapに設定(ログ出力しない)
	 *
	 * @param msgId
	 * @return
	 */
	protected Map<String, Object> setMsgToResultMapNoLog(String msgId) {

		// メッセージを取得する
		Message message = systemService.getMessage(msgId);
		resultMap.put(NSDConstant.RESULT_MSG_NAME, message);

		return resultMap;
	}
}
