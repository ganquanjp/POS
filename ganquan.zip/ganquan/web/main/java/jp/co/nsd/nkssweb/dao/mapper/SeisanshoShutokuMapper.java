package jp.co.nsd.nkssweb.dao.mapper;

import java.util.List;

import jp.co.nsd.nkssweb.dao.SeisanshoShutokuKensaku;
import jp.co.nsd.nkssweb.dao.SeisanshoShutokuShokai;

public interface SeisanshoShutokuMapper {

    List<SeisanshoShutokuKensaku> kensaku(SeisanshoShutokuKensaku record);

    List<SeisanshoShutokuShokai> shokai(SeisanshoShutokuShokai record);

}