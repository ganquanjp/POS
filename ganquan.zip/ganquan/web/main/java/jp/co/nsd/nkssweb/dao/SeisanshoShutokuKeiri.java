package jp.co.nsd.nkssweb.dao;

public class SeisanshoShutokuKeiri {

	// 行番号
	private int rowNo;

	// 精算書番号
	private String seisanShoNo;

	// 精算箇所
	private String soshikiRenNm;

	// 理由
	private String riyu;

	// 処理No
	private String hansu;

	// 使用開始年月日
	private String siyoStartYmd;

	// 使用開始年月日(FROM)
	private String siyoStartYmdFrom;

	// 使用開始年月日(TO)
	private String siyoStartYmdTo;

	// 取得価額合計
	private String shutokuKagakuGokei;

	// 承認状態
	private String shoninJotai;

	// 承認ステータス
	private String shoninSattus;

	// 工事件名コード
	private String kenmeiCd;

	// 工事件名
	private String kenmeiNm;

	public int getRowNo() {
		return rowNo;
	}

	public void setRowNo(int rowNo) {
		this.rowNo = rowNo;
	}

	public String getSeisanShoNo() {
		return seisanShoNo;
	}

	public void setSeisanShoNo(String seisanShoNo) {
		this.seisanShoNo = seisanShoNo;
	}

	public String getSoshikiRenNm() {
		return soshikiRenNm;
	}

	public void setSoshikiRenNm(String soshikiRenNm) {
		this.soshikiRenNm = soshikiRenNm;
	}

	public String getRiyu() {
		return riyu;
	}

	public void setRiyu(String riyu) {
		this.riyu = riyu;
	}

	public String getHansu() {
		return hansu;
	}

	public void setHansu(String hansu) {
		this.hansu = hansu;
	}

	public String getSiyoStartYmd() {
		return siyoStartYmd;
	}

	public void setSiyoStartYmd(String siyoStartYmd) {
		this.siyoStartYmd = siyoStartYmd;
	}

	public String getSiyoStartYmdFrom() {
		return siyoStartYmdFrom;
	}

	public void setSiyoStartYmdFrom(String siyoStartYmdFrom) {
		this.siyoStartYmdFrom = siyoStartYmdFrom;
	}

	public String getSiyoStartYmdTo() {
		return siyoStartYmdTo;
	}

	public void setSiyoStartYmdTo(String siyoStartYmdTo) {
		this.siyoStartYmdTo = siyoStartYmdTo;
	}

	public String getShutokuKagakuGokei() {
		return shutokuKagakuGokei;
	}

	public void setShutokuKagakuGokei(String shutokuKagakuGokei) {
		this.shutokuKagakuGokei = shutokuKagakuGokei;
	}

	public String getShoninJotai() {
		return shoninJotai;
	}

	public void setShoninJotai(String shoninJotai) {
		this.shoninJotai = shoninJotai;
	}

	public String getShoninSattus() {
		return shoninSattus;
	}

	public void setShoninSattus(String shoninSattus) {
		this.shoninSattus = shoninSattus;
	}

	public String getKenmeiCd() {
		return kenmeiCd;
	}

	public void setKenmeiCd(String kenmeiCd) {
		this.kenmeiCd = kenmeiCd;
	}

	public String getKenmeiNm() {
		return kenmeiNm;
	}

	public void setKenmeiNm(String kenmeiNm) {
		this.kenmeiNm = kenmeiNm;
	}








}