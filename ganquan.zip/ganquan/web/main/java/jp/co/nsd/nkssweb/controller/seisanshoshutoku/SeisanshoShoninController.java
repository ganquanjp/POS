/***********************************************************************
*
*業務名: 工事精算システム
*機能名: 除却（登録・修正・削除）(ログ出力処理)
*
*機能概要: 除却情報を処理する。
*
*JavaＶｅｒ：J2SE1.8.0準拠
*
*更新履歴: Ver.1.00 2018/03/06　NSD　新規作成
***********************************************************************/

package jp.co.nsd.nkssweb.controller.seisanshoshutoku;

import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.beanutils.BeanUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import jp.co.nsd.nkssweb.dao.Message;
import jp.co.nsd.nkssweb.dao.SeisanshoShonin;
import jp.co.nsd.nkssweb.dao.SeisanshoShoninShokai;
import jp.co.nsd.nkssweb.service.SystemService;
import jp.co.nsd.nkssweb.service.seisanshoshutoku.SeisanshoShoninService;
import jp.co.nsd.nkssweb.utils.NSDCommUtils;
import jp.co.nsd.nkssweb.utils.NSDConstant;

/**
 * 承認（検索・照会・更新）処理
 *
 * @version 1.00
 */
@RestController
public class SeisanshoShoninController {

	// ログ
	private Logger logger = LoggerFactory.getLogger(this.getClass());

	@Autowired
	private SeisanshoShoninService seisanshoShoninService;

	protected SystemService systemService;

	/**
	 * 承認（検索）処理
	 *
	 * @param reqMap
	 *            INPUTパラメータ
	 * @return 承認情報データ
	 * @exception IllegalAccessException
	 * @exception InvocationTargetException
	 * @version 1.00
	 */
	@RequestMapping(value = "/seisanshoShonin-selectByWhere", method = RequestMethod.POST)
	public Map<String, Object> selectByWhere(@RequestParam Map<String, Object> reqMap) {

		// 開始ログ
		logger.info("SeisanshoShoninController.selectByWhere 開始します。");

		Map<String, Object> returnMap = new HashMap<String, Object>();

		Message message = new Message();

		SeisanshoShonin seisanshoShonin = new SeisanshoShonin();

		List<SeisanshoShonin> sssSNLst = new ArrayList<>();

		// 画面入力した検索条件を取得する
		try {
			// Mapの情報をBeanのプロパティにセット
			BeanUtils.populate(seisanshoShonin, reqMap);

			// 使用開始年月日（From）と使用開始年月日（To）の大小比較チェック
			if (NSDCommUtils.chkDateFromTo(seisanshoShonin.getSiyoStartYmdFrom(), seisanshoShonin.getSiyoStartYmdTo())) {
				// 処理結果データ
				returnMap.put(NSDConstant.RESULT_DATA_LIST_NAME, sssSNLst);
				// メッセージ内容
				message = systemService.getMessage(NSDConstant.MSGID_SYSTEM_ERROR);
				returnMap.put(NSDConstant.RESULT_MSG_NAME, message);

				// 終了ログ
				logger.info("SeisanshoShoninController.selectByWhere 終了します。");

				return returnMap;
			}
		} catch (IllegalAccessException | InvocationTargetException e) {
			// エーラログ
			logger.info("SeisanshoShoninController.selectByWhereでエラーが発生しました。");
			e.printStackTrace();
		}

		// サービス呼び出し
		sssSNLst = seisanshoShoninService.getshoninInfo(seisanshoShonin);
		// 処理結果データ
		returnMap.put(NSDConstant.RESULT_DATA_LIST_NAME, sssSNLst);
		// メッセージ内容
		returnMap.put(NSDConstant.RESULT_MSG_NAME, message);

		// 終了ログ
		logger.info("SeisanshoShoninController.selectByWhere 終了します。");

		return returnMap;
	}
	/**
	 * 取得承認（照会）処理
	 *
	 * @param reqMap
	 *            INPUTパラメータ
	 * @return 承認情報データ
	 * @exception IllegalAccessException
	 * @exception InvocationTargetException
	 * @version 1.00
	 */
	@RequestMapping(value = "/seisanshoShonin-selectBySeisanShoNo", method = RequestMethod.POST)
	public Map<String, Object> selectBySeisanShoNo(@RequestParam Map<String, Object> reqMap) {

		// 開始ログ
		logger.info("SeisanshoShoninController.selectBySeisanShoNo 開始します。");

		Map<String, Object> returnMap = new HashMap<String, Object>();

		SeisanshoShoninShokai seisanshoShoninShokai = new SeisanshoShoninShokai();

		// 精算書より除却情報を取得する
		try {
			// Mapの情報をBeanのプロパティにセット
			BeanUtils.populate(seisanshoShoninShokai, reqMap);

		} catch (IllegalAccessException | InvocationTargetException e) {
			// エーラログ
			logger.info("SeisanshoShoninController.selectBySeisanShoNoでエラーが発生しました。");
		}

		// サービス呼び出し
		SeisanshoShoninShokai sssSNSkDto = seisanshoShoninService
				.getshutokuInfoBySeisanShoNo(seisanshoShoninShokai);

		// 処理結果データ
		returnMap.put(NSDConstant.RESULT_DATA_LIST_NAME, sssSNSkDto);
		// メッセージ内容
		returnMap.put(NSDConstant.RESULT_MSG_NAME, NSDConstant.BLANK_STRING);

		// 終了ログ
		logger.info("SeisanshoShoninController.selectBySeisanShoNo 終了します。");

		return returnMap;
	}
}
