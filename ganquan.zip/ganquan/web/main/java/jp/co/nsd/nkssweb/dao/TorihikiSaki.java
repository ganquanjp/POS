package jp.co.nsd.nkssweb.dao;

public class TorihikiSaki {

	private int rowNo;

    private String abbTorihkCod;

    private String abbTekiyfYmd;

    private String abbTekiytYmd;

    private String abbSiyoFlg;

    private String abbTorihkKnj;

    private String abbTorihkKna;

    private String abbTorihkYbn;

    private String abbTorihkAdr;

    private String abbTorihkTel;

    private String abbTorihkFax;

    private String abbFrbankCod;

    private String abbFrbnksCod;

    private String abbFrbnkKbn;

    private String abbFryoknSbt;

    private String abbFrkozaNo;

    private String abbFrybchCod;

    private String abbFrybtsCod;

    private String abbFrybtsNo;

    private String abbFrkozaKna;

    private String abbSoufKnj;

    private String abbSoufYbn;

    private String abbSoufAdr;

    private String abbFrtesrKbn;

    private String abbYbisyuCod;

    private String abbTepcogCod;

    private String abbTr1mojKna;

    private String abbShrkahFlg;

    private String abbHyojiNo;

    private String abbTekingFlg;

    private String abbUpdateCnt;

    private String abbTorokDh;

    private String abbTorshaCod;

    private String abbUpdateDh;

    private String abbUpdshaCod;

    public int getRowNo() {
		return rowNo;
	}

	public void setRowNo(int rowNo) {
		this.rowNo = rowNo;
	}

	public String getAbbTorihkCod() {
        return abbTorihkCod;
    }

    public void setAbbTorihkCod(String abbTorihkCod) {
        this.abbTorihkCod = abbTorihkCod == null ? null : abbTorihkCod.trim();
    }

    public String getAbbTekiyfYmd() {
        return abbTekiyfYmd;
    }

    public void setAbbTekiyfYmd(String abbTekiyfYmd) {
        this.abbTekiyfYmd = abbTekiyfYmd;
    }

    public String getAbbTekiytYmd() {
        return abbTekiytYmd;
    }

    public void setAbbTekiytYmd(String abbTekiytYmd) {
        this.abbTekiytYmd = abbTekiytYmd;
    }

    public String getAbbSiyoFlg() {
        return abbSiyoFlg;
    }

    public void setAbbSiyoFlg(String abbSiyoFlg) {
        this.abbSiyoFlg = abbSiyoFlg == null ? null : abbSiyoFlg.trim();
    }

    public String getAbbTorihkKnj() {
        return abbTorihkKnj;
    }

    public void setAbbTorihkKnj(String abbTorihkKnj) {
        this.abbTorihkKnj = abbTorihkKnj == null ? null : abbTorihkKnj.trim();
    }

    public String getAbbTorihkKna() {
        return abbTorihkKna;
    }

    public void setAbbTorihkKna(String abbTorihkKna) {
        this.abbTorihkKna = abbTorihkKna == null ? null : abbTorihkKna.trim();
    }

    public String getAbbTorihkYbn() {
        return abbTorihkYbn;
    }

    public void setAbbTorihkYbn(String abbTorihkYbn) {
        this.abbTorihkYbn = abbTorihkYbn == null ? null : abbTorihkYbn.trim();
    }

    public String getAbbTorihkAdr() {
        return abbTorihkAdr;
    }

    public void setAbbTorihkAdr(String abbTorihkAdr) {
        this.abbTorihkAdr = abbTorihkAdr == null ? null : abbTorihkAdr.trim();
    }

    public String getAbbTorihkTel() {
        return abbTorihkTel;
    }

    public void setAbbTorihkTel(String abbTorihkTel) {
        this.abbTorihkTel = abbTorihkTel == null ? null : abbTorihkTel.trim();
    }

    public String getAbbTorihkFax() {
        return abbTorihkFax;
    }

    public void setAbbTorihkFax(String abbTorihkFax) {
        this.abbTorihkFax = abbTorihkFax == null ? null : abbTorihkFax.trim();
    }

    public String getAbbFrbankCod() {
        return abbFrbankCod;
    }

    public void setAbbFrbankCod(String abbFrbankCod) {
        this.abbFrbankCod = abbFrbankCod == null ? null : abbFrbankCod.trim();
    }

    public String getAbbFrbnksCod() {
        return abbFrbnksCod;
    }

    public void setAbbFrbnksCod(String abbFrbnksCod) {
        this.abbFrbnksCod = abbFrbnksCod == null ? null : abbFrbnksCod.trim();
    }

    public String getAbbFrbnkKbn() {
        return abbFrbnkKbn;
    }

    public void setAbbFrbnkKbn(String abbFrbnkKbn) {
        this.abbFrbnkKbn = abbFrbnkKbn == null ? null : abbFrbnkKbn.trim();
    }

    public String getAbbFryoknSbt() {
        return abbFryoknSbt;
    }

    public void setAbbFryoknSbt(String abbFryoknSbt) {
        this.abbFryoknSbt = abbFryoknSbt == null ? null : abbFryoknSbt.trim();
    }

    public String getAbbFrkozaNo() {
        return abbFrkozaNo;
    }

    public void setAbbFrkozaNo(String abbFrkozaNo) {
        this.abbFrkozaNo = abbFrkozaNo == null ? null : abbFrkozaNo.trim();
    }

    public String getAbbFrybchCod() {
        return abbFrybchCod;
    }

    public void setAbbFrybchCod(String abbFrybchCod) {
        this.abbFrybchCod = abbFrybchCod == null ? null : abbFrybchCod.trim();
    }

    public String getAbbFrybtsCod() {
        return abbFrybtsCod;
    }

    public void setAbbFrybtsCod(String abbFrybtsCod) {
        this.abbFrybtsCod = abbFrybtsCod == null ? null : abbFrybtsCod.trim();
    }

    public String getAbbFrybtsNo() {
        return abbFrybtsNo;
    }

    public void setAbbFrybtsNo(String abbFrybtsNo) {
        this.abbFrybtsNo = abbFrybtsNo == null ? null : abbFrybtsNo.trim();
    }

    public String getAbbFrkozaKna() {
        return abbFrkozaKna;
    }

    public void setAbbFrkozaKna(String abbFrkozaKna) {
        this.abbFrkozaKna = abbFrkozaKna == null ? null : abbFrkozaKna.trim();
    }

    public String getAbbSoufKnj() {
        return abbSoufKnj;
    }

    public void setAbbSoufKnj(String abbSoufKnj) {
        this.abbSoufKnj = abbSoufKnj == null ? null : abbSoufKnj.trim();
    }

    public String getAbbSoufYbn() {
        return abbSoufYbn;
    }

    public void setAbbSoufYbn(String abbSoufYbn) {
        this.abbSoufYbn = abbSoufYbn == null ? null : abbSoufYbn.trim();
    }

    public String getAbbSoufAdr() {
        return abbSoufAdr;
    }

    public void setAbbSoufAdr(String abbSoufAdr) {
        this.abbSoufAdr = abbSoufAdr == null ? null : abbSoufAdr.trim();
    }

    public String getAbbFrtesrKbn() {
        return abbFrtesrKbn;
    }

    public void setAbbFrtesrKbn(String abbFrtesrKbn) {
        this.abbFrtesrKbn = abbFrtesrKbn == null ? null : abbFrtesrKbn.trim();
    }

    public String getAbbYbisyuCod() {
        return abbYbisyuCod;
    }

    public void setAbbYbisyuCod(String abbYbisyuCod) {
        this.abbYbisyuCod = abbYbisyuCod == null ? null : abbYbisyuCod.trim();
    }

    public String getAbbTepcogCod() {
        return abbTepcogCod;
    }

    public void setAbbTepcogCod(String abbTepcogCod) {
        this.abbTepcogCod = abbTepcogCod == null ? null : abbTepcogCod.trim();
    }

    public String getAbbTr1mojKna() {
        return abbTr1mojKna;
    }

    public void setAbbTr1mojKna(String abbTr1mojKna) {
        this.abbTr1mojKna = abbTr1mojKna == null ? null : abbTr1mojKna.trim();
    }

    public String getAbbShrkahFlg() {
        return abbShrkahFlg;
    }

    public void setAbbShrkahFlg(String abbShrkahFlg) {
        this.abbShrkahFlg = abbShrkahFlg == null ? null : abbShrkahFlg.trim();
    }

    public String getAbbHyojiNo() {
        return abbHyojiNo;
    }

    public void setAbbHyojiNo(String abbHyojiNo) {
        this.abbHyojiNo = abbHyojiNo;
    }

    public String getAbbTekingFlg() {
        return abbTekingFlg;
    }

    public void setAbbTekingFlg(String abbTekingFlg) {
        this.abbTekingFlg = abbTekingFlg == null ? null : abbTekingFlg.trim();
    }

    public String getAbbUpdateCnt() {
        return abbUpdateCnt;
    }

    public void setAbbUpdateCnt(String abbUpdateCnt) {
        this.abbUpdateCnt = abbUpdateCnt;
    }

    public String getAbbTorokDh() {
        return abbTorokDh;
    }

    public void setAbbTorokDh(String abbTorokDh) {
        this.abbTorokDh = abbTorokDh;
    }

    public String getAbbTorshaCod() {
        return abbTorshaCod;
    }

    public void setAbbTorshaCod(String abbTorshaCod) {
        this.abbTorshaCod = abbTorshaCod == null ? null : abbTorshaCod.trim();
    }

    public String getAbbUpdateDh() {
        return abbUpdateDh;
    }

    public void setAbbUpdateDh(String abbUpdateDh) {
        this.abbUpdateDh = abbUpdateDh;
    }

    public String getAbbUpdshaCod() {
        return abbUpdshaCod;
    }

    public void setAbbUpdshaCod(String abbUpdshaCod) {
        this.abbUpdshaCod = abbUpdshaCod == null ? null : abbUpdshaCod.trim();
    }
}