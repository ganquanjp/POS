package jp.co.nsd.nkssweb.dao;

import java.math.BigDecimal;

public class Kss007Key {
    private BigDecimal jokyakuSeisanShoId;

    private BigDecimal jokyakuShisanNo;

    private String motoKoteiShisanId;

    public BigDecimal getJokyakuSeisanShoId() {
        return jokyakuSeisanShoId;
    }

    public void setJokyakuSeisanShoId(BigDecimal jokyakuSeisanShoId) {
        this.jokyakuSeisanShoId = jokyakuSeisanShoId;
    }

    public BigDecimal getJokyakuShisanNo() {
        return jokyakuShisanNo;
    }

    public void setJokyakuShisanNo(BigDecimal jokyakuShisanNo) {
        this.jokyakuShisanNo = jokyakuShisanNo;
    }

    public String getMotoKoteiShisanId() {
        return motoKoteiShisanId;
    }

    public void setMotoKoteiShisanId(String motoKoteiShisanId) {
        this.motoKoteiShisanId = motoKoteiShisanId == null ? null : motoKoteiShisanId.trim();
    }
}