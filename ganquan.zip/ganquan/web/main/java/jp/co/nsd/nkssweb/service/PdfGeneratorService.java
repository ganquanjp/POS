package jp.co.nsd.nkssweb.service;

public interface PdfGeneratorService {

	void CreatePDF();

}
