package jp.co.nsd.nkssweb.dao;

public class KoteshisanDaityo {

	// No．
	private int rowNo;

	// 工事件名
	private String kamokuKnj;

	// 精算書番号
	private String seisanNo;

	// 使用開始年月日
	private String useYmd;

	// 取得年月日
	private String getYmd;

	// 固定資産番号
	private String koteiNo;

	// 親固定資産番号
	private String komk06Kna;

	// 枝番
	private String komk07Kna;

	// 固定資産名称
	private String koteiKnj;

	// 種類
	private String shuKnj;

	// 構造
	private String kouKnj;

	// 資産単位
	private String saiKnj;

	// 科目１
	private String shu4Knj;

	// 科目２
	private String shu5Knj;

	// 科目３
	private String shu6Knj;

	// 取引先
	private String torihikiKnj;

	// 法定耐用年数
	private String shotaiYs;

	// 残存耐用年数
	private String skeikaY;

	// 償却方法
	private String meishoKnj;

	// 償却率
	private String ssykRit;

	// 物品
	private String kagak1Yen;

	// 工費
	private String kagak2Yen;

	// 総係費
	private String kagak3Yen;

	// 取得価額
	private String getkgkYen;

	// 前年度末簿価
	private String maebkasYen;

	// 当期償却額（予定）
	private String tkishsYen;

	// （差引）年度末簿価
	private String endsYen;

	// 物品数量
	private String meiSu;

	// 単位名称
	private String taniKnj;

	// 管理箇所
	private String kanriKnj;

	// 負担箇所
	private String futan1Knj;

	// 設置場所
	private String bashoKnj;

	// 製品名/型番/製品会社名称
	private String kaisyaKnj;

	// 摘要１
	private String memo1Knj;

	// 摘要２
	private String memo2Knj;

	// 摘要３
	private String komk11Knj;

	// 摘要４
	private String komk12Knj;

	// 摘要５
	private String komk13Knj;

	// 旧資産コード
	private String komk08Kna;

	// 工事担当箇所
	private String komk15Knj;

	// 工事担当者
	private String komk14Knj;

	// 会計整理年月
	private String kaikeiYm;

	// 分割元固定資産番号
	private String koteibktNo;

	// 除却年月日
	private String jyokykYmd;

	// 新旧償却区分
	private String meisho1Knj;

	// 残存価額
	private String zanzonsYen;

	// 法定耐用年数（税法）
	private String zeitaiYs;

	// 残存耐用年数（税法）
	private String zkeikaY;

	// 前年度末簿価（税法）
	private String maebkazYen;

	// 当期償却額（税法）
	private String tkishzYen;

	// 年度末簿価（税法）
	private String endzYen;

	// 申告先名称
	private String shinkkKnj;

	// 申告種類
	private String meisho2Knj;

	// 年始前年評価額
	private String ybnhykYen;

	// 年始現在評価額
	private String yfnhykYen;

	public int getRowNo() {
		return rowNo;
	}

	public void setRowNo(int rowNo) {
		this.rowNo = rowNo;
	}

	public String getKamokuKnj() {
		return kamokuKnj;
	}

	public void setKamokuKnj(String kamokuKnj) {
		this.kamokuKnj = kamokuKnj;
	}

	public String getSeisanNo() {
		return seisanNo;
	}

	public void setSeisanNo(String seisanNo) {
		this.seisanNo = seisanNo;
	}

	public String getUseYmd() {
		return useYmd;
	}

	public void setUseYmd(String useYmd) {
		this.useYmd = useYmd;
	}

	public String getGetYmd() {
		return getYmd;
	}

	public void setGetYmd(String getYmd) {
		this.getYmd = getYmd;
	}

	public String getKoteiNo() {
		return koteiNo;
	}

	public void setKoteiNo(String koteiNo) {
		this.koteiNo = koteiNo;
	}

	public String getKomk06Kna() {
		return komk06Kna;
	}

	public void setKomk06Kna(String komk06Kna) {
		this.komk06Kna = komk06Kna;
	}

	public String getKomk07Kna() {
		return komk07Kna;
	}

	public void setKomk07Kna(String komk07Kna) {
		this.komk07Kna = komk07Kna;
	}

	public String getKoteiKnj() {
		return koteiKnj;
	}

	public void setKoteiKnj(String koteiKnj) {
		this.koteiKnj = koteiKnj;
	}

	public String getShuKnj() {
		return shuKnj;
	}

	public void setShuKnj(String shuKnj) {
		this.shuKnj = shuKnj;
	}

	public String getKouKnj() {
		return kouKnj;
	}

	public void setKouKnj(String kouKnj) {
		this.kouKnj = kouKnj;
	}

	public String getSaiKnj() {
		return saiKnj;
	}

	public void setSaiKnj(String saiKnj) {
		this.saiKnj = saiKnj;
	}

	public String getShu4Knj() {
		return shu4Knj;
	}

	public void setShu4Knj(String shu4Knj) {
		this.shu4Knj = shu4Knj;
	}

	public String getShu5Knj() {
		return shu5Knj;
	}

	public void setShu5Knj(String shu5Knj) {
		this.shu5Knj = shu5Knj;
	}

	public String getShu6Knj() {
		return shu6Knj;
	}

	public void setShu6Knj(String shu6Knj) {
		this.shu6Knj = shu6Knj;
	}

	public String getTorihikiKnj() {
		return torihikiKnj;
	}

	public void setTorihikiKnj(String torihikiKnj) {
		this.torihikiKnj = torihikiKnj;
	}

	public String getShotaiYs() {
		return shotaiYs;
	}

	public void setShotaiYs(String shotaiYs) {
		this.shotaiYs = shotaiYs;
	}

	public String getSkeikaY() {
		return skeikaY;
	}

	public void setSkeikaY(String skeikaY) {
		this.skeikaY = skeikaY;
	}

	public String getMeishoKnj() {
		return meishoKnj;
	}

	public void setMeishoKnj(String meishoKnj) {
		this.meishoKnj = meishoKnj;
	}

	public String getSsykRit() {
		return ssykRit;
	}

	public void setSsykRit(String ssykRit) {
		this.ssykRit = ssykRit;
	}

	public String getKagak1Yen() {
		return kagak1Yen;
	}

	public void setKagak1Yen(String kagak1Yen) {
		this.kagak1Yen = kagak1Yen;
	}

	public String getKagak2Yen() {
		return kagak2Yen;
	}

	public void setKagak2Yen(String kagak2Yen) {
		this.kagak2Yen = kagak2Yen;
	}

	public String getKagak3Yen() {
		return kagak3Yen;
	}

	public void setKagak3Yen(String kagak3Yen) {
		this.kagak3Yen = kagak3Yen;
	}

	public String getGetkgkYen() {
		return getkgkYen;
	}

	public void setGetkgkYen(String getkgkYen) {
		this.getkgkYen = getkgkYen;
	}

	public String getMaebkasYen() {
		return maebkasYen;
	}

	public void setMaebkasYen(String maebkasYen) {
		this.maebkasYen = maebkasYen;
	}

	public String getTkishsYen() {
		return tkishsYen;
	}

	public void setTkishsYen(String tkishsYen) {
		this.tkishsYen = tkishsYen;
	}

	public String getEndsYen() {
		return endsYen;
	}

	public void setEndsYen(String endsYen) {
		this.endsYen = endsYen;
	}

	public String getMeiSu() {
		return meiSu;
	}

	public void setMeiSu(String meiSu) {
		this.meiSu = meiSu;
	}

	public String getTaniKnj() {
		return taniKnj;
	}

	public void setTaniKnj(String taniKnj) {
		this.taniKnj = taniKnj;
	}

	public String getKanriKnj() {
		return kanriKnj;
	}

	public void setKanriKnj(String kanriKnj) {
		this.kanriKnj = kanriKnj;
	}

	public String getFutan1Knj() {
		return futan1Knj;
	}

	public void setFutan1Knj(String futan1Knj) {
		this.futan1Knj = futan1Knj;
	}

	public String getBashoKnj() {
		return bashoKnj;
	}

	public void setBashoKnj(String bashoKnj) {
		this.bashoKnj = bashoKnj;
	}

	public String getKaisyaKnj() {
		return kaisyaKnj;
	}

	public void setKaisyaKnj(String kaisyaKnj) {
		this.kaisyaKnj = kaisyaKnj;
	}

	public String getMemo1Knj() {
		return memo1Knj;
	}

	public void setMemo1Knj(String memo1Knj) {
		this.memo1Knj = memo1Knj;
	}

	public String getMemo2Knj() {
		return memo2Knj;
	}

	public void setMemo2Knj(String memo2Knj) {
		this.memo2Knj = memo2Knj;
	}

	public String getKomk11Knj() {
		return komk11Knj;
	}

	public void setKomk11Knj(String komk11Knj) {
		this.komk11Knj = komk11Knj;
	}

	public String getKomk12Knj() {
		return komk12Knj;
	}

	public void setKomk12Knj(String komk12Knj) {
		this.komk12Knj = komk12Knj;
	}

	public String getKomk13Knj() {
		return komk13Knj;
	}

	public void setKomk13Knj(String komk13Knj) {
		this.komk13Knj = komk13Knj;
	}

	public String getKomk08Kna() {
		return komk08Kna;
	}

	public void setKomk08Kna(String komk08Kna) {
		this.komk08Kna = komk08Kna;
	}

	public String getKomk15Knj() {
		return komk15Knj;
	}

	public void setKomk15Knj(String komk15Knj) {
		this.komk15Knj = komk15Knj;
	}

	public String getKomk14Knj() {
		return komk14Knj;
	}

	public void setKomk14Knj(String komk14Knj) {
		this.komk14Knj = komk14Knj;
	}

	public String getKaikeiYm() {
		return kaikeiYm;
	}

	public void setKaikeiYm(String kaikeiYm) {
		this.kaikeiYm = kaikeiYm;
	}

	public String getKoteibktNo() {
		return koteibktNo;
	}

	public void setKoteibktNo(String koteibktNo) {
		this.koteibktNo = koteibktNo;
	}

	public String getJyokykYmd() {
		return jyokykYmd;
	}

	public void setJyokykYmd(String jyokykYmd) {
		this.jyokykYmd = jyokykYmd;
	}

	public String getMeisho1Knj() {
		return meisho1Knj;
	}

	public void setMeisho1Knj(String meisho1Knj) {
		this.meisho1Knj = meisho1Knj;
	}

	public String getZanzonsYen() {
		return zanzonsYen;
	}

	public void setZanzonsYen(String zanzonsYen) {
		this.zanzonsYen = zanzonsYen;
	}

	public String getZeitaiYs() {
		return zeitaiYs;
	}

	public void setZeitaiYs(String zeitaiYs) {
		this.zeitaiYs = zeitaiYs;
	}

	public String getZkeikaY() {
		return zkeikaY;
	}

	public void setZkeikaY(String zkeikaY) {
		this.zkeikaY = zkeikaY;
	}

	public String getMaebkazYen() {
		return maebkazYen;
	}

	public void setMaebkazYen(String maebkazYen) {
		this.maebkazYen = maebkazYen;
	}

	public String getTkishzYen() {
		return tkishzYen;
	}

	public void setTkishzYen(String tkishzYen) {
		this.tkishzYen = tkishzYen;
	}

	public String getEndzYen() {
		return endzYen;
	}

	public void setEndzYen(String endzYen) {
		this.endzYen = endzYen;
	}

	public String getShinkkKnj() {
		return shinkkKnj;
	}

	public void setShinkkKnj(String shinkkKnj) {
		this.shinkkKnj = shinkkKnj;
	}

	public String getMeisho2Knj() {
		return meisho2Knj;
	}

	public void setMeisho2Knj(String meisho2Knj) {
		this.meisho2Knj = meisho2Knj;
	}

	public String getYbnhykYen() {
		return ybnhykYen;
	}

	public void setYbnhykYen(String ybnhykYen) {
		this.ybnhykYen = ybnhykYen;
	}

	public String getYfnhykYen() {
		return yfnhykYen;
	}

	public void setYfnhykYen(String yfnhykYen) {
		this.yfnhykYen = yfnhykYen;
	}




}