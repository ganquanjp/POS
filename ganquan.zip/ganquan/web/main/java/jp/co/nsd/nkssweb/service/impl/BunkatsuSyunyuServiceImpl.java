package jp.co.nsd.nkssweb.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import jp.co.nsd.nkssweb.dao.BunkatsuSyunyu;
import jp.co.nsd.nkssweb.dao.mapper.BunkatsuSyunyuMapper;
import jp.co.nsd.nkssweb.service.BunkatsuSyunyuService;

@Service
public class BunkatsuSyunyuServiceImpl implements BunkatsuSyunyuService {

	@Autowired
	private BunkatsuSyunyuMapper bunkatsuSyunyuMapper;

	/**
	 * 分割収入画面内容取得
	 *
	 */
	public List<BunkatsuSyunyu> getBunkatsuInfo(BunkatsuSyunyu selectCondition) {
		List<BunkatsuSyunyu> sssStkList = new ArrayList<BunkatsuSyunyu>();

		sssStkList = bunkatsuSyunyuMapper.selectByWhere(selectCondition);

		// int pageStartNo = NSDCommUtils.getPageingStartNo(1);
		//
		for (int i = 1; i <= sssStkList.size(); i++) {
			sssStkList.get(i - 1).setKouban(i);
			// sssStk = new SeisanshoShutoku();
			// sssStk.setRowNo(i);
			// sssStk.setKojiKenmeiCode("0C02800".concat(String.valueOf(i)));
			// sssStk.setKojiKenmei("件名".concat(String.valueOf(i)));
			// sssStk.setShutokuYMD(NSDDateUtils.Now("HH:mm:ss"));
			// sssStkList.add(sssStk);
		}

		return sssStkList;

		// return seisanshoShutokuMapper.selectByWhere(seisanshoShutoku);
	}
}
