package jp.co.nsd.nkssweb.controller;

import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.beanutils.BeanUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import jp.co.nsd.nkssweb.dao.BunkatsuSyunyu;
import jp.co.nsd.nkssweb.dao.Message;
import jp.co.nsd.nkssweb.service.BunkatsuSyunyuService;
import jp.co.nsd.nkssweb.service.SystemService;
import jp.co.nsd.nkssweb.utils.NSDCommUtils;
import jp.co.nsd.nkssweb.utils.NSDConstant;
@RestController
public class BunkatsuSyunyuController {

	// ログ
	private Logger logger = LoggerFactory.getLogger(this.getClass());

	@Autowired
	private BunkatsuSyunyuService bunkatsuSyunyuService;

	protected SystemService systemService;

	/*
	 * 分割収入経理審査/連携（検索）画面から
	 *
	 * @param reqMap
	 *            INPUTパラメータ
	 * @return 除却情報データ
	 * @exception IllegalAccessException
	 * @exception InvocationTargetException
	 * @version 1.00
	 */
	@RequestMapping(value = "/bunkatsuSyunyu-selectByWhere", method = RequestMethod.POST)
	public Map<String, Object> selectByWhere(@RequestParam Map<String, Object> reqMap) {

		// 開始ログ
		logger.info("BunkatsuSyunyuController.selectByWhere 開始します。");

		BunkatsuSyunyu bunkatsuSyunyu = new BunkatsuSyunyu();

		Map<String, Object> returnMap = new HashMap<String, Object>();

		Message message = new Message();

		List<BunkatsuSyunyu> bsLst = new ArrayList<>();

		try {
			// Mapの情報をBeanのプロパティにセット
			BeanUtils.populate(bunkatsuSyunyu, reqMap);

			// 除却予定年月日（From）と除却予定年月日（To）の大小比較チェック
			if (NSDCommUtils.chkDateFromTo(bunkatsuSyunyu.getSabisukaisiymdF(),
					bunkatsuSyunyu.getSabisukaisiymdT())) {
				// 処理結果データ
				returnMap.put(NSDConstant.RESULT_DATA_LIST_NAME, bsLst);
				// メッセージ内容
				message = systemService.getMessage(NSDConstant.MSG_NOT_FOUND_MSGID);
				returnMap.put(NSDConstant.RESULT_MSG_NAME, message);

				// 終了ログ
				logger.info("BunkatsuSyunyuController.selectByWhere 終了します。");

				return returnMap;
			}
		} catch (IllegalAccessException | InvocationTargetException e) {
			// エーラログ
			logger.info("BunkatsuSyunyuController.selectByWhereでエラーが発生しました。");
		}

		bsLst = bunkatsuSyunyuService.getBunkatsuInfo(bunkatsuSyunyu);

		// 処理結果データ
		returnMap.put(NSDConstant.RESULT_DATA_LIST_NAME, bsLst);
		// メッセージ内容
		returnMap.put(NSDConstant.RESULT_MSG_NAME, NSDConstant.BLANK_STRING);

		// 終了ログ
		logger.info("BunkatsuSyunyuController.selectByWhere 終了します。");

		// サービスを呼び出す
		return returnMap;
	}

}
