package jp.co.nsd.nkssweb.controller.seisanshotoroku;

import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.beanutils.BeanUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import jp.co.nsd.nkssweb.dao.Kss002;
import jp.co.nsd.nkssweb.dao.Kss004;
import jp.co.nsd.nkssweb.dao.SeisanshoToroku;
import jp.co.nsd.nkssweb.service.seisanshotoroku.SeisanshoTorokuService;

@RestController
public class SeisanshoTorokuController {

	// ログ
	private Logger logger = LoggerFactory.getLogger(this.getClass());

	@Autowired
	private SeisanshoTorokuService seisanshoTorokuService;

	/*
	 * 精算書登録・検索
	 */
	@RequestMapping(value = "/seisanshoToroku-kensaku", method = RequestMethod.POST)
	public Map<String, Object> getSeisanshoTorokuKensaku(@RequestParam Map<String, Object> reqMap) {

		logger.info("getSeisanshoTorokuKensaku 開始します。");

		Map<String, Object> resultMap = new HashMap<String, Object>();

		SeisanshoToroku selectCondition = new SeisanshoToroku();
		List<SeisanshoToroku> sssTrKList = new ArrayList<SeisanshoToroku>();

		try {
			// 画面入力した検索条件をBeanのプロパティにセット
			BeanUtils.populate(selectCondition, reqMap);

		} catch (IllegalAccessException | InvocationTargetException e) {
			logger.info("getSeisanshoTorokuKensakuでエラーが発生しました。");
			resultMap.put("msg", "エラーが発生しました。");
			return resultMap;
		}

		try {
			// サービスを呼び出す
			sssTrKList = seisanshoTorokuService.getSeisanshoTorokuKensaku(selectCondition);
		} catch (Exception e) {
			logger.info("seisanshoTorokuService.getSeisanshoTorokuKensakuでエラーが発生しました。");
			logger.info(e.getMessage());
			logger.info(e.getStackTrace().toString());
			resultMap.put("msg", "エラーが発生しました。");
			return resultMap;
		}

		// 処理結果データ
		resultMap.put("dataList", sssTrKList);

		// 終了ログ
		logger.info("getSeisanshoTorokuKensaku 終了します。");

		return resultMap;
	}

	/*
	 * 精算書登録・照会
	 */
	@RequestMapping(value = "/seisanshoToroku-shokai", method = RequestMethod.POST)
	public Map<String, Object> getSeisanshoTorokuShokai(@RequestParam Map<String, Object> reqMap) {

		logger.info("getSeisanshoTorokuShokai 開始します。");

		Map<String, Object> resultMap = new HashMap<String, Object>();

		SeisanshoToroku sssTrk = new SeisanshoToroku();

		List<SeisanshoToroku> sssTrkList = new ArrayList<SeisanshoToroku>();

		try {
			// 画面入力した検索条件をBeanのプロパティにセット
			BeanUtils.populate(sssTrk, reqMap);

		} catch (IllegalAccessException | InvocationTargetException e) {
			logger.info("getSeisanshoTorokuShokaiでエラーが発生しました。");
			logger.info(e.getStackTrace().toString());
			resultMap.put("msg", "エラーが発生しました。");
			return resultMap;
		}

		try {
			// サービスを呼び出す
			sssTrkList = seisanshoTorokuService.getSeisanshoTorokuShokai(sssTrk);
		} catch (Exception e) {
			logger.info("seisanshoTorokuService.getSeisanshoTorokuShokaiでエラーが発生しました。");
			logger.info(e.getStackTrace().toString());
			logger.info(e.getMessage());
			resultMap.put("msg", "エラーが発生しました。");
			return resultMap;
		}

		// 処理結果データ
		resultMap.put("dataList", sssTrkList);

		// 終了ログ
		logger.info("getSeisanshoTorokuShokai 終了します。");

		return resultMap;
	}

	/*
	 * 取得新規登録画面から
	 */
	@RequestMapping(value = "/seisanshoToroku-insertSeisansho", method = RequestMethod.POST)
	public Map<String, Object> insertSeisansho(@RequestParam Map<String, Object> reqMap) {

		logger.info("insertSeisansho 開始します。");

		Map<String, Object> resultMap = new HashMap<String, Object>();

		Kss004 kss004 = new Kss004();
		Kss002 kss002 = new Kss002();

		try {
			// 画面入力した検索条件をBeanのプロパティにセット
			BeanUtils.populate(kss004, reqMap);
			BeanUtils.populate(kss002, reqMap);

		} catch (IllegalAccessException | InvocationTargetException e) {
			logger.info("insertSeisanshoでエラーが発生しました。");
			resultMap.put("msg", "エラーが発生しました。");
			return resultMap;
		}

		try {
			// サービスを呼び出す
			seisanshoTorokuService.insertSeisansho(kss002, kss004);
		} catch (Exception e) {
			logger.info("seisanshoTorokuService.insertSeisanshoでエラーが発生しました。");
			resultMap.put("msg", "エラーが発生しました。");
			return resultMap;
		}

		return resultMap;
	}
}
