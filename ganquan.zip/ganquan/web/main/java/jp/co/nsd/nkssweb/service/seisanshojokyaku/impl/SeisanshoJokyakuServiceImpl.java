/***********************************************************************
*
*業務名: 工事精算システム
*機能名: 除却（登録・修正・削除）(サービス処理)
*
*機能概要: 除却情報を処理する。
*
*JavaＶｅｒ：J2SE1.8.0準拠
*
*更新履歴: Ver.1.00 2018/03/06　NSD　新規作成
***********************************************************************/
package jp.co.nsd.nkssweb.service.seisanshojokyaku.impl;

import java.lang.reflect.InvocationTargetException;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.commons.beanutils.BeanUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import jp.co.nsd.nkssweb.dao.KoteiSisan;
import jp.co.nsd.nkssweb.dao.Kss006;
import jp.co.nsd.nkssweb.dao.Kss006Key;
import jp.co.nsd.nkssweb.dao.Kss007;
import jp.co.nsd.nkssweb.dao.Kss007Key;
import jp.co.nsd.nkssweb.dao.SeisanshoJokyaku;
import jp.co.nsd.nkssweb.dao.SeisanshoJokyakuKoteiSisan;
import jp.co.nsd.nkssweb.dao.SeisanshoJokyakuShokai;
import jp.co.nsd.nkssweb.dao.SeisanshoJokyakuShokaiList;
import jp.co.nsd.nkssweb.dao.mapper.Kss006Mapper;
import jp.co.nsd.nkssweb.dao.mapper.Kss007Mapper;
import jp.co.nsd.nkssweb.dao.mapper.SanshoMapper;
import jp.co.nsd.nkssweb.dao.mapper.SeisanshoJokyakuMapper;
import jp.co.nsd.nkssweb.service.seisanshojokyaku.SeisanshoJokyakuService;
import jp.co.nsd.nkssweb.utils.NSDConstant;

/**
 * 除却（登録・修正・削除）処理
 *
 * @see SeisanshoJokyakuService
 * @version 1.00
 */
@Service
public class SeisanshoJokyakuServiceImpl implements SeisanshoJokyakuService {

	// ログ
	private Logger logger = LoggerFactory.getLogger(this.getClass());

	@Autowired
	private SeisanshoJokyakuMapper seisanshoJokyakuMapper;

	@Autowired
	private SanshoMapper sanshoMapper;

	@Autowired
	private Kss006Mapper kss006Mapper;

	@Autowired
	private Kss007Mapper kss007Mapper;

	/**
	 * 除却（検索）処理
	 *
	 * @param seisanshoJokyaku
	 *            INPUTパラメータ
	 * @return sssJykList 除却情報データリスト
	 * @version 1.00
	 */
	public List<SeisanshoJokyaku> getJokyakuInfo(SeisanshoJokyaku seisanshoJokyaku) {

		// 開始ログ
		logger.info("SeisanshoJokyakuServiceImpl.getJokyakuInfo 開始します。");

		// 除却情報を取得する
		List<SeisanshoJokyaku> sssJykList = seisanshoJokyakuMapper.selectByWhere(seisanshoJokyaku);

		for (int i = 1; i <= sssJykList.size(); i++) {
			// ROWNOを設定する
			sssJykList.get(i - 1).setRowNo(i);
		}

		// 終了ログ
		logger.info("SeisanshoJokyakuServiceImpl.getJokyakuInfo 終了します。");

		return sssJykList;
	}

	/**
	 * 除却（照会）処理
	 *
	 * @param seisanshoJokyakuShokai
	 *            INPUTパラメータ
	 * @return SeisanshoJokyakuShokaiList 除却情報データ
	 * @version 1.00
	 */
	public SeisanshoJokyakuShokaiList getJokyakuInfoBySeisanShoNo(SeisanshoJokyakuShokai selectCondition) {

		// 開始ログ
		logger.info("SeisanshoJokyakuServiceImpl.getJokyakuInfoBySeisanShoNo 開始します。");

		// 除却情報
		SeisanshoJokyakuShokaiList resultDto = new SeisanshoJokyakuShokaiList();

		// 除却資産情報を取得する
		List<SeisanshoJokyakuShokai> sssJykSkList = seisanshoJokyakuMapper.selectBySeisanShoNo(selectCondition);

		List<SeisanshoJokyakuKoteiSisan> sssJykKsLst = new ArrayList<>();

		for (int i = 0; i < sssJykSkList.size(); i++) {
			// 除却資産情報
			SeisanshoJokyakuShokai sssJykSkDto = sssJykSkList.get(i);

			// 除却固定資産情報
			SeisanshoJokyakuKoteiSisan sssJykKsDto = new SeisanshoJokyakuKoteiSisan();

			// Mapの情報をBeanのプロパティにセット
			try {
				BeanUtils.copyProperties(resultDto, sssJykSkDto);

				KoteiSisan koteiSisan = new KoteiSisan();

				koteiSisan.setKoteiCod(sssJykSkDto.getMotoKoteiShisanId());
				// 固定資産情報を取得する
				List<KoteiSisan> ksLstDto = sanshoMapper.selectKoteiSisan(koteiSisan);

				// 固定資産情報取得できないの場合
				if (null != ksLstDto && ksLstDto.size() > 0) {
					// 固定資産情報
					KoteiSisan ksDto = ksLstDto.get(0);
					// ROWNO
					ksDto.setRowNo(i + 1);

					// 子資産残
					if (NSDConstant.STRING_0.equals(ksDto.getKoshiKbn())) {
						// 無
						ksDto.setKoshiKbn(NSDConstant.NASI);
					} else if (NSDConstant.STRING_1.equals(ksDto.getKoshiKbn())) {
						// 有
						ksDto.setKoshiKbn(NSDConstant.ARI);
					} else {
						// 処理なし
					}

					BeanUtils.copyProperties(sssJykKsDto, ksDto);

					// 固定資産情報を追加
					sssJykKsLst.add(sssJykKsDto);
				}

			} catch (IllegalAccessException | InvocationTargetException e) {
				// 終了ログ
				logger.info("SeisanshoJokyakuServiceImpl.getJokyakuInfoBySeisanShoNo 終了します。");
			}

		}
		// 固定資産情報リスト
		resultDto.setKoteiSisanLst(sssJykKsLst);

		// 終了ログ
		logger.info("SeisanshoJokyakuServiceImpl.getJokyakuInfoBySeisanShoNo 終了します。");

		return resultDto;
	}

	/**
	 * 除却（削除）処理
	 *
	 * @param seisanshoJokyaku
	 *            INPUTパラメータ
	 * @return cnt
	 * @version 1.00
	 */
	public int delByPyKey(SeisanshoJokyaku seisanshoJokyaku) {

		Kss007Key kss007Key = new Kss007Key();
		// 除却精算書ＩＤ
		kss007Key.setJokyakuSeisanShoId(seisanshoJokyaku.getJokyakuSeisanShoId());
		// 除却資産ＩＤ
		kss007Key.setJokyakuShisanNo(seisanshoJokyaku.getJokyakuShisanNo());

		List<Kss007> kss007Lst = seisanshoJokyakuMapper.selectByPyKey(kss007Key);

		// 除却資産明細情報を削除
		int kss007cnt = seisanshoJokyakuMapper.deleteByPyKey(kss007Key);
		// 削除件数判断(除却資産明細)
		if (kss007cnt > 0) {

			Kss006Key kss006Key = new Kss006Key();
			// 除却精算書ＩＤ
			kss006Key.setJokyakuSeisanShoId(seisanshoJokyaku.getJokyakuSeisanShoId());
			// 除却資産ＩＤ
			kss006Key.setJokyakuShisanNo(seisanshoJokyaku.getJokyakuShisanNo());
			// 除却資産情報を削除
			int kss006cnt = kss006Mapper.deleteByPrimaryKey(kss006Key);

			// 削除件数判断(除却資産)
			if (kss006cnt > 0) {

				for (int i = 0; i < kss007Lst.size(); i++) {
					Kss007 kss007 = kss007Lst.get(i);

					KoteiSisan koteiSisan = new KoteiSisan();

					// 固定資産ID
					koteiSisan.setKoteiCod(kss007.getMotoKoteiShisanId());

					// 除却精算制御区分
					koteiSisan.setJkkseiKbn(NSDConstant.STRING_0);

					// 固定資産更新
					seisanshoJokyakuMapper.updateByPrimaryKey(koteiSisan);
				}

			}
		}

		return 0;
	}

	/**
	 * 除却（登録）処理
	 *
	 * @param kss006
	 *            INPUTパラメータ
	 * @param kss007Lst
	 *            INPUTパラメータ
	 * @return cnt
	 * @version 1.00
	 */
	public int insertInfo(Kss006 kss006, List<Kss007> kss007Lst) {

		Date date = new Date();

		// 除却資産のMAXID（除却精算書ＩＤ、除却資産ＩＤ、除却精算書番号）を取得
		SeisanshoJokyaku sj = seisanshoJokyakuMapper.selectMaxId();

		// 除却精算書ＩＤ
		BigDecimal maxJokyakuSeisanShoId = BigDecimal.ONE;
		// 除却資産ＩＤ
		BigDecimal maxjokyakuShisanNo = BigDecimal.ONE;
		// 除却精算書番号
		String maxjokyakuSeisanShoNo = NSDConstant.STRING_100000000000001;

		// 除却資産のMAXID存在の場合
		if (null != sj) {
			// 除却精算書ＩＤ
			maxJokyakuSeisanShoId = sj.getJokyakuSeisanShoId().add(BigDecimal.ONE);
			// 除却資産ＩＤ
			maxjokyakuShisanNo = sj.getJokyakuShisanNo().add(BigDecimal.ONE);
			// 除却精算書番号
			maxjokyakuSeisanShoNo = String.valueOf(new BigDecimal(sj.getJokyakuSeisanShoNo()).add(BigDecimal.ONE));
		}

		// 除却精算書ＩＤ
		kss006.setJokyakuSeisanShoId(maxJokyakuSeisanShoId);
		// 除却資産ＩＤ
		kss006.setJokyakuShisanNo(maxjokyakuShisanNo);
		// 除却精算書番号
		kss006.setJokyakuSeisanShoNo(maxjokyakuSeisanShoNo);

		// 承認ステータス
		kss006.setShoninSattus(NSDConstant.STRING_00);

		// 登録年月日
		kss006.setEntryDate(date);
		// 登録ユーザーＩＤ
		kss006.setEntryUserId(NSDConstant.STRING_A9999); // TODO
										// 社員コード（実行ユーザーの社員コード）
		// 更新年月日
		kss006.setUpdateDate(date);
		// 更新ユーザーＩＤ
		kss006.setUpdateUserId(NSDConstant.STRING_A9999); // TODO
											// 社員コード（実行ユーザーの社員コード）
		// 除却資産登録
		int cnt = kss006Mapper.insertSelective(kss006);

		if (0 < cnt) {

			// 除却資産明細
			for (Kss007 kss007 : kss007Lst) {

				// 除却精算書ＩＤ
				kss007.setJokyakuSeisanShoId(kss006.getJokyakuSeisanShoId());
				// 除却資産ＩＤ
				kss007.setJokyakuShisanNo(kss006.getJokyakuShisanNo());

				// 除却区分コード(「0:全部除却」を設定)
				kss007.setJokyakuKbn(NSDConstant.STRING_0);
				// 除却種別コード(「1:その他」を設定)
				kss007.setJokyakuShubetsuCd(NSDConstant.STRING_1);
				// 貯蔵品分類コード
				kss007.setChozoBunruiCd(NSDConstant.STRING_0);
				// 登録年月日
				kss007.setEntryDate(date);
				// 登録ユーザーＩＤ
				kss007.setEntryUserId(NSDConstant.STRING_A9999); // TODO
												// 社員コード（実行ユーザーの社員コード）
				// 更新年月日
				kss007.setUpdateDate(date);
				// 更新ユーザーＩＤ
				kss007.setUpdateUserId(NSDConstant.STRING_A9999); // TODO
													// 社員コード（実行ユーザーの社員コード）

				// 除却資産明細登録
				cnt = kss007Mapper.insertSelective(kss007);

				if (0 < cnt) {

					KoteiSisan koteiSisan = new KoteiSisan();

					// 固定資産ID
					koteiSisan.setKoteiCod(kss007.getMotoKoteiShisanId());

					// 除却精算制御区分
					koteiSisan.setJkkseiKbn(NSDConstant.STRING_1);

					// 固定資産更新
					seisanshoJokyakuMapper.updateByPrimaryKey(koteiSisan);
				}
			}
		}

		return 0;
	}

}
