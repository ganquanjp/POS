package jp.co.nsd.nkssweb.dao;

public class BunkatsuSyunyu {

	// 行番号
	private int kouban;

	// 工事件名コード
	private String koujikodo;

	// 工事件名
	private String kojiKenmei;

	// 精算箇所
	private String seisankasyo;

	// 精算書番号
	private String seisanshono;

	// サービス開始年月日
	private String sabisukaisiymd;

	// サービス開始年月日
	private String sabisukaisiymdF;

	// サービス開始年月日
	private String sabisukaisiymdT;

	// 承認状態
	private String shoninjyotai;

	// 経理審査否認理由
	private String keirihininriyu;

	public int getKouban() {
		return kouban;
	}

	public void setKouban(int kouban) {
		this.kouban = kouban;
	}

	public String getKoujikodo() {
		return koujikodo;
	}

	public void setKoujikodo(String koujikodo) {
		this.koujikodo = koujikodo;
	}

	public String getKojiKenmei() {
		return kojiKenmei;
	}

	public void setKojiKenmei(String kojiKenmei) {
		this.kojiKenmei = kojiKenmei;
	}

	public String getSeisankasyo() {
		return seisankasyo;
	}

	public void setSeisankasyo(String seisankasyo) {
		this.seisankasyo = seisankasyo;
	}

	public String getSeisanshono() {
		return seisanshono;
	}

	public void setSeisanshono(String seisanshono) {
		this.seisanshono = seisanshono;
	}

	public String getSabisukaisiymd() {
		return sabisukaisiymd;
	}

	public void setSabisukaisiymd(String sabisukaisiymd) {
		this.sabisukaisiymd = sabisukaisiymd;
	}

	public String getSabisukaisiymdF() {
		return sabisukaisiymdF;
	}

	public void setSabisukaisiymdF(String sabisukaisiymdF) {
		this.sabisukaisiymdF = sabisukaisiymdF;
	}

	public String getSabisukaisiymdT() {
		return sabisukaisiymdT;
	}

	public void setSabisukaisiymdT(String sabisukaisiymdT) {
		this.sabisukaisiymdT = sabisukaisiymdT;
	}

	public String getShoninjyotai() {
		return shoninjyotai;
	}

	public void setShoninjyotai(String shoninjyotai) {
		this.shoninjyotai = shoninjyotai;
	}

	public String getKeirihininriyu() {
		return keirihininriyu;
	}

	public void setKeirihininriyu(String keirihininriyu) {
		this.keirihininriyu = keirihininriyu;
	}




}