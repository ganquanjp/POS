package jp.co.nsd.nkssweb.dao.mapper;

import java.util.List;

import jp.co.nsd.nkssweb.dao.SeisanshoToroku;

public interface SeisanshoTorokuMapper {

    List<SeisanshoToroku> selectByWhere(SeisanshoToroku record);

    List<SeisanshoToroku> selectByKey(SeisanshoToroku record);

}