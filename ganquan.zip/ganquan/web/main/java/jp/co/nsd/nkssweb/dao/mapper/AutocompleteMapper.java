package jp.co.nsd.nkssweb.dao.mapper;

import java.util.List;

import jp.co.nsd.nkssweb.dao.Kss002;
import jp.co.nsd.nkssweb.dao.Kss011;
import jp.co.nsd.nkssweb.dao.Kss013;

public interface AutocompleteMapper {


    List<Kss002> selectAllKss002();


    List<Kss011> selectAllKss011();


	List<Kss013> selectAllKss013();
}