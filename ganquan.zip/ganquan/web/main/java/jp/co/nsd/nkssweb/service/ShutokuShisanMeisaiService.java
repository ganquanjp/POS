package jp.co.nsd.nkssweb.service;

import jp.co.nsd.nkssweb.dao.Kss005;

public interface ShutokuShisanMeisaiService {

	/**
	 * 取得資産明細登録
	 *
	 * @param record
	 * @return
	 */
	void insertKss005(Kss005 record);
}
