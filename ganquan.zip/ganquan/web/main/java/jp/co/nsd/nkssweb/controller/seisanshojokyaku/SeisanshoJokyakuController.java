/***********************************************************************
*
*業務名: 工事精算システム
*機能名: 除却（登録・修正・削除）(ログ出力処理)
*
*機能概要: 除却情報を処理する。
*
*JavaＶｅｒ：J2SE1.8.0準拠
*
*更新履歴: Ver.1.00 2018/03/06　NSD　新規作成
***********************************************************************/

package jp.co.nsd.nkssweb.controller.seisanshojokyaku;

import java.lang.reflect.InvocationTargetException;
import java.math.BigDecimal;
import java.sql.Date;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.ibm.icu.text.SimpleDateFormat;

import jp.co.nsd.nkssweb.controller.BaseController;
import jp.co.nsd.nkssweb.dao.Kss006;
import jp.co.nsd.nkssweb.dao.Kss007;
import jp.co.nsd.nkssweb.dao.SeisanshoJokyaku;
import jp.co.nsd.nkssweb.dao.SeisanshoJokyakuShokai;
import jp.co.nsd.nkssweb.dao.SeisanshoJokyakuShokaiList;
import jp.co.nsd.nkssweb.service.seisanshojokyaku.SeisanshoJokyakuService;
import jp.co.nsd.nkssweb.utils.NSDCommUtils;
import jp.co.nsd.nkssweb.utils.NSDConstant;

/**
 * 除却（登録・修正・削除）処理
 *
 * @version 1.00
 */
@RestController
public class SeisanshoJokyakuController extends BaseController {

	SeisanshoJokyakuController() {
		super();
	}

	@Autowired
	private SeisanshoJokyakuService seisanshoJokyakuService;

	/**
	 * 除却（検索）処理
	 *
	 * @param reqMap
	 *            INPUTパラメータ
	 * @return 除却情報データ
	 * @exception IllegalAccessException
	 * @exception InvocationTargetException
	 * @version 1.00
	 */
	@RequestMapping(value = "/seisanshoJokyaku-selectByWhere", method = RequestMethod.POST)
	public Map<String, Object> selectByWhere(@RequestParam Map<String, Object> reqMap) {

		init();

		// メソッド名を取得する
		methodName = Thread.currentThread().getStackTrace()[1].getMethodName();

		// 開始ログ
		logger.info(methodName.concat(NSDConstant.LOG_INFO_METHOD_BEGIN));

		SeisanshoJokyaku seisanshoJokyaku = new SeisanshoJokyaku();

		List<SeisanshoJokyaku> sssJkkLst = new ArrayList<>();

		// 画面入力した検索条件を取得する
		try {
			// Mapの情報をBeanのプロパティにセット
			BeanUtils.populate(seisanshoJokyaku, reqMap);

			// 除却予定年月日（From）と除却予定年月日（To）の大小比較チェック
			if (NSDCommUtils.chkDateFromTo(seisanshoJokyaku.getJokyakuYoteYmdFrom(),
					seisanshoJokyaku.getJokyakuYoteYmdTo())) {

				// エラーメッセージを返却Mapに設定する
				return setMsgToResultMap(NSDConstant.MSGID_INPUT_ERROR);

			}

			// サービス呼び出し
			sssJkkLst = seisanshoJokyakuService.getJokyakuInfo(seisanshoJokyaku);

		} catch (Exception e) {

			// エラーメッセージを返却Mapに設定する
			return setMsgToResultMap(NSDConstant.MSGID_SYSTEM_ERROR);

		}

		// 検索結果を返却Mapに設定する
		setDataToResultMap(sssJkkLst);

		// 終了ログ
		logger.info(methodName.concat(NSDConstant.LOG_INFO_METHOD_END));

		return resultMap;
	}

	/**
	 * 除却（照会）処理
	 *
	 * @param reqMap
	 *            INPUTパラメータ
	 * @return 除却情報データ
	 * @exception IllegalAccessException
	 * @exception InvocationTargetException
	 * @version 1.00
	 */
	@RequestMapping(value = "/seisanshoJokyaku-selectBySeisanShoNo", method = RequestMethod.POST)
	public Map<String, Object> selectBySeisanShoNo(@RequestParam Map<String, Object> reqMap) {

		// 開始ログ
		logger.info("selectBySeisanShoNo 開始します。");

		Map<String, Object> resultMap = new HashMap<String, Object>();

		SeisanshoJokyakuShokai shokaiCondition = new SeisanshoJokyakuShokai();

		// 精算書より除却情報を取得する
		try {
			// Mapの情報をBeanのプロパティにセット
			BeanUtils.populate(shokaiCondition, reqMap);

		} catch (IllegalAccessException | InvocationTargetException e) {
			// エーラログ
			logger.info("selectBySeisanShoNoでエラーが発生しました。");
		}

		// サービス呼び出し
		SeisanshoJokyakuShokaiList sssJkkSkDto = seisanshoJokyakuService.getJokyakuInfoBySeisanShoNo(shokaiCondition);

		// 処理結果データ
		resultMap.put(NSDConstant.RESULT_DATA_LIST_NAME, sssJkkSkDto);
		// メッセージ内容
		resultMap.put(NSDConstant.RESULT_MSG_NAME, "");

		// 終了ログ
		logger.info("selectBySeisanShoNo 終了します。");

		return resultMap;
	}

	/**
	 * 除却（削除）処理
	 *
	 * @param reqMap
	 *            INPUTパラメータ
	 * @return 除却情報データ
	 * @exception IllegalAccessException
	 * @exception InvocationTargetException
	 * @version 1.00
	 */
	@RequestMapping(value = "/seisanshoJokyaku-delByPyKey", method = RequestMethod.POST)
	public Map<String, Object> delByPyKey(@RequestParam Map<String, Object> reqMap) {

		// 開始ログ
		logger.info("delByPyKey 開始します。");

		Map<String, Object> resultMap = new HashMap<String, Object>();

		SeisanshoJokyaku seisanshoJokyaku = new SeisanshoJokyaku();

		// 除却情報を削除する
		try {
			// Mapの情報をBeanのプロパティにセット
			BeanUtils.populate(seisanshoJokyaku, reqMap);

		} catch (IllegalAccessException | InvocationTargetException e) {
			// エーラログ
			logger.info("delByPyKeyでエラーが発生しました。");
		}

		// サービス呼び出し
		seisanshoJokyakuService.delByPyKey(seisanshoJokyaku);

		// 処理結果データ
		resultMap.put(NSDConstant.RESULT_DATA_LIST_NAME, "");
		// メッセージ内容
		resultMap.put(NSDConstant.RESULT_MSG_NAME, "");

		// 終了ログ
		logger.info("delByPyKey 終了します。");

		return resultMap;
	}

	/**
	 * 除却（登録）処理
	 *
	 * @param reqMap
	 *            INPUTパラメータ
	 * @return 除却情報データ
	 * @exception IllegalAccessException
	 * @exception InvocationTargetException
	 * @version 1.00
	 * @throws ParseException
	 */
	@RequestMapping(value = "/seisanshoJokyaku-insertInfo", method = RequestMethod.POST)
	public Map<String, Object> insertInfo(@RequestParam Map<String, Object> reqMap) throws ParseException {

		// 開始ログ
		logger.info("insertInfo 開始します。");
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd");
		// 除却資産
		Kss006 kss006 = new Kss006();
		// 精算箇所コード
		kss006.setSeisanSoshikiCd((String) reqMap.get("seisanSoshikiCd"));
		// 適用開始日
		kss006.setTekiyoStartYmd(
				sdf.parse(sdf.format(new Date(Long.parseLong((String) reqMap.get("tekiyoStartYmd"))))));
		// 除却予定年月
		kss006.setJokyakuYoteYmd(sdf.parse((String) reqMap.get("jokyakuYoteYmd")));
		// 登録者コード
		kss006.setSeisanEntryUserId((String) reqMap.get("userId"));
		// 摘要
		kss006.setTekiyo((String) reqMap.get("tekiyo"));
		// 工事件名
		kss006.setKenmeiNm((String) reqMap.get("kenmeiNm"));
		// 担当者適用開始日
		kss006.setTantoTekiyoStartYmd(
				sdf.parse(sdf.format(new Date(Long.parseLong((String) reqMap.get("nyushaYmd"))))));

		List<Kss007> kss007Lst = new ArrayList<>();

		Map<String, Object> resultMap = new HashMap<String, Object>();

		// MapKey
		String key;
		for (int i = 0; i < 20; i++) {

			// 固定資産番号KEY
			key = "koteiSisanLst".concat("[" + i + "]").concat("[koteiNo]");
			// 固定資産番号が空の場合
			if (StringUtils.isEmpty((String) reqMap.get(key))) {
				continue;
			}

			Kss007 kss007 = new Kss007();
			// 除却元固定資産ＩＤ
			kss007.setMotoKoteiShisanId((String) reqMap.get(key));
			// 種類コードKEY
			key = "koteiSisanLst".concat("[" + i + "]").concat("[syurui]");
			kss007.setShuruiCd((String) reqMap.get(key));
			// 構造コードKEY
			key = "koteiSisanLst".concat("[" + i + "]").concat("[kouzo]");
			kss007.setKouzouCd((String) reqMap.get(key));
			// 資産単位コードKEY
			key = "koteiSisanLst".concat("[" + i + "]").concat("[sisanTani]");
			kss007.setShisanTaniCd((String) reqMap.get(key));
			// 科目１コードKEY
			key = "koteiSisanLst".concat("[" + i + "]").concat("[kamoku1]");
			kss007.setKamokuCd1((String) reqMap.get(key));
			// 科目２コードKEY
			key = "koteiSisanLst".concat("[" + i + "]").concat("[kamoku2]");
			kss007.setKamokuCd2((String) reqMap.get(key));
			// 科目３コードKEY
			key = "koteiSisanLst".concat("[" + i + "]").concat("[kamoku3]");
			kss007.setKamokuCd3((String) reqMap.get(key));
			// 除＿数量KEY
			key = "koteiSisanLst".concat("[" + i + "]").concat("[meiSu]");
			kss007.setJokyakuSuryo(new BigDecimal((String) reqMap.get(key)));
			// 除＿取得価額KEY
			key = "koteiSisanLst".concat("[" + i + "]").concat("[getkgkYen]");
			kss007.setJokyakuGaku(Long.parseLong((String) reqMap.get(key)));

			// 除却資産明細
			kss007Lst.add(kss007);
		}

		// サービス呼び出し
		seisanshoJokyakuService.insertInfo(kss006, kss007Lst);

		// 処理結果データ
		resultMap.put(NSDConstant.RESULT_DATA_LIST_NAME, "");
		// メッセージ内容
		resultMap.put(NSDConstant.RESULT_MSG_NAME, "");

		// 終了ログ
		logger.info("insertInfo 終了します。");

		return resultMap;
	}
}
