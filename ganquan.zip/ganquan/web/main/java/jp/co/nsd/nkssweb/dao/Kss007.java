package jp.co.nsd.nkssweb.dao;

import java.math.BigDecimal;
import java.util.Date;

public class Kss007 extends Kss007Key {
    private String rirekiNo;

    private String jokyakuKbn;

    private String shuruiCd;

    private String kouzouCd;

    private String shisanTaniCd;

    private String kamokuCd1;

    private String kamokuCd2;

    private String kamokuCd3;

    private String jokyakuShubetsuCd;

    private BigDecimal jokyakuSuryo;

    private Long jokyakuGaku;

    private String chozoBunruiCd;

    private Date entryDate;

    private String entryUserId;

    private Date updateDate;

    private String updateUserId;

    public String getRirekiNo() {
        return rirekiNo;
    }

    public void setRirekiNo(String rirekiNo) {
        this.rirekiNo = rirekiNo == null ? null : rirekiNo.trim();
    }

    public String getJokyakuKbn() {
        return jokyakuKbn;
    }

    public void setJokyakuKbn(String jokyakuKbn) {
        this.jokyakuKbn = jokyakuKbn == null ? null : jokyakuKbn.trim();
    }

    public String getShuruiCd() {
        return shuruiCd;
    }

    public void setShuruiCd(String shuruiCd) {
        this.shuruiCd = shuruiCd == null ? null : shuruiCd.trim();
    }

    public String getKouzouCd() {
        return kouzouCd;
    }

    public void setKouzouCd(String kouzouCd) {
        this.kouzouCd = kouzouCd == null ? null : kouzouCd.trim();
    }

    public String getShisanTaniCd() {
        return shisanTaniCd;
    }

    public void setShisanTaniCd(String shisanTaniCd) {
        this.shisanTaniCd = shisanTaniCd == null ? null : shisanTaniCd.trim();
    }

    public String getKamokuCd1() {
        return kamokuCd1;
    }

    public void setKamokuCd1(String kamokuCd1) {
        this.kamokuCd1 = kamokuCd1 == null ? null : kamokuCd1.trim();
    }

    public String getKamokuCd2() {
        return kamokuCd2;
    }

    public void setKamokuCd2(String kamokuCd2) {
        this.kamokuCd2 = kamokuCd2 == null ? null : kamokuCd2.trim();
    }

    public String getKamokuCd3() {
        return kamokuCd3;
    }

    public void setKamokuCd3(String kamokuCd3) {
        this.kamokuCd3 = kamokuCd3 == null ? null : kamokuCd3.trim();
    }

    public String getJokyakuShubetsuCd() {
        return jokyakuShubetsuCd;
    }

    public void setJokyakuShubetsuCd(String jokyakuShubetsuCd) {
        this.jokyakuShubetsuCd = jokyakuShubetsuCd == null ? null : jokyakuShubetsuCd.trim();
    }

    public BigDecimal getJokyakuSuryo() {
        return jokyakuSuryo;
    }

    public void setJokyakuSuryo(BigDecimal jokyakuSuryo) {
        this.jokyakuSuryo = jokyakuSuryo;
    }

    public Long getJokyakuGaku() {
        return jokyakuGaku;
    }

    public void setJokyakuGaku(Long jokyakuGaku) {
        this.jokyakuGaku = jokyakuGaku;
    }

    public String getChozoBunruiCd() {
        return chozoBunruiCd;
    }

    public void setChozoBunruiCd(String chozoBunruiCd) {
        this.chozoBunruiCd = chozoBunruiCd == null ? null : chozoBunruiCd.trim();
    }

    public Date getEntryDate() {
        return entryDate;
    }

    public void setEntryDate(Date entryDate) {
        this.entryDate = entryDate;
    }

    public String getEntryUserId() {
        return entryUserId;
    }

    public void setEntryUserId(String entryUserId) {
        this.entryUserId = entryUserId == null ? null : entryUserId.trim();
    }

    public Date getUpdateDate() {
        return updateDate;
    }

    public void setUpdateDate(Date updateDate) {
        this.updateDate = updateDate;
    }

    public String getUpdateUserId() {
        return updateUserId;
    }

    public void setUpdateUserId(String updateUserId) {
        this.updateUserId = updateUserId == null ? null : updateUserId.trim();
    }
}