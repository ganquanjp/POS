/***********************************************************************
*
*業務名: 工事精算システム
*機能名: 各参照ボタン用検索処理
*
*機能概要: 各参照ボタン用検索処理
*
*JavaＶｅｒ：J2SE1.8.0準拠
*
*更新履歴: Ver.1.00 2018/03/06　NSD　新規作成
***********************************************************************/

package jp.co.nsd.nkssweb.controller;

import java.lang.reflect.InvocationTargetException;
import java.sql.Date;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import jp.co.nsd.nkssweb.dao.KanriFutanks;
import jp.co.nsd.nkssweb.dao.KoteiSisan;
import jp.co.nsd.nkssweb.dao.Message;
import jp.co.nsd.nkssweb.dao.SechiBasho;
import jp.co.nsd.nkssweb.dao.TorihikiSaki;
import jp.co.nsd.nkssweb.service.SanshoService;
import jp.co.nsd.nkssweb.service.SystemService;
import jp.co.nsd.nkssweb.utils.NSDConstant;

/**
 * 参照ボタン用コントロール
 *
 * @version 1.00
 */
@RestController
public class SanshoController {

	// ログ
	private Logger logger = LoggerFactory.getLogger(this.getClass());

	@Autowired
	private SanshoService sanshoService;

	protected SystemService systemService;

	/**
	 * 固定資産（検索）処理
	 *
	 * @param reqMap
	 *            INPUTパラメータ
	 * @return 固定資産情報データ
	 * @version 1.00
	 */
	@RequestMapping(value = "/sansho-koteishisan", method = RequestMethod.POST)
	public Map<String, Object> getKoteiShisan(@RequestParam Map<String, Object> reqMap) {

		// 開始ログ
		logger.info("getKoteiShisan 開始します。");

		Map<String, Object> resultMap = new HashMap<String, Object>();

		Message message = new Message();

		KoteiSisan koteiSisan = new KoteiSisan();

		List<KoteiSisan> ktssList = new ArrayList<KoteiSisan>();

		// 画面入力した検索条件を取得する
		try {
			// Mapの情報をBeanのプロパティにセット
			BeanUtils.populate(koteiSisan, reqMap);

			// 使用開始年月日（From）と使用開始年月日（To）の大小比較チェック
			if (chkDateFromTo(koteiSisan.getUseYmdFrom(), koteiSisan.getUseYmdTo())) {
				// 処理結果データ
				resultMap.put(NSDConstant.RESULT_DATA_LIST_NAME, ktssList);
				// メッセージ内容
				// TODO: メッセージID未定
				message = systemService.getMessage("");
				resultMap.put(NSDConstant.RESULT_MSG_NAME, message);

				// 終了ログ
				logger.info("getKoteiShisan 終了します。");

				return resultMap;
			}
		} catch (IllegalAccessException | InvocationTargetException e) {
			// エーラログ
			logger.info("getKoteiShisanでエラーが発生しました。");
			e.printStackTrace();
		}

		try {
			// サービス呼び出し
			ktssList = sanshoService.getKoteiSisanInfo(koteiSisan);
		} catch (Exception e) {
			logger.info("sanshoService.getKoteiSisanInfo でエラーが発生しました。");
			logger.debug(e.getMessage());
			logger.debug(e.getStackTrace().toString());
			message = systemService.getMessage(NSDConstant.MSGID_SYSTEM_ERROR);
			resultMap.put(NSDConstant.RESULT_MSG_NAME, message);
			return resultMap;
		}

		// 処理結果データ
		resultMap.put("dataList", ktssList);
		// メッセージ内容
		resultMap.put("msg", "");

		// 終了ログ
		logger.info("getKoteiShisan 終了します。");

		return resultMap;
	}

	/**
	 * 取引先（検索）処理
	 *
	 * @param reqMap
	 * @return
	 */
	@RequestMapping(value = "/sansho-torihikisaki", method = RequestMethod.POST)
	public Map<String, Object> getTorihikiSaki(@RequestParam Map<String, Object> reqMap) {

		// 開始ログ
		logger.info("getTorihikiSaki 開始します。");

		Map<String, Object> resultMap = new HashMap<String, Object>();

		Message message = new Message();

		TorihikiSaki torihikiSaki = new TorihikiSaki();

		List<TorihikiSaki> trhksList = new ArrayList<TorihikiSaki>();

		// 画面入力した検索条件を取得する
		try {
			// Mapの情報をBeanのプロパティにセット
			BeanUtils.populate(torihikiSaki, reqMap);

		} catch (IllegalAccessException | InvocationTargetException e) {
			// エーラログ
			logger.info("getTorihikiSakiでエラーが発生しました。");
			e.printStackTrace();
		}

		try {
			// サービス呼び出し
			trhksList = sanshoService.getTorihikiSakiInfo(torihikiSaki);
		} catch (Exception e) {
			logger.info("sanshoService.getTorihikiSakiInfo でエラーが発生しました。");
			logger.debug(e.getMessage());
			logger.debug(e.getStackTrace().toString());
			message = systemService.getMessage(NSDConstant.MSGID_SYSTEM_ERROR);
			resultMap.put(NSDConstant.RESULT_MSG_NAME, message);
			return resultMap;
		}

		// 処理結果データ
		resultMap.put(NSDConstant.RESULT_DATA_LIST_NAME, trhksList);
		// メッセージ内容
		resultMap.put(NSDConstant.RESULT_MSG_NAME, NSDConstant.BLANK_STRING);

		// 終了ログ
		logger.info("getTorihikiSaki 終了します。");

		return resultMap;
	}

	/**
	 * 管理箇所/負担箇所検索処理
	 *
	 * @param reqMap
	 *            INPUTパラメータ
	 * @return 管理箇所/負担箇所情報データ
	 * @exception IllegalAccessException
	 * @exception InvocationTargetException
	 * @version 1.00
	 */
	@RequestMapping(value = "/sansho-kanrifutanks", method = RequestMethod.POST)
	public Map<String, Object> getKanriFutanks(@RequestParam Map<String, Object> reqMap) {

		// 開始ログ
		logger.info("getKanriFutanks 開始します。");

		Map<String, Object> resultMap = new HashMap<String, Object>();

		Message message = new Message();

		KanriFutanks kanriFutanks = new KanriFutanks();

		List<KanriFutanks> krftList = new ArrayList<KanriFutanks>();

		// 画面入力した検索条件を取得する
		try {
			// Mapの情報をBeanのプロパティにセット
			BeanUtils.populate(kanriFutanks, reqMap);

		} catch (IllegalAccessException | InvocationTargetException e) {
			// エーラログ
			logger.info("getKanriFutanksでエラーが発生しました。");
			e.printStackTrace();
		}

		try {
			// サービス呼び出し
			krftList = sanshoService.getKanriFutanInfo(kanriFutanks);
		} catch (Exception e) {
			logger.info("sanshoService.getKanriFutanInfo でエラーが発生しました。");
			logger.debug(e.getMessage());
			logger.debug(e.getStackTrace().toString());
			message = systemService.getMessage(NSDConstant.MSGID_SYSTEM_ERROR);
			resultMap.put(NSDConstant.RESULT_MSG_NAME, message);
			return resultMap;
		}


		// 処理結果データ
		resultMap.put(NSDConstant.RESULT_DATA_LIST_NAME, krftList);
		// メッセージ内容
		resultMap.put(NSDConstant.RESULT_MSG_NAME, NSDConstant.BLANK_STRING);

		// 終了ログ
		logger.info("getKanriFutanks 終了します。");

		return resultMap;
	}

	/**
	 * 設置場所（検索）処理
	 *
	 * @param reqMap
	 * @return
	 */
	@RequestMapping(value = "/sansho-sechibasho", method = RequestMethod.POST)
	public Map<String, Object> getSechiBasho(@RequestParam Map<String, Object> reqMap) {

		// 開始ログ
		logger.info("getSechiBasho 開始します。");

		Map<String, Object> resultMap = new HashMap<String, Object>();

		Message message = new Message();

		SechiBasho sechiBasho = new SechiBasho();

		List<SechiBasho> scbsList = new ArrayList<SechiBasho>();

		// 画面入力した検索条件を取得する
		try {
			// Mapの情報をBeanのプロパティにセット
			BeanUtils.populate(sechiBasho, reqMap);

		} catch (IllegalAccessException | InvocationTargetException e) {
			// エーラログ
			logger.info("getSechiBashoでエラーが発生しました。");
			e.printStackTrace();
		}

		try {
			// サービス呼び出し
			scbsList = sanshoService.getSechiBashoInfo(sechiBasho);
		} catch (Exception e) {
			logger.info("sanshoService.getSechiBashoInfo でエラーが発生しました。");
			logger.debug(e.getMessage());
			logger.debug(e.getStackTrace().toString());
			message = systemService.getMessage(NSDConstant.MSGID_SYSTEM_ERROR);
			resultMap.put(NSDConstant.RESULT_MSG_NAME, message);
			return resultMap;
		}


		// 処理結果データ
		resultMap.put(NSDConstant.RESULT_DATA_LIST_NAME, scbsList);
		// メッセージ内容
		resultMap.put(NSDConstant.RESULT_MSG_NAME, NSDConstant.BLANK_STRING);

		// 終了ログ
		logger.info("getSechiBasho 終了します。");

		return resultMap;
	}

	/**
	 * 日付From-To大小比較チェック
	 *
	 * @param dateFrom
	 *            String
	 * @param dateTo
	 *            String
	 * @return boolean
	 */
	public boolean chkDateFromTo(String dateFrom, String dateTo) {

		// 使用開始年月日（From）と使用開始年月日（To）存在の場合
		if (StringUtils.isNotEmpty(dateFrom) && StringUtils.isNotEmpty(dateTo)) {
			// 使用開始年月日（From）と使用開始年月日（To）の大小比較チェック
			if (Date.valueOf(dateFrom).compareTo(Date.valueOf(dateTo)) == 1) {
				return true;
			}
		}
		return false;
	}
}
