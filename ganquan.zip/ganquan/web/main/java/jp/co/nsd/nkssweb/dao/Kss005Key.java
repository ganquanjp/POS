package jp.co.nsd.nkssweb.dao;

import java.math.BigDecimal;

public class Kss005Key {
    private BigDecimal seisanShoId;

    private BigDecimal koteiShisanId;

    public BigDecimal getSeisanShoId() {
        return seisanShoId;
    }

    public void setSeisanShoId(BigDecimal seisanShoId) {
        this.seisanShoId = seisanShoId;
    }

    public BigDecimal getKoteiShisanId() {
        return koteiShisanId;
    }

    public void setKoteiShisanId(BigDecimal koteiShisanId) {
        this.koteiShisanId = koteiShisanId;
    }
}