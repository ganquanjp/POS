/***********************************************************************
*
*業務名: 工事精算システム
*機能名: 候補内容(共通処理)
*
*機能概要: 入力中の内容を部分一致にて検索し、
*          候補を入力フォーム下部に表示のデータを取得する
*
*JavaＶｅｒ：J2SE1.8.0準拠
*
*更新履歴: Ver.1.00 2018/03/13　NSD　新規作成
***********************************************************************/

package jp.co.nsd.nkssweb.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import jp.co.nsd.nkssweb.dao.Kss002;
import jp.co.nsd.nkssweb.dao.Kss011;
import jp.co.nsd.nkssweb.dao.Kss013;
import jp.co.nsd.nkssweb.dao.Message;
import jp.co.nsd.nkssweb.service.AutocompleteService;
import jp.co.nsd.nkssweb.service.SystemService;
import jp.co.nsd.nkssweb.utils.NSDConstant;

/**
 * 候補内容(共通処理)
 *
 * @version 1.00
 */
@RestController
public class AutocompleteController {

	// ログ
	private Logger logger = LoggerFactory.getLogger(this.getClass());

	@Autowired
	private AutocompleteService autocompleteService;

	protected SystemService systemService;

	/**
	 * ユーザ情報全件取得
	 *
	 * @version 1.00
	 */
	@RequestMapping(value = "/autocomplete-selectUserMaster", method = RequestMethod.GET)
	public Map<String, Object> selectUserMaster() {

		logger.info("selectUserMaster 開始します。");

		Map<String, Object> resultMap = new HashMap<String, Object>();

		Message message = new Message();

		List<Kss013> kss013List = new ArrayList<Kss013>();

		try {
			// サービスを呼び出す
			kss013List = autocompleteService.getUserMaster();

		} catch (Exception e) {
			logger.info("autocompleteService.getUserMasterでエラーが発生しました。");
			logger.info(e.getStackTrace().toString());
			logger.info(e.getMessage());
			message = systemService.getMessage(NSDConstant.MSGID_SYSTEM_ERROR);
			resultMap.put(NSDConstant.RESULT_MSG_NAME, message);
			return resultMap;
		}

		// 処理結果データ
		resultMap.put(NSDConstant.RESULT_DATA_LIST_NAME, kss013List);

		// 終了ログ
		logger.info("selectUserMaster 終了します。");

		return resultMap;
	}


	/*
	 * 件名マスタ全件取得
	 */
	@RequestMapping(value = "/autocomplete-selectKenmeiMaster", method = RequestMethod.GET)
	public Map<String, Object> selectKenmeiMaster() {

		logger.info("selectKenmeiMaster 開始します。");

		Map<String, Object> resultMap = new HashMap<String, Object>();

		Message message = new Message();

		List<Kss002> kss002List = new ArrayList<Kss002>();

		try {
			// サービスを呼び出す
			kss002List = autocompleteService.getKenmeiMaster();
		} catch (Exception e) {
			logger.info("autocompleteService.getKenmeiMasterでエラーが発生しました。");
			logger.info(e.getStackTrace().toString());
			logger.info(e.getMessage());
			message = systemService.getMessage(NSDConstant.MSGID_SYSTEM_ERROR);
			resultMap.put(NSDConstant.RESULT_MSG_NAME, message);
			return resultMap;
		}

		// 処理結果データ
		resultMap.put(NSDConstant.RESULT_DATA_LIST_NAME, kss002List);

		// 終了ログ
		logger.info("selectKenmeiMaster 終了します。");

		return resultMap;
	}

	/*
	 * 組織マスタ全件取得
	 */
	@RequestMapping(value = "/autocomplete-selectSoshikiMaster", method = RequestMethod.GET)
	public Map<String, Object> selectSoshikiMaster() {

		logger.info("selectSoshikiMaster 開始します。");

		Map<String, Object> resultMap = new HashMap<String, Object>();

		Message message = new Message();

		List<Kss011> kss011List = new ArrayList<Kss011>();

		try {
			// サービスを呼び出す
			kss011List = autocompleteService.getSoshikiMaster();
		} catch (Exception e) {
			logger.info("autocompleteService.getSoshikiMasterでエラーが発生しました。");
			logger.info(e.getStackTrace().toString());
			logger.info(e.getMessage());
			message = systemService.getMessage(NSDConstant.MSGID_SYSTEM_ERROR);
			resultMap.put(NSDConstant.RESULT_MSG_NAME, message);
			return resultMap;
		}

		// 処理結果データ
		resultMap.put(NSDConstant.RESULT_DATA_LIST_NAME, kss011List);

		// 終了ログ
		logger.info("selectSoshikiMaster 終了します。");

		return resultMap;
	}
}
