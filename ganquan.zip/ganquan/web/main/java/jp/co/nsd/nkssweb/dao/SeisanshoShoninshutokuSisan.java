package jp.co.nsd.nkssweb.dao;


public class SeisanshoShoninshutokuSisan {

	// 行番
	private int rowNo;

	// 固定資産番号
	private String koteiShisanNo;

	// 固定資産名称
	private String koteiShisanNm;

	// 取得年月日
	private String shutokuYmd;

	// 取得価額
	private String shutokuKagaku;

	public int getRowNo() {
		return rowNo;
	}

	public void setRowNo(int rowNo) {
		this.rowNo = rowNo;
	}

	public String getKoteiShisanNo() {
		return koteiShisanNo;
	}

	public void setKoteiShisanNo(String koteiShisanNo) {
		this.koteiShisanNo = koteiShisanNo;
	}

	public String getKoteiShisanNm() {
		return koteiShisanNm;
	}

	public void setKoteiShisanNm(String koteiShisanNm) {
		this.koteiShisanNm = koteiShisanNm;
	}

	public String getShutokuYmd() {
		return shutokuYmd;
	}

	public void setShutokuYmd(String shutokuYmd) {
		this.shutokuYmd = shutokuYmd;
	}

	public String getShutokuKagaku() {
		return shutokuKagaku;
	}

	public void setShutokuKagaku(String shutokuKagaku) {
		this.shutokuKagaku = shutokuKagaku;
	}



}