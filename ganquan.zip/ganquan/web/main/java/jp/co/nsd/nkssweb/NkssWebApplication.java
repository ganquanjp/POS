package jp.co.nsd.nkssweb;

import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
@MapperScan("jp.co.nsd.nkssweb.dao.mapper")
public class NkssWebApplication {

	public static void main(String[] args) {
		SpringApplication.run(NkssWebApplication.class, args);
	}
}
