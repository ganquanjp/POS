package jp.co.nsd.nkssweb.dao;

import java.math.BigDecimal;

public class Kss006Key {
    private BigDecimal jokyakuSeisanShoId;

    private BigDecimal jokyakuShisanNo;

    public BigDecimal getJokyakuSeisanShoId() {
        return jokyakuSeisanShoId;
    }

    public void setJokyakuSeisanShoId(BigDecimal jokyakuSeisanShoId) {
        this.jokyakuSeisanShoId = jokyakuSeisanShoId;
    }

    public BigDecimal getJokyakuShisanNo() {
        return jokyakuShisanNo;
    }

    public void setJokyakuShisanNo(BigDecimal jokyakuShisanNo) {
        this.jokyakuShisanNo = jokyakuShisanNo;
    }
}