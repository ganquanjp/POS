package jp.co.nsd.nkssweb.dao.mapper;

import java.util.List;

import jp.co.nsd.nkssweb.dao.KanriFutanks;
import jp.co.nsd.nkssweb.dao.KoteiSisan;
import jp.co.nsd.nkssweb.dao.SechiBasho;
import jp.co.nsd.nkssweb.dao.TorihikiSaki;

public interface SanshoMapper {

	/**
	 * 固定資産検索画面
	 *
	 * @param koteiSisan
	 *            INPUTパラメータ
	 * @return　検索結果
	 */
	List<KoteiSisan> selectKoteiSisan(KoteiSisan koteiSisan);

	/**
	 * 取引先検索画面
	 *
	 * @param torihikiSaki
	 *            INPUTパラメータ
	 * @return　検索結果
	 */
	List<TorihikiSaki> selectTorihikiSaki(TorihikiSaki torihikiSaki);

	/**
	 * 管理箇所/負担箇所検索画面
	 *
	 * @param kanriFutanks
	 *            INPUTパラメータ
	 * @return　検索結果
	 */
	List<KanriFutanks> selectKanriFutanks(KanriFutanks kanriFutanks);

	/**
	 * 設置場所検索画面
	 *
	 * @param sechiBasho
	 *            INPUTパラメータ
	 * @return　検索結果
	 */
	List<SechiBasho> selectSechiBasho(SechiBasho sechiBasho);
}