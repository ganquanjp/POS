package jp.co.nsd.nkssweb.dao;

import java.util.Date;

public class Kss015Key {
    private String kanriSoshikiCd;

    private Date kanriTekiyoStartYmd;

    private String futanSoshikiCd;

    private Date futanTekiyoStartYmd;

    public String getKanriSoshikiCd() {
        return kanriSoshikiCd;
    }

    public void setKanriSoshikiCd(String kanriSoshikiCd) {
        this.kanriSoshikiCd = kanriSoshikiCd == null ? null : kanriSoshikiCd.trim();
    }

    public Date getKanriTekiyoStartYmd() {
        return kanriTekiyoStartYmd;
    }

    public void setKanriTekiyoStartYmd(Date kanriTekiyoStartYmd) {
        this.kanriTekiyoStartYmd = kanriTekiyoStartYmd;
    }

    public String getFutanSoshikiCd() {
        return futanSoshikiCd;
    }

    public void setFutanSoshikiCd(String futanSoshikiCd) {
        this.futanSoshikiCd = futanSoshikiCd == null ? null : futanSoshikiCd.trim();
    }

    public Date getFutanTekiyoStartYmd() {
        return futanTekiyoStartYmd;
    }

    public void setFutanTekiyoStartYmd(Date futanTekiyoStartYmd) {
        this.futanTekiyoStartYmd = futanTekiyoStartYmd;
    }
}