/***********************************************************************
*
*業務名: 工事精算システム
*機能名: 除却（登録・修正・削除）(サービス処理)
*
*機能概要: 除却情報を処理する。
*
*JavaＶｅｒ：J2SE1.8.0準拠
*
*更新履歴: Ver.1.00 2018/03/06　NSD　新規作成
***********************************************************************/
package jp.co.nsd.nkssweb.service.impl;

import java.util.Date;
import java.util.List;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import jp.co.nsd.nkssweb.dao.KanriFutanhimodzuki;
import jp.co.nsd.nkssweb.dao.Kss015;
import jp.co.nsd.nkssweb.dao.mapper.KanriFutanhimodzukiMapper;
import jp.co.nsd.nkssweb.dao.mapper.Kss015Mapper;
import jp.co.nsd.nkssweb.service.KanriFutanhimodzukiService;
import jp.co.nsd.nkssweb.utils.NSDConstant;

/**
 * 管理箇所/負担箇所紐付（検索・修正・新規）処理
 *
 * @see KanriFutanhimodzukiService
 * @version 1.00
 */
@Service
public class KanriFutanhimodzukiServiceImpl implements KanriFutanhimodzukiService {

	// ログ
	private Logger logger = LoggerFactory.getLogger(this.getClass());

	@Autowired
	private KanriFutanhimodzukiMapper kanriFutanhimodzukiMapper;
	@Autowired
	private Kss015Mapper kss015Mapper;

	/**
	 * 管理箇所/負担箇所（検索）処理
	 *
	 * @param kanriFutanhimodzuki
	 *            INPUTパラメータ
	 * @return kfhList 管理箇所/負担箇所情報データリスト
	 * @version 1.00
	 */
	public List<KanriFutanhimodzuki> getKanriFutanInfo(KanriFutanhimodzuki kanriFutanhimodzuki) {

		// 開始ログ
		logger.info("KanriFutanhimodzukiServiceImpl.getKanriFutanInfo 開始します。");

		// 除却情報を取得する
		List<KanriFutanhimodzuki> kfhList = kanriFutanhimodzukiMapper.selectByWhere(kanriFutanhimodzuki);

		for (int i = 1; i <= kfhList.size(); i++) {
			// ROWNOを設定する
			kfhList.get(i - 1).setRowNo(i);
		}

		// 終了ログ
		logger.info("KanriFutanhimodzukiServiceImpl.getKanriFutanInfo 終了します。");

		return kfhList;
	}

	/**
	 * 管理箇所/負担箇所紐付（登録）処理
	 *
	 * @param KanriFutanhimodzuki
	 *            INPUTパラメータ
	 * @version 1.00
	 */
	public int insertInfo(List<KanriFutanhimodzuki> krFtLst) {

		Kss015 kss015;

		Date date = new Date();

		// SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");

		// 管理負担箇所
		for (KanriFutanhimodzuki kanriFutanhimodzuki : krFtLst) {

			kss015 = new Kss015();

			// 管理箇所
			// kss015.setKanriSoshikiKnj(kanriFutanhimodzuki.getKanriSoshikiKnj());
			// 管理箇所コード
			kss015.setKanriSoshikiCd(kanriFutanhimodzuki.getKanriSoshikiCd());

			// 管理箇所適用期間（FROM）

			kss015.setKanriTekiyoStartYmd(kanriFutanhimodzuki.getKanriTekiyoStartYmd());

			// 管理箇所適用期間（TO）
			kss015.setKanriTekiyoEndYmd(kanriFutanhimodzuki.getKanriTekiyoEndYmd());

			// 負担箇所
			// kss015.setFutanSoshikiKnj(kanriFutanhimodzuki.getFutanSoshikiKnj());

			// 負担箇所コード
			kss015.setFutanSoshikiCd(kanriFutanhimodzuki.getFutanSoshikiCd());

			// 負担箇所適用期間（FROM）
			kss015.setFutanTekiyoStartYmd(kanriFutanhimodzuki.getFutanTekiyoStartYmd());

			// 負担箇所適用期間（FROM）
			kss015.setFutanTekiyoEndYmd(kanriFutanhimodzuki.getFutanTekiyoEndYmd());

			// 登録年月日
			kss015.setEntryDate(date);

			// 登録ユーザーＩＤ
			kss015.setEntryUserId(NSDConstant.STRING_A9999); // TODO
											// 社員コード（実行ユーザーの社員コード）
			// 更新年月日
			kss015.setUpdateDate(date);

			// 更新ユーザーＩＤ
			kss015.setUpdateUserId(NSDConstant.STRING_A9999); // TODO
			// 社員コード（実行ユーザーの社員コード）
			// 除却資産明細登録
			kss015Mapper.insertSelective(kss015);
		}

		return 0;
	}

}
