package jp.co.nsd.nkssweb.utils;

/**
 * プロパティファイルの値を読込
 *
 * @author nsdH272059
 *
 */
public class NSDProperties {

	/**
	 * IDよりValueを取得する
	 *
	 * @param PropertiesID
	 * @return
	 */
	public static String getProperties(String PropertiesID) {
		String value = "";
//		byte ptext[] = myString.getBytes();
//		String value = new String(ptext, "UTF-8");
		return value;
	}

}
