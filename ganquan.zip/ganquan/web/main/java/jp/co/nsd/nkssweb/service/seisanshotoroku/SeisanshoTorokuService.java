package jp.co.nsd.nkssweb.service.seisanshotoroku;

import java.util.List;

import jp.co.nsd.nkssweb.dao.Kss002;
import jp.co.nsd.nkssweb.dao.Kss004;
import jp.co.nsd.nkssweb.dao.SeisanshoToroku;

public interface SeisanshoTorokuService {

	/**
	 * 精算書登録・検索
	 *
	 * @return
	 */
	List<SeisanshoToroku> getSeisanshoTorokuKensaku(SeisanshoToroku selectCondition);

	/**
	 * 精算書登録・照会
	 *
	 * @return
	 */
	List<SeisanshoToroku> getSeisanshoTorokuShokai(SeisanshoToroku selectCondition);

	/**
	 * 精算書登録
	 *
	 * @param kss004
	 */
	void insertSeisansho(Kss002 kss002, Kss004 kss004);

}
