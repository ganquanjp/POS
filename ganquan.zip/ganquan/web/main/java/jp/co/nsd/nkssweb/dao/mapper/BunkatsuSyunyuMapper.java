package jp.co.nsd.nkssweb.dao.mapper;

import java.util.List;

import jp.co.nsd.nkssweb.dao.BunkatsuSyunyu;

public interface BunkatsuSyunyuMapper {

    List<BunkatsuSyunyu> selectByWhere(BunkatsuSyunyu record);

}