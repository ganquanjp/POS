package jp.co.nsd.nkssweb.dao;

public class SeisanshoShutokuKensaku {

	private int rowNo;
	private String seisanShoId;
	private String seisanShoNo;
	private String koteiShisanId;
	private String soshikiNm;
	private String siyoStartYmdFrom;
	private String siyoStartYmdTo;
	private String torokushaName;
	private String koteiShisanNo;
	private String koteiShisanName;
	private String shutokuYmdFrom;
	private String shutokuYmdTo;
	private String sechiBashoName;
	private String kenmeiCd;
	private String kenmeiNm;
	private String kanriSoshikiCd;
	private String kojiTantoUserNm;

	public int getRowNo() {
		return rowNo;
	}

	public void setRowNo(int rowNo) {
		this.rowNo = rowNo;
	}

	public String getSeisanShoId() {
		return seisanShoId;
	}

	public void setSeisanShoId(String seisanShoId) {
		this.seisanShoId = seisanShoId;
	}

	public String getSeisanShoNo() {
		return seisanShoNo;
	}

	public void setSeisanShoNo(String seisanShoNo) {
		this.seisanShoNo = seisanShoNo;
	}

	public String getKoteiShisanId() {
		return koteiShisanId;
	}

	public void setKoteiShisanId(String koteiShisanId) {
		this.koteiShisanId = koteiShisanId;
	}

	public String getSoshikiNm() {
		return soshikiNm;
	}

	public void setSoshikiNm(String soshikiNm) {
		this.soshikiNm = soshikiNm;
	}

	public String getSiyoStartYmdFrom() {
		return siyoStartYmdFrom;
	}

	public void setSiyoStartYmdFrom(String siyoStartYmdFrom) {
		this.siyoStartYmdFrom = siyoStartYmdFrom;
	}

	public String getSiyoStartYmdTo() {
		return siyoStartYmdTo;
	}

	public void setSiyoStartYmdTo(String siyoStartYmdTo) {
		this.siyoStartYmdTo = siyoStartYmdTo;
	}

	public String getTorokushaName() {
		return torokushaName;
	}

	public void setTorokushaName(String torokushaName) {
		this.torokushaName = torokushaName;
	}

	public String getKoteiShisanNo() {
		return koteiShisanNo;
	}

	public void setKoteiShisanNo(String koteiShisanNo) {
		this.koteiShisanNo = koteiShisanNo;
	}

	public String getKoteiShisanName() {
		return koteiShisanName;
	}

	public void setKoteiShisanName(String koteiShisanName) {
		this.koteiShisanName = koteiShisanName;
	}

	public String getShutokuYmdFrom() {
		return shutokuYmdFrom;
	}

	public void setShutokuYmdFrom(String shutokuYmdFrom) {
		this.shutokuYmdFrom = shutokuYmdFrom;
	}

	public String getShutokuYmdTo() {
		return shutokuYmdTo;
	}

	public void setShutokuYmdTo(String shutokuYmdTo) {
		this.shutokuYmdTo = shutokuYmdTo;
	}

	public String getSechiBashoName() {
		return sechiBashoName;
	}

	public void setSechiBashoName(String sechiBashoName) {
		this.sechiBashoName = sechiBashoName;
	}

	public String getKenmeiCd() {
		return kenmeiCd;
	}

	public void setKenmeiCd(String kenmeiCd) {
		this.kenmeiCd = kenmeiCd;
	}

	public String getKenmeiNm() {
		return kenmeiNm;
	}

	public void setKenmeiNm(String kenmeiNm) {
		this.kenmeiNm = kenmeiNm;
	}

	public String getKanriSoshikiCd() {
		return kanriSoshikiCd;
	}

	public void setKanriSoshikiCd(String kanriSoshikiCd) {
		this.kanriSoshikiCd = kanriSoshikiCd;
	}

	public String getKojiTantoUserNm() {
		return kojiTantoUserNm;
	}

	public void setKojiTantoUserNm(String kojiTantoUserNm) {
		this.kojiTantoUserNm = kojiTantoUserNm;
	}

}