package jp.co.nsd.nkssweb.dao;

public class KanriFutanks {

	// 行番号
	private int rowNo;

	// 行番号
	private int siyoymd;

	// 管理箇所
	private String kanrikasyo;

	// 管理箇所コード
	private String kanrikasyocd;

	// 管理箇所適用期間（FROM）
	private String kkikanF;

	// 管理箇所適用期間（TO）
	private String kkikanT;

	// 負担箇所
	private String futankasyo;

	// 管理箇所コード
	private String futankasyocd;

	// 負担箇所適用期間（FROM）
	private String fkikanF;

	// 負担箇所適用期間（TO）
	private String fkikanT;

	public int getRowNo() {
		return rowNo;
	}

	public void setRowNo(int rowNo) {
		this.rowNo = rowNo;
	}

	public int getSiyoymd() {
		return siyoymd;
	}

	public void setSiyoymd(int siyoymd) {
		this.siyoymd = siyoymd;
	}

	public String getKanrikasyo() {
		return kanrikasyo;
	}

	public void setKanrikasyo(String kanrikasyo) {
		this.kanrikasyo = kanrikasyo;
	}

	public String getKanrikasyocd() {
		return kanrikasyocd;
	}

	public void setKanrikasyocd(String kanrikasyocd) {
		this.kanrikasyocd = kanrikasyocd;
	}

	public String getKkikanF() {
		return kkikanF;
	}

	public void setKkikanF(String kkikanF) {
		this.kkikanF = kkikanF;
	}

	public String getKkikanT() {
		return kkikanT;
	}

	public void setKkikanT(String kkikanT) {
		this.kkikanT = kkikanT;
	}

	public String getFutankasyo() {
		return futankasyo;
	}

	public void setFutankasyo(String futankasyo) {
		this.futankasyo = futankasyo;
	}

	public String getFutankasyocd() {
		return futankasyocd;
	}

	public void setFutankasyocd(String futankasyocd) {
		this.futankasyocd = futankasyocd;
	}

	public String getFkikanF() {
		return fkikanF;
	}

	public void setFkikanF(String fkikanF) {
		this.fkikanF = fkikanF;
	}

	public String getFkikanT() {
		return fkikanT;
	}

	public void setFkikanT(String fkikanT) {
		this.fkikanT = fkikanT;
	}




}