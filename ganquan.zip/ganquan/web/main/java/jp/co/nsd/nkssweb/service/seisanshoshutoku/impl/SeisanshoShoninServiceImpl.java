/***********************************************************************
*
*業務名: 工事精算システム
*機能名: 除却（登録・修正・削除）(サービス処理)
*
*機能概要: 除却情報を処理する。
*
*JavaＶｅｒ：J2SE1.8.0準拠
*
*更新履歴: Ver.1.00 2018/03/06　NSD　新規作成
***********************************************************************/
package jp.co.nsd.nkssweb.service.seisanshoshutoku.impl;

import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.beanutils.BeanUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import jp.co.nsd.nkssweb.dao.SeisanshoShonin;
import jp.co.nsd.nkssweb.dao.SeisanshoShoninShokai;
import jp.co.nsd.nkssweb.dao.SeisanshoShoninshutokuSisan;
import jp.co.nsd.nkssweb.dao.mapper.SeisanshoShoninMapper;
import jp.co.nsd.nkssweb.service.seisanshoshutoku.SeisanshoShoninService;
import jp.co.nsd.nkssweb.utils.NSDConstant;

/**
 * 承認（検索・照会・更新）処理
 *
 * @see SeisanshoShoninService
 * @version 1.00
 */
@Service
public class SeisanshoShoninServiceImpl implements SeisanshoShoninService {

	// ログ
	private Logger logger = LoggerFactory.getLogger(this.getClass());

	@Autowired
	private SeisanshoShoninMapper seisanshoShoninMapper;

	/**
	 * 承認（検索）処理
	 *
	 * @param seisanshoShonin
	 *            INPUTパラメータ
	 * @return sssSNList 承認情報データリスト
	 * @version 1.00
	 */
	public List<SeisanshoShonin> getshoninInfo(SeisanshoShonin seisanshoShonin) {

		// 開始ログ
		logger.info("SeisanshoShoninServiceImpl.getshoninInfo 開始します。");

		// 除却情報を取得する
		List<SeisanshoShonin> sssSNList = seisanshoShoninMapper.selectByWhere(seisanshoShonin);

		for (int i = 0; i < sssSNList.size(); i++) {

			SeisanshoShonin sssSNSn = sssSNList.get(i);
			// ROWNOを設定する
			sssSNSn.setRowNo(i + 1);

			// 承認状態
			if (NSDConstant.STRING_00.equals(sssSNSn.getShoninSattus())) {
				// 00:登録中
				sssSNSn.setShoninJotai(NSDConstant.SHONIN_SATTUS_00);

			} else if (NSDConstant.STRING_01.equals(sssSNSn.getShoninSattus())) {
				// 01:承認済(経理提出)
				sssSNSn.setShoninJotai(NSDConstant.SHONIN_SATTUS_01);

			} else if (NSDConstant.STRING_02.equals(sssSNSn.getShoninSattus())) {
				// 02:経理審査済
				sssSNSn.setShoninJotai(NSDConstant.SHONIN_SATTUS_02);

			} else if (NSDConstant.STRING_03.equals(sssSNSn.getShoninSattus())) {
				// 03:除却済
				sssSNSn.setShoninJotai(NSDConstant.SHONIN_SATTUS_03);

			} else if (NSDConstant.STRING_20.equals(sssSNSn.getShoninSattus())) {
				// 20:経理審査否認
				sssSNSn.setShoninJotai(NSDConstant.SHONIN_SATTUS_20);

			} else {
				// 処理なし
			}

		}

		// 終了ログ
		logger.info("SeisanshoShoninServiceImpl.getshoninInfo 終了します。");

		return sssSNList;
	}
	/**
	 * 取得承認（照会）処理
	 *
	 * @param seisanshoShoninShokai
	 *            INPUTパラメータ
	 * @return seisanshoShoninShokai 取得承認情報データ
	 * @version 1.00
	 */
	public SeisanshoShoninShokai getshutokuInfoBySeisanShoNo(SeisanshoShoninShokai seisanshoShoninShokai) {

		// 開始ログ
		logger.info("SeisanshoShoninServiceImpl.getshutokuInfoBySeisanShoNo 開始します。");

		// 取得情報
		SeisanshoShoninShokai resultDto = new SeisanshoShoninShokai();

		// 取得資産明細情報
		SeisanshoShoninshutokuSisan sssStkKsDto;

		// 取得情報を取得する
		List<SeisanshoShoninShokai> sssStSNList = seisanshoShoninMapper.selectBySeisanShoNo(seisanshoShoninShokai);

		List<SeisanshoShoninshutokuSisan> sssStkKsLst = new ArrayList<>();

		for (int i = 0; i < sssStSNList.size(); i++) {
			// 取得資産情報
			SeisanshoShoninShokai sssStkSkDto = sssStSNList.get(i);

			// Mapの情報をBeanのプロパティにセット
			try {
				BeanUtils.copyProperties(resultDto, sssStkSkDto);

				// 承認状態
				if (NSDConstant.STRING_00.equals(resultDto.getShoninSattus())) {
					// 00:登録中
					resultDto.setShoninSattus(NSDConstant.SHONIN_SATTUS_00);

				} else if (NSDConstant.STRING_01.equals(resultDto.getShoninSattus())) {
					// 01:承認済(経理提出)
					resultDto.setShoninSattus(NSDConstant.SHONIN_SATTUS_01);

				} else if (NSDConstant.STRING_02.equals(resultDto.getShoninSattus())) {
					// 02:経理審査済
					resultDto.setShoninSattus(NSDConstant.SHONIN_SATTUS_02);

				} else if (NSDConstant.STRING_03.equals(resultDto.getShoninSattus())) {
					// 03:除却済
					resultDto.setShoninSattus(NSDConstant.SHONIN_SATTUS_03);

				} else if (NSDConstant.STRING_20.equals(resultDto.getShoninSattus())) {
					// 20:経理審査否認
					resultDto.setShoninSattus(NSDConstant.SHONIN_SATTUS_20);

				} else {
					// 処理なし
				}

				sssStkKsDto = new SeisanshoShoninshutokuSisan();

				sssStkKsDto.setKoteiShisanNo(sssStkSkDto.getKoteiShisanNo());

				sssStkKsDto.setKoteiShisanNm(sssStkSkDto.getKoteiShisanNm());

				sssStkKsDto.setShutokuKagaku(sssStkSkDto.getShutokuKagaku());

				sssStkKsDto.setShutokuYmd(sssStkSkDto.getShutokuYmd());

				sssStkKsDto.setRowNo(i + 1);

				sssStkKsLst.add(sssStkKsDto);

			} catch (IllegalAccessException | InvocationTargetException e) {
				// 終了ログ
				logger.info("SeisanshoJokyakuServiceImpl.getJokyakuInfoBySeisanShoNo 終了します。");
			}
		}

		resultDto.setShutokuSisanLst(sssStkKsLst);
		// 終了ログ
		logger.info("SeisanshoShoninServiceImpl.getshutokuInfoBySeisanShoNo 終了します。");

		return resultDto;
	}

}
