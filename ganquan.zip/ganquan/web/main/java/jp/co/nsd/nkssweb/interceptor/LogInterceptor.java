package jp.co.nsd.nkssweb.interceptor;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.aspectj.lang.annotation.Aspect;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.HandlerInterceptor;
import org.springframework.web.servlet.ModelAndView;

@Aspect
@Configuration
public class LogInterceptor implements HandlerInterceptor{

	Logger logger = LoggerFactory.getLogger(this.getClass());


//    @Pointcut("execution(* jp.co.nsd.nkssweb.controller..*(..))")
//    public void excudeService() {
//    }
//
//	@Before("excudeService()")
//	public void before(){
//		logger.info("before");
//	}
//
//	@After("excudeService()")
//	public void after(){
//		logger.info("after");
//	}
//
//    @Around("excudeService()")
//    public void doAround(ProceedingJoinPoint pjp) throws Throwable {
//    	logger.info("around");
//    }

	@Override
	public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler)
			throws Exception {
		logger.info("1");
		return false;
	}

	@Override
	public void postHandle(HttpServletRequest request, HttpServletResponse response, Object handler,
			ModelAndView modelAndView) throws Exception {
		logger.info("2");

	}

	@Override
	public void afterCompletion(HttpServletRequest request, HttpServletResponse response, Object handler, Exception ex)
			throws Exception {
		logger.info("3");

	}
}