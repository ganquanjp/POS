/***********************************************************************
*
*業務名: 工事精算システム
*機能名: 除却（経理審査/連携）(ログ出力処理)
*
*機能概要: 除却情報を処理する。
*
*JavaＶｅｒ：J2SE1.8.0準拠
*
*更新履歴: Ver.1.00 2018/03/06　NSD　新規作成
***********************************************************************/

package jp.co.nsd.nkssweb.controller.seisanshoshutoku;

import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.beanutils.BeanUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import jp.co.nsd.nkssweb.dao.Message;
import jp.co.nsd.nkssweb.dao.SeisanshoShutokuKeiri;
import jp.co.nsd.nkssweb.dao.SeisanshoShutokuKrsk;
import jp.co.nsd.nkssweb.service.SystemService;
import jp.co.nsd.nkssweb.service.seisanshoshutoku.SeisanshoShutokuKeiriService;
import jp.co.nsd.nkssweb.utils.NSDCommUtils;
import jp.co.nsd.nkssweb.utils.NSDConstant;

/**
 * 取得（経理審査/連携）処理
 *
 * @version 1.00
 */
@RestController
public class SeisanshoShutokuKeiriController {

	// ログ
	private Logger logger = LoggerFactory.getLogger(this.getClass());

	@Autowired
	private SeisanshoShutokuKeiriService seisanshoShutokuKeiriService;

	protected SystemService systemService;

	/**
	 * 取得（経理審査/連携）処理
	 *
	 * @param reqMap
	 *            INPUTパラメータ
	 * @return 取得情報データ
	 * @exception IllegalAccessException
	 * @exception InvocationTargetException
	 * @version 1.00
	 */
	@RequestMapping(value = "/seisanshoShutokuKeiri-selectByWhere", method = RequestMethod.POST)
	public Map<String, Object> selectByWhere(@RequestParam Map<String, Object> reqMap) {

		// 開始ログ
		logger.info("SeisanshoShutokuKeiriController.selectByWhere 開始します。");

		Map<String, Object> returnMap = new HashMap<String, Object>();

		Message message = new Message();

		SeisanshoShutokuKeiri seisanshoShutokuKeiri = new SeisanshoShutokuKeiri();

		List<SeisanshoShutokuKeiri> sssStkKrLst = new ArrayList<>();

		// 画面入力した検索条件を取得する
		try {
			// Mapの情報をBeanのプロパティにセット
			BeanUtils.populate(seisanshoShutokuKeiri, reqMap);

			// 除却年月日（From）と除却年月日（To）の大小比較チェック
			if (NSDCommUtils.chkDateFromTo(seisanshoShutokuKeiri.getSiyoStartYmdFrom(),
					seisanshoShutokuKeiri.getSiyoStartYmdTo())) {
				// 処理結果データ
				returnMap.put(NSDConstant.RESULT_DATA_LIST_NAME, sssStkKrLst);
				// メッセージ内容
				message = systemService.getMessage(NSDConstant.MSGID_SYSTEM_ERROR);
				returnMap.put(NSDConstant.RESULT_MSG_NAME, message);

				// 終了ログ
				logger.info("SeisanshoShutokuKeiriController.selectByWhere 終了します。");

				return returnMap;
			}
		} catch (IllegalAccessException | InvocationTargetException e) {
			// エーラログ
			logger.info("SeisanshoShutokuKeiriController.selectByWhereでエラーが発生しました。");
			e.printStackTrace();
		}

		// サービス呼び出し
		sssStkKrLst = seisanshoShutokuKeiriService.getshutokuKeiriInfo(seisanshoShutokuKeiri);
		// 処理結果データ
		returnMap.put(NSDConstant.RESULT_DATA_LIST_NAME, sssStkKrLst);
		// メッセージ内容
		returnMap.put(NSDConstant.RESULT_MSG_NAME, NSDConstant.BLANK_STRING);

		// 終了ログ
		logger.info("SeisanshoShutokuKeiriController.selectByWhere 終了します。");

		return returnMap;
	}

	/**
	 * 取得（経理審査/連携）更新処理
	 *
	 * @param reqMap
	 *            INPUTパラメータ
	 * @return 取得情報データ
	 * @exception IllegalAccessException
	 * @exception InvocationTargetException
	 * @version 1.00
	 */
	@RequestMapping(value = "/seisanshoShutokuKrsk-selectBySeisanShoNo", method = RequestMethod.POST)
	public Map<String, Object> selectBySeisanShoNo(@RequestParam Map<String, Object> reqMap) {

		// 開始ログ
		logger.info("SeisanshoShoninController.selectBySeisanShoNo 開始します。");

		Map<String, Object> returnMap = new HashMap<String, Object>();

		SeisanshoShutokuKrsk seisanshoShutokuKrsk = new SeisanshoShutokuKrsk();

		// 精算書より除却情報を取得する
		try {
			// Mapの情報をBeanのプロパティにセット
			BeanUtils.populate(seisanshoShutokuKrsk, reqMap);

		} catch (IllegalAccessException | InvocationTargetException e) {
			// エーラログ
			logger.info("SeisanshoShoninController.selectBySeisanShoNoでエラーが発生しました。");
		}

		// サービス呼び出し
//		SeisanshoShutokuKrsk sssSNSkDto = seisanshoShutokuKeiriService
//				.getshutokuInfoBySeisanShoNo(seisanshoShutokuKrsk);

		// 処理結果データ
//		returnMap.put("dataList", sssSNSkDto);
		// メッセージ内容
		returnMap.put(NSDConstant.RESULT_MSG_NAME, NSDConstant.BLANK_STRING);

		// 終了ログ
		logger.info("SeisanshoShoninController.selectBySeisanShoNo 終了します。");

		return returnMap;
	}
}
