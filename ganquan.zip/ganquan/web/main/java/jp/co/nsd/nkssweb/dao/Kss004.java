package jp.co.nsd.nkssweb.dao;

import java.math.BigDecimal;
import java.util.Date;

public class Kss004 extends Kss004Key {
    private String seisanShoNo;

    private String koteiShisanNo;

    private String kenmeiCd;

    private String seisanSoshikiCd;

    private Date siyoStartYmd;

    private String seisanEntryUserId;

    private String tekiyo;

    private String shoninSattus;

    private String riyu;

    private BigDecimal hansu;

    private Date entryDate;

    private String entryUserId;

    private Date updateDate;

    private String updateUserId;

    public String getSeisanShoNo() {
        return seisanShoNo;
    }

    public void setSeisanShoNo(String seisanShoNo) {
        this.seisanShoNo = seisanShoNo == null ? null : seisanShoNo.trim();
    }

    public String getKoteiShisanNo() {
        return koteiShisanNo;
    }

    public void setKoteiShisanNo(String koteiShisanNo) {
        this.koteiShisanNo = koteiShisanNo == null ? null : koteiShisanNo.trim();
    }

    public String getKenmeiCd() {
        return kenmeiCd;
    }

    public void setKenmeiCd(String kenmeiCd) {
        this.kenmeiCd = kenmeiCd == null ? null : kenmeiCd.trim();
    }

    public String getSeisanSoshikiCd() {
        return seisanSoshikiCd;
    }

    public void setSeisanSoshikiCd(String seisanSoshikiCd) {
        this.seisanSoshikiCd = seisanSoshikiCd == null ? null : seisanSoshikiCd.trim();
    }

    public Date getSiyoStartYmd() {
        return siyoStartYmd;
    }

    public void setSiyoStartYmd(Date siyoStartYmd) {
        this.siyoStartYmd = siyoStartYmd;
    }

    public String getSeisanEntryUserId() {
        return seisanEntryUserId;
    }

    public void setSeisanEntryUserId(String seisanEntryUserId) {
        this.seisanEntryUserId = seisanEntryUserId == null ? null : seisanEntryUserId.trim();
    }

    public String getTekiyo() {
        return tekiyo;
    }

    public void setTekiyo(String tekiyo) {
        this.tekiyo = tekiyo == null ? null : tekiyo.trim();
    }

    public String getShoninSattus() {
        return shoninSattus;
    }

    public void setShoninSattus(String shoninSattus) {
        this.shoninSattus = shoninSattus == null ? null : shoninSattus.trim();
    }

    public String getRiyu() {
        return riyu;
    }

    public void setRiyu(String riyu) {
        this.riyu = riyu == null ? null : riyu.trim();
    }

    public BigDecimal getHansu() {
        return hansu;
    }

    public void setHansu(BigDecimal hansu) {
        this.hansu = hansu;
    }

    public Date getEntryDate() {
        return entryDate;
    }

    public void setEntryDate(Date entryDate) {
        this.entryDate = entryDate;
    }

    public String getEntryUserId() {
        return entryUserId;
    }

    public void setEntryUserId(String entryUserId) {
        this.entryUserId = entryUserId == null ? null : entryUserId.trim();
    }

    public Date getUpdateDate() {
        return updateDate;
    }

    public void setUpdateDate(Date updateDate) {
        this.updateDate = updateDate;
    }

    public String getUpdateUserId() {
        return updateUserId;
    }

    public void setUpdateUserId(String updateUserId) {
        this.updateUserId = updateUserId == null ? null : updateUserId.trim();
    }
}