package jp.co.nsd.nkssweb.dao.mapper;

import jp.co.nsd.nkssweb.dao.Kss023;
import jp.co.nsd.nkssweb.dao.Kss023Key;

public interface Kss023Mapper {
    int deleteByPrimaryKey(Kss023Key key);

    int insert(Kss023 record);

    int insertSelective(Kss023 record);

    Kss023 selectByPrimaryKey(Kss023Key key);

    int updateByPrimaryKeySelective(Kss023 record);

    int updateByPrimaryKey(Kss023 record);
}