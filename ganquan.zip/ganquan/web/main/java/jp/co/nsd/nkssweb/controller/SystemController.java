/***********************************************************************
*
*業務名: 工事精算システム
*機能名: 除却（登録・修正・削除）(ログ出力処理)
*
*機能概要: 除却情報を処理する。
*
*JavaＶｅｒ：J2SE1.8.0準拠
*
*更新履歴: Ver.1.00 2018/03/06　NSD　新規作成
***********************************************************************/

package jp.co.nsd.nkssweb.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.commons.beanutils.BeanUtils;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import jp.co.nsd.nkssweb.dao.Kss013;
import jp.co.nsd.nkssweb.dao.UserMenuGroup;
import jp.co.nsd.nkssweb.utils.NSDConstant;

/**
 * 固定資産検索処理
 *
 * @version 1.00
 */
@RestController
public class SystemController extends BaseController {

	/**
	 * ユーザーログイン処理
	 *
	 * @param reqMap
	 * @return
	 */
	@RequestMapping(value = "/system-userlogin", method = RequestMethod.POST)
	public Map<String, Object> userLogin(@RequestParam Map<String, Object> reqMap) {

		init();

		// メソッド名取得
		methodName = Thread.currentThread().getStackTrace()[1].getMethodName();

		// 開始ログ
		logger.info(methodName.concat(NSDConstant.LOG_INFO_METHOD_BEGIN));

		Kss013 kss013 = new Kss013();

		List<UserMenuGroup> umgList = new ArrayList<>();

		// 画面入力した検索条件を取得する
		try {
			// Mapの情報をBeanのプロパティにセット
			BeanUtils.populate(kss013, reqMap);

			// ログインユーザー存在確認サービス呼び出し
			if (!systemService.validateUser(kss013.getUserId())) {
				return setMsgToResultMap(NSDConstant.MSGID_USER_NOT_EXIST);
			}

			// ログインユーザー権限確認サービス呼び出し
			umgList = systemService.validatePrivilege(kss013.getUserId());

			if (umgList.size() == 0) {
				// 権限取得しない場合
				return setMsgToResultMap(NSDConstant.MSGID_LOGIN_FAILED);
			}

		} catch (Exception e) {

			// エラーメッセージを返却Mapに設定
			return setMsgToResultMap(NSDConstant.MSGID_SYSTEM_ERROR);

		}

		// 検索結果を返却Mapに設定する
		setDataToResultMap(umgList);
		setMsgToResultMapNoLog(NSDConstant.MSGID_LOGIN_SUCCES);

		// 終了ログ
		logger.info(methodName.concat(NSDConstant.LOG_INFO_METHOD_END));

		return resultMap;
	}

}
