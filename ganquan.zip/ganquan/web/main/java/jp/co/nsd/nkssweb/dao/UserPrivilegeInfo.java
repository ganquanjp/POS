package jp.co.nsd.nkssweb.dao;

public class UserPrivilegeInfo extends Kss022 {

	private String menuLinkNm;

	private String menuGroupId;

	public String getMenuLinkNm() {
		return menuLinkNm;
	}

	public void setMenuLinkNm(String menuLinkNm) {
		this.menuLinkNm = menuLinkNm;
	}

	public String getMenuGroupId() {
		return menuGroupId;
	}

	public void setMenuGroupId(String menuGroupId) {
		this.menuGroupId = menuGroupId;
	}

}