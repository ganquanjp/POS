package jp.co.nsd.nkssweb.service;

import java.util.List;

import jp.co.nsd.nkssweb.dao.Message;
import jp.co.nsd.nkssweb.dao.UserMenuGroup;

public interface SystemService {

	/**
	 * ログインユーザーの確認
	 *
	 * @param userId
	 * @return
	 */
	boolean validateUser(String userId);

	/**
	 * ログインユーザーの権限確認
	 * @param userId
	 * @return
	 */
	List<UserMenuGroup> validatePrivilege(String userId);

	/**
	 * メッセージの取得
	 *
	 * @param msgId
	 * @return
	 */
	Message getMessage(String msgId);

}
