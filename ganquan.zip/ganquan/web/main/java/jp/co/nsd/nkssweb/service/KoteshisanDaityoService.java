package jp.co.nsd.nkssweb.service;

import java.util.List;

import jp.co.nsd.nkssweb.dao.KoteshisanDaityo;

public interface KoteshisanDaityoService {

	/**
	 * 精算書一覧検索
	 *
	 * @return
	 */
	List<KoteshisanDaityo> getKenmeiInfo(KoteshisanDaityo selectCondition);

}
