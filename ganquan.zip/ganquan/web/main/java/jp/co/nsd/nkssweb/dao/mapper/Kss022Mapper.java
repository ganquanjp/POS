package jp.co.nsd.nkssweb.dao.mapper;

import jp.co.nsd.nkssweb.dao.Kss022;
import jp.co.nsd.nkssweb.dao.Kss022Key;

public interface Kss022Mapper {
    int deleteByPrimaryKey(Kss022Key key);

    int insert(Kss022 record);

    int insertSelective(Kss022 record);

    Kss022 selectByPrimaryKey(Kss022Key key);

    int updateByPrimaryKeySelective(Kss022 record);

    int updateByPrimaryKey(Kss022 record);
}