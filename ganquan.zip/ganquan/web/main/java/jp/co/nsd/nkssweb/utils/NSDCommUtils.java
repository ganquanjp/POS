package jp.co.nsd.nkssweb.utils;

import java.sql.Date;

import org.apache.commons.lang.StringUtils;

/**
 * システム共通ユーティリティ
 *
 * @author nsdH272059
 *
 */
public final class NSDCommUtils {

	/**
	 * ページ番号より、開始行番を取得する
	 *
	 * @param pageNo
	 * @return
	 */
	public static int getPageingStartNo(int pageNo) {
		return (pageNo - 1) * NSDConstant.PAGE_RECORDS + 1;
	}

	/**
	 * 日付From-To大小比較チェック
	 *
	 * @param dateFrom
	 *            String
	 * @param dateTo
	 *            String
	 * @return boolean
	 */
	public static boolean chkDateFromTo(String dateFrom, String dateTo) {

		// 開始年月日（From）と終了年月日（To）存在の場合
		if (StringUtils.isNotEmpty(dateFrom) && StringUtils.isNotEmpty(dateTo)) {
			// 開始年月日（From）と終了年月日（To）の大小比較チェック
			if (Date.valueOf(dateFrom).compareTo(Date.valueOf(dateTo)) == 1) {
				return true;
			}
		}
		return false;
	}

	/**
	 * 承認状態名称
	 *
	 * @param shoninSattus
	 *            String
	 * @return 承認状態名称
	 */
	public static String getShoninJotai(String shoninSattus) {

		// 承認状態
		if ("00".equals(shoninSattus)) {
			// 00:登録中
			return NSDConstant.SHONIN_SATTUS_00;

		} else if ("01".equals(shoninSattus)) {
			// 01:承認済(経理提出)
			return NSDConstant.SHONIN_SATTUS_01;

		} else if ("20".equals(shoninSattus)) {
			// 20:経理審査否認
			return NSDConstant.SHONIN_SATTUS_20;

		} else {
			// 処理なし
		}
		return "";
	}

	/**
	 * NULL値は空文字に変換する。
	 *
	 * @param str
	 *            String
	 * @return 空文字
	 */
	public static String nullToBlankStr(String str) {

		if (null == str){
			str = "";
		}
		return str;
	}

}
