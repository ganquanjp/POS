package jp.co.nsd.nkssweb.dao.mapper;

import java.util.List;

import jp.co.nsd.nkssweb.dao.Kss024;
import jp.co.nsd.nkssweb.dao.UserPrivilegeInfo;

public interface SystemMapper {

	/**
	 * ユーザー・ロール情報取得
	 *
	 * @param userId
	 *            INPUTパラメータ
	 * @return　検索結果
	 */
	List<Kss024> selectUserRole(String userId);

	/**
	 * ユーザー権限取得
	 *
	 * @param roleId
	 *            INPUTパラメータ
	 * @return　検索結果
	 */
	List<UserPrivilegeInfo> selectUserPrivilege(String roleId);

}