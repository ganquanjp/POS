package jp.co.nsd.nkssweb.dao;

import java.math.BigDecimal;
import java.util.List;

public class SeisanshoJokyakuShoninShokai {

	// 除却精算書ＩＤ
	private BigDecimal jokyakuSeisanShoId;

	// 除却資産ＩＤ
	private BigDecimal jokyakuShisanNo;

	// 除却元固定資産ＩＤ
	private String motoKoteiShisanId;

	// 履歴番号
	private String rirekiNo;

	// 除却精算書番号
	private String jokyakuSeisanShoNo;

	// 件名
	private String kenmeiNm;

	// 除却予定年月日
	private String jokyakuYoteYmd;

	// 除却年月日
	private String jokyakuYmd;

	// 組織連結略名
	private String soshikiRenNm;

	// 除_取得価額
	private String jokyakuGaku;

	// 除却取得価額合計
	private String jokyakuKagakuGokei;

	// 承認状態
	private String shoninJotai;

	// 承認ステータス
	private String shoninSattus;

	// 理由
	private String riyu;

	// 版数
	private String hansu;

	// 固定資産情報
	private List<SeisanshoJokyakuKoteiSisan> koteiSisanLst;

	public BigDecimal getJokyakuSeisanShoId() {
		return jokyakuSeisanShoId;
	}

	public void setJokyakuSeisanShoId(BigDecimal jokyakuSeisanShoId) {
		this.jokyakuSeisanShoId = jokyakuSeisanShoId;
	}

	public BigDecimal getJokyakuShisanNo() {
		return jokyakuShisanNo;
	}

	public void setJokyakuShisanNo(BigDecimal jokyakuShisanNo) {
		this.jokyakuShisanNo = jokyakuShisanNo;
	}

	public String getMotoKoteiShisanId() {
		return motoKoteiShisanId;
	}

	public void setMotoKoteiShisanId(String motoKoteiShisanId) {
		this.motoKoteiShisanId = motoKoteiShisanId;
	}

	public String getRirekiNo() {
		return rirekiNo;
	}

	public void setRirekiNo(String rirekiNo) {
		this.rirekiNo = rirekiNo;
	}

	public String getJokyakuSeisanShoNo() {
		return jokyakuSeisanShoNo;
	}

	public void setJokyakuSeisanShoNo(String jokyakuSeisanShoNo) {
		this.jokyakuSeisanShoNo = jokyakuSeisanShoNo;
	}

	public String getKenmeiNm() {
		return kenmeiNm;
	}

	public void setKenmeiNm(String kenmeiNm) {
		this.kenmeiNm = kenmeiNm;
	}

	public String getJokyakuYoteYmd() {
		return jokyakuYoteYmd;
	}

	public void setJokyakuYoteYmd(String jokyakuYoteYmd) {
		this.jokyakuYoteYmd = jokyakuYoteYmd;
	}

	public String getJokyakuYmd() {
		return jokyakuYmd;
	}

	public void setJokyakuYmd(String jokyakuYmd) {
		this.jokyakuYmd = jokyakuYmd;
	}

	public String getSoshikiRenNm() {
		return soshikiRenNm;
	}

	public void setSoshikiRenNm(String soshikiRenNm) {
		this.soshikiRenNm = soshikiRenNm;
	}

	public String getJokyakuGaku() {
		return jokyakuGaku;
	}

	public void setJokyakuGaku(String jokyakuGaku) {
		this.jokyakuGaku = jokyakuGaku;
	}

	public String getJokyakuKagakuGokei() {
		return jokyakuKagakuGokei;
	}

	public void setJokyakuKagakuGokei(String jokyakuKagakuGokei) {
		this.jokyakuKagakuGokei = jokyakuKagakuGokei;
	}

	public String getShoninJotai() {
		return shoninJotai;
	}

	public void setShoninJotai(String shoninJotai) {
		this.shoninJotai = shoninJotai;
	}

	public String getShoninSattus() {
		return shoninSattus;
	}

	public void setShoninSattus(String shoninSattus) {
		this.shoninSattus = shoninSattus;
	}

	public String getRiyu() {
		return riyu;
	}

	public void setRiyu(String riyu) {
		this.riyu = riyu;
	}

	public String getHansu() {
		return hansu;
	}

	public void setHansu(String hansu) {
		this.hansu = hansu;
	}

	public List<SeisanshoJokyakuKoteiSisan> getKoteiSisanLst() {
		return koteiSisanLst;
	}

	public void setKoteiSisanLst(List<SeisanshoJokyakuKoteiSisan> koteiSisanLst) {
		this.koteiSisanLst = koteiSisanLst;
	}


}