package jp.co.nsd.nkssweb.utils;

import java.text.ParsePosition;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * システム共通ユーティリティ
 *
 * @author nsdH272059
 *
 */
public class NSDDateUtils {

	/**
	 * 文字列はjava.util.Dateに変換
	 *
	 * @param time
	 * @return
	 */
	public static Date stringToDate(String time) {
		SimpleDateFormat formatter;
		int tempPos = time.indexOf("AD");
		time = time.trim();
		formatter = new SimpleDateFormat("yyyy.MM.dd G 'at' hh:mm:ss z");
		if (tempPos > -1) {
			time = time.substring(0, tempPos) + "西暦" + time.substring(tempPos + "AD".length());// china
			formatter = new SimpleDateFormat("yyyy.MM.dd G 'at' hh:mm:ss z");
		}
		tempPos = time.indexOf("-");
		if (tempPos > -1 && (time.indexOf(" ") < 0)) {
			formatter = new SimpleDateFormat("yyyyMMddHHmmssZ");
		} else if ((time.indexOf("/") > -1) && (time.indexOf(" ") > -1)) {
			formatter = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
		} else if ((time.indexOf("-") > -1) && (time.indexOf(" ") > -1)) {
			formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		} else if ((time.indexOf("/") > -1) && (time.indexOf("am") > -1) || (time.indexOf("pm") > -1)) {
			formatter = new SimpleDateFormat("yyyy-MM-dd KK:mm:ss a");
		} else if ((time.indexOf("-") > -1) && (time.indexOf("am") > -1) || (time.indexOf("pm") > -1)) {
			formatter = new SimpleDateFormat("yyyy-MM-dd KK:mm:ss a");
		}
		ParsePosition pos = new ParsePosition(0);
		java.util.Date ctime = formatter.parse(time, pos);

		return ctime;
	}

	/**
	 * 文字列はjava.util.Dateに変換
	 *
	 * @param dateStr
	 * @param dateFormatter
	 * @return
	 */
	public static Date stringToDate(String dateStr, String dateFormatter) {
		SimpleDateFormat formatter;
		formatter = new SimpleDateFormat(dateFormatter);
		ParsePosition pos = new ParsePosition(0);
		java.util.Date date = formatter.parse(dateStr, pos);

		return date;
	}

	/**
	 * java.util.Dateは文字列に変換
	 *
	 * @param time
	 * @param dateFormatter
	 * @return
	 */
	public static String dateToString(Date time, String dateFormatter) {
		SimpleDateFormat formatter;
		formatter = new SimpleDateFormat(dateFormatter);
		String ctime = formatter.format(time);

		return ctime;
	}

	/**
	 * システム時刻
	 *
	 * @return
	 */
	public static String Now() {
		return dateToString(new Date(), "yyyy-MM-dd HH:mm:ss");
	}

	/**
	 * システム時刻、フォーマット付き
	 *
	 * @param dateFormatter
	 * @return
	 */
	public static String Now(String dateFormatter) {
		return dateToString(new Date(), dateFormatter);
	}
}
