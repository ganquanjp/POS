/***********************************************************************
*
*業務名: 工事精算システム
*機能名: 除却（経理審査/連携）(サービス処理)
*
*機能概要: 除却（経理審査/連携）情報を処理する。
*
*JavaＶｅｒ：J2SE1.8.0準拠
*
*更新履歴: Ver.1.00 2018/03/06　NSD　新規作成
***********************************************************************/
package jp.co.nsd.nkssweb.service.seisanshoshutoku.impl;

import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.beanutils.BeanUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import jp.co.nsd.nkssweb.dao.Aads01;
import jp.co.nsd.nkssweb.dao.SeisanshoShutokuKeiri;
import jp.co.nsd.nkssweb.dao.SeisanshoShutokuKrsk;
import jp.co.nsd.nkssweb.dao.mapper.SeisanshoShutokuKeiriMapper;
import jp.co.nsd.nkssweb.service.seisanshoshutoku.SeisanshoShutokuKeiriService;
import jp.co.nsd.nkssweb.utils.NSDConstant;

/**
 * 取得（経理審査/連携）処理
 *
 * @see SeisanshoShutokuKeiriService
 * @version 1.00
 */
@Service
public class SeisanshoShutokuKeiriServiceImpl implements SeisanshoShutokuKeiriService {

	// ログ
	private Logger logger = LoggerFactory.getLogger(this.getClass());

	@Autowired
	private SeisanshoShutokuKeiriMapper seisanshoShutokuKeiriMapper;

	/**
	 * 取得（経理審査/連携）検索処理
	 *
	 * @param seisanshoShutokuKeiri
	 *            INPUTパラメータ
	 * @return sssStkKrList 取得情報データリスト
	 * @version 1.00
	 */
	public List<SeisanshoShutokuKeiri> getshutokuKeiriInfo(SeisanshoShutokuKeiri seisanshoShutokuKeiri) {

		// 開始ログ
		logger.info("SeisanshoShutokuKeiriServiceImpl.getshutokuKeiriInfo 開始します。");

		// 除却情報を取得する
		List<SeisanshoShutokuKeiri> sssStkKrList = seisanshoShutokuKeiriMapper.selectByWhere(seisanshoShutokuKeiri);

		for (int i = 0; i < sssStkKrList.size(); i++) {

			SeisanshoShutokuKeiri sssStkSn = sssStkKrList.get(i);

			// ROWNOを設定する
			sssStkSn.setRowNo(i + 1);

			// 承認状態
			if (NSDConstant.STRING_01.equals(sssStkSn.getShoninSattus())) {
				// 01:承認済(経理提出)
				sssStkSn.setShoninJotai(NSDConstant.SHONIN_SATTUS_01);

			} else if (NSDConstant.STRING_02.equals(sssStkSn.getShoninSattus())) {
				// 02:経理審査済
				sssStkSn.setShoninJotai(NSDConstant.SHONIN_SATTUS_02);

			} else if (NSDConstant.STRING_20.equals(sssStkSn.getShoninSattus())) {
				// 20:経理審査否認
				sssStkSn.setShoninJotai(NSDConstant.SHONIN_SATTUS_20);

			} else {
				// 処理なし
			}
		}

		// 終了ログ
		logger.info("SeisanshoShutokuKeiriServiceImpl.getshutokuKeiriInfo 終了します。");

		return sssStkKrList;
	}
	/**
	 * 取得（経理審査/連携）（照会）処理
	 *
	 * @param seisanshoShutokuKrsk
	 *            INPUTパラメータ
	 * @return seisanshoShutokuKrsk 取得承認情報データ
	 * @version 1.00
	 */
	public SeisanshoShutokuKrsk getshutokuInfoBySeisanShoNo(SeisanshoShutokuKrsk seisanshoShutokuKrsk) {

		// 開始ログ
		logger.info("SeisanshoShutokuKeiriServiceImpl.getshutokuInfoBySeisanShoNo 開始します。");

		// 取得情報
		SeisanshoShutokuKrsk resultDto = new SeisanshoShutokuKrsk();

		// 取得資産明細情報
		Aads01 sssStkKsDto;

		// 取得情報を取得する
		List<SeisanshoShutokuKrsk> sssStSNList = seisanshoShutokuKeiriMapper.selectBySeisanShoNo(seisanshoShutokuKrsk);

		List<Aads01> sssStkKsLst = new ArrayList<>();

		for (int i = 0; i < sssStSNList.size(); i++) {
			// 取得資産情報
			SeisanshoShutokuKrsk sssStkSkDto = sssStSNList.get(i);

			// Mapの情報をBeanのプロパティにセット
			try {
				BeanUtils.copyProperties(resultDto, sssStkSkDto);

				sssStkKsDto = new Aads01();

				sssStkSkDto.setRowNo(i + 1);

				sssStkKsLst.add(sssStkKsDto);

			} catch (IllegalAccessException | InvocationTargetException e) {
				// 終了ログ
				logger.info("SeisanshoJokyakuServiceImpl.getJokyakuInfoBySeisanShoNo 終了します。");
			}
		}

		resultDto.setKeSanLst(sssStkKsLst);
		// 終了ログ
		logger.info("SeisanshoShoninServiceImpl.getshutokuInfoBySeisanShoNo 終了します。");

		return resultDto;
	}

}
