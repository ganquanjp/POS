package jp.co.nsd.nkssweb.dao.mapper;

import java.util.List;

import jp.co.nsd.nkssweb.dao.SeisanshoTorokuKmskJhe;

public interface SeisanshoTorokuKmskJheMapper {

    List<SeisanshoTorokuKmskJhe> selectByWhere(SeisanshoTorokuKmskJhe record);

    int updateByPrimaryKey(SeisanshoTorokuKmskJhe record);


}