package jp.co.nsd.nkssweb.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import jp.co.nsd.nkssweb.dao.Sample;
import jp.co.nsd.nkssweb.service.SampleService;

@RestController
public class SampleController {

	// ログ
	private Logger logger = LoggerFactory.getLogger(this.getClass());

    @Autowired
    private SampleService sampleService;

    @RequestMapping(value = "/sample-selectOne", method = RequestMethod.GET)
    public Sample selectOne(@RequestParam(value = "userId", required = true) String userId) {
    	logger.info("SampleController selectOne start");
        return sampleService.selectByPrimaryKey(userId);
    }

    @RequestMapping(value = "/sample-selectAll", method = RequestMethod.GET)
    public List<Sample> selectAll() {
        return sampleService.selectAll();
    }

    @RequestMapping(value = "/sample-selectByWhere", method = RequestMethod.GET)
    public List<Sample> selectByWhere() {

        return sampleService.selectByWhere();
    }

    @RequestMapping(value = "/sample-callTestFunction", method = RequestMethod.GET)
    public void callTestFunction(@RequestParam(value = "userId", required = true) String userId) {

        sampleService.callTestFunction(userId);
    }
}
