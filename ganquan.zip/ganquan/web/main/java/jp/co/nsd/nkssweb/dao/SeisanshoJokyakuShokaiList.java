package jp.co.nsd.nkssweb.dao;

import java.util.List;

public class SeisanshoJokyakuShokaiList extends SeisanshoJokyakuShokai {

	// 除却固定資産情報
	private List<SeisanshoJokyakuKoteiSisan> koteiSisanLst;

	public List<SeisanshoJokyakuKoteiSisan> getKoteiSisanLst() {
		return koteiSisanLst;
	}

	public void setKoteiSisanLst(List<SeisanshoJokyakuKoteiSisan> koteiSisanLst) {
		this.koteiSisanLst = koteiSisanLst;
	}



}