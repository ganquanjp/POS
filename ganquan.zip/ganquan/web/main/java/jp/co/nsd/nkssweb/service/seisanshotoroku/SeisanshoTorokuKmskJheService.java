package jp.co.nsd.nkssweb.service.seisanshotoroku;

import java.util.List;

import jp.co.nsd.nkssweb.dao.SeisanshoTorokuKmskJhe;

public interface SeisanshoTorokuKmskJheService {

	/**
	 * 精算書一覧検索
	 *
	 * @return
	 */
	List<SeisanshoTorokuKmskJhe> getKenmeiInfo(SeisanshoTorokuKmskJhe selectCondition);

}
