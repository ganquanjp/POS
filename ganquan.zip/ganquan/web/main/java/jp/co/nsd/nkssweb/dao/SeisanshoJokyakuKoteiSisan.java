package jp.co.nsd.nkssweb.dao;

public class SeisanshoJokyakuKoteiSisan extends KoteiSisan {

	// 除_取得価額
	private String jokyakuGaku;

	// 除却種別コード
	private String jokyakuShubetsuCd;

	// 除却種別名称
	private String jokyakuShubetsuNm;

	// 除却区分コード
	private String jokyakuKbn;

	// 除却区分名称
	private String jokyakuKbnNm;

	// 除_数量
	private String jokyakuSuryo;

	// 資産単位コード
	private String shisanTaniCd;

	// 資産単位名称
	private String shisanTaniNm;

	public String getJokyakuGaku() {
		return jokyakuGaku;
	}

	public void setJokyakuGaku(String jokyakuGaku) {
		this.jokyakuGaku = jokyakuGaku;
	}

	public String getJokyakuShubetsuCd() {
		return jokyakuShubetsuCd;
	}

	public void setJokyakuShubetsuCd(String jokyakuShubetsuCd) {
		this.jokyakuShubetsuCd = jokyakuShubetsuCd;
	}

	public String getJokyakuShubetsuNm() {
		return jokyakuShubetsuNm;
	}

	public void setJokyakuShubetsuNm(String jokyakuShubetsuNm) {
		this.jokyakuShubetsuNm = jokyakuShubetsuNm;
	}

	public String getJokyakuKbn() {
		return jokyakuKbn;
	}

	public void setJokyakuKbn(String jokyakuKbn) {
		this.jokyakuKbn = jokyakuKbn;
	}

	public String getJokyakuKbnNm() {
		return jokyakuKbnNm;
	}

	public void setJokyakuKbnNm(String jokyakuKbnNm) {
		this.jokyakuKbnNm = jokyakuKbnNm;
	}

	public String getJokyakuSuryo() {
		return jokyakuSuryo;
	}

	public void setJokyakuSuryo(String jokyakuSuryo) {
		this.jokyakuSuryo = jokyakuSuryo;
	}

	public String getShisanTaniCd() {
		return shisanTaniCd;
	}

	public void setShisanTaniCd(String shisanTaniCd) {
		this.shisanTaniCd = shisanTaniCd;
	}

	public String getShisanTaniNm() {
		return shisanTaniNm;
	}

	public void setShisanTaniNm(String shisanTaniNm) {
		this.shisanTaniNm = shisanTaniNm;
	}

}