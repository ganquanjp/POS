package jp.co.nsd.nkssweb.controller.seisanshoshutoku;

import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.beanutils.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import jp.co.nsd.nkssweb.controller.BaseController;
import jp.co.nsd.nkssweb.dao.Kss005;
import jp.co.nsd.nkssweb.dao.Message;
import jp.co.nsd.nkssweb.dao.SeisanshoShutokuKensaku;
import jp.co.nsd.nkssweb.dao.SeisanshoShutokuShokai;
import jp.co.nsd.nkssweb.service.seisanshoshutoku.SeisanshoShutokuService;
import jp.co.nsd.nkssweb.utils.NSDConstant;

@RestController
public class SeisanshoShutokuController extends BaseController {

	SeisanshoShutokuController() {
		super();
	}

//	// ログ@PropertySource("${menu-router}")
//	private Logger logger = LoggerFactory.getLogger(this.getClass());

	@Autowired
	private SeisanshoShutokuService seisanshoShutokuService;

//	@Value("${menu_group_id.kss02}")
//	private String aaa;
//
//	@Value("${menu_group_name.kss06}")
//	private String bbb;

	/*
	 * 精算書取得・検索
	 */
	@RequestMapping(value = "/seisanshoShutoku-kensaku", method = RequestMethod.POST)
	public Map<String, Object> getSeisanshoShutokuKensaku(@RequestParam Map<String, Object> reqMap) {

		init();

		// メソッド名を取得する
		methodName = Thread.currentThread().getStackTrace()[1].getMethodName();

		// 開始ログ
		logger.info(methodName.concat(NSDConstant.LOG_INFO_METHOD_BEGIN));

//		try {
//			logger.info(new String(aaa.getBytes("ISO-8859-1"), "UTF-8"));
//			logger.info(new String(bbb.getBytes("ISO-8859-1"), "UTF-8"));
//		} catch (UnsupportedEncodingException e1) {
//			// TODO 自動生成された catch ブロック
//			e1.printStackTrace();
//			return new HashMap<String, Object>();
//		}

		SeisanshoShutokuKensaku selectCondition = new SeisanshoShutokuKensaku();
		List<SeisanshoShutokuKensaku> stkKsList = new ArrayList<SeisanshoShutokuKensaku>();

		try {

			// 画面入力した検索条件をBeanのプロパティにセット
			BeanUtils.populate(selectCondition, reqMap);

			// サービスを呼び出す
			stkKsList = seisanshoShutokuService.getSeisanshoShutokuKensaku(selectCondition);

		} catch (Exception e) {

			// エラーメッセージを返却Mapに設定する
			return setMsgToResultMap(NSDConstant.MSGID_SYSTEM_ERROR);

		}

		// 検索結果を返却Mapに設定する
		setDataToResultMap(stkKsList);

		// 終了ログ
		logger.info(methodName.concat(NSDConstant.LOG_INFO_METHOD_END));

		return resultMap;

	}

	/*
	 * 精算書取得・照会
	 */
	@RequestMapping(value = "/seisanshoShutoku-shokai", method = RequestMethod.POST)
	public Map<String, Object> getSeisanshoShutokuShokai(@RequestParam Map<String, Object> reqMap) {

//		logger.info("getSeisanshoShutokuShokai 開始します。");

		Map<String, Object> resultMap = new HashMap<String, Object>();
		Message message = new Message();

		SeisanshoShutokuShokai selectCondition = new SeisanshoShutokuShokai();
		List<SeisanshoShutokuShokai> stkskList = new ArrayList<SeisanshoShutokuShokai>();

		try {
			// 画面入力した検索条件をBeanのプロパティにセット
			BeanUtils.populate(selectCondition, reqMap);

		} catch (IllegalAccessException | InvocationTargetException e) {
			// エラーログ
			message = systemService.getMessage(NSDConstant.MSGID_SYSTEM_ERROR);
			resultMap.put(NSDConstant.RESULT_MSG_NAME, message);
			return resultMap;
		}

		try {
			// サービスを呼び出す
			stkskList = seisanshoShutokuService.getSeisanshoShutokuShokai(selectCondition);
		} catch (Exception e) {
			// エラーログ
			message = systemService.getMessage(NSDConstant.MSGID_SYSTEM_ERROR);
			resultMap.put(NSDConstant.RESULT_MSG_NAME, message);
			return resultMap;
		}

		// 処理結果データ
		if (stkskList.size() == 0) {
			message = systemService.getMessage(NSDConstant.MSGID_SYSTEM_INFO);
			resultMap.put(NSDConstant.RESULT_MSG_NAME, message);
		}else{
			resultMap.put(NSDConstant.RESULT_DATA_LIST_NAME, stkskList);
		}

		// 終了ログ
//		logger.info("getSeisanshoShutokuShokai 終了します。");

		return resultMap;
	}

	/*
	 * 精算書取得・新規
	 */
	@RequestMapping(value = "/seisanshoShutoku-insert", method = RequestMethod.POST)
	public Map<String, Object> insert(@RequestParam Map<String, Object> reqMap) {

//		logger.info("insert 開始します。");

		Map<String, Object> resultMap = new HashMap<String, Object>();
		Message message = new Message();

		Kss005 kss005 = new Kss005();

		try {
			// 画面入力した検索条件をBeanのプロパティにセット
			BeanUtils.populate(kss005, reqMap);
		} catch (IllegalAccessException | InvocationTargetException e) {
			// エラーログ
			message = systemService.getMessage(NSDConstant.MSGID_SYSTEM_ERROR);
			resultMap.put(NSDConstant.RESULT_MSG_NAME, message);
			return resultMap;
		}

		try {
			// サービスを呼び出す
			seisanshoShutokuService.insert(kss005);
		} catch (Exception e) {
			// エラーログ
			message = systemService.getMessage(NSDConstant.MSGID_SYSTEM_ERROR);
			resultMap.put(NSDConstant.RESULT_MSG_NAME, message);
			return resultMap;
		}

		return resultMap;
	}
}
