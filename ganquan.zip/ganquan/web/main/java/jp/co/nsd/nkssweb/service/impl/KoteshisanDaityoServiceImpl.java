package jp.co.nsd.nkssweb.service.impl;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import jp.co.nsd.nkssweb.dao.KoteshisanDaityo;
import jp.co.nsd.nkssweb.dao.mapper.KoteshisanDaityoMapper;
import jp.co.nsd.nkssweb.service.KoteshisanDaityoService;
import jp.co.nsd.nkssweb.utils.NSDConstant;

import java.io.FileOutputStream;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.DataFormat;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.streaming.SXSSFWorkbook;

@Service
public class KoteshisanDaityoServiceImpl implements KoteshisanDaityoService {

	@Autowired
	private KoteshisanDaityoMapper sssTrkMapper;

	@Override
	public List<KoteshisanDaityo> getKenmeiInfo(KoteshisanDaityo selectCondition) {

		List<KoteshisanDaityo> sssTrkList = new ArrayList<KoteshisanDaityo>();

		sssTrkList = sssTrkMapper.selectByWhere(selectCondition);

        try {

        	Date toda = new Date();

        	String filePath = NSDConstant.STRING_FILE_PATH;

        	Calendar calendar = Calendar.getInstance();

        	int year = calendar.get(Calendar.YEAR);
        	int month = calendar.get(Calendar.MONTH) + 1;
        	int day = calendar.get(Calendar.DATE) - 3;
        	StringBuffer dayBefore = new StringBuffer();
        	int monthLen = String.valueOf( month ).length();


        	if (monthLen == 1){

        		String outMonth = String.valueOf(month);
        		outMonth = NSDConstant.STRING_0 + outMonth;
            	dayBefore.append( year );
            	dayBefore.append( outMonth );
            	dayBefore.append( day );

        	} else {
        		dayBefore.append( year );
        		dayBefore.append( month );
        		dayBefore.append( day );

        	}

        	if (Files.notExists(Paths.get(filePath + dayBefore))){

        		System.out.println("三日前のフォルダは存在しません。");

        	} else {

        		System.out.println("三日前のフォルダは存在します。");
        		// ファイル削除
        		Files.delete(Paths.get(filePath + dayBefore + NSDConstant.STRING_FUGO + dayBefore + NSDConstant.STRING_EXCEL_FILE_NAME));
        		// パス削除
        		Files.delete(Paths.get(filePath + dayBefore));

        		System.out.println("三日前のフォルダが削除しました。");
        	}


        	SimpleDateFormat fileFormat = new SimpleDateFormat(NSDConstant.STRING_YYMMDD);

        	String nowDay = fileFormat.format(toda).toString();

        	filePath = filePath + nowDay + NSDConstant.STRING_FUGO;

        	if (Files.notExists(Paths.get(filePath))){

        		System.out.println("システム日付のフォルダは存在しません。");
        		// パス作成
        		Files.createDirectories(Paths.get(filePath));

        	} else {

        		System.out.println("システム日付のフォルダは存在します。");

        	}


        	String outputFilePath = filePath + nowDay + NSDConstant.STRING_EXCEL_FILE_NAME;
        	Workbook book = null;
        	FileOutputStream fout = null;

        	try {
        		book = new SXSSFWorkbook();
        		Font font = book.createFont();
        		font.setFontName(NSDConstant.STRING_FONT_NAME);
        		font.setFontHeightInPoints((short) 9);
        		DataFormat format = book.createDataFormat();


                //文字列用のスタイル
                CellStyle style_string = book.createCellStyle();
                style_string.setFont(font);

                //整数用のスタイル
                CellStyle style_int = book.createCellStyle();
                style_int.setDataFormat(format.getFormat(NSDConstant.STRING_FORMAT));
                style_int.setFont(font);

                Row row;
                int rowNumber = 0;
                Cell cell;
                int colNumber = 0;
                Sheet sheet;

                sheet = book.createSheet();


                // タイトル設定
                row = sheet.createRow(rowNumber);
                cell = row.createCell(colNumber++);
                cell.setCellValue(NSDConstant.STRING_NO);

                cell = row.createCell(colNumber++);
                cell.setCellValue(NSDConstant.STRING_KOJIKENMEI);

                cell = row.createCell(colNumber++);
                cell.setCellValue(NSDConstant.STRING_SEISAN_NO);

                cell = row.createCell(colNumber++);
                cell.setCellValue(NSDConstant.STRING_START_YMD);

                cell = row.createCell(colNumber++);
                cell.setCellValue(NSDConstant.STRING_GET_YMD);

                cell = row.createCell(colNumber++);
                cell.setCellValue(NSDConstant.STRING_KOTEI_NO);

                cell = row.createCell(colNumber++);
                cell.setCellValue(NSDConstant.STRING_OYAKOTEI_NO);

                cell = row.createCell(colNumber++);
                cell.setCellValue(NSDConstant.STRING_EDABAN);

                cell = row.createCell(colNumber++);
                cell.setCellValue(NSDConstant.STRING_KOTEI_NAME);

                cell = row.createCell(colNumber++);
                cell.setCellValue(NSDConstant.STRING_SHURUI);

                cell = row.createCell(colNumber++);
                cell.setCellValue(NSDConstant.STRING_KOZO);

                cell = row.createCell(colNumber++);
                cell.setCellValue(NSDConstant.STRING_SISANTANI);

                cell = row.createCell(colNumber++);
                cell.setCellValue(NSDConstant.STRING_KAMOKU1);

                cell = row.createCell(colNumber++);
                cell.setCellValue(NSDConstant.STRING_KAMOKU2);

                cell = row.createCell(colNumber++);
                cell.setCellValue(NSDConstant.STRING_KAMOKU3);

                cell = row.createCell(colNumber++);
                cell.setCellValue(NSDConstant.STRING_TORIHIKISAKI);

                cell = row.createCell(colNumber++);
                cell.setCellValue(NSDConstant.STRING_HOTEI_TAIYO_YS);

                cell = row.createCell(colNumber++);
                cell.setCellValue(NSDConstant.STRING_ZANZON_TAIYO_YS);

                cell = row.createCell(colNumber++);
                cell.setCellValue(NSDConstant.STRING_SYOKYAKU_HOHO);

                cell = row.createCell(colNumber++);
                cell.setCellValue(NSDConstant.STRING_SYOKYAKURITU);

                cell = row.createCell(colNumber++);
                cell.setCellValue(NSDConstant.STRING_BUTUHIN);

                cell = row.createCell(colNumber++);
                cell.setCellValue(NSDConstant.STRING_KOBI);

                cell = row.createCell(colNumber++);
                cell.setCellValue(NSDConstant.STRING_SOKOBI);

                cell = row.createCell(colNumber++);
                cell.setCellValue(NSDConstant.STRING_GET_KAGAKU);

                cell = row.createCell(colNumber++);
                cell.setCellValue(NSDConstant.STRING_ZENNENDOMATU_KAGAKU);

                cell = row.createCell(colNumber++);
                cell.setCellValue(NSDConstant.STRING_TOKISYOKYAKU_YOTEI);

                cell = row.createCell(colNumber++);
                cell.setCellValue(NSDConstant.STRING_SB_NENDOMATU_KAGAKU);

                cell = row.createCell(colNumber++);
                cell.setCellValue(NSDConstant.STRING_BUTUHIN_SURYO);

                cell = row.createCell(colNumber++);
                cell.setCellValue(NSDConstant.STRING_TANI_NAME);

                cell = row.createCell(colNumber++);
                cell.setCellValue(NSDConstant.STRING_KANRI_KASYO);

                cell = row.createCell(colNumber++);
                cell.setCellValue(NSDConstant.STRING_FUTAN_KASYO);

                cell = row.createCell(colNumber++);
                cell.setCellValue(NSDConstant.STRING_SETI_BASYO);

                cell = row.createCell(colNumber++);
                cell.setCellValue(NSDConstant.STRING_SE_KATA_NAME);

                cell = row.createCell(colNumber++);
                cell.setCellValue(NSDConstant.STRING_TEKIYO1);

                cell = row.createCell(colNumber++);
                cell.setCellValue(NSDConstant.STRING_TEKIYO2);

                cell = row.createCell(colNumber++);
                cell.setCellValue(NSDConstant.STRING_TEKIYO3);

                cell = row.createCell(colNumber++);
                cell.setCellValue(NSDConstant.STRING_TEKIYO4);

                cell = row.createCell(colNumber++);
                cell.setCellValue(NSDConstant.STRING_TEKIYO5);

                cell = row.createCell(colNumber++);
                cell.setCellValue(NSDConstant.STRING_KSISAN_CD);

                cell = row.createCell(colNumber++);
                cell.setCellValue(NSDConstant.STRING_KJ_TANTO_KASYO);

                cell = row.createCell(colNumber++);
                cell.setCellValue(NSDConstant.STRING_KJ_TANTO_SYA);

                cell = row.createCell(colNumber++);
                cell.setCellValue(NSDConstant.STRING_KK_SEIRI_YMD);

                cell = row.createCell(colNumber++);
                cell.setCellValue(NSDConstant.STRING_BKM_KOTEISISAN_NO);

                cell = row.createCell(colNumber++);
                cell.setCellValue(NSDConstant.STRING_JKYAKU_YMD);

                cell = row.createCell(colNumber++);
                cell.setCellValue(NSDConstant.STRING_SK_SKYAKU_KUBUN);

                cell = row.createCell(colNumber++);
                cell.setCellValue(NSDConstant.STRING_ZANZON_KAGAKU);

                cell = row.createCell(colNumber++);
                cell.setCellValue(NSDConstant.STRING_HT_NAIYO_NENSU);

                cell = row.createCell(colNumber++);
                cell.setCellValue(NSDConstant.STRING_ZZ_NAIYO_NENSU);

                cell = row.createCell(colNumber++);
                cell.setCellValue(NSDConstant.STRING_MNDM_KAGAKU);

                cell = row.createCell(colNumber++);
                cell.setCellValue(NSDConstant.STRING_TK_SYOKYSKU_GAKU);

                cell = row.createCell(colNumber++);
                cell.setCellValue(NSDConstant.STRING_NENDOMATU_GAKU);

                cell = row.createCell(colNumber++);
                cell.setCellValue(NSDConstant.STRING_SINKOSAKI_NAME);

                cell = row.createCell(colNumber++);
                cell.setCellValue(NSDConstant.STRING_SINKO_SYURUI);

                cell = row.createCell(colNumber++);
                cell.setCellValue(NSDConstant.STRING_NSZN_GAKU);

                cell = row.createCell(colNumber++);
                cell.setCellValue(NSDConstant.STRING_NSGZ_GAKU);


                for (int i = 0; i < sssTrkList.size(); i++) {

                	KoteshisanDaityo sssTrkkDto = sssTrkList.get(i);

                	// 出力データ内容設定
                    rowNumber++;
                    colNumber = 0;
                    row = sheet.createRow(rowNumber);
                    cell = row.createCell(colNumber++);
                    cell.setCellValue(i+1);

                    cell = row.createCell(colNumber++);
                    cell.setCellValue(sssTrkkDto.getKamokuKnj());

                    cell = row.createCell(colNumber++);
                    cell.setCellValue(sssTrkkDto.getSeisanNo());

                    cell = row.createCell(colNumber++);
                    cell.setCellValue(sssTrkkDto.getUseYmd());

                    cell = row.createCell(colNumber++);
                    cell.setCellValue(sssTrkkDto.getGetYmd());

                    cell = row.createCell(colNumber++);
                    cell.setCellValue(sssTrkkDto.getKoteiNo());

                    cell = row.createCell(colNumber++);
                    cell.setCellValue(sssTrkkDto.getKomk06Kna());

                    cell = row.createCell(colNumber++);
                    cell.setCellValue(sssTrkkDto.getKomk07Kna());

                    cell = row.createCell(colNumber++);
                    cell.setCellValue(sssTrkkDto.getKoteiKnj());

                    cell = row.createCell(colNumber++);
                    cell.setCellValue(sssTrkkDto.getShuKnj());

                    cell = row.createCell(colNumber++);
                    cell.setCellValue(sssTrkkDto.getKouKnj());

                    cell = row.createCell(colNumber++);
                    cell.setCellValue(sssTrkkDto.getSaiKnj());

                    cell = row.createCell(colNumber++);
                    cell.setCellValue(sssTrkkDto.getShu4Knj());

                    cell = row.createCell(colNumber++);
                    cell.setCellValue(sssTrkkDto.getShu5Knj());

                    cell = row.createCell(colNumber++);
                    cell.setCellValue(sssTrkkDto.getShu6Knj());

                    cell = row.createCell(colNumber++);
                    cell.setCellValue(sssTrkkDto.getTorihikiKnj());

                    cell = row.createCell(colNumber++);
                    cell.setCellValue(sssTrkkDto.getShotaiYs());

                    cell = row.createCell(colNumber++);
                    cell.setCellValue(sssTrkkDto.getSkeikaY());

                    cell = row.createCell(colNumber++);
                    cell.setCellValue(sssTrkkDto.getMeishoKnj());

                    cell = row.createCell(colNumber++);
                    cell.setCellValue(sssTrkkDto.getSsykRit());

                    cell = row.createCell(colNumber++);
                    cell.setCellValue(sssTrkkDto.getKagak1Yen());

                    cell = row.createCell(colNumber++);
                    cell.setCellValue(sssTrkkDto.getKagak2Yen());

                    cell = row.createCell(colNumber++);
                    cell.setCellValue(sssTrkkDto.getKagak3Yen());

                    cell = row.createCell(colNumber++);
                    cell.setCellValue(sssTrkkDto.getGetkgkYen());

                    cell = row.createCell(colNumber++);
                    cell.setCellValue(sssTrkkDto.getMaebkasYen());

                    cell = row.createCell(colNumber++);
                    cell.setCellValue(sssTrkkDto.getTkishsYen());

                    cell = row.createCell(colNumber++);
                    cell.setCellValue(sssTrkkDto.getEndsYen());

                    cell = row.createCell(colNumber++);
                    cell.setCellValue(sssTrkkDto.getMeiSu());

                    cell = row.createCell(colNumber++);
                    cell.setCellValue(sssTrkkDto.getTaniKnj());

                    cell = row.createCell(colNumber++);
                    cell.setCellValue(sssTrkkDto.getKanriKnj());

                    cell = row.createCell(colNumber++);
                    cell.setCellValue(sssTrkkDto.getFutan1Knj());

                    cell = row.createCell(colNumber++);
                    cell.setCellValue(sssTrkkDto.getBashoKnj());

                    cell = row.createCell(colNumber++);
                    cell.setCellValue(sssTrkkDto.getKaisyaKnj());

                    cell = row.createCell(colNumber++);
                    cell.setCellValue(sssTrkkDto.getMemo1Knj());

                    cell = row.createCell(colNumber++);
                    cell.setCellValue(sssTrkkDto.getMemo2Knj());

                    cell = row.createCell(colNumber++);
                    cell.setCellValue(sssTrkkDto.getKomk11Knj());

                    cell = row.createCell(colNumber++);
                    cell.setCellValue(sssTrkkDto.getKomk12Knj());

                    cell = row.createCell(colNumber++);
                    cell.setCellValue(sssTrkkDto.getKomk13Knj());

                    cell = row.createCell(colNumber++);
                    cell.setCellValue(sssTrkkDto.getKomk08Kna());

                    cell = row.createCell(colNumber++);
                    cell.setCellValue(sssTrkkDto.getKomk15Knj());

                    cell = row.createCell(colNumber++);
                    cell.setCellValue(sssTrkkDto.getKomk14Knj());

                    cell = row.createCell(colNumber++);
                    cell.setCellValue(sssTrkkDto.getKaikeiYm());

                    cell = row.createCell(colNumber++);
                    cell.setCellValue(sssTrkkDto.getKoteibktNo());

                    cell = row.createCell(colNumber++);
                    cell.setCellValue(sssTrkkDto.getJyokykYmd());

                    cell = row.createCell(colNumber++);
                    cell.setCellValue(sssTrkkDto.getMeisho1Knj());

                    cell = row.createCell(colNumber++);
                    cell.setCellValue(sssTrkkDto.getZanzonsYen());

                    cell = row.createCell(colNumber++);
                    cell.setCellValue(sssTrkkDto.getZeitaiYs());

                    cell = row.createCell(colNumber++);
                    cell.setCellValue(sssTrkkDto.getZkeikaY());

                    cell = row.createCell(colNumber++);
                    cell.setCellValue(sssTrkkDto.getMaebkazYen());

                    cell = row.createCell(colNumber++);
                    cell.setCellValue(sssTrkkDto.getTkishzYen());

                    cell = row.createCell(colNumber++);
                    cell.setCellValue(sssTrkkDto.getEndzYen());

                    cell = row.createCell(colNumber++);
                    cell.setCellValue(sssTrkkDto.getShinkkKnj());

                    cell = row.createCell(colNumber++);
                    cell.setCellValue(sssTrkkDto.getMeisho2Knj());

                    cell = row.createCell(colNumber++);
                    cell.setCellValue(sssTrkkDto.getYbnhykYen());

                    cell = row.createCell(colNumber++);
                    cell.setCellValue(sssTrkkDto.getYfnhykYen());


                }

                //ファイル出力
                fout = new FileOutputStream(outputFilePath);
                book.write(fout);


        	}
        	finally {
                if (fout != null) {
                    try {
                        fout.close();
                    }
                    catch (IOException e) {
                    }
                }
                if (book != null) {
                    try {
                        /*
                            SXSSFWorkbookはメモリ空間を節約する代わりにテンポラリファイルを大量に生成するため、
                            不要になった段階でdisposeしてテンポラリファイルを削除する必要がある
                         */
                        ((SXSSFWorkbook) book).dispose();
                    }
                    catch (Exception e) {
                    }
                }
        	}

        } catch (IOException ex) {

            ex.printStackTrace();

        }

		return sssTrkList;

	}

}
