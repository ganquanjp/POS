package jp.co.nsd.nkssweb.dao;

import java.util.Date;

public class Kss015 extends Kss015Key {
    private Date kanriTekiyoEndYmd;

    private Date futanTekiyoEndYmd;

    private Date entryDate;

    private String entryUserId;

    private Date updateDate;

    private String updateUserId;

    public Date getKanriTekiyoEndYmd() {
        return kanriTekiyoEndYmd;
    }

    public void setKanriTekiyoEndYmd(Date kanriTekiyoEndYmd) {
        this.kanriTekiyoEndYmd = kanriTekiyoEndYmd;
    }

    public Date getFutanTekiyoEndYmd() {
        return futanTekiyoEndYmd;
    }

    public void setFutanTekiyoEndYmd(Date futanTekiyoEndYmd) {
        this.futanTekiyoEndYmd = futanTekiyoEndYmd;
    }

    public Date getEntryDate() {
        return entryDate;
    }

    public void setEntryDate(Date entryDate) {
        this.entryDate = entryDate;
    }

    public String getEntryUserId() {
        return entryUserId;
    }

    public void setEntryUserId(String entryUserId) {
        this.entryUserId = entryUserId == null ? null : entryUserId.trim();
    }

    public Date getUpdateDate() {
        return updateDate;
    }

    public void setUpdateDate(Date updateDate) {
        this.updateDate = updateDate;
    }

    public String getUpdateUserId() {
        return updateUserId;
    }

    public void setUpdateUserId(String updateUserId) {
        this.updateUserId = updateUserId == null ? null : updateUserId.trim();
    }
}