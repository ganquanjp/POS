package jp.co.nsd.nkssweb.controller.seisanshotoroku;

import java.io.IOException;
import org.springframework.web.bind.annotation.RestController;


@RestController
public class SeisanshoTorokuKmskJheBatstartController {
	/*
	 * 精算書登録・件名即時反映(Batファイル起動)
	 */
//	@RequestMapping(value = "/seisanshoTorokuKmskJhe-selectByBat", method = RequestMethod.POST)
	public void doEnter() throws Exception {
		 try {
			 // Batファイル格納するところと名前をメモする
			 String sCmd = "C:\\Users\\nsdH281003\\Desktop\\Kenmei.bat";
			 ProcessBuilder builder = new ProcessBuilder(sCmd);
			// Batファイル起動する
			 Process process = builder.start();
			 int ret = process.waitFor();
			 System.out.println("process exited with value : " + ret);
		 }catch (IOException e) {
			 // start()で例外が発生
			 e.printStackTrace();
		 } catch (InterruptedException e) {
			 // waitFor()で例外が発生
			 e.printStackTrace();
		 }
	 }
}
