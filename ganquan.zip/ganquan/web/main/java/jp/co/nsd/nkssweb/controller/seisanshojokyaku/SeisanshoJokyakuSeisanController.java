/***********************************************************************
*
*業務名: 工事精算システム
*機能名: 除却（精算通告）(ログ出力処理)
*
*機能概要: 除却情報を処理する。
*
*JavaＶｅｒ：J2SE1.8.0準拠
*
*更新履歴: Ver.1.00 2018/03/06　NSD　新規作成
***********************************************************************/

package jp.co.nsd.nkssweb.controller.seisanshojokyaku;

import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.beanutils.BeanUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import jp.co.nsd.nkssweb.dao.Message;
import jp.co.nsd.nkssweb.dao.SeisanshoJokyakuSeisan;
import jp.co.nsd.nkssweb.dao.SeisanshoJokyakuSeisanShokai;
import jp.co.nsd.nkssweb.service.SystemService;
import jp.co.nsd.nkssweb.service.seisanshojokyaku.SeisanshoJokyakuSeisanService;
import jp.co.nsd.nkssweb.utils.NSDCommUtils;
import jp.co.nsd.nkssweb.utils.NSDConstant;

/**
 * 除却（精算通告）処理
 *
 * @version 1.00
 */
@RestController
public class SeisanshoJokyakuSeisanController {

	// ログ
	private Logger logger = LoggerFactory.getLogger(this.getClass());

	@Autowired
	private SeisanshoJokyakuSeisanService seisanshoJokyakuSeisanService;

	protected SystemService systemService;

	/**
	 * 除却（精算通告）検索処理
	 *
	 * @param reqMap
	 *            INPUTパラメータ
	 * @return 除却情報データ
	 * @exception IllegalAccessException
	 * @exception InvocationTargetException
	 * @version 1.00
	 */
	@RequestMapping(value = "/seisanshoJokyakuSeisan-selectByWhere", method = RequestMethod.POST)
	public Map<String, Object> selectByWhere(@RequestParam Map<String, Object> reqMap) {

		// 開始ログ
		logger.info("SeisanshoJokyakuSeisanController.selectByWhere 開始します。");

		Map<String, Object> returnMap = new HashMap<String, Object>();

		Message message = new Message();

		SeisanshoJokyakuSeisan seisanshoJokyakuSeisan = new SeisanshoJokyakuSeisan();

		List<SeisanshoJokyakuSeisan> sssJkkSsLst = new ArrayList<>();

		// 画面入力した検索条件を取得する
		try {
			// Mapの情報をBeanのプロパティにセット
			BeanUtils.populate(seisanshoJokyakuSeisan, reqMap);

			// 除却年月日（From）と除却年月日（To）の大小比較チェック
			if (NSDCommUtils.chkDateFromTo(seisanshoJokyakuSeisan.getJokyakuYmdFrom(),
					seisanshoJokyakuSeisan.getJokyakuYmdTo())) {
				// 処理結果データ
				returnMap.put(NSDConstant.RESULT_DATA_LIST_NAME, sssJkkSsLst);
				// メッセージ内容
				message = systemService.getMessage(NSDConstant.MSGID_SYSTEM_ERROR);
				returnMap.put(NSDConstant.RESULT_MSG_NAME, message);

				// 終了ログ
				logger.info("SeisanshoJokyakuSeisanController.selectByWhere 終了します。");

				return returnMap;
			}
		} catch (IllegalAccessException | InvocationTargetException e) {
			// エーラログ
			logger.info("SeisanshoJokyakuSeisanController.selectByWhereでエラーが発生しました。");
			e.printStackTrace();
		}

		// サービス呼び出し
		sssJkkSsLst = seisanshoJokyakuSeisanService.getJokyakuSeisanInfo(seisanshoJokyakuSeisan);
		// 処理結果データ
		returnMap.put(NSDConstant.RESULT_DATA_LIST_NAME, sssJkkSsLst);
		// メッセージ内容
		returnMap.put(NSDConstant.RESULT_MSG_NAME, NSDConstant.BLANK_STRING);

		// 終了ログ
		logger.info("SeisanshoJokyakuSeisanController.selectByWhere 終了します。");

		return returnMap;
	}

	/**
	 * 除却（精算通告）照会処理
	 *
	 * @param reqMap
	 *            INPUTパラメータ
	 * @return 除却情報データ
	 * @exception IllegalAccessException
	 * @exception InvocationTargetException
	 * @version 1.00
	 */
	@RequestMapping(value = "/seisanshoJokyakuSeisan-selectBySeisanShoNo", method = RequestMethod.POST)
	public Map<String, Object> selectBySeisanShoNo(@RequestParam Map<String, Object> reqMap) {

		// 開始ログ
		logger.info("SeisanshoJokyakuSeisanController.selectBySeisanShoNo 開始します。");

		Map<String, Object> returnMap = new HashMap<String, Object>();

		SeisanshoJokyakuSeisanShokai seisanshoJokyakuSeisanShokai = new SeisanshoJokyakuSeisanShokai();

		// 精算書より除却情報を取得する
		try {
			// Mapの情報をBeanのプロパティにセット
			BeanUtils.populate(seisanshoJokyakuSeisanShokai, reqMap);

		} catch (IllegalAccessException | InvocationTargetException e) {
			// エーラログ
			logger.info("SeisanshoJokyakuSeisanController.selectBySeisanShoNoでエラーが発生しました。");
		}

		// サービス呼び出し
		SeisanshoJokyakuSeisanShokai sssJkkSsSkDto = seisanshoJokyakuSeisanService
				.getJokyakuInfoBySeisanShoNo(seisanshoJokyakuSeisanShokai);

		// 処理結果データ
		returnMap.put(NSDConstant.RESULT_DATA_LIST_NAME, sssJkkSsSkDto);
		// メッセージ内容
		returnMap.put(NSDConstant.RESULT_MSG_NAME, NSDConstant.BLANK_STRING);

		// 終了ログ
		logger.info("SeisanshoJokyakuSeisanController.selectBySeisanShoNo 終了します。");

		return returnMap;
	}
}
