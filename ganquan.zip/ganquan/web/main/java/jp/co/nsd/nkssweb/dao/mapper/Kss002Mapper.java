package jp.co.nsd.nkssweb.dao.mapper;

import jp.co.nsd.nkssweb.dao.Kss002;
import jp.co.nsd.nkssweb.dao.Kss002Key;

public interface Kss002Mapper {
    int deleteByPrimaryKey(Kss002Key key);

    int insert(Kss002 record);

    int insertSelective(Kss002 record);

    Kss002 selectByPrimaryKey(Kss002Key key);

    int updateByPrimaryKeySelective(Kss002 record);

    int updateByPrimaryKey(Kss002 record);

}