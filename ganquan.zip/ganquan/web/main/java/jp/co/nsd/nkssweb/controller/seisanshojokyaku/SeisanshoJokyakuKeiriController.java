/***********************************************************************
*
*業務名: 工事精算システム
*機能名: 除却（経理審査/連携）(ログ出力処理)
*
*機能概要: 除却情報を処理する。
*
*JavaＶｅｒ：J2SE1.8.0準拠
*
*更新履歴: Ver.1.00 2018/03/06　NSD　新規作成
***********************************************************************/

package jp.co.nsd.nkssweb.controller.seisanshojokyaku;

import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.beanutils.BeanUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import jp.co.nsd.nkssweb.dao.Message;
import jp.co.nsd.nkssweb.dao.SeisanshoJokyakuKeiri;
import jp.co.nsd.nkssweb.service.SystemService;
import jp.co.nsd.nkssweb.service.seisanshojokyaku.SeisanshoJokyakuKeiriService;
import jp.co.nsd.nkssweb.utils.NSDCommUtils;
import jp.co.nsd.nkssweb.utils.NSDConstant;

/**
 * 除却（経理審査/連携）処理
 *
 * @version 1.00
 */
@RestController
public class SeisanshoJokyakuKeiriController {

	// ログ
	private Logger logger = LoggerFactory.getLogger(this.getClass());

	@Autowired
	private SeisanshoJokyakuKeiriService seisanshoJokyakuKeiriService;

	protected SystemService systemService;

	/**
	 * 除却（経理審査/連携）処理
	 *
	 * @param reqMap
	 *            INPUTパラメータ
	 * @return 除却情報データ
	 * @exception IllegalAccessException
	 * @exception InvocationTargetException
	 * @version 1.00
	 */
	@RequestMapping(value = "/seisanshoJokyakuKeiri-selectByWhere", method = RequestMethod.POST)
	public Map<String, Object> selectByWhere(@RequestParam Map<String, Object> reqMap) {

		// 開始ログ
		logger.info("SeisanshoJokyakuKeiriController.selectByWhere 開始します。");

		Map<String, Object> returnMap = new HashMap<String, Object>();

		Message message = new Message();

		SeisanshoJokyakuKeiri seisanshoJokyakuKeiri = new SeisanshoJokyakuKeiri();

		List<SeisanshoJokyakuKeiri> sssJkkKrLst = new ArrayList<>();

		// 画面入力した検索条件を取得する
		try {
			// Mapの情報をBeanのプロパティにセット
			BeanUtils.populate(seisanshoJokyakuKeiri, reqMap);

			// 除却年月日（From）と除却年月日（To）の大小比較チェック
			if (NSDCommUtils.chkDateFromTo(seisanshoJokyakuKeiri.getJokyakuYmdFrom(),
					seisanshoJokyakuKeiri.getJokyakuYmdTo())) {
				// 処理結果データ
				returnMap.put(NSDConstant.RESULT_DATA_LIST_NAME, sssJkkKrLst);
				// メッセージ内容
				message = systemService.getMessage(NSDConstant.MSGID_SYSTEM_ERROR);
				returnMap.put(NSDConstant.RESULT_MSG_NAME, message);

				// 終了ログ
				logger.info("SeisanshoJokyakuKeiriController.selectByWhere 終了します。");

				return returnMap;
			}
		} catch (IllegalAccessException | InvocationTargetException e) {
			// エーラログ
			logger.info("SeisanshoJokyakuKeiriController.selectByWhereでエラーが発生しました。");
			e.printStackTrace();
		}

		// サービス呼び出し
		sssJkkKrLst = seisanshoJokyakuKeiriService.getJokyakuKeiriInfo(seisanshoJokyakuKeiri);
		// 処理結果データ
		returnMap.put(NSDConstant.RESULT_DATA_LIST_NAME, sssJkkKrLst);
		// メッセージ内容
		returnMap.put(NSDConstant.RESULT_MSG_NAME, NSDConstant.BLANK_STRING);

		// 終了ログ
		logger.info("SeisanshoJokyakuKeiriController.selectByWhere 終了します。");

		return returnMap;
	}

	/**
	 * 除却（経理審査/連携）更新処理
	 *
	 * @param reqMap
	 *            INPUTパラメータ
	 * @return 除却情報データ
	 * @exception IllegalAccessException
	 * @exception InvocationTargetException
	 * @version 1.00
	 */
	@RequestMapping(value = "/seisanshoJokyakuKeiri-gotoUpdate", method = RequestMethod.POST)
	public Map<String, Object> gotoUpdate(@RequestParam Map<String, Object> reqMap) {

		// 開始ログ
		logger.info("SeisanshoJokyakuKeiriController.selectBySeisanShoNo 開始します。");

		Map<String, Object> returnMap = new HashMap<String, Object>();

//		SeisanshoJokyakuShoninShokai seisanshoJokyakuShoninShokai = new SeisanshoJokyakuShoninShokai();
//
//		// 精算書より除却情報を取得する
//		try {
//			// Mapの情報をBeanのプロパティにセット
//			BeanUtils.populate(seisanshoJokyakuShoninShokai, reqMap);
//
//		} catch (IllegalAccessException | InvocationTargetException e) {
//			// エーラログ
//			logger.info("SeisanshoJokyakuKeiriController.selectBySeisanShoNoでエラーが発生しました。");
//		}
//
		// サービス呼び出し
//		SeisanshoJokyakuShoninShokai sssJkkSnSkDto = seisanshoJokyakuKeiriService
//				.gotoUpdate();

		// 処理結果データ
		returnMap.put(NSDConstant.RESULT_DATA_LIST_NAME, NSDConstant.BLANK_STRING);
		// メッセージ内容
		returnMap.put(NSDConstant.RESULT_MSG_NAME, NSDConstant.BLANK_STRING);

		// 終了ログ
		logger.info("SeisanshoJokyakuKeiriController.selectBySeisanShoNo 終了します。");

		return returnMap;
	}
}
