/***********************************************************************
*
*業務名: 工事精算システム
*機能名: 除却（経理審査/連携）(サービス処理)
*
*機能概要: 除却情報を処理する。
*
*JavaＶｅｒ：J2SE1.8.0準拠
*
*更新履歴: Ver.1.00 2018/03/06　NSD　新規作成
***********************************************************************/
package jp.co.nsd.nkssweb.service.seisanshoshutoku;

import java.util.List;

import jp.co.nsd.nkssweb.dao.SeisanshoShutokuKeiri;
import jp.co.nsd.nkssweb.dao.SeisanshoShutokuKrsk;

/**
 * 取得（経理審査/連携）処理
 *
 * @version 1.00
 */
public interface SeisanshoShutokuKeiriService {

	/**
	 * 取得（経理審査/連携）情報取得
	 *
	 * @param SeisanshoJokyakuKeiri
	 *            INPUTパラメータ
	 * @return　検索結果
	 */
	List<SeisanshoShutokuKeiri> getshutokuKeiriInfo(SeisanshoShutokuKeiri seisanshoShutokuKeiri);

	/**
	 * 取得（経理審査/連携）情報取得（照会画面）
	 *
	 * @param seisanshoShutokuKrsk
	 *            INPUTパラメータ
	 * @return　検索結果
	 */
	SeisanshoShutokuKrsk getshutokuInfoBySeisanShoNo(SeisanshoShutokuKrsk seisanshoShutokuKrsk);

}
