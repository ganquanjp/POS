package jp.co.nsd.nkssweb.dao.mapper;

import jp.co.nsd.nkssweb.dao.Kss007;
import jp.co.nsd.nkssweb.dao.Kss007Key;

public interface Kss007Mapper {
    int deleteByPrimaryKey(Kss007Key key);

    int insert(Kss007 record);

    int insertSelective(Kss007 record);

    Kss007 selectByPrimaryKey(Kss007Key key);

    int updateByPrimaryKeySelective(Kss007 record);

    int updateByPrimaryKey(Kss007 record);
}