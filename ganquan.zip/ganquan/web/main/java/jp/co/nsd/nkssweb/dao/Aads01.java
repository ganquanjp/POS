package jp.co.nsd.nkssweb.dao;

import java.math.BigDecimal;

public class Aads01 {
	// 決算スケジュール情報

	// 会計整理年月日
	private String kaikeiYm;

	// 入力開始日
	private String infromYmd;

	// 入力終了日
	private String intoYmd;

	// 承認期限日
	private String snkigYmd;

	// 月次締切日
	private String getsjsYmd;

	// 月次締切通告日時
	private String getsmtDh;

	// 年度末処理日
	private String nendmtYmd;

	// 更新カウンタ
	private BigDecimal updateCnt;

	// 登録日時
	private String torokDh;

	// 登録者コード
	private String torshaCod;

	// 更新日時
	private String updateDh;

	// 更新者コード
	private String updshaCod;

	public String getKaikeiYm() {
		return kaikeiYm;
	}

	public void setKaikeiYm(String kaikeiYm) {
		this.kaikeiYm = kaikeiYm;
	}

	public String getInfromYmd() {
		return infromYmd;
	}

	public void setInfromYmd(String infromYmd) {
		this.infromYmd = infromYmd;
	}

	public String getIntoYmd() {
		return intoYmd;
	}

	public void setIntoYmd(String intoYmd) {
		this.intoYmd = intoYmd;
	}

	public String getSnkigYmd() {
		return snkigYmd;
	}

	public void setSnkigYmd(String snkigYmd) {
		this.snkigYmd = snkigYmd;
	}

	public String getGetsjsYmd() {
		return getsjsYmd;
	}

	public void setGetsjsYmd(String getsjsYmd) {
		this.getsjsYmd = getsjsYmd;
	}

	public String getGetsmtDh() {
		return getsmtDh;
	}

	public void setGetsmtDh(String getsmtDh) {
		this.getsmtDh = getsmtDh;
	}

	public String getNendmtYmd() {
		return nendmtYmd;
	}

	public void setNendmtYmd(String nendmtYmd) {
		this.nendmtYmd = nendmtYmd;
	}

	public BigDecimal getUpdateCnt() {
		return updateCnt;
	}

	public void setUpdateCnt(BigDecimal updateCnt) {
		this.updateCnt = updateCnt;
	}

	public String getTorokDh() {
		return torokDh;
	}

	public void setTorokDh(String torokDh) {
		this.torokDh = torokDh;
	}

	public String getTorshaCod() {
		return torshaCod;
	}

	public void setTorshaCod(String torshaCod) {
		this.torshaCod = torshaCod;
	}

	public String getUpdateDh() {
		return updateDh;
	}

	public void setUpdateDh(String updateDh) {
		this.updateDh = updateDh;
	}

	public String getUpdshaCod() {
		return updshaCod;
	}

	public void setUpdshaCod(String updshaCod) {
		this.updshaCod = updshaCod;
	}


}