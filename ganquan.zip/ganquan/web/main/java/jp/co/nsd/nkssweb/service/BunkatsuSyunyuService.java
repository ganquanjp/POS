package jp.co.nsd.nkssweb.service;

import java.util.List;

import jp.co.nsd.nkssweb.dao.BunkatsuSyunyu;

public interface BunkatsuSyunyuService {

	/**
	 * 分割情報取得
	 *
	 * @param selectCondition
	 * @return
	 */
	List<BunkatsuSyunyu> getBunkatsuInfo(BunkatsuSyunyu selectCondition);

}
