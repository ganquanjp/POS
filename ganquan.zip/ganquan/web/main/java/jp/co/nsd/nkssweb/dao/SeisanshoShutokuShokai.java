package jp.co.nsd.nkssweb.dao;

public class SeisanshoShutokuShokai extends Kss005 {

	private int rowNo;
	private String soshikiNm;
	private String siyoStartYmd;
	private String torokushaName;
	private String koteiShisanNo;
	private String koteiShisanName;
	private String sechiBashoName;
	private String kenmeiCd;
	private String kenmeiNm;
	private Long shutokuGaku;

	public int getRowNo() {
		return rowNo;
	}

	public void setRowNo(int rowNo) {
		this.rowNo = rowNo;
	}

	public String getSoshikiNm() {
		return soshikiNm;
	}

	public void setSoshikiNm(String soshikiNm) {
		this.soshikiNm = soshikiNm;
	}

	public String getSiyoStartYmd() {
		return siyoStartYmd;
	}

	public void setSiyoStartYmd(String siyoStartYmd) {
		this.siyoStartYmd = siyoStartYmd;
	}

	public String getTorokushaName() {
		return torokushaName;
	}

	public void setTorokushaName(String torokushaName) {
		this.torokushaName = torokushaName;
	}

	public String getKoteiShisanNo() {
		return koteiShisanNo;
	}

	public void setKoteiShisanNo(String koteiShisanNo) {
		this.koteiShisanNo = koteiShisanNo;
	}

	public String getKoteiShisanName() {
		return koteiShisanName;
	}

	public void setKoteiShisanName(String koteiShisanName) {
		this.koteiShisanName = koteiShisanName;
	}

	public String getSechiBashoName() {
		return sechiBashoName;
	}

	public void setSechiBashoName(String sechiBashoName) {
		this.sechiBashoName = sechiBashoName;
	}

	public String getKenmeiCd() {
		return kenmeiCd;
	}

	public void setKenmeiCd(String kenmeiCd) {
		this.kenmeiCd = kenmeiCd;
	}

	public String getKenmeiNm() {
		return kenmeiNm;
	}

	public void setKenmeiNm(String kenmeiNm) {
		this.kenmeiNm = kenmeiNm;
	}

	public Long getShutokuGaku() {
		return shutokuGaku;
	}

	public void setShutokuGaku(Long shutokuGaku) {
		this.shutokuGaku = shutokuGaku;
	}

}