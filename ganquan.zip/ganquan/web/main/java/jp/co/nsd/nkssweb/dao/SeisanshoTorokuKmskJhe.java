package jp.co.nsd.nkssweb.dao;

public class SeisanshoTorokuKmskJhe {

	// 件名ID
	private int rowNo;
	// 件名ID
	private Long kenmeiId;
	// 件名CD
	private String kenmeiCd;
	// 件名
	private String kenmeiNm;
	// 使用フラグ
	// 発生科目コード
	// 科目内訳名称
	// 責任組織１コード固定
	// 繰越区分
	// 予定着工年月
	// 予定竣工年月
	// 予算額
	// 予備１
	// 予備２
	// 予備３
	// 予備４
	// 予備５
	// 適用期間(To)無効フラグ
	// 更新カウンタ
	// 登録日時
	private String entryDate;
	// 登録者コード
	private String entryUserId;
	// 更新日時
	private String updateDate;
	// 更新者コード
	private String updateUserId;
	// 連携ステータス
	private String renkeiStatus;
	public int getRowNo() {
		return rowNo;
	}
	public void setRowNo(int rowNo) {
		this.rowNo = rowNo;
	}
	public Long getKenmeiId() {
		return kenmeiId;
	}
	public void setKenmeiId(Long kenmeiId) {
		this.kenmeiId = kenmeiId;
	}
	public String getKenmeiCd() {
		return kenmeiCd;
	}
	public void setKenmeiCd(String kenmeiCd) {
		this.kenmeiCd = kenmeiCd;
	}
	public String getKenmeiNm() {
		return kenmeiNm;
	}
	public void setKenmeiNm(String kenmeiNm) {
		this.kenmeiNm = kenmeiNm;
	}
	public String getEntryDate() {
		return entryDate;
	}
	public void setEntryDate(String entryDate) {
		this.entryDate = entryDate;
	}
	public String getEntryUserId() {
		return entryUserId;
	}
	public void setEntryUserId(String entryUserId) {
		this.entryUserId = entryUserId;
	}
	public String getUpdateDate() {
		return updateDate;
	}
	public void setUpdateDate(String updateDate) {
		this.updateDate = updateDate;
	}
	public String getUpdateUserId() {
		return updateUserId;
	}
	public void setUpdateUserId(String updateUserId) {
		this.updateUserId = updateUserId;
	}
	public String getRenkeiStatus() {
		return renkeiStatus;
	}
	public void setRenkeiStatus(String renkeiStatus) {
		this.renkeiStatus = renkeiStatus;
	}







}