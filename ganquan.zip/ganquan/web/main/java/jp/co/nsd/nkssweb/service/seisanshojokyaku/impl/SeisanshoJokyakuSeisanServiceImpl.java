/***********************************************************************
*
*業務名: 工事精算システム
*機能名: 除却（精算通告）(サービス処理)
*
*機能概要: 除却（精算通告）情報を処理する。
*
*JavaＶｅｒ：J2SE1.8.0準拠
*
*更新履歴: Ver.1.00 2018/03/06　NSD　新規作成
***********************************************************************/
package jp.co.nsd.nkssweb.service.seisanshojokyaku.impl;

import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.beanutils.BeanUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import jp.co.nsd.nkssweb.dao.KoteiSisan;
import jp.co.nsd.nkssweb.dao.SeisanshoJokyakuKoteiSisan;
import jp.co.nsd.nkssweb.dao.SeisanshoJokyakuSeisan;
import jp.co.nsd.nkssweb.dao.SeisanshoJokyakuSeisanShokai;
import jp.co.nsd.nkssweb.dao.mapper.SanshoMapper;
import jp.co.nsd.nkssweb.dao.mapper.SeisanshoJokyakuSeisanMapper;
import jp.co.nsd.nkssweb.service.seisanshojokyaku.SeisanshoJokyakuSeisanService;
import jp.co.nsd.nkssweb.utils.NSDConstant;

/**
 * 除却（精算通告）処理
 *
 * @see SeisanshoJokyakuSeisanService
 * @version 1.00
 */
@Service
public class SeisanshoJokyakuSeisanServiceImpl implements SeisanshoJokyakuSeisanService {

	// ログ
	private Logger logger = LoggerFactory.getLogger(this.getClass());

	@Autowired
	private SeisanshoJokyakuSeisanMapper seisanshoJokyakuSeisanMapper;

	@Autowired
	private SanshoMapper sanshoMapper;

	/**
	 * 除却（精算通告）検索処理
	 *
	 * @param seisanshoJokyakuSeisan
	 *            INPUTパラメータ
	 * @return sssJykList 除却情報データリスト
	 * @version 1.00
	 */
	public List<SeisanshoJokyakuSeisan> getJokyakuSeisanInfo(SeisanshoJokyakuSeisan seisanshoJokyakuSeisan) {

		// 開始ログ
		logger.info("SeisanshoJokyakuSeisanServiceImpl.getJokyakuSeisaiInfo 開始します。");

		// 除却情報を取得する
		List<SeisanshoJokyakuSeisan> sssJykSsList = seisanshoJokyakuSeisanMapper.selectByWhere(seisanshoJokyakuSeisan);

		for (int i = 1; i <= sssJykSsList.size(); i++) {
			// ROWNOを設定する
			sssJykSsList.get(i - 1).setRowNo(i);
		}

		// 終了ログ
		logger.info("SeisanshoJokyakuSeisanServiceImpl.getJokyakuSeisaiInfo 終了します。");

		return sssJykSsList;
	}

	@Override
	public SeisanshoJokyakuSeisanShokai getJokyakuInfoBySeisanShoNo(
			SeisanshoJokyakuSeisanShokai seisanshoJokyakuSeisanShokai) {
		// 開始ログ
		logger.info("SeisanshoJokyakuSeisanServiceImpl.getJokyakuInfoBySeisanShoNo 開始します。");

		// 除却情報
		SeisanshoJokyakuSeisanShokai resultDto = new SeisanshoJokyakuSeisanShokai();
		// 除却固定資産情報
		SeisanshoJokyakuKoteiSisan sssJykKsDto;

		// 除却資産情報を取得する
		List<SeisanshoJokyakuSeisanShokai> sssJykSsSkList = seisanshoJokyakuSeisanMapper
				.selectBySeisanShoNo(seisanshoJokyakuSeisanShokai);

		List<SeisanshoJokyakuKoteiSisan> sssJykKsLst = new ArrayList<>();

		for (int i = 0; i < sssJykSsSkList.size(); i++) {
			// 除却資産情報
			SeisanshoJokyakuSeisanShokai sssJykSsSkDto = sssJykSsSkList.get(i);

			// Mapの情報をBeanのプロパティにセット
			try {
				BeanUtils.copyProperties(resultDto, sssJykSsSkDto);

				KoteiSisan koteiSisan = new KoteiSisan();

				koteiSisan.setKoteiCod(sssJykSsSkDto.getMotoKoteiShisanId());
				// 固定資産情報を取得する
				List<KoteiSisan> ksLstDto = sanshoMapper.selectKoteiSisan(koteiSisan);

				// 固定資産情報取得できないの場合
				if (null != ksLstDto && ksLstDto.size() > 0) {
					// 固定資産情報
					KoteiSisan ksDto = ksLstDto.get(0);

					sssJykKsDto = new SeisanshoJokyakuKoteiSisan();
					// ROWNO
					sssJykKsDto.setRowNo(i + 1);
					// 固定資産番号
					sssJykKsDto.setKoteiNo(ksDto.getKoteiNo());
					// 固定資産番号
					sssJykKsDto.setKoteiKnj(ksDto.getKoteiKnj());
					// 取得年月日
					sssJykKsDto.setGetYmd(ksDto.getGetYmd());
					// 元_数量
					sssJykKsDto.setMeiSu(ksDto.getMeiSu());
					// 単位
					sssJykKsDto.setTaniKnj(ksDto.getTaniKnj());
					// 元_取得価額
					sssJykKsDto.setGetkgkYen(ksDto.getGetkgkYen());
					// 除却区分
					sssJykKsDto.setJokyakuKbnNm(sssJykSsSkDto.getJokyakuKbnNm());

					// 除却区分
					if (NSDConstant.STRING_0.equals(ksDto.getKoshiKbn())) {
						// 0：全部除却
						sssJykKsDto.setJokyakuKbnNm(NSDConstant.JOKYAKU_KBN_0);
					} else if (NSDConstant.STRING_1.equals(ksDto.getKoshiKbn())) {
						// 1：一部除却
						sssJykKsDto.setJokyakuKbnNm(NSDConstant.JOKYAKU_KBN_1);
					} else {
						// 処理なし
					}

					// 除却種別コード
					sssJykKsDto.setJokyakuShubetsuCd(sssJykSsSkDto.getJokyakuShubetsuCd());
					// 除却種別名称
					sssJykKsDto.setJokyakuShubetsuNm(sssJykSsSkDto.getJokyakuShubetsuNm());
					// 除_数量
					sssJykKsDto.setJokyakuSuryo(ksDto.getGetkgkYen());
					// 除_取得価額
					sssJykKsDto.setJokyakuGaku(sssJykSsSkDto.getJokyakuGaku());
					// 固定資産情報を追加
					sssJykKsLst.add(sssJykKsDto);
				}

			} catch (IllegalAccessException | InvocationTargetException e) {
				// 終了ログ
				logger.info("SeisanshoJokyakuSeisanServiceImpl.getJokyakuInfoBySeisanShoNo 終了します。");
			}

		}
		// 固定資産情報リスト
		resultDto.setKoteiSisanLst(sssJykKsLst);

		// 終了ログ
		logger.info("SeisanshoJokyakuSeisanServiceImpl.getJokyakuInfoBySeisanShoNo 終了します。");

		return resultDto;
	}

}
