/***********************************************************************
*
*業務名: 工事精算システム
*機能名: 除却（登録・修正・削除）(DB処理)
*
*機能概要: 除却情報を処理する。
*
*JavaＶｅｒ：J2SE1.8.0準拠
*
*更新履歴: Ver.1.00 2018/03/06　NSD　新規作成
***********************************************************************/
package jp.co.nsd.nkssweb.dao.mapper;

import java.util.List;

import jp.co.nsd.nkssweb.dao.KoteiSisan;
import jp.co.nsd.nkssweb.dao.Kss007;
import jp.co.nsd.nkssweb.dao.Kss007Key;
import jp.co.nsd.nkssweb.dao.SeisanshoJokyaku;
import jp.co.nsd.nkssweb.dao.SeisanshoJokyakuShokai;

/**
 * 除却（登録・修正・削除）DB処理
 *
 * @version 1.00
 */
public interface SeisanshoJokyakuMapper {

    /**
     * 除却情報取得（検索画面）
     *
     * @param seisanshoJokyaku
     *            INPUTパラメータ
     * @return　検索結果
     */
    List<SeisanshoJokyaku> selectByWhere(SeisanshoJokyaku seisanshoJokyaku);

    /**
     * 除却情報取得（照会画面）
     *
     * @param seisanshoJokyakuShokai
     *            INPUTパラメータ
     * @return　検索結果
     */
    List<SeisanshoJokyakuShokai> selectBySeisanShoNo(SeisanshoJokyakuShokai seisanshoJokyakuShokai);

    /**
     * 固定資産更新（照会画面）
     *
     * @param koteiSisan
     *            INPUTパラメータ
     * @return　更新結果
     */
    int updateByPrimaryKey(KoteiSisan koteiSisan);

    /**
     * 除却情報取得（削除）
     *
     * @param key
     *            INPUTパラメータ
     * @return　検索結果
     */
    List<Kss007> selectByPyKey(Kss007Key key);

    /**
     * 除却情報取得（削除）
     *
     * @param key
     *            INPUTパラメータ
     * @return　検索結果
     */
    int deleteByPyKey(Kss007Key key);

    /**
     * 除却資産のMAXID（除却精算書ＩＤ、除却資産ＩＤ、除却精算書番号）を取得
     *
     * @return MAX（除却精算書ＩＤ）
     */
    SeisanshoJokyaku selectMaxId();

}