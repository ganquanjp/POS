package jp.co.nsd.nkssweb.service.seisanshotoroku.impl;

import java.io.BufferedWriter;
import java.io.File;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.io.FileOutputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import jp.co.nsd.nkssweb.dao.SeisanshoTorokuKmskJhe;
import jp.co.nsd.nkssweb.dao.mapper.SeisanshoTorokuKmskJheMapper;
import jp.co.nsd.nkssweb.service.seisanshotoroku.SeisanshoTorokuKmskJheService;
import jp.co.nsd.nkssweb.utils.NSDConstant;


@Service
public class SeisanshoTorokuKmskJheServiceImpl implements SeisanshoTorokuKmskJheService {

	@Autowired
	private SeisanshoTorokuKmskJheMapper sssTrkMapper;

	@Override
	public List<SeisanshoTorokuKmskJhe> getKenmeiInfo(SeisanshoTorokuKmskJhe selectCondition) {

		List<SeisanshoTorokuKmskJhe> sssTrkList = new ArrayList<SeisanshoTorokuKmskJhe>();

		sssTrkList = sssTrkMapper.selectByWhere(selectCondition);

        try {
        	Date toda = new Date();
        	String filePath = NSDConstant.STRING_FILE_PATH;
        	SimpleDateFormat fileFormat = new SimpleDateFormat(NSDConstant.STRING_YYMMDD);
        	String fileName = filePath+fileFormat.format(toda).toString()+NSDConstant.STRING_FILE_NAME;
            // 出力ファイルの作成
        	File file_w3 = new File(fileName);
        	PrintWriter p = new PrintWriter(new BufferedWriter(new OutputStreamWriter(new FileOutputStream(file_w3),NSDConstant.SHIFT_JIS)));


            // 内容をセットする
            for(int i = 0; i < sssTrkList.size(); i++){

            	SeisanshoTorokuKmskJhe sssTrkkDto = sssTrkList.get(i);

            	if (i == 0) {
            		p.print(NSDConstant.STRING_KENMEI_ID);
            		p.print(NSDConstant.STRING_KANMA);
            		p.print(NSDConstant.STRING_KENMEI_CD);
            		p.print(NSDConstant.STRING_KANMA);
            		p.print(NSDConstant.STRING_KENMEI);
            		p.print(NSDConstant.STRING_KANMA);
            		p.print(NSDConstant.STRING_TOROKU_YMD);
            		p.print(NSDConstant.STRING_KANMA);
            		p.print(NSDConstant.STRING_TOROKU_NAME);
            		p.print(NSDConstant.STRING_KANMA);
            		p.print(NSDConstant.STRING_KOSIN_YMD);
            		p.print(NSDConstant.STRING_KANMA);
            		p.print(NSDConstant.STRING_KOSIN_NAME);
            		p.print(NSDConstant.STRING_KANMA);
            		p.print(NSDConstant.STRING_RENKEI_STATUS);
            		p.println();    // 改行
            		p.print(sssTrkkDto.getKenmeiId());
            		p.print(NSDConstant.STRING_KANMA);
            		p.print(sssTrkkDto.getKenmeiCd());
            		p.print(NSDConstant.STRING_KANMA);
            		p.print(sssTrkkDto.getKenmeiNm());
            		p.print(NSDConstant.STRING_KANMA);
            		p.print(sssTrkkDto.getEntryDate());
            		p.print(NSDConstant.STRING_KANMA);
            		p.print(sssTrkkDto.getEntryUserId());
            		p.print(NSDConstant.STRING_KANMA);
            		p.print(sssTrkkDto.getUpdateDate());
            		p.print(NSDConstant.STRING_KANMA);
            		p.print(sssTrkkDto.getUpdateUserId());
            		p.print(NSDConstant.STRING_KANMA);
            		p.print(sssTrkkDto.getRenkeiStatus());
            		p.println();    // 改行

            		SeisanshoTorokuKmskJhe seisanshoTorokuKmskJhe = new SeisanshoTorokuKmskJhe();

            		seisanshoTorokuKmskJhe.setKenmeiId(sssTrkkDto.getKenmeiId());

            		seisanshoTorokuKmskJhe.setRenkeiStatus(NSDConstant.STRING_1);

            		sssTrkMapper.updateByPrimaryKey(seisanshoTorokuKmskJhe);

            	} else {
            		p.print(sssTrkkDto.getKenmeiId());
            		p.print(NSDConstant.STRING_KANMA);
            		p.print(sssTrkkDto.getKenmeiCd());
            		p.print(NSDConstant.STRING_KANMA);
            		p.print(sssTrkkDto.getKenmeiNm());
            		p.print(NSDConstant.STRING_KANMA);
            		p.print(sssTrkkDto.getEntryDate());
            		p.print(NSDConstant.STRING_KANMA);
            		p.print(sssTrkkDto.getEntryUserId());
            		p.print(NSDConstant.STRING_KANMA);
            		p.print(sssTrkkDto.getUpdateDate());
            		p.print(NSDConstant.STRING_KANMA);
            		p.print(sssTrkkDto.getUpdateUserId());
            		p.print(NSDConstant.STRING_KANMA);
            		p.print(sssTrkkDto.getRenkeiStatus());
            		p.println();    // 改行

            		SeisanshoTorokuKmskJhe seisanshoTorokuKmskJhe = new SeisanshoTorokuKmskJhe();

            		seisanshoTorokuKmskJhe.setKenmeiId(sssTrkkDto.getKenmeiId());

            		seisanshoTorokuKmskJhe.setRenkeiStatus(NSDConstant.STRING_1);

            		sssTrkMapper.updateByPrimaryKey(seisanshoTorokuKmskJhe);

            	}
            }

            // ファイルに書き出し閉じる
            p.close();
            // ファイル出力完了時にメッセージ出力
            System.out.println("ファイル出力完了！");

        } catch (IOException ex) {

            ex.printStackTrace();

        }

		return sssTrkList;

	}
}
