package jp.co.nsd.nkssweb.dao;

public class UserSubMenu {

	private String menuId;

	private String menuLinkNm;

	private String routerName;

	public String getMenuId() {
		return menuId;
	}

	public void setMenuId(String menuId) {
		this.menuId = menuId;
	}

	public String getMenuLinkNm() {
		return menuLinkNm;
	}

	public void setMenuLinkNm(String menuLinkNm) {
		this.menuLinkNm = menuLinkNm;
	}

	public String getRouterName() {
		return routerName;
	}

	public void setRouterName(String routerName) {
		this.routerName = routerName;
	}

}