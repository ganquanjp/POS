import Vue from 'vue'
import Vuex from 'vuex'

Vue.use(Vuex)

const store = new Vuex.Store({
  state: {
    currentPage: 1,
    message: {msgId: '', msgLevel: '', content: ''},
    tableData: [],
    currentPageData: [],
    sortItem: {column: '', prop: '', order: ''},
    preGamenData: {
      inputData: {},
      tableData: []
    }
  }
})

export default store
