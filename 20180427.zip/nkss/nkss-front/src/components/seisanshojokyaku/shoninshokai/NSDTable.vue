<template>
  <div>
    <div class="div-style1" v-if="formItem.shoninStatus == '20'">
      <el-row class="row-class">
        <el-col class="lab-class">　経理審査否認理由</el-col>
        <el-col style= "width: 303px;">
          <el-input v-model="formItem.riyu" size="mini" :disabled="true" />
        </el-col>
      </el-row>
    </div>
    <div class="div-style2">
      <el-row class="row-class">
        <el-col style= "width: 474px; background-color: #2053cc; color: white;">　除却資産</el-col>
      </el-row>
      <el-row class="row-class">
        <el-col class="lab-class">　精算書番号</el-col>
        <el-col style= "width: 303px;">
          <el-input v-model="formItem.jokyakuSeisanShoNo" size="mini" :disabled="true" />
        </el-col>
      </el-row>
      <el-row class="row-class">
        <el-col class="lab-class">　処理No</el-col>
        <el-col style= "width: 303px;">
          <input v-model="formItem.hansu" size="mini" class="nsd-input-class" disabled="disabled" style="cursor: default;" />
        </el-col>
      </el-row>
      <el-row class="row-class">
        <el-col class="lab-class">　除却年月日</el-col>
        <el-col style= "width: 303px;">
          <el-input v-model="formItem.jokyakuYmd" size="mini" :disabled="true" />
        </el-col>
      </el-row>
      <el-row class="row-class">
        <el-col class="lab-class">　除却取得価額合計</el-col>
          <el-col class="input-group" style= "width: 303px">
            <vue-numeric currency="\" separator="," v-model="formItem.jokyakuKagakuGokei" size="mini" class="nsd-input-class" disabled="disabled" style="cursor: default;"></vue-numeric>
          </el-col>
      </el-row>
      <el-row class="row-class">
        <el-col class="lab-class">　承認状態</el-col>
        <el-col style= "width: 303px;">
          <el-input v-model="formItem.shoninJotai" size="mini" :disabled="true" />
        </el-col>
      </el-row>
      <el-row class="row-class">
        <el-col class="lab-class">　工事件名</el-col>
        <el-col style= "width: 303px;">
          <el-input v-model="formItem.kenmeiNm" size="mini" :disabled="true" />
        </el-col>
      </el-row>
    </div>
    <div style="height: 25px;">
      <div style="position: absolute; top: 225px; left: 10px;">
        <span style="font-size: 12px;">{{this.$store.state.tableData.koteiSisanLst.length}}件</span>
      </div>
      <div style="position: absolute; top: 215px; right: 0px;">
        <el-pagination
          background
          @size-change="handleSizeChange"
          @current-change="handleCurrentChange"
          :current-page.sync="pageData.currentPage"
          :page-sizes="pageData.pageSizeArr"
          :page-size="pageData.pageSizeAct"
          layout="prev, pager, next"
          prev-text="前へ"
          next-text="次へ"
          :total="this.$store.state.tableData.koteiSisanLst.length">
        </el-pagination>
      </div>
    </div>
    <div style="margin-left: 10px;">
      <el-table
        :data="this.$store.state.currentPageData"
        border
        max-height= 287>
        <el-table-column
          prop="rowNo"
          label="NO."
          min-width="70px">
        </el-table-column>
        <el-table-column
          prop="koteiNo"
          label="固定資産番号"
          min-width="120px">
        </el-table-column>
        <el-table-column
          prop="koteiKnj"
          label="固定資産名称"
          min-width="250px">
        </el-table-column>
        <el-table-column
          prop="getYmd"
          label="取得年月日"
          min-width="120px">
        </el-table-column>
        <el-table-column
          prop="useYmd"
          label="使用開始年月日"
          min-width="120px">
        </el-table-column>
        <el-table-column
          prop="jokyakuGaku"
          label="除却取得原価"
          header-align=left
          align=right
          :formatter="commaFormatter"
          min-width="120px">
        </el-table-column >
      </el-table>
    </div>
    <div>
      <nsd-button-bar v-bind:buttons="buttonName" v-bind:formItem="formItem"></nsd-button-bar>
    </div>
  </div>
</template>
<script scoped>
import NSDButtonBar from '@/components/common/NSDButtonBar.vue'

export default {
  components: {
    'nsd-button-bar': NSDButtonBar
  },
  created: function () {
    this.formItem = this.$store.state.tableData
    if (this.formItem.shoninJotai === 'データ連係済') {
      this.buttonName[1].disabled = true
    } else {
      this.buttonName[1].disabled = false
    }
    this.getPageData()
  },
  methods: {
    handleSizeChange (index) {
      this.pageData.pageSizeAct = index
      this.initTableList(1)
    },
    handleCurrentChange (index) {
      this.initTableList(index)
    },
    initTableList (index) {
      this._initPageData(index)
      this.getPageData()
    },
    _initPageData (index) {
      this.pageData.pageNum = (index - 1) * this.pageData.pageSizeAct
      this.pageData.currentPage = index
    },
    getPageData () {
      this.$store.state.currentPageData = this.$store.state.tableData.koteiSisanLst.slice(this.pageData.pageSizeAct * (this.pageData.currentPage - 1), this.pageData.pageSizeAct * this.pageData.currentPage)
    }
  },
  data () {
    return {
      buttonName: [
        {name: this.$CONST_.buttonName.PRINT, primary: true, show: true, action: 'popup', url: '', backUrl: '', msg: '印刷しますか？'},
        {name: this.$CONST_.buttonName.UPDATE, primary: true, show: true, action: 'back', url: '', backUrl: 'nsdnsssjkkshoninkosin', msg: ''},
        {name: this.$CONST_.buttonName.BACK, primary: true, show: true, action: 'back', url: '', backUrl: 'nsdnsssjkkshoninkensku', msg: ''}
      ],
      formItem: '',
      pageData: {
        total: 0,
        pageNum: 0,
        pageSizeArr: this.$CONST_.tableConst.PAGE_SIZES,
        pageSizeAct: this.$CONST_.tableConst.PAGE_SIZE,
        currentPage: 1,
        visible: false
      }
    }
  }
}
</script>
<style scoped>
.row-class {
  height: 30px;
  margin-bottom: 1px;
  margin-left: 1px;
  margin-right: 1px;
}
.lab-class {
  width: 170px;
  background-color: #77cad8;
  line-height: 30px;
  margin-right: 1px;
}
.div-style1 {
  font-size: 12px;
  width: 476px;
  height: 100%;
  margin-bottom: 10px;
  margin-left: 10px;
  line-height:30px;
  border: 1px solid;
  padding-top: 1px;
}
.div-style2 {
  font-size: 12px;
  width: 476px;
  height: 100%;
  margin-left: 10px;
  line-height:30px;
  border: 1px solid;
  padding-top: 1px;
}
</style>
