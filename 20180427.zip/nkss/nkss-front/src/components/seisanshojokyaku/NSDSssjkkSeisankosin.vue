<template>
  <div>
    <el-row>
      <el-col>
        <nsd-content-title v-bind:titlename="titlename" v-bind:message="this.$store.state.message"></nsd-content-title>
      </el-col>
    </el-row>
    <el-row>
      <el-col>
        <nsd-table-bar></nsd-table-bar>
      </el-col>
    </el-row>
  </div>
</template>

<script>
import NsdContentTitle from '@/components/common/NSDContentTitle.vue'
import NSDTable from '@/components/seisanshojokyaku/seisankosin/NSDTable.vue'

export default {
  components: {
    'nsd-content-title': NsdContentTitle,
    'nsd-table-bar': NSDTable

  },
  data () {
    return {
      titlename: '【除却精算通告】更新'
    }
  }
}
</script>

<style scoped>
</style>
