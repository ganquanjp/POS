<template>
  <div style= "padding-left: 10px; padding-right: 10px; width: 1100px;">
    <div style="position: relative;">
     <span style="font-size: 12px;">{{this.$store.state.tableData.length}}件</span>
      <div style="position: absolute; top: -10px; right: 0px;">
        <el-pagination
          background
          @size-change="handleSizeChange"
          @current-change="handleCurrentChange"
          :current-page.sync="$store.state.currentPage"
          :page-sizes="pageData.pageSizeArr"
          :page-size="pageData.pageSizeAct"
          layout="prev, pager, next"
          prev-text="前へ"
          next-text="次へ"
          :total="this.$store.state.tableData.length">
        </el-pagination>
      </div>
    </div>
    <el-table
      :data="this.$store.state.currentPageData"
      border
      max-height=350
      :span-method="objectSpanMethod"
      :header-cell-class-name="sortCallClass"
      @sort-change="handleSortChange">
      <el-table-column
        prop="rowNo"
        label="NO."
        min-width="70px">
      </el-table-column>
      <el-table-column
        sortable="custom"
        prop="jokyakuSeisanShoNo"
        label="精算書番号"
        min-width="180px">
      </el-table-column>
      <el-table-column
        prop="soshikiRenNm"
        label="精算箇所"
        min-width="200px">
      </el-table-column>
      <el-table-column
        sortable="custom"
        prop="hansu"
        label="処理No"
        header-align=left
        min-width="80px"
        align= right>
      </el-table-column>
      <el-table-column
        sortable="custom"
        prop="jokyakuYmd"
        label="除却年月日"
        min-width="120px">
      </el-table-column>
      <el-table-column
        sortable="custom"
        prop="jokyakuKagakuGokei"
        label="除却取得価額合計"
        min-width="150px"
        header-align=left
        align= right
        :formatter="commaFormatter">
      </el-table-column>
      <el-table-column
        prop="shoninJotai"
        label="承認状態"
        min-width="100px">
      </el-table-column>
      <el-table-column
        prop="kenmeiNm"
        label="工事件名"
        min-width="150px">
      </el-table-column>
    </el-table>
  </div>
</template>
<script scoped>
  export default {
    created: function () {
      if (this.$store.state.tableData.length > 0) {
        this.getPageData()
      }
    },
    data () {
      return {
        tableData: [],
        pageData: {
          total: 0,
          pageNum: 0,
          pageSizeArr: this.$CONST_.tableConst.PAGE_SIZES,
          pageSizeAct: this.$CONST_.tableConst.PAGE_SIZE,
          visible: false
        }
      }
    },
    methods: {
      handleSizeChange (index) {
        this.pageData.pageSizeAct = index
        this.initTableList(1)
      },
      handleCurrentChange (index) {
        this.initTableList(index)
      },
      initTableList (index) {
        this._initPageData(index)
        this.getPageData()
      },
      _initPageData (index) {
        this.pageData.pageNum = (index - 1) * this.pageData.pageSizeAct
        this.$store.state.currentPage = index
      },
      getPageData () {
        this.$store.state.currentPageData = this.$store.state.tableData.slice(this.pageData.pageSizeAct * (this.$store.state.currentPage - 1), this.pageData.pageSizeAct * this.$store.state.currentPage)
      },
      sortCallClass ({row, column, rowIndex, columnIndex}) {
        if (column['property'] === this.$store.state.sortItem.prop) {
          return this.$store.state.sortItem.order
        }
      },
      // ヘッダーにてソートボタンを押すとソート変更する
      handleSortChange ({ column, prop, order }) {
        this.funcSortChange(column, prop, order, this.$store)
        // ページデータ再設定
        this.getPageData()
      },
      objectSpanMethod ({row, column, rowIndex, columnIndex}) {
        var pageCounts = Math.ceil(this.$store.state.tableData.length / this.pageData.pageSizeAct)
        var max = this.pageData.pageSizeAct * this.$store.state.currentPage
        if (this.$store.state.currentPage === pageCounts) {
          max = this.$store.state.tableData.length
        }
        var k = this.pageData.pageSizeAct * (this.$store.state.currentPage - 1)
        // 指定列の結合セル数を設定する
        if (rowIndex === 0 && columnIndex === 2) {
          while (k < max) {
            this.$store.state.tableData[k].rowspan1 = 1
            for (var i = k + 1; i < max; i++) {
              if (this.$store.state.tableData[k].soshikiRenNm === this.$store.state.tableData[i].soshikiRenNm && this.$store.state.tableData[k].soshikiRenNm !== null && this.$store.state.tableData[k].soshikiRenNm !== '') {
                this.$store.state.tableData[k].rowspan1++
                this.$store.state.tableData[i].rowspan1 = 0
              } else {
                break
              }
            }
            k = i
          }
        // 指定列の結合セル数を設定する
        } else if (rowIndex === 0 && columnIndex === 4) {
          var max2 = 1
          while (k < max) {
            this.$store.state.tableData[k].rowspan2 = 1
            // 前の列が結合したの場合、次列を結合する
            if (this.$store.state.tableData[k].rowspan1 !== 1) {
              if (this.$store.state.tableData[k].rowspan1 > 1) {
                max2 = k + this.$store.state.tableData[k].rowspan1
              }
              for (var m = k + 1; m < max2; m++) {
                if (this.$store.state.tableData[k].jokyakuYmd === this.$store.state.tableData[m].jokyakuYmd && this.$store.state.tableData[k].jokyakuYmd !== null && this.$store.state.tableData[k].jokyakuYmd !== '') {
                  this.$store.state.tableData[k].rowspan2++
                  this.$store.state.tableData[m].rowspan2 = 0
                } else {
                  break
                }
              }
              k = m
            } else {
              k++
            }
          }
        }
        // セル結合
        if (columnIndex === 2) {
          if (row.rowspan1 > 1) {
            return {
              rowspan: row.rowspan1,
              colspan: 1
            }
          } else if (row.rowspan1 === 0) {
            return {
              rowspan: 0,
              colspan: 0
            }
          } else {
            return {
              rowspan: 1,
              colspan: 1
            }
          }
        } else if (columnIndex === 4) {
          if (row.rowspan2 > 1) {
            return {
              rowspan: row.rowspan2,
              colspan: 1
            }
          } else if (row.rowspan2 === 0) {
            return {
              rowspan: 0,
              colspan: 0
            }
          } else {
            return {
              rowspan: 1,
              colspan: 1
            }
          }
        }
      }
    }
  }
</script>
<style scoped>
</style>
