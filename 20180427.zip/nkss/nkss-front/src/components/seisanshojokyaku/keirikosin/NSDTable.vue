<template>
  <div>
    <div class="page-style">
      <el-row class="row-class">
        <el-col class="lab-class">　会計整理年月<span class="span-class">（必須）</span></el-col>
        <el-col style= "width: 130px;">
          <el-select v-model="formItem.kaikeiSeiriYm" size="mini" >
            <el-option
              v-for="item in this.kaikeiSeiriYmList"
              :key="item.sa1KaikeiYm"
              :label="item.sa1KaikeiYm"
              :value="item.sa1KaikeiYm">
           </el-option>
         </el-select>
        </el-col>
      </el-row>
      <el-row class="row-class">
        <el-col class="lab-class">　パワー経理の発行組織<span class="span-class">（必須）</span></el-col>
        <el-col style= "width: 200px;">
          <el-autocomplete
            style= "width: 200px;"
            v-model="formItem.hakouSoshikiNm" 
            :fetch-suggestions="querySearchAsynchakouSoshikiNm"
            @select="handleSelecthakouSoshikiNm"
            id="search_text" 
            size="mini" 
            >
          </el-autocomplete>
        </el-col>
      </el-row>
    </div>
    <div style="height: 25px;">
      <div style="position: absolute; top: 70px; left: 10px;">
        <span style="font-size: 12px;">{{this.formItem.sisanInfoLst.length}}件</span>
      </div>
      <div style="position: absolute; top: 60px; right: 0px;">
        <el-pagination
          background
          @size-change="handleSizeChange"
          @current-change="handleCurrentChange"
          :current-page.sync="pageData.currentPage"
          :page-sizes="pageData.pageSizeArr"
          :page-size="pageData.pageSizeAct"
          layout="prev, pager, next"
          prev-text="前へ"
          next-text="次へ"
          :total="this.formItem.sisanInfoLst.length">
        </el-pagination>
      </div>
    </div>
    <div style="margin-left: 10px;">
      <el-table
        :data="this.formItem.sisanInfoLst"
        max-height=350
        border>
        <el-table-column 
          prop="rowNo"
          label="NO."
          min-width="40px">
        </el-table-column>
        <el-table-column
          width="55px"
          header-align=center
          :render-header="renderChkHeader">
           <template slot-scope="scope">
             <el-checkbox v-model="scope.row.upd" style="top: 3px; left: 15px;" size="mini" />
           </template>
        </el-table-column>
        <el-table-column
          prop="jokyakuSeisanShoNo"
          label="精算書番号"
          min-width="140px">
        </el-table-column>
        <el-table-column
          prop="soshikiRenNm"
          label="精算箇所"
          min-width="200px">
        </el-table-column>
        <el-table-column
          prop="hansu"
          label="処理No"
          min-width="70px"
          header-align=left
          align=right>
        </el-table-column>
        <el-table-column
          prop="jokyakuKagakuGokei"
          label="取得除却価額合計"
          min-width="100px"
          header-align=left
          align=right
          :formatter="commaFormatter">
        </el-table-column>
        <el-table-column
          :render-header="renderHeader"
          min-width="150px">
            <template slot-scope="scope">
              <el-select v-model="scope.row.shoninStatus" size="mini" style="min-width: 142px;">
                <el-option
                  v-for="item in shoninStatusList"
                  :key="item.cd1"
                  :label="item.cdKnj"
                  :value="item.cd1">
                </el-option>
              </el-select>
            </template>
        </el-table-column >
        <el-table-column
          label="経理否認理由"
          min-width="150px">
            <template slot-scope="scope">
              <el-input v-model="scope.row.riyu" size="mini"></el-input>
            </template>
        </el-table-column>
        <el-table-column
          prop="kenmeiNm"
          label="工事件名"
          min-width="90px">
        </el-table-column>
      </el-table>
    </div>
    <el-row>
      <el-col>
        <nsd-button-bar v-bind:buttons="buttonName" v-bind:formItem="formItem" @resetInit="resetInit"></nsd-button-bar>
      </el-col>
    </el-row>
  </div>
</template>
<script scoped>
import NSDButtonBar from '@/components/common/NSDButtonBar.vue'

export default {
  components: {
    'nsd-button-bar': NSDButtonBar
  },
  created () {
    this.loadShoninStatus()
    this.resetInitData = JSON.parse(JSON.stringify(this.$store.state.tableData))
    this.formItem.sisanInfoLst = JSON.parse(JSON.stringify(this.$store.state.tableData))
    this.initShow()
  },
  mounted () {
    this.hakouSoshikiNm = this.loadHakouSoshikiNM()
  },
  methods: {
    initShow () {
      this.funcHttpPostComm('/comm-getHakouSoshiki', {soshikCod: '1000'}, this.initHakouSoshikiCallBack)
      this.funcHttpPostComm('/autocomplete-selectKaikeiYmMaster', '', this.initKaikeiYmCallBack)
    },
    initHakouSoshikiCallBack (val) {
      if (val.length > 0) {
        this.formItem.hakouSoshikiNm = val[0].ab9SoshikKnj
        this.formItem.hakouSoshikiCd = val[0].ab9SoshikCod
        this.formItem.TekiyfYmd = val[0].ab9TekiyfYmd
        this.formItem.TekiytYmd = val[0].ab9TekiytYmd
      }
    },
    initKaikeiYmCallBack (val) {
      this.kaikeiSeiriYmList = val
      if (val.length > 0) {
        this.formItem.kaikeiSeiriYm = val[0].sa1KaikeiYm
      }
    },
    resetInit () {
      this.formItem.sisanInfoLst = this.resetInitData
      this.initShow()
      this.updChkAll = false
    },
    handleSizeChange (index) {
      this.pageData.pageSizeAct = index
      this.initTableList(1)
    },
    handleCurrentChange (index) {
      this.initTableList(index)
    },
    initTableList (index) {
      this._initPageData(index)
      this.getPageData()
    },
    _initPageData (index) {
      this.pageData.pageNum = (index - 1) * this.pageData.pageSizeAct
      this.pageData.currentPage = index
    },
    getPageData () {
      this.$store.state.currentPageData = this.formItem.sisanInfoLst.slice(this.pageData.pageSizeAct * (this.pageData.currentPage - 1), this.pageData.pageSizeAct * this.pageData.currentPage)
    },
    renderHeader (createElement, { column }) {
      return createElement(
        'span',
        [
          '承認状態',
          createElement('span', {style: 'color: red; right: 0px;'}, '(必須)')
        ]
      )
    },
    renderChkHeader (createElement, { column }) {
      return createElement(
        'el-checkbox', {on: { change: this.updHandleHeader }, attrs: {value: this.updChkAll}}, [createElement('span', {style: 'font-size: 11px; color: black; font-weight: bold;'}, '更新')]
      )
    },
    loadShoninStatus () {
      var searchWhere = {
        cdShubetsu: this.$CONST_.cdShubetsu.SHONIN_STATUS,
        cd1Arr: [
          this.$CONST_.shoninStatus.SHONIN,
          this.$CONST_.shoninStatus.RENKEI,
          this.$CONST_.shoninStatus.HININ
        ]
      }
      this.funcHttpPostComm('/comm-getCodeShubetsuList', searchWhere, this.loadShoninStatusCallBack)
    },
    loadShoninStatusCallBack (val) {
      this.shoninStatusList = val
    },
    loadHakouSoshikiNM () {
      var items = ['ab9SoshikKnj', 'ab9SoshikCod', 'ab9TekiyfYmd', 'ab9TekiytYmd']
      return this.funcGetDropDownValue('/autocomplete-selectSoshikTeisuMaster', items)
    },
    handleSelecthakouSoshikiNm (item) {
      this.formItem.hakouSoshikiNm = item.value
      this.formItem.hakouSoshikiCd = item.ab9SoshikCod
      this.formItem.TekiyfYmd = item.ab9TekiyfYmd
      this.formItem.TekiytYmd = item.ab9TekiytYmd
    },
    querySearchAsynchakouSoshikiNm (queryString, cb) {
      var hakouSoshikiNm = this.hakouSoshikiNm
      var results = queryString ? hakouSoshikiNm.filter(this.createStateFilter(queryString)) : hakouSoshikiNm
      clearTimeout(this.timeout)
      this.timeout = setTimeout(() => {
        cb(results.slice(0, 10))
      }, 200 * Math.random())
    },
    createStateFilter (queryString) {
      return (state) => {
        return (state.value.toLowerCase().indexOf(queryString.toLowerCase()) >= 0)
      }
    },
    updHandleHeader (checked) {
      this.updChkAll = checked
      var itemLst = JSON.parse(JSON.stringify(this.formItem.sisanInfoLst))
      this.formItem.sisanInfoLst = []
      for (var i = 0; i < itemLst.length; i++) {
        if (checked) {
          itemLst[i].upd = true
        } else {
          itemLst[i].upd = false
        }
      }
      this.formItem.sisanInfoLst = itemLst
    }
  },
  data () {
    return {
      buttonName: [
        {name: this.$CONST_.buttonName.UPDATE, primary: true, show: true, action: 'popup', url: '/seisanshoJokyakuKeiri-updateInfo', backUrl: 'nsdsssjkkkeirikensaku', msg: '更新しますか？'},
        {name: this.$CONST_.buttonName.RESET, primary: true, show: true, action: 'resetInit', url: '', msg: 'リセットしますか？'},
        {name: this.$CONST_.buttonName.BACK, primary: true, show: true, action: 'back', url: '', backUrl: 'nsdsssjkkkeirikensaku', msg: ''}
      ],
      shoninStatusList: [],
      kaikeiSeiriYmList: [],
      updChkAll: false,
      formItem: {
        hakouSoshikiNm: '',
        sisanInfoLst: [{upd: false}]
      },
      resetInitData: {},
      pageData: {
        total: 0,
        pageNum: 0,
        pageSizeArr: this.$CONST_.tableConst.PAGE_SIZES,
        pageSizeAct: this.$CONST_.tableConst.PAGE_SIZE,
        currentPage: 1
      }
    }
  }
}
</script>
<style scoped>
.page-style {
  font-size: 12px;
  width: 373px;
  height: 100%;
  line-height:30px;
  border: 1px solid;
  padding-top: 1px;
  margin-left: 10px;
}
.row-class {
  height: 30px;
  margin-bottom: 1px;
  margin-left: 1px;
  margin-right: 1px;
}
.lab-class {
  width: 170px;
  background-color: #77cad8;
  line-height: 30px;
  margin-right: 1px;
}
.span-class {
 color: red;
 float: right;
}
</style>
