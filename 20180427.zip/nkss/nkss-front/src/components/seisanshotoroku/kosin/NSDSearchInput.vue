<template>
  <div class="page-style">
    <el-row class="row-class">
      <el-col class= "lab-class">　精算書番号</el-col>
      <el-col style= "width: 345px;">
        <el-input v-model="formItem.seisanshoNo" size="mini" :disabled="true"></el-input>
      </el-col>
    </el-row>
    <el-row class="row-class">
      <el-col class= "lab-class">　精算箇所<span class="span-class">（必須）</span></el-col>
      <el-col style= "width: 600px;">
        <el-autocomplete 
          v-model="formItem.seisanSoshikiNm" 
          :fetch-suggestions="querySearchAsync1"
          @select="handleSelect1"
          id="search_text" 
          size="mini" 
          >
        </el-autocomplete>
      </el-col>
    </el-row>
    <el-row class="row-class">
      <el-col class= "lab-class">　使用開始年月日<span class="span-class">（必須）</span></el-col>
      <el-col style= "width: 145px;">
        <el-tooltip effect="light" placement="right-start">
          <div slot="content">K工事（一括個別収入）＝お客様検収日<br/>
                              T工事・K工事（標準）＝工事竣工日<br/>
                              K工事（リース）＝契約開始日</div>
          <el-date-picker
            v-model="formItem.siyoStartYmd"
            size="mini"
            style= "width: 140px;"
            type="date">
          </el-date-picker>
        </el-tooltip>
      </el-col>
    </el-row>
    <el-row class="row-class">
      <el-col class= "lab-class">　登録者氏名<span class="span-class">（必須）</span></el-col>
      <el-col style= "width: 345px;">
        <el-input v-model="formItem.seisanEntryUserId" size="mini"></el-input>
      </el-col>
    </el-row>
    <el-row class="row-class">
      <el-col class= "lab-class">　摘要</el-col>
      <el-col style= "width: 345px;">
        <el-input maxlength="30" v-model="formItem.tekiyo" size="mini"></el-input>
      </el-col>
    </el-row>
    <el-row class="row-class">
      <el-col class= "lab-class">　予約数</el-col>
      <el-col style= "width: 145px; ">
        <input v-model="formItem.yoyakusu" class="nsd-input-class" :disabled="true"></input>
      </el-col>
    </el-row>
    <el-row class="row-class">
      <el-col class= "lab-class">　追加予約数</el-col>
      <el-col style= "width: 145px; ">
        <input maxlength="3" v-model="formItem.tsuikaYoyakusu" class="nsd-input-class"></input>
      </el-col>
    </el-row>
    <el-row class="row-class">
      <el-col class= "lab-class">　工事件名コード<span class="span-class">（必須）</span></el-col>
      <el-col style= "width: 345px;">
        <el-tooltip effect="light" placement="right-start">
          <div slot="content">決裁書起案番号または需要箇所契約番号</div>
          <el-autocomplete 
            v-model="formItem.kenmeiCd" 
            :fetch-suggestions="querySearchAsync2"
            @select="handleSelect2"
            id="search_text" 
            size="mini" 
            >
          </el-autocomplete>
        </el-tooltip>
      </el-col>
    </el-row>
    <el-row class="row-class">
      <el-col class= "lab-class">　工事件名名称<span class="span-class">（必須）</span></el-col>
      <el-col style= "width: 300px;">
        <el-autocomplete 
          v-model="formItem.kenmeiNm" 
          :fetch-suggestions="querySearchAsync3"
          @select="handleSelect3"
          id="search_text" 
          size="mini" 
          style= "width: 300px;"
          >
        </el-autocomplete>
      </el-col>
    </el-row>
    <el-row class="row-class">
      <el-col class= "lab-class">　適用開始日<span class="span-class">（必須）</span></el-col>
      <el-col style= "width: 145px;">
        <el-date-picker
          v-model="formItem.tekiyoStartYmd"
          size="mini"
          style= "width: 140px;"
          type="date">
        </el-date-picker>
      </el-col>
    </el-row>
    <el-row class="row-class">
      <el-col class= "lab-class">　適用終了日<span class="span-class">（必須）</span></el-col>
      <el-col style= "width: 145px;">
        <el-date-picker
          v-model="formItem.tekiyoEndYmd"
          size="mini"
          style= "width: 140px;"
          type="date">
        </el-date-picker>
      </el-col>
    </el-row>
  </div>
</template>

<script>
export default {
  data () {
    return {
      formItem: {
        seisanshoNo: '',
        seisanSoshikiNm: '',
        siyoStartYmd: '',
        seisanEntryUserId: '',
        tekiyo: '',
        yoyakusu: '',
        tsuikaYoyakusu: '',
        kenmeiCd: '',
        kenmeiNm: '',
        tekiyoStartYmd: '',
        tekiyoEndYmd: ''
      }
    }
  },
  methods: {
    loadSeisanKasho () {
      var items = ['soshikiCd', 'soshikiNm']
      return this.funcGetDropDownValue('/autocomplete-selectSoshikiMaster', items)
    },
    loadKojiCD () {
      var items = ['kenmeiCd', 'kenmeiNm', 'tekiyoStartYmd', 'tekiyoEndYmd']
      return this.funcGetDropDownValue('/autocomplete-selectKenmeiMaster', items)
    },
    loadKojiNM () {
      var items = ['kenmeiNm', 'kenmeiCd', 'tekiyoStartYmd', 'tekiyoEndYmd']
      return this.funcGetDropDownValue('/autocomplete-selectKenmeiMaster', items)
    },
    querySearchAsync1 (queryString, cb) {
      var seisanKasho = this.seisanKasho
      var results = queryString ? seisanKasho.filter(this.createStateFilter(queryString)) : seisanKasho
      clearTimeout(this.timeout)
      this.timeout = setTimeout(() => {
        cb(results)
      }, 200 * Math.random())
    },
    querySearchAsync2 (queryString, cb) {
      var kojiCode = this.kojiCode
      var results = queryString ? kojiCode.filter(this.createStateFilter(queryString)) : kojiCode
      clearTimeout(this.timeout)
      this.timeout = setTimeout(() => {
        cb(results)
      }, 200 * Math.random())
    },
    querySearchAsync3 (queryString, cb) {
      var kojiName = this.kojiName
      var results = queryString ? kojiName.filter(this.createStateFilter(queryString)) : kojiName
      clearTimeout(this.timeout)
      this.timeout = setTimeout(() => {
        cb(results)
      }, 200 * Math.random())
    },
    createStateFilter (queryString) {
      return (state) => {
        return (state.value.toLowerCase().indexOf(queryString.toLowerCase()) === 0)
      }
    },
    handleSelect1 (item) {
      console.log(item)
      this.formItem.seisanSoshikiCd = item.seisanSoshikiCd
    },
    handleSelect2 (item) {
      console.log(item)
      this.formItem.kenmeiCd = item.value
      this.formItem.kenmeiNm = item.kenmeiNm
      this.formItem.tekiyoStartYmd = item.tekiyoStartYmd
      this.formItem.tekiyoEndYmd = item.tekiyoEndYmd
    },
    handleSelect3 (item) {
      console.log(item)
      this.formItem.kenmeiNm = item.value
      this.formItem.kenmeiCd = item.kenmeiCd
      this.formItem.tekiyoStartYmd = item.tekiyoStartYmd
      this.formItem.tekiyoEndYmd = item.tekiyoEndYmd
    }
  },
  mounted () {
    this.seisanKasho = this.loadSeisanKasho()
    this.kojiCode = this.loadKojiCD()
    this.kojiName = this.loadKojiNM()
  }
}
</script>

<style scoped>
.page-style {
  font-size: 12px;
  width: 775px;
  height: 100%;
  margin-left:10px;
  border: 1px solid;
  padding-top: 1px;
  padding-right: 1px;
}
.row-class {
  height: 30px;
  margin-bottom: 1px;
  margin-left: 1px;
  margin-right: 1px;
}
.lab-class {
  width: 170px;
  background-color: #77cad8;
  line-height: 30px;
  margin-right: 1px;
}
.checkbox-class {
  width: 300px;
  line-height: 30px;
  margin-left: 5px;
}
.span-class {
 color: red;
 float: right;
}
</style>
