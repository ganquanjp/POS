<template>
  <div class='page-style'>
    <nsd-content-title
       class='nsd-test-style'
       titlename='データ通信サンプル'
       message='メッセージ欄'>
    </nsd-content-title>
    <span>{{ user.userId }} {{ user.userName }} {{ user.startDate }} {{ user.expiredDate }}</span>
    <el-button size="mini" @click="btnClick" >
      プロシージャ呼出す
    </el-button>
  </div>
</template>

<script>
import NsdContentTitle from '@/components/common/NSDContentTitle.vue'
var user = {}
export default {
  components: {
    'nsd-content-title': NsdContentTitle
  },
  created: function () {
    this.doAction()
  },
  data () {
    return {
      user
    }
  },
  methods: {
    doAction: function () {
      this.$http.get('/nkss-web/sample-selectOne?userId=0003')
        .then(function (response) {
          user = response.data
        })
        .catch(function (error) {
          console.log(error)
        })
    },
    btnClick: function () {
      this.$http.get('/nkss-web/sample-callTestFunction?userId=0007')
        .then(function (response) {
          user = response.data
        })
        .catch(function (error) {
          console.log(error)
        })
    }
  }
}
</script>

<style scoped>
.page-style {
  
}
</style>
