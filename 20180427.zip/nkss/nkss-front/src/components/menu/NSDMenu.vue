<template>
  <div class="page-style">
    <el-row>
      <el-col>
        <nsd-content-title v-bind:titlename="titlename" v-bind:message="this.$store.state.message"></nsd-content-title>
      </el-col>
    </el-row>
  </div>
</template>

<script>
import NsdContentTitle from '@/components/common/NSDContentTitle.vue'

export default {
  components: {
    'nsd-content-title': NsdContentTitle
  },
  data () {
    return {
      titlename: 'メニュー'
    }
  }
}
</script>

<style scoped>
.page-style {
  width: 100%;
}
</style>
