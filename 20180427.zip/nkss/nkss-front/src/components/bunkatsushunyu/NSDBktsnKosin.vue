<template>
  <div>
    <el-row>
      <el-col>
        <nsd-content-title v-bind:titlename="titlename" v-bind:message="this.$store.state.message"></nsd-content-title>
      </el-col>
    </el-row>
    <el-row>
      <el-col>
        <div style= "padding-left: 10px; padding-top: 10px;">
          <div style="position: relative;">
            <span style="font-size: 12px;">{{ seisanShoInfo.length }}件</span>
            <div style="position: absolute; top: -3px; right: 0px;">
              <el-pagination
                background
                @size-change="handleSizeChange"
                @current-change="handlerCurrentChange"
                :current-page.sync="currentPage1"
                :page-size="50"
                small
                layout="prev, pager, next"
                prev-text="前へ"
                next-text="次へ"
                :total="150">
              </el-pagination>
            </div>
          </div>
          <el-table
            :data="seisanShoInfo"
            height=111
            @select-all="handlerSelectAll"
            border>
            <el-table-column prop="rowNo" label="No." min-width="48px"></el-table-column>
            <el-table-column type="selection" min-width="30px" align=center></el-table-column>
            <el-table-column prop="seisanShoNo" label="精算書番号" min-width="120px">
              <template slot-scope="scope">
                <el-button type="text" @click="showKoteiShisanInfo(scope.row)">{{scope.row.seisanShoNo}}</el-button>
              </template>
            </el-table-column>
            <el-table-column prop="soshikiRenNm" label="精算箇所" min-width="200px"></el-table-column>
            <el-table-column prop="shoriNo" label="処理No" min-width="80px"></el-table-column>
            <el-table-column prop="serviceKaisiYmd" label="サービス開始年月日" width="140px">
              <template slot-scope="scope">
                <el-date-picker v-model="scope.row.serviceKaisiYmd" type="date" style="width: 100%;" size="mini">
                </el-date-picker>
              </template>
            </el-table-column>
            <el-table-column prop="keiyakuBeginDate" label="契約期間(自)" min-width="140px">
              <template slot-scope="scope">
                <el-date-picker v-model="scope.row.keiyakuBeginDate" type="date" style="width: 100%;" size="mini">
                </el-date-picker>
              </template>
            </el-table-column>
            <el-table-column prop="keiyakuEndDate" label="契約期間(至)" min-width="140px">
              <template slot-scope="scope">
                <el-date-picker v-model="scope.row.keiyakuEndDate" type="date" style="width: 100%;" size="mini">
                </el-date-picker>
              </template>
            </el-table-column>
            <el-table-column :render-header="renderShoninStatus" min-width="100px">
              <template slot-scope="scope">
                <el-select v-model="scope.row.shoninStatusCd" size="mini" style="width: 100%;">
                  <el-option v-for="item in shoninStatusList" :key="item.cd1" :label="item.cdKnj" :value="item.cd1">
                  </el-option>
                </el-select>
              </template>
            </el-table-column >
            <el-table-column label="経理否認理由" min-width="100px">
              <template slot-scope="scope">
                <el-input v-model="scope.row.riyu" size="mini" style="width: 100%;"></el-input>
              </template>
            </el-table-column>
            <el-table-column prop="kenmeiCd" label="工事件名コード" min-width="100px"></el-table-column>
            <el-table-column prop="kenmeiNm" label="工事件名" min-width="150px"></el-table-column>
          </el-table>
        </div>
      </el-col>
    </el-row>
    <el-row>
      <el-row>
        <el-col>
          <div style= "padding-left: 10px; padding-top: 10px;">
            <div style="position: relative;">
              <span style="font-size: 12px;">{{ koteiShisanInfo.length }}件</span>
              <div style="position: absolute; top: -3px; right: 0px;">
                <el-pagination
                  background
                  @size-change="handleSizeChange"
                  @current-change="handlerCurrentChange"
                  :current-page.sync="currentPage1"
                  :page-size="50"
                  small
                  layout="prev, pager, next"
                  prev-text="前へ"
                  next-text="次へ"
                  :total="150">
                </el-pagination>
              </div>
            </div>
            <el-table
              :data="koteiShisanInfo"
              height=158
              @select-all="handlerShisanSelectAll"
              border>
              <el-table-column prop="rowNo" label="No." min-width="48px"></el-table-column>
              <el-table-column prop="koteiShisanNo" label="固定資産番号" min-width="140px"></el-table-column>
              <el-table-column prop="koteiShisanNm" label="固定資産名称" min-width="200px"></el-table-column>
              <el-table-column prop="torihikiSakiNm" label="取引先名称" min-width="200px"></el-table-column>
              <el-table-column prop="getYmd" label="取得年月日" min-width="140px"></el-table-column>
              <el-table-column prop="getGaku" label="取得価額" min-width="110px"></el-table-column>
            </el-table>
          </div>
        </el-col>
      </el-row>
      <el-row>
        <div class="kotei-detail-style">
          <el-col :span="8">
            <el-row class="row-class">
              <el-col class="lab-class">　種類</el-col>
              <el-col style= "width: 200px">
                <el-input v-model="shurui" size="mini" :disabled="true" />
              </el-col>
            </el-row>
            <el-row class="row-class">
              <el-col class="lab-class">　構造</el-col>
              <el-col style= "width: 200px">
                <el-input v-model="kozou" size="mini" :disabled="true" />
              </el-col>
            </el-row>
            <el-row class="row-class">
              <el-col class="lab-class">　資産単位</el-col>
              <el-col style= "width: 200px">
                <el-input v-model="shisanTani" size="mini" :disabled="true" />
              </el-col>
            </el-row>
            <el-row class="row-class">
              <el-col class="lab-class">　科目１</el-col>
              <el-col style= "width: 200px">
                <el-input v-model="kamoku1" size="mini" :disabled="true" />
              </el-col>
            </el-row>
            <el-row class="row-class">
              <el-col class="lab-class">　科目２</el-col>
              <el-col style= "width: 200px">
                <el-input v-model="kamoku2" size="mini" :disabled="true" />
              </el-col>
            </el-row>
            <el-row class="row-class">
              <el-col class="lab-class">　科目３</el-col>
              <el-col style= "width: 200px">
                <el-input v-model="kamoku3" size="mini" :disabled="true" />
              </el-col>
            </el-row>
          </el-col>
          <el-col :span="8">
            <el-row class="row-class">
              <el-col class="lab-class">　備忘価額_税</el-col>
              <el-col style= "width: 200px">
                <el-input v-model="shurui" size="mini" :disabled="true" />
              </el-col>
            </el-row>
            <el-row class="row-class">
              <el-col class="lab-class">　償却可能限度額_税</el-col>
              <el-col style= "width: 200px">
                <el-input v-model="kozou" size="mini" :disabled="true" />
              </el-col>
            </el-row>
            <el-row class="row-class">
              <el-col class="lab-class">　償却方法_税</el-col>
              <el-col style= "width: 200px">
                <el-input v-model="shisanTani" size="mini" :disabled="true" />
              </el-col>
            </el-row>
            <el-row class="row-class">
              <el-col class="lab-class">　残存率_税</el-col>
              <el-col style= "width: 200px">
                <el-input v-model="kamoku1" size="mini" :disabled="true" />
              </el-col>
            </el-row>
            <el-row class="row-class">
              <el-col class="lab-class">　耐用月数_税</el-col>
              <el-col style= "width: 200px">
                <el-input v-model="kamoku2" size="mini" :disabled="true" />
              </el-col>
            </el-row>
          </el-col>
          <el-col :span="8">
            <el-row class="row-class">
              <el-col class="lab-class">　備忘価額_商</el-col>
              <el-col style= "width: 200px">
                <el-input v-model="shurui" size="mini" :disabled="true" />
              </el-col>
            </el-row>
            <el-row class="row-class">
              <el-col class="lab-class">　償却可能限度額_商</el-col>
              <el-col style= "width: 200px">
                <el-input v-model="kozou" size="mini" :disabled="true" />
              </el-col>
            </el-row>
            <el-row class="row-class">
              <el-col class="lab-class">　償却方法_商</el-col>
              <el-col style= "width: 200px">
                <el-input v-model="shisanTani" size="mini" :disabled="true" />
              </el-col>
            </el-row>
            <el-row class="row-class">
              <el-col class="lab-class">　残存率_商</el-col>
              <el-col style= "width: 200px">
                <el-input v-model="kamoku1" size="mini" :disabled="true" />
              </el-col>
            </el-row>
            <el-row class="row-class">
              <el-col class="lab-class">　耐用月数_商</el-col>
              <el-col style= "width: 200px">
                <el-input v-model="kamoku2" size="mini" :disabled="true" />
              </el-col>
            </el-row>
          </el-col>
        </div>
      </el-row>
    </el-row>
    <el-row>
      <el-col>
        <nsd-button-bar v-bind:buttons="buttonName" v-bind:formItem="formItem"></nsd-button-bar>
      </el-col>
    </el-row>
  </div>
</template>

<script>
import NsdContentTitle from '@/components/common/NSDContentTitle.vue'
import NSDButtonBar from '@/components/common/NSDButtonBar.vue'

export default {
  components: {
    'nsd-content-title': NsdContentTitle,
    'nsd-button-bar': NSDButtonBar
  },
  created () {
    this.$store.state.message.content = this.$CONST_.msgContent.RENKEI
    this.loadShoninStatus()
  },
  data () {
    return {
      titlename: '【分割収入経理審査／連係】更新',
      buttonName: [
        {name: this.$CONST_.buttonName.UPDATE, primary: true, show: true, action: 'post'},
        {name: this.$CONST_.buttonName.RESET, primary: true, show: true, action: 'reset'},
        {name: this.$CONST_.buttonName.BACK, primary: true, show: true, action: 'back', backUrl: 'nsdbktsnkensaku'}
      ],
      shoninStatusList: [],
      seisanShoInfo: [
        {
          rowNo: '1',
          seisanShoNo: '000000000000012',
          soshikiRenNm: '精算箇所',
          shoriNo: '123456789',
          serviceKaisiYmd: '2018-05-01',
          keiyakuBeginDate: '2018-04-01',
          keiyakuEndDate: '2019-03-31',
          shoninStatusCd: '02',
          riyu: '固定資産名称ＡＡＡＡ',
          kojiKenmeiCd: '1',
          kojiKenmeiNm: '工事件名'
        },
        {
          rowNo: '2',
          seisanShoNo: '000000000000013',
          soshikiRenNm: '精算箇所',
          shoriNo: '123456789',
          serviceKaisiYmd: '2018-05-01',
          keiyakuBeginDate: '2018-04-01',
          keiyakuEndDate: '2019-03-31',
          shoninStatusCd: '02',
          riyu: '固定資産名称ＡＡＡＡ',
          kojiKenmeiCd: '1',
          kojiKenmeiNm: '工事件名'
        },
        {
          rowNo: '3',
          seisanShoNo: '000000000000014',
          soshikiRenNm: '精算箇所',
          shoriNo: '123456789',
          serviceKaisiYmd: '2018-05-01',
          keiyakuBeginDate: '2018-04-01',
          keiyakuEndDate: '2019-03-31',
          shoninStatusCd: '02',
          riyu: '固定資産名称ＡＡＡＡ',
          kojiKenmeiCd: '1',
          kojiKenmeiNm: '工事件名'
        },
        {
          rowNo: '4',
          seisanShoNo: '000000000000015',
          soshikiRenNm: '精算箇所',
          shoriNo: '123456789',
          serviceKaisiYmd: '2018-05-01',
          keiyakuBeginDate: '2018-04-01',
          keiyakuEndDate: '2019-03-31',
          shoninStatusCd: '02',
          riyu: '固定資産名称ＡＡＡＡ',
          kojiKenmeiCd: '1',
          kojiKenmeiNm: '工事件名'
        }
      ],
      koteiShisanInfo: [
        {rowNo: 1},
        {rowNo: 2},
        {rowNo: 3},
        {rowNo: 4},
        {rowNo: 5},
        {rowNo: 6},
        {rowNo: 7},
        {rowNo: 8},
        {rowNo: 9},
        {rowNo: 10},
        {rowNo: 11},
        {rowNo: 12},
        {rowNo: 13}
      ],
      formItem: {},
      multipleSelection: []
    }
  },
  methods: {
    showKoteiShisanInfo: function (row) {
      console.log(row)
    },
    renderShoninStatus (createElement, { column }) {
      return createElement(
        'label',
        [
          '承認状態',
          createElement(
            'span', {style: 'color: red;'}, '(必須)')
        ]
      )
    },
    loadShoninStatus () {
      var searchWhere = {
        cdShubetsu: this.$CONST_.cdShubetsu.SHONIN_STATUS,
        cd1Arr: [
          this.$CONST_.shoninStatus.SHONIN,
          this.$CONST_.shoninStatus.RENKEI
        ]
      }
      this.funcHttpPostComm('/comm-getCodeShubetsuList', searchWhere, this.loadShoninStatusCallBack)
    },
    loadShoninStatusCallBack (val) {
      this.shoninStatusList = val
    }
  }
}
</script>

<style scoped>
.kotei-detail-style {
  font-size: 12px;
  height: 100%;
  margin-left:10px;
  border: 0px solid;
  padding-top: 1px;
  padding-right: 1px;
}
.row-class {
  height: 28px;
  margin-bottom: 1px;
  margin-left: 1px;
  margin-right: 1px;
}
.lab-class {
  width: 120px;
  background-color: #77cad8;
  line-height: 28px;
  margin-right: 1px;
}
</style>
