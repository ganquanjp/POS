<template>
  <div style= "padding-left: 10px; padding-right: 10px;">
    <div style="position: relative;">
     <span style="font-size: 12px;">{{this.$store.state.tableData.length}}件</span>
      <div style="position: absolute; top: -10px; right: 0px;">
        <el-pagination
          background
          @size-change="handleSizeChange"
          @current-change="handleCurrentChange"
          :current-page.sync="$store.state.currentPage"
          :page-sizes="pageData.pageSizeArr"
          :page-size="pageData.pageSizeAct"
          layout="prev, pager, next"
          prev-text="前へ"
          next-text="次へ"
          :total="this.$store.state.tableData.length">
        </el-pagination>
      </div>
    </div>
    <el-table
      :data="this.$store.state.currentPageData"
      border
      max-height=430
      @sort-change="handleSortChange"
      :header-cell-class-name="sortCallClass">
      <el-table-column 
        prop="rowNo"
        label="NO."
        min-width="50px">
      </el-table-column>
      <el-table-column
        prop="kanriSoshikiKnj"
        label="管理箇所"
        min-width="165px">
      </el-table-column >
      <el-table-column
        sortable="custom"
        :formatter="dateFormat"
        prop="kanriTekiyoStartYmd"
        label="管理箇所適用期間（FROM）"
        min-width="180px">
      </el-table-column>
      <el-table-column
        sortable="custom"
        :formatter="dateFormat"
        prop="kanriTekiyoEndYmd"
        label="管理箇所適用期間（TO）"
        min-width="180px">
      </el-table-column>
      <el-table-column
        prop="futanSoshikiKnj"
        label="負担箇所"
        min-width="165px">
      </el-table-column>
      <el-table-column
        sortable="custom"
        :formatter="dateFormat"
        prop="futanTekiyoStartYmd"
        label="負担箇所適用期間（FROM）"
        min-width="180px">
      </el-table-column>
      <el-table-column
        sortable="custom"
        :formatter="dateFormat"
        prop="futanTekiyoEndYmd"
        label="負担箇所適用期間（TO）"
        min-width="180px">
      </el-table-column>
    </el-table>
  </div>
</template>
<script scoped>
import moment from 'moment'

export default {
  created: function () {
    if (this.$store.state.tableData.length > 0) {
      this.getPageData()
    }
  },
  data () {
    return {
      tableData: [],
      pageData: {
        total: 0,
        pageNum: 0,
        pageSizeArr: this.$CONST_.tableConst.PAGE_SIZES,
        pageSizeAct: this.$CONST_.tableConst.PAGE_SIZE,
        visible: false
      }
    }
  },
  methods: {
    handleSizeChange (index) {
      this.pageData.pageSizeAct = index
      this.initTableList(1)
    },
    handleCurrentChange (index) {
      this.initTableList(index)
    },
    initTableList (index) {
      this._initPageData(index)
      this.getPageData()
    },
    _initPageData (index) {
      this.pageData.pageNum = (index - 1) * this.pageData.pageSizeAct
      this.$store.state.currentPage = index
    },
    getPageData () {
      this.$store.state.currentPageData = this.$store.state.tableData.slice(this.pageData.pageSizeAct * (this.$store.state.currentPage - 1), this.pageData.pageSizeAct * this.$store.state.currentPage)
    },
    sortCallClass ({row, column, rowIndex, columnIndex}) {
      if (column['property'] === this.$store.state.sortItem.prop) {
        return this.$store.state.sortItem.order
      }
    },
    // ヘッダーにてソートボタンを押すとソート変更する
    handleSortChange ({ column, prop, order }) {
      this.funcSortChange(column, prop, order, this.$store)
      // ページデータ再設定
      this.getPageData()
    },
    dateFormat (row, column) {
      if (row[column.property] !== undefined) {
        return moment(row[column.property]).format('YYYY-MM-DD')
      }
    }
  }
}
</script>
<style scoped>
</style>
