<template>
  <div>
    <div class="page-style">
      <el-row class="row-class">
        <el-col style= "width: 170px; margin-left:-1px; background-color: #77cad8;">　管理箇所（コード／名称）</el-col>
        <el-col style= "width: 140px;">
          <el-input v-model="formItem.kanriSoshikiCd" size="mini" placeholder=""></el-input>
        </el-col>
        <el-col :span="1" style="line-height: 30px;">　/</el-col>
        <el-col style= "width: 140px; margin-left:-1px;">
          <el-input v-model="formItem.kanriSoshikiKnj" size="mini" placeholder=""></el-input>
        </el-col>
      </el-row>
      <el-row class="row-class">
        <el-col style= "width: 170px; margin-left:-1px; background-color: #77cad8;">　負担箇所（コード／名称）</el-col>
        <el-col style= "width: 140px;">
          <el-input v-model="formItem.futanSoshikiCd" size="mini" placeholder=""></el-input>
        </el-col>
        <el-col :span="1" style="line-height: 30px;">　/</el-col>
        <el-col style= "width: 140px; margin-left:-1px;">
          <el-input v-model="formItem.futanSoshikiKnj" size="mini" placeholder=""></el-input>
        </el-col>
      </el-row>
    </div>
    <el-row>
      <el-col>
        <nsd-button-bar v-bind:buttons="buttonName" v-bind:formItem="formItem"></nsd-button-bar>
        <!-- 更新ボタン制御用、除去不可-->
        <el-input v-if="notshow" size="mini"></el-input>
      </el-col>
    </el-row>
  </div>
</template>

<script>
import NSDButtonBar from '@/components/common/NSDButtonBar.vue'

export default {
  components: {
    'nsd-button-bar': NSDButtonBar
  },
  computed: {
    notshow: function () {
      if (this.$store.state.tableData.length === 0) {
        return false
      } else {
        return false
      }
    },
    btnUpdateDisable: function () {
      return this.$store.state.tableData.length === 0
    }
  },
  data () {
    return {
      buttonName: [
        {name: this.$CONST_.buttonName.SEARCH, primary: true, show: true, action: 'post', url: '/kanriFutanhimodzuki-selectByWhere'},
        {name: this.$CONST_.buttonName.RESET, primary: true, show: true, action: 'reset', url: '', msg: 'リセットしますか？'},
        {id: 'update', name: this.$CONST_.buttonName.UPDATE, disabled: this.btnUpdateDisable, primary: true, show: true, action: 'back', url: '', backUrl: 'nsdkrftkskosin'}
      ],
      timeout: null,
      formItem: {
        kanriSoshikiCd: '',
        kanriSoshikiKnj: '',
        futanSoshikiCd: '',
        futanSoshikiKnj: ''
      }
    }
  },
  methods: {
    loadAll () {
      return [
        { 'value': '総務部' },
        { 'value': '総務部　一括' },
        { 'value': '財務部' },
        { 'value': '財務部　一括' },
        { 'value': '人事部' },
        { 'value': '人事部　一括' }
      ]
    },
    querySearchAsync (queryString, cb) {
      var bumen = this.bumen
      var results = queryString ? bumen.filter(this.createStateFilter(queryString)) : bumen
      clearTimeout(this.timeout)
      this.timeout = setTimeout(() => {
        cb(results)
      }, 200 * Math.random())
    },
    createStateFilter (queryString) {
      return (state) => {
        return (state.value.toLowerCase().indexOf(queryString.toLowerCase()) === 0)
      }
    },
    handleSelect (item) {
      console.log(item)
    }
  },
  mounted () {
    this.bumen = this.loadAll()
  }
}
</script>

<style scoped>
.page-style {
  font-size: 12px;
  width: 470px;
  height: 100%;
  margin-left:10px;
  line-height:30px;
  border: 1px solid;
  padding-top: 1px;
  padding-left: 1px;
  padding-right: 1px;
}
.row-class {
  height: 30px;
  margin-bottom: 1px;
  margin-left: 1px;
  margin-right: 1px;
}
</style>
