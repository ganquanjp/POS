<template>
  <div>
    <el-row>
      <el-col>
        <nsd-content-title v-bind:titlename="titlename" v-bind:message="this.$store.state.message"></nsd-content-title>
      </el-col>
    </el-row>
    <el-row>
      <el-col>
        <nsd-table-bar></nsd-table-bar>
      </el-col>
    </el-row>
  </div>
</template>

<script>
import NsdContentTitle from '@/components/common/NSDContentTitle.vue'
import NSDTable from '@/components/kanrifutankasho/sinki/NSDTable.vue'

export default {
  components: {
    'nsd-content-title': NsdContentTitle,
    'nsd-table-bar': NSDTable

  },
  data () {
    return {
      titlename: '【管理箇所／負担箇所紐付】新規登録'
    }
  }
}
</script>

<style scoped>
</style>
