<template>
  <div>
    <div>
      <el-table
        ref="tab"
        :data="this.formItem.kanriFutanLst" 
        max-height="520"
        border>
        <el-table-column 
          prop="rowNo"
          label="NO."
          width="50px">
        </el-table-column>
        <el-table-column 
          min-width="500px"
          :render-header="renderHeader1">
          >
          <el-table-column
            min-width="180px"
            prop="kanriSoshikiKnj"
            id="search_text" 
            label="名称">
            <template slot-scope="scope">
              <el-autocomplete
                style= "width: 220px;"
                v-model="scope.row.kanriSoshikiKnj"
                :value="scope.row.kanriSoshikiCd"
                :fetch-suggestions="querySearchAsyncKSoshikiKnj"
                @select="handleSelectKSoshikiKnj(scope.row, $event)"
                size="mini" 
                >
              </el-autocomplete>
            </template>
          </el-table-column>
          <el-table-column 
            prop="kanriTekiyoStartYmd"
            width="140px"
            label="適用期間（FROM）"
            :formatter="dateFormat"
            >
          </el-table-column>
          <el-table-column 
            prop="kanriTekiyoEndYmd"
            width="140px"
            label="適用期間（TO）"
            :formatter="dateFormat"
            >
            </el-date-picker>
          </el-table-column>
        </el-table-column>
        <el-table-column 
          min-width="500px"
          :render-header="renderHeader2">
          >
          <el-table-column
            min-width="180px"
            prop="futanSoshikiKnj"
            id="search_text" 
            label="名称">
            <template slot-scope="scope">
              <el-autocomplete
                style= "width: 220px;"
                v-model="scope.row.futanSoshikiKnj"
                :value="scope.row.futanSoshikiCd"
                :fetch-suggestions="querySearchAsyncFSoshikiKnj"
                @select="handleSelectFSoshikiKnj(scope.row, $event)"
                size="mini" 
                >
              </el-autocomplete>
            </template>
          </el-table-column>
          <el-table-column
            prop="futanTekiyoStartYmd"
            width="140px"
            label="適用期間（FROM）"
            :formatter="dateFormat"
            >
            </el-date-picker>
          </el-table-column>
          <el-table-column
            prop="futanTekiyoEndYmd"
            width="140px"
            label="適用期間（TO）"
            :formatter="dateFormat"
            >
            </el-date-picker>
          </el-table-column>
        </el-table-column>
      </el-table>
    </div>
    <el-row>
      <el-col>
        <nsd-button-bar v-bind:buttons="buttonName" v-bind:formItem="formItem"></nsd-button-bar>
      </el-col>
    </el-row>
  </div>
</template>
<script>
import NSDButtonBar from '@/components/common/NSDButtonBar.vue'
import moment from 'moment'
export default {
  components: {
    'nsd-button-bar': NSDButtonBar
  },
  created: function () {
    for (var i = 0; i < 25; i++) {
      var kanriFutan = {
        rowNo: i + 1,
        kanriSoshikiKnj: '',
        kanriSoshikiCd: '',
        kanriTekiyoStartYmd: '',
        kanriTekiyoEndYmd: '',
        futanSoshikiKnj: '',
        futanSoshikiCd: '',
        futanTekiyoStartYmd: '',
        futanTekiyoEndYmd: ''
      }
      this.formItem.kanriFutanLst.push(kanriFutan)
    }
  },
  mounted () {
    this.kanriSoshikiKnj = this.loadKSoshikiKnj()
    this.futanSoshikiKnj = this.loadFSoshikiKnj()
  },
  data () {
    return {
      rowIndex: '',
      showModal: false,
      buttonName: [
        {name: this.$CONST_.buttonName.INSERT, primary: true, show: true, action: 'post', url: '/kanriFutanhimodzuki-insertInfo'},
        {name: this.$CONST_.buttonName.RESET, primary: true, show: true, action: 'reset'}
      ],
      formItem: {
        kanriFutanLst: []
      }
    }
  },
  methods: {
    renderHeader1 (createElement, { column }) {
      return createElement(
        'label',
        [
          '管理箇所',
          createElement('span', {style: 'color: red;'}, '　(必須)')
        ]
      )
    },
    renderHeader2 (createElement, { column }) {
      return createElement(
        'label',
        [
          '負担箇所',
          createElement('span', {style: 'color: red;'}, '　(必須)')
        ]
      )
    },
    handleSelectKSoshikiKnj (row, item) {
      row.kanriSoshikiKnj = item.value
      row.kanriSoshikiCd = item.ab9SoshikCod
      row.kanriTekiyoStartYmd = item.ab9TekiyfYmd
      row.kanriTekiyoEndYmd = item.ab9TekiytYmd
    },
    loadKSoshikiKnj () {
      var items = ['ab9SoshikKnj', 'ab9SoshikCod', 'ab9TekiyfYmd', 'ab9TekiytYmd']
      return this.funcGetDropDownValue('/autocomplete-selectSoshikTeisuMaster', items)
    },
    querySearchAsyncKSoshikiKnj (queryString, cb) {
      var kanriSoshikiKnj = this.kanriSoshikiKnj
      var results = queryString ? kanriSoshikiKnj.filter(this.createStateFilter(queryString)) : kanriSoshikiKnj
      clearTimeout(this.timeout)
      this.timeout = setTimeout(() => {
        cb(results)
      }, 200 * Math.random())
    },
    handleSelectFSoshikiKnj (row, item) {
      row.futanSoshikiKnj = item.value
      row.futanSoshikiCd = item.ab9SoshikCod
      row.futanTekiyoStartYmd = item.ab9TekiyfYmd
      row.futanTekiyoEndYmd = item.ab9TekiytYmd
    },
    loadFSoshikiKnj () {
      var items = ['ab9SoshikKnj', 'ab9SoshikCod', 'ab9TekiyfYmd', 'ab9TekiytYmd']
      return this.funcGetDropDownValue('/autocomplete-selectSoshikTeisuMaster', items)
    },
    querySearchAsyncFSoshikiKnj (queryString, cb) {
      var futanSoshikiKnj = this.futanSoshikiKnj
      var results = queryString ? futanSoshikiKnj.filter(this.createStateFilter(queryString)) : futanSoshikiKnj
      clearTimeout(this.timeout)
      this.timeout = setTimeout(() => {
        cb(results)
      }, 200 * Math.random())
    },
    createStateFilter (queryString) {
      return (state) => {
        return (state.value.toLowerCase().indexOf(queryString.toLowerCase()) >= 0)
      }
    },
    dateFormat (row, column) {
      if (row[column.property] !== '') {
        return moment(row[column.property]).format('YYYY-MM-DD')
      }
    }
  }
}
</script>
<style>
.el-table .class-header {
  color: black;
  font-size: 12px;
}
</style>
