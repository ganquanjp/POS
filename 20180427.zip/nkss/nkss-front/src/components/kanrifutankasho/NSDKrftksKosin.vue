<template>
  <div>
    <el-row>
      <el-col>
        <nsd-content-title v-bind:titlename="titlename" v-bind:message="this.$store.state.message"></nsd-content-title>
      </el-col>
    </el-row>
    <el-row>
      <el-col>
        <div style="padding: 10px; height: 490px">
          <div style="position: relative;">
            <span style="font-size: 12px;">{{ this.formItem.length }}件</span>
            <div style="position: absolute; top: -8px; right: 0px;">
              <el-pagination
                background
                @size-change="handleSizeChange"
                @current-change="handleCurrentChange"
                :current-page.sync="$store.state.currentPage"
                :page-sizes="pageData.pageSizeArr"
                :page-size="pageData.pageSizeAct"
                layout="prev, pager, next"
                prev-text="前へ"
                next-text="次へ"
                :total="this.formItem.length">
              </el-pagination>
            </div>
          </div>
          <el-table
            :data="this.formItem"
            border
            :header-row-class-name="headerClassName"
            height="450">
            <el-table-column 
              prop="rowNo"
              label="NO."
              width="50px">
            </el-table-column>
            <el-table-column label="更新" align="center">
              <el-table-column 
                prop="kousin"
                width="45px"
                align="center"
                :render-header="renderHeaderCheckbox">
                 <template slot-scope="scope" style="align: center">
                   <el-checkbox v-model="scope.row.date" />
                 </template>
              </el-table-column>
            </el-table-column>
            <el-table-column label="削除" align="center">
              <el-table-column 
                prop="sakujyo"
                width="45px"
                 align="center"
                :render-header="renderHeaderCheckbox">
                 <template slot-scope="scope">
                   <el-checkbox v-model="scope.row.date2" />
                 </template>
              </el-table-column>
            </el-table-column>
            <el-table-column :render-header="renderHeader1">
              <el-table-column
                min-width="220px"
                label="名称">
                <template slot-scope="scope">
                  <el-autocomplete v-model="scope.row.kanriSoshikiKnj"
                  :value="scope.row.kanriSoshikiCd"
                  :fetch-suggestions="querySearchAsyncKSoshikiKnj"
                  @select="handleSelectKSoshikiKnj(scope.row, $event)"
                  size="mini">
                  </el-autocomplete>
                </template>
              </el-table-column>
              <el-table-column 
                prop="kanriTekiyoStartYmd"
                width="110px"
                :render-header="renderHeaderYmdFrom"
                :formatter="dateFormat">
              </el-table-column>
              <el-table-column 
                prop="kanriTekiyoEndYmd"
                width="110px"
                :render-header="renderHeaderYmdTo"
                :formatter="dateFormat">
              </el-table-column>
            </el-table-column>
            <el-table-column :render-header="renderHeader2">
              <el-table-column
                min-width="220px"
                label="名称">>
                <template slot-scope="scope">
                  <el-autocomplete v-model="scope.row.futanSoshikiKnj"
                  :value="scope.row.futanSoshikiCd"
                  :fetch-suggestions="querySearchAsyncFSoshikiKnj"
                  @select="handleSelectFSoshikiKnj(scope.row, $event)"
                  size="mini">
                  </el-autocomplete>
                </template>
              </el-table-column>
              <el-table-column
                prop="futanTekiyoStartYmd"
                width="110px"
                :render-header="renderHeaderYmdFrom"
                :formatter="dateFormat">
              </el-table-column>
              <el-table-column
                prop="futanTekiyoEndYmd"
                width="110px"
                :render-header="renderHeaderYmdTo"
                :formatter="dateFormat">
              </el-table-column>
            </el-table-column>
          </el-table>
        </div>
      </el-col>
    </el-row>
    <el-row>
      <el-col>
        <nsd-button-bar v-bind:buttons="buttonName" v-bind:clicks="btnClick"></nsd-button-bar>
      </el-col>
    </el-row>
  </div>
</template>

<script>
import NsdContentTitle from '@/components/common/NSDContentTitle.vue'
import NSDButtonBar from '@/components/common/NSDButtonBar.vue'
import moment from 'moment'

export default {
  components: {
    'nsd-content-title': NsdContentTitle,
    'nsd-button-bar': NSDButtonBar
  },
  created () {
    this.$store.state.message.content = this.$CONST_.msgContent.UPDATE
    this.resetInitData = JSON.parse(JSON.stringify(this.$store.state.tableData))
    this.formItem = JSON.parse(JSON.stringify(this.$store.state.tableData))
  },
  mounted () {
    this.kanriSoshikiKnj = this.loadKSoshikiKnj()
    this.futanSoshikiKnj = this.loadFSoshikiKnj()
  },
  methods: {
    renderHeader1 (createElement, { column }) {
      return createElement(
        'label',
        [
          '管理箇所',
          createElement('span', {style: 'color: red;'}, '　(必須)')
        ]
      )
    },
    renderHeader2 (createElement, { column }) {
      return createElement(
        'label',
        [
          '負担箇所',
          createElement('span', {style: 'color: red;'}, '　(必須)')
        ]
      )
    },
    renderHeaderYmdFrom (createElement, { column }) {
      return createElement(
        'label', '適用期間(FROM)'
      )
    },
    renderHeaderYmdTo (createElement, { column }) {
      return createElement(
        'label', '適用期間(TO)'
      )
    },
    renderHeaderCheckbox (createElement, { column }) {
      return createElement(
        'el-checkbox'
      )
    },
    dateFormat (row, column) {
      if (row[column.property] !== '') {
        return moment(row[column.property]).format('YYYY-MM-DD')
      }
    },
    handleSelectKSoshikiKnj (row, item) {
      row.kanriSoshikiKnj = item.value
      row.kanriSoshikiCd = item.ab9SoshikCod
      row.kanriTekiyoStartYmd = item.ab9TekiyfYmd
      row.kanriTekiyoEndYmd = item.ab9TekiytYmd
    },
    loadKSoshikiKnj () {
      var items = ['ab9SoshikKnj', 'ab9SoshikCod', 'ab9TekiyfYmd', 'ab9TekiytYmd']
      return this.funcGetDropDownValue('/autocomplete-selectSoshikTeisuMaster', items)
    },
    querySearchAsyncKSoshikiKnj (queryString, cb) {
      var kanriSoshikiKnj = this.kanriSoshikiKnj
      var results = queryString ? kanriSoshikiKnj.filter(this.createStateFilter(queryString)) : kanriSoshikiKnj
      clearTimeout(this.timeout)
      this.timeout = setTimeout(() => {
        cb(results)
      }, 200 * Math.random())
    },
    handleSelectFSoshikiKnj (row, item) {
      row.futanSoshikiKnj = item.value
      row.futanSoshikiCd = item.ab9SoshikCod
      row.futanTekiyoStartYmd = item.ab9TekiyfYmd
      row.futanTekiyoEndYmd = item.ab9TekiytYmd
    },
    loadFSoshikiKnj () {
      var items = ['ab9SoshikKnj', 'ab9SoshikCod', 'ab9TekiyfYmd', 'ab9TekiytYmd']
      return this.funcGetDropDownValue('/autocomplete-selectSoshikTeisuMaster', items)
    },
    querySearchAsyncFSoshikiKnj (queryString, cb) {
      var futanSoshikiKnj = this.futanSoshikiKnj
      var results = queryString ? futanSoshikiKnj.filter(this.createStateFilter(queryString)) : futanSoshikiKnj
      clearTimeout(this.timeout)
      this.timeout = setTimeout(() => {
        cb(results)
      }, 200 * Math.random())
    },
    createStateFilter (queryString) {
      return (state) => {
        return (state.value.toLowerCase().indexOf(queryString.toLowerCase()) >= 0)
      }
    }
  },
  data () {
    return {
      titlename: '【管理箇所／負担箇所紐付】更新',
      buttonName: [
        {name: this.$CONST_.buttonName.UPDATE, primary: true, show: true, action: 'post'},
        {name: this.$CONST_.buttonName.RESET, primary: true, show: true, action: 'reset'},
        {name: this.$CONST_.buttonName.BACK, primary: true, show: true, action: 'back', backUrl: 'nsdkrftkskensaku'}
      ],
      resetInitData: [],
      showModal: false,
      formItem: [],
      pageData: {
        total: 0,
        pageNum: 0,
        pageSizeArr: this.$CONST_.tableConst.PAGE_SIZES,
        pageSizeAct: this.$CONST_.tableConst.PAGE_SIZE,
        visible: false
      }
    }
  }
}
</script>

<style scoped>
</style>
