<template>
  <div>
    <div class="page-style">
      <el-row class="row-class">
        <el-col class="lab-class">　精算書番号</el-col>
        <el-col style= "width: 140px;">
          <el-input v-model="formItem.seisanShoNo" size="mini"></el-input>
        </el-col>
      </el-row>
      <el-row class="row-class">
        <el-col class="lab-class">　精算箇所</el-col>
        <el-col style= "width: 140px;">
          <el-input v-model="formItem.soshikiRenNm" size="mini"></el-input>
        </el-col>
      </el-row>
      <el-row class="row-class">
        <el-col class="lab-class">　使用開始年月日</el-col>
        <el-col style= "width: 140px;">
          <el-date-picker
            v-model="formItem.siyoStartYmdFrom"
            size="mini"
            style="width: 140px;"
            type="date"
            value-format="yyyy-MM-dd">
          </el-date-picker>
        </el-col>
        <el-col :span="1"style="line-height: 25px; margin-left: 5px; margin-right: -5px;">－</el-col>
        <el-col style= "width: 140px;">
          <el-date-picker
            v-model="formItem.siyoStartYmdTo"
            size="mini"
            style="width: 140px;"
            type="date"
            value-format="yyyy-MM-dd">
          </el-date-picker>
        </el-col>
      </el-row>
      <el-row class="row-class">
        <el-col class="lab-class">　登録者氏名</el-col>
        <el-col style= "width: 140px;">
          <el-input v-model="formItem.torokusyaNm" size="mini"></el-input>
        </el-col>
      </el-row>
      <el-row class="row-class">
        <el-col class="lab-class">　承認状態</el-col>
        <el-col style= "width: 140px;">
          <el-select v-model="formItem.shoninStatusCd" size="mini" placeholder="">
            <el-option
              v-for="item in shoninStatusList"
              :key="item.cd1"
              :label="item.cdKnj"
              :value="item.cd1">
           </el-option>
         </el-select>
        </el-col>
      </el-row>
      <el-row class="row-class">
        <el-col class="lab-class">　工事件名</el-col>
        <el-col style= "width: 140px;">
          <el-input v-model="formItem.kenmeiNm" size="mini"></el-input>
        </el-col>
      </el-row>
    </div>
    <el-row>
      <el-col>
        <nsd-button-bar v-bind:buttons="buttonName" v-bind:formItem="formItem"></nsd-button-bar>
      </el-col>
    </el-row>
  </div>
</template>

<script>
import NSDButtonBar from '@/components/common/NSDButtonBar.vue'

export default {
  components: {
    'nsd-button-bar': NSDButtonBar
  },
  created: function () {
    this.funcDataRestore()
    if (typeof (this.$store.state.preGamenData.inputData) !== 'undefined') {
      this.formItem = this.$store.state.preGamenData.inputData
    }
    this.loadShoninStatus()
  },
  data () {
    return {
      buttonName: [
        {name: this.$CONST_.buttonName.SEARCH, primary: true, show: true, action: 'post', url: '/seisanshoShonin-selectByWhere'},
        {name: this.$CONST_.buttonName.RESET, primary: true, show: true, action: 'reset', url: '', msg: 'リセットしますか？'}
      ],
      shoninStatusList: [],
      formItem: {
        seisanShoNo: '',
        soshikiRenNm: '',
        siyoStartYmdFrom: '',
        siyoStartYmdTo: '',
        torokusyaNm: '',
        shoninStatusCd: '',
        kenmeiNm: ''
      }
    }
  },
  methods: {
    loadShoninStatus () {
      var searchWhere = {
        cdShubetsu: this.$CONST_.cdShubetsu.SHONIN_STATUS,
        cd1Arr: [
          this.$CONST_.shoninStatus.TOROKU,
          this.$CONST_.shoninStatus.SHONIN,
          this.$CONST_.shoninStatus.HININ
        ]
      }
      this.funcHttpPostComm('/comm-getCodeShubetsuList', searchWhere, this.loadShoninStatusCallBack)
    },
    loadShoninStatusCallBack (val) {
      this.shoninStatusList = val
      this.shoninStatusList.unshift({cd1: '', cdKnj: ''})
    }
  }
}
</script>

<style scoped>
.page-style {
  font-size: 12px;
  width: 473px;
  height: 100%;
  margin-left:10px;
  line-height:30px;
  border: 1px solid;
  padding-top: 1px;
  padding-right: 1px;
}
.row-class {
  height: 30px;
  margin-bottom: 1px;
  margin-left: 1px;
  margin-right: 1px;
}
.lab-class {
  width: 170px;
  background-color: #77cad8;
  line-height: 30px;
  margin-right: 1px;
}
</style>
