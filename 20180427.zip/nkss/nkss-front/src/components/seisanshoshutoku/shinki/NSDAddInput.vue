<template>
  <div>
    <div class="scroll-box">
      <div class="page-style">
        <el-row class="row-class">
          <el-col style= "width: 100%; background-color: #2053cc; color: #FFFFFF; line-height: 30px;">　基本情報</el-col>
        </el-row>
        <el-row class="row-class">
          <el-col class="lab-class">　固定資産番号<span class="span-class">（必須）</span></el-col>
          <el-col style= "width: 170px; padding-top: -5px;">
            <el-input v-model="formItem.koteiShisanNo" size="mini" :disabled=true>
              <el-button slot="append" style="position: absolute; top: 20px; left: 10px;" size="mini" @click="showModalKotei = true">参照</el-button>
            </el-input>
          </el-col>
        </el-row>
        <el-row class="row-class">
          <el-col class="lab-class">　親固定資産番号<span class="span-class">（必須）</span></el-col>
          <el-col style= "width: 170px">
          <el-input v-model="formItem.oyaKoteiShisanNo" size="mini">
              <el-button slot="append" style="position: absolute; top: 20px; left: 10px;" size="mini" @click="showModalKoteioya = true">参照</el-button>
            </el-input>
          </el-col>
          <el-col style= "width: 60px; background-color: #77cad8; line-height: 30px; margin: 0px 1px 0px 1px;">　枝番</el-col>
          <el-col style= "width: 100px">
            <el-input max-length="4" v-model="formItem.oyaKoteiShisanEda"  size="mini" />
          </el-col>
        </el-row>
        <el-row class="row-class">
          <el-col class="lab-class">　取得年月日<span class="span-class">（必須）</span></el-col>
          <el-col style= "width: 260px">
            <el-date-picker
              v-model="formItem.shutokuYmd"
              size="mini"
              style= "width: 140px;"
              type="date">
            </el-date-picker>
          </el-col>
        </el-row>
        <el-row class="row-class">
          <el-col class="lab-class">　固定資産名称<span class="span-class">（必須）</span></el-col>
          <el-col style= "width: 333px">
            <el-input max-length="20" v-model="formItem.koteiShisanNm"  size="mini" />
          </el-col>
        </el-row>
        <el-row class="row-class">
          <el-col class="lab-class">　種類<span class="span-class">（必須）</span></el-col>
          <el-col style= "width: 333px">
            <el-tooltip effect="light" placement="right-start">
              <div slot="content">自社所有建物の場合は、「建物（自社ビル）」または「建物付属（自社ビル）」を選択する。<br/>
                                  ただし建物付属設備のうち、DCの動力源となる電気設備、発・変電設備、蓄電池設備、<br/>
                                  中央監視制御装置、電話交換機、広告設備等は「建物附属」を選択する。<br/>
                                  K工事（リース）に係る設備、消耗品等は「リース投資（XXX）」として処理する。</div>
              <el-select v-model="formItem.shuruiCd" size="mini" style="width: 200px;" @change="shuruiChange">
                <el-option
                  v-for="item in this.optionsShurui"
                  :key="item.aw1ShuCod"
                  :label="item.aw1ShuKnj"
                  :value="item.aw1ShuCod">
                </el-option>
              </el-select>
            </el-tooltip>
          </el-col>
        </el-row>
        <el-row class="row-class">
          <el-col class="lab-class">　構造</el-col>
          <el-col style= "width: 333px">
            <el-select v-model="formItem.kouzouCd" size="mini" style="width: 200px;" @change="kouzouChange">
              <el-option
                v-for="item in this.optionsKouzou"
                :key="item.aw2KouCod"
                :label="item.aw2KouKnj"
                :value="item.aw2KouCod">
              </el-option>
            </el-select>
          </el-col>
        </el-row>
        <el-row class="row-class">
          <el-col class="lab-class">　資産単位</el-col>
          <el-col style= "width: 333px">
            <el-select v-model="formItem.shisanTaniCd" size="mini" style="width: 200px;" @change="shisanTaniChange">
              <el-option
                v-for="item in this.optionsShisanTani"
                :key="item.aw3SaiCod"
                :label="item.aw3SaiKnj"
                :value="item.aw3SaiCod">
              </el-option>
            </el-select>
          </el-col>
        </el-row>
        <el-row class="row-class">
          <el-col class="lab-class">　科目１</el-col>
          <el-col style= "width: 333px">
            <el-select v-model="formItem.kamokuCd1" size="mini" style="width: 200px;" @change="kamokuCd1Change">
              <el-option
                v-for="item in this.optionsKamoku1"
                :key="item.aw4Shu4Cod"
                :label="item.aw4Shu4Knj"
                :value="item.aw4Shu4Cod">
              </el-option>
            </el-select>
          </el-col>
        </el-row>
        <el-row class="row-class">
          <el-col class="lab-class">　科目２</el-col>
          <el-col style= "width: 333px">
            <el-tooltip effect="light" placement="right-start">
              <div slot="content">DC設備＝DC内の資産<br/>
                                  業務設備＝本社の資産</div>
              <el-select v-model="formItem.kamokuCd2" size="mini" style="width: 200px;" @change="kamokuCd2Change">
                <el-option
                  v-for="item in this.optionsKamoku2"
                  :key="item.aw5Shu5Cod"
                  :label="item.aw5Shu5Knj"
                  :value="item.aw5Shu5Cod">
                </el-option>
              </el-select>
            </el-tooltip>
          </el-col>
        </el-row>
        <el-row class="row-class">
          <el-col class="lab-class">　科目３</el-col>
          <el-col style= "width: 333px">
            <el-tooltip effect="light" placement="right-start">
              <div slot="content">初期費用＝K工事（一括個別収入）<br/>
                                  一般＝T工事、K工事（標準・リース）</div>
              <el-select v-model="formItem.kamokuCd3" size="mini" style="width: 200px;" @change="kamokuCd3Change">
                <el-option
                  v-for="item in this.optionsKamoku3"
                  :key="item.aw6Shu6Cod"
                  :label="item.aw6Shu6Knj"
                  :value="item.aw6Shu6Cod">
                </el-option>
              </el-select>
            </el-tooltip>
          </el-col>
        </el-row>
        <el-row class="row-class">
          <el-col class="lab-class" v-if=this.ztaiyoYmFlg>　耐用月数<span class="span-class">（必須）</span></el-col>
          <el-col class="lab-class" v-if=!this.ztaiyoYmFlg>　耐用年数<span class="span-class">（必須）</span></el-col>
          <el-col style= "width: 50px">
            <input class="nsd-input-class" v-model="formItem.taiyoNensuZei" ></input>
          </el-col>
        </el-row>
      </div>
      <div class="page-style" style="margin-top: 10px;">
        <el-row class="row-class">
          <el-col style= "width: 100%; background-color: #2053cc; color: #FFFFFF; line-height: 30px;">　取得情報</el-col>
        </el-row>
        <el-row class="row-class">
          <el-col class="lab-class">　取引先名称<span class="span-class" v-if=this.torihikiFlg>（必須）</span></el-col>
          <el-col style= "width: 333px; padding-top: -5px;">
            <el-input v-model="formItem.torihikiSakiNm" size="mini" :disabled=!this.torihikiFlg>
              <el-button slot="append" v-if=this.torihikiBtnFlg style="position: absolute; top: 20px; left: 10px;" size="mini" @click="showModalTrhks = true">参照</el-button>
            </el-input>
          </el-col>
        </el-row>
        <el-row class="row-class">
          <el-col class="lab-class">　製造会社名称</el-col>
          <el-col style= "width: 333px; padding-top: -5px;">
            <el-input max-length="20" v-model="formItem.seizoKaishaNm" size="mini" />
          </el-col>
        </el-row>
        <el-row class="row-class">
          <el-col class="lab-class">　製品名称</el-col>
          <el-col style= "width: 200px">
            <el-input max-length="10" v-model="formItem.seihinNm"  size="mini" />
          </el-col>
        </el-row>
        <el-row class="row-class">
          <el-col class="lab-class">　型番</el-col>
          <el-col style= "width: 200px">
            <el-input max-length="10" v-model="formItem.kataban"  size="mini" />
          </el-col>
        </el-row>
        <el-row class="row-class">
          <el-col class="lab-class">　物品数量<span class="span-class">（必須）</span></el-col>
          <el-col style= "width: 200px">
            <el-input v-model="formItem.suryo"  size="mini" />
          </el-col>
        </el-row>
        <el-row class="row-class">
          <el-col class="lab-class">　単位<span class="span-class">（必須）</span></el-col>
          <el-col style= "width: 200px">
            <el-select v-model="formItem.taniCd" size="mini" style="width: 200px;">
              <el-option
                v-for="item in this.optionsTani"
                :key="item.awfTaniCod"
                :label="item.awfTaniKnj"
                :value="item.awfTaniCod">
              </el-option>
            </el-select>
          </el-col>
        </el-row>
        <el-row class="row-class">
          <el-col class="lab-class">　物品<span class="span-class">（必須）</span></el-col>
          <el-col class="input-group" style= "width: 200px">
            <input v-model="formItem.buppinGaku" size="mini" class="nsd-input-class label-input-class">
            </input>
          </el-col>
        </el-row>
        <el-row class="row-class">
          <el-col class="lab-class">　工費<span class="span-class">（必須）</span></el-col>
          <el-col class="input-group" style= "width: 200px">
            <input v-model="formItem.kouhiGaku" size="mini" class="nsd-input-class label-input-class">
            </input>
          </el-col>
        </el-row>
        <el-row class="row-class">
          <el-col class="lab-class">　総係費</el-col>
          <el-col class="input-group" style= "width: 200px">
            <input v-model="formItem.souKeihiGaku" size="mini" class="nsd-input-class label-input-class">
            </input>
          </el-col>
        </el-row>
      </div>
      <div class="page-style" style="margin-top: 10px;">
        <el-row class="row-class">
          <el-col style= "width: 100%; background-color: #2053cc; color: #FFFFFF; line-height: 30px;">　管理情報</el-col>
        </el-row>
        <el-row class="row-class">
          <el-col class="lab-class">　管理箇所名称<span class="span-class">（必須）</span></el-col>
          <el-col style= "width: 333px; padding-top: -5px;">
            <el-tooltip effect="light" placement="right-start">
              <div slot="content">DC＝資産の管理部門名＋センター名<br/>
                                  本社＝資産の管理部門名＋一括</div>
              <el-input v-model="formItem.kanriSoshikiNm" size="mini" :disabled=true>
                <el-button slot="append" style="position: absolute; top: 20px; left: 10px;" size="mini" @click="showModalKanri = true">参照</el-button>
              </el-input>
            </el-tooltip>
          </el-col>
        </el-row>
        <el-row class="row-class">
          <el-col class="lab-class">　負担箇所<span class="span-class">（必須）</span></el-col>
          <el-col style= "width: 333px; padding-top: -5px;">
          <el-input :disabled="true" v-model="formItem.futanSoshikiNm" size="mini"></el-input>
          </el-col>
        </el-row>
        <el-row class="row-class">
          <el-col class="lab-class">　設置場所名称<span class="span-class">（必須）</span></el-col>
          <el-col style= "width: 200px">
            <el-input v-model="formItem.sechiBashoNm" size="mini" :disabled=true>
              <el-button slot="append" style="position: absolute; top: 20px; left: 10px;" size="mini" @click="showModalSechi = true">参照</el-button>
            </el-input>
          </el-col>
        </el-row>
        <el-row class="row-class">
          <el-col class="lab-class">　取得事由<span class="span-class">（必須）</span></el-col>
          <el-col style= "width: 333px">
            <el-select v-model="formItem.shutokuRiyuCd" size="mini" style="width: 200px;">
              <el-option
                v-for="item in this.optionsShutokuRiyu"
                :key="item.awkKmksbtCod"
                :label="item.awkMeishoKnj"
                :value="item.awkKmksbtCod">
              </el-option>
            </el-select>
          </el-col>
        </el-row>
      </div>
      <div class="page-style" style="margin-top: 10px;">
        <el-row class="row-class">
          <el-col style= "width: 100%; background-color: #2053cc; color: #FFFFFF; line-height: 30px;">　任意情報</el-col>
        </el-row>
        <el-row class="row-class">
          <el-col class="lab-class">　摘要１</el-col>
          <el-col style= "width: 333px; padding-top: -5px;">
            <el-input max-length="30" v-model="formItem.tekiyo1" size="mini" />
          </el-col>
        </el-row>
        <el-row class="row-class">
          <el-col class="lab-class">　摘要２</el-col>
          <el-col style= "width: 333px; padding-top: -5px;">
            <el-input max-length="20" v-model="formItem.tekiyo2" size="mini" />
          </el-col>
        </el-row>
        <el-row class="row-class">
          <el-col class="lab-class">　摘要３</el-col>
          <el-col style= "width: 333px">
            <el-input max-length="5" v-model="formItem.tekiyo3"  size="mini" />
          </el-col>
        </el-row>
        <el-row class="row-class">
          <el-col class="lab-class">　摘要４</el-col>
          <el-col style= "width: 333px">
            <el-input max-length="5" v-model="formItem.tekiyo4"  size="mini" />
          </el-col>
        </el-row>
        <el-row class="row-class">
          <el-col class="lab-class">　摘要５</el-col>
          <el-col style= "width: 333px">
            <el-input max-length="5" v-model="formItem.tekiyo5"  size="mini" />
          </el-col>
        </el-row>
        <el-row class="row-class">
          <el-col class="lab-class">　工事担当箇所</el-col>
          <el-col style= "width: 333px">
            <el-input max-length="6" v-model="formItem.kojiSeisanUserCd"  size="mini" />
          </el-col>
        </el-row>
        <el-row class="row-class">
          <el-col class="lab-class">　工事担当者</el-col>
          <el-col style= "width: 333px">
            <el-input max-length="10" v-model="formItem.kojiTantoUserNm"  size="mini" />
          </el-col>
        </el-row>
      </div>
    </div>
    <el-row>
      <el-col>
        <nsd-button-bar v-bind:buttons="buttonName" v-bind:formItem="formItem"></nsd-button-bar>
      </el-col>
    </el-row>
    <modal-kotei v-if="showModalKotei" @close="showModalKotei = false" @backData="backDataKotei" v-bind:hanteFlg="this.hanteFlg"></modal-kotei>
    <modal-koteioya v-if="showModalKoteioya" @close="showModalKoteioya = false" @backData="backDataKoteiOya"></modal-koteioya>
    <modal-trhks v-if="showModalTrhks" @close="showModalTrhks = false" @backData="backDataTrhks"></modal-trhks>
    <modal-kanri v-if="showModalKanri" @close="showModalKanri = false" @backData="backDataKanri"></modal-kanri>
    <modal-sechi v-if="showModalSechi" @close="showModalSechi = false" @backData="backDataSechi"></modal-sechi>
  </div>
</template>

<script>
import NSDButtonBar from '@/components/common/NSDButtonBar.vue'
import NSDKanrifutankensaku from '@/components/common/modal/NSDKanrifutankensaku'
import NSDKoteisisankensaku from '@/components/common/modal/NSDKoteisisankensaku'
import NSDSechiBashokensaku from '@/components/common/modal/NSDSechiBashokensaku'
import NSDTorihikiSakikensaku from '@/components/common/modal/NSDTorihikiSakikensaku'

export default {
  components: {
    'nsd-button-bar': NSDButtonBar,
    'modal-kotei': NSDKoteisisankensaku,
    'modal-koteioya': NSDKoteisisankensaku,
    'modal-kanri': NSDKanrifutankensaku,
    'modal-sechi': NSDSechiBashokensaku,
    'modal-trhks': NSDTorihikiSakikensaku
  },
  created: function () {
    this.init()
    this.leaseControl()
  },
  methods: {
    init () {
      this.funcHttpPostComm('/comm-getShuNmLst', '', this.getShuNmLstCallBack)
      this.funcHttpPostComm('/comm-getTaniLst', '', this.getTaniLstCallBack)
      this.funcHttpPostComm('/comm-getMeiShouLst', {awkKomokSbt: '103'}, this.getMeiShouLstCallBack)
    },
    getTaniLstCallBack (val) {
      this.optionsTani = val
    },
    getMeiShouLstCallBack (val) {
      this.optionsShutokuRiyu = val
    },
    getShuNmLstCallBack (val) {
      this.optionsShurui = val
    },
    shuruiChange (val) {
      this.formItem.kouzouCd = ''
      this.formItem.shisanTaniCd = ''
      this.formItem.kamokuCd1 = ''
      this.formItem.kamokuCd2 = ''
      this.formItem.kamokuCd3 = ''
      this.optionsKouzou = []
      this.optionsShisanTani = []
      this.optionsKamoku1 = []
      this.optionsKamoku2 = []
      this.optionsKamoku3 = []
      var param = {shuCod: val}
      this.funcHttpPostComm('/comm-getKouNmLst', param, this.getKouNmLstCallBack)
    },
    getKouNmLstCallBack (val) {
      this.optionsKouzou = val
      this.leaseControl(this.formItem.shuruiCd)
    },
    kouzouChange (val) {
      this.formItem.shisanTaniCd = ''
      this.formItem.kamokuCd1 = ''
      this.formItem.kamokuCd2 = ''
      this.formItem.kamokuCd3 = ''
      this.optionsShisanTani = []
      this.optionsKamoku1 = []
      this.optionsKamoku2 = []
      this.optionsKamoku3 = []
      var param = {shuCod: this.formItem.shuruiCd, kouzou: val}
      this.funcHttpPostComm('/comm-getSaiNmLst', param, this.getSaiNmLstCallBack)
    },
    getSaiNmLstCallBack (val) {
      this.optionsShisanTani = val
    },
    shisanTaniChange (val) {
      this.formItem.kamokuCd1 = ''
      this.formItem.kamokuCd2 = ''
      this.formItem.kamokuCd3 = ''
      this.optionsKamoku1 = []
      this.optionsKamoku2 = []
      this.optionsKamoku3 = []
      var param = {shuCod: this.formItem.shuruiCd, kouzou: this.formItem.kouzouCd, shisanTani: val}
      this.funcHttpPostComm('/comm-getShu4NmLst', param, this.getShu4NmLstCallBack)
    },
    getShu4NmLstCallBack (val) {
      this.optionsKamoku1 = val
    },
    kamokuCd1Change (val) {
      this.formItem.kamokuCd2 = ''
      this.formItem.kamokuCd3 = ''
      this.optionsKamoku2 = []
      this.optionsKamoku3 = []
      var param = {shuCod: this.formItem.shuruiCd, kouzou: this.formItem.kouzouCd, shisanTani: this.formItem.shisanTaniCd, kamoku1: val}
      this.funcHttpPostComm('/comm-getShu5NmLst', param, this.getShu5NmLstCallBack)
    },
    getShu5NmLstCallBack (val) {
      this.optionsKamoku2 = val
      this.leaseControl(this.formItem.shuruiCd, val)
    },
    kamokuCd2Change (val) {
      this.formItem.kamokuCd3 = ''
      this.optionsKamoku3 = []
      var param = {
        shuCod: this.formItem.shuruiCd,
        kouzou: this.formItem.kouzouCd,
        shisanTani: this.formItem.shisanTaniCd,
        kamoku1: this.formItem.kamokuCd1,
        kamoku2: val
      }
      this.funcHttpPostComm('/comm-getShu6NmLst', param, this.getShu6NmLstCallBack)
    },
    getShu6NmLstCallBack (val) {
      this.optionsKamoku3 = val
    },
    kamokuCd3Change (val) {
      this.leaseControl(this.formItem.shuruiCd, this.formItem.kamokuCd1, val)
    },
    backDataKotei (val) {
      this.formItem.koteiShisanNo = val['koteiNo']
      this.formItem.koteiShisanId = val['koteiCod']
      this.formItem.getYmd = val['getYmd']
      this.formItem.shutokuYmd = val['getYmd']
    },
    backDataKoteiOya (val) {
      this.formItem.oyaKoteiShisanNo = val['koteioyaNo']
      this.formItem.oyaKoteiShisanEda = val['edaBan']
    },
    backDataTrhks (val) {
      this.formItem.torihikiSakiCd = val['abbTorihkCod']
      this.formItem.torihikiSakiNm = val['abbTorihkKnj']
      this.formItem.torihikiSakifYmd = val['abbTekiyfYmd']
      this.formItem.torihikiSakitYmd = val['abbTekiytYmd']
    },
    backDataKanri (val) {
      console.log(val)
      this.formItem.kanriSoshikiCd = val['kanrikasyocd']
      this.formItem.kanriSoshikiNm = val['kanrikasyo']
      this.formItem.kanriSoshikiF = val['kkikanF']
      this.formItem.kanriSoshikiT = val['kkikanT']
      this.formItem.futanSoshikiCd = val['futankasyocd']
      this.formItem.futanSoshikiNm = val['futankasyo']
      this.formItem.futanSoshikiF = val['fkikanF']
      this.formItem.futanSoshikiT = val['fkikanT']
    },
    backDataSechi (val) {
      this.formItem.sechiBashoCd = val['sechiBashoCd']
      this.formItem.sechiBashoNm = val['sechiBashoNm']
    },
    leaseControl (shuCd, shu4Cd, shu6Cd) {
      if (shuCd === '12' || shuCd === '42' || shuCd === '43' || shuCd === '51' || shuCd === '61' || shu4Cd === '305') {
        this.ztaiyoYmFlg = true
        this.torihikiFlg = true
        this.torihikiBtnFlg = true
      } else {
        this.ztaiyoYmFlg = false
        this.torihikiFlg = false
        this.torihikiBtnFlg = false
        this.formItem.torihikiSakiCd = ''
        this.formItem.torihikiSakiNm = ''
        if (shu6Cd === '99') {
          this.torihikiFlg = true
          this.torihikiBtnFlg = true
        }
      }
    },
    succesCallBack (val) {
      console.log(val)
    }
  },
  data () {
    return {
      showModalKotei: false,
      showModalKoteioya: false,
      showModalKanri: false,
      showModalSechi: false,
      showModalTrhks: false,
      buttonName: [
        {name: this.$CONST_.buttonName.INSERT, primary: true, show: true, action: 'insert', url: '/seisanshoShutoku-insert', callBack: this.succesCallBack, msg: '登録しますか？'},
        {name: this.$CONST_.buttonName.RESET, primary: true, show: true, action: 'reset', url: ''}
      ],
      hanteFlg: '1',
      optionsShurui: [],
      optionsKouzou: [],
      optionsShisanTani: [],
      optionsKamoku1: [],
      optionsKamoku2: [],
      optionsKamoku3: [],
      optionsTani: [],
      optionsShutokuRiyu: [],
      sechiBashoList: [],
      ztaiyoYmFlg: true,
      torihikiFlg: true,
      torihikiBtnFlg: false,
      formItem: {
        koteiShisanNo: '',
        oyaKoteiShisanNo: '',
        oyaKoteiShisanEda: '',
        shutokuYmd: '',
        koteiShisanNm: '',
        shuruiCd: '',
        kouzouCd: '',
        shisanTaniCd: '',
        kamokuCd1: '',
        kamokuCd2: '',
        kamokuCd3: '',
        taiyoNensuZei: '',
        torihikiSakiCd: '',
        torihikiSakiNm: '',
        seizoKaishaNm: '',
        seihinNm: '',
        kataban: '',
        suryo: '0.00',
        taniCd: '',
        buppinGaku: '0',
        kouhiGaku: '0',
        souKeihiGaku: '0',
        kanriSoshikiCd: '',
        kanriSoshikiNm: '',
        futanSoshikiCd: '',
        futanSoshikiNm: '',
        sechiBashoCd: '',
        sechiBashoNm: '',
        shutokuRiyuCd: '',
        tekiyo1: '',
        tekiyo2: '',
        tekiyo3: '',
        tekiyo4: '',
        tekiyo5: '',
        kojiTantoUserNm: '',
        kojiSeisanUserCd: ''
      }
    }
  }
}
</script>

<style scoped>
.page-style {
  font-size: 12px;
  margin-left:10px;
  width: 476px;
  border: 1px solid;
  padding-top: 1px;
}
.row-class {
  height: 30px;
  margin-bottom: 1px;
  margin-left: 1px;
  margin-right: 1px;
}
.lab-class {
  line-height: 30px;
  width: 140px;
  background-color: #77cad8;
  margin-right: 1px;
}
.scroll-box {
  height: 535px;
  overflow-y: auto;
}
.input-group {
  line-height: normal;
  display: inline-table;
  width: 100%;
  border-collapse: separate;
}
.label-input-class {
  border-top-right-radius: 0;
  border-bottom-right-radius: 0;
}
.span-class {
 color: red;
 float: right;
}
</style>
