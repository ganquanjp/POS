<template>
  <div>
    <div class="page-style">
      <el-row class="row-class">
        <el-col style= "width: 379px; background-color: #2053cc; color: white;">　取得情報</el-col>
      </el-row>
      <el-row class="row-class">
        <el-col class="lab-class">　精算書番号</el-col>
        <el-col style= "width: 237px;">
          <el-input v-model="formItem.seisanShoNo" size="mini" :disabled="true"></el-input>
        </el-col>
      </el-row>
      <el-row class="row-class">
        <el-col class="lab-class">　処理No</el-col>
        <el-col style= "width: 237px;">
          <input v-model="formItem.hansu" size="mini" class="nsd-input-class" disabled="disabled">
        </el-col>
      </el-row>
      <el-row class="row-class">
        <el-col class="lab-class">　使用開始年月日</el-col>
        <el-col style= "width: 237px;">
          <el-input v-model="formItem.siyoStartYmd" size="mini" :disabled="true"></el-input>
        </el-col>
      </el-row>
      <el-row class="row-class">
        <el-col class="lab-class">　取得価額合計</el-col>
          <el-col class="input-group" style= "width: 237px">
            <vue-numeric currency="\" separator="," v-model="formItem.shutokuKagakuGoke" size="mini" class="nsd-input-class label-input-class" disabled="disabled" style="cursor: default;"></vue-numeric>
            </input>
          </el-col>
      </el-row>
      <el-row class="row-class">
        <el-col class="lab-class">　承認状態<span class="span-class">（必須）</span></el-col>
        <el-col style= "width: 237px;">
            <el-select v-model="formItem.shoninStatus" size="mini" style="width: 237px;">
              <el-option
                v-for="item in shoninStatusList"
                :key="item.cd1"
                :label="item.cdKnj"
                :value="item.cd1">
              </el-option>
            </el-select>
        </el-col>
      </el-row>
      <el-row class="row-class">
        <el-col class="lab-class">　工事件名</el-col>
        <el-col style= "width: 237px;">
          <el-input v-model="formItem.kenmeiNm" size="mini" :disabled="true"></el-input>
        </el-col>
      </el-row>
    </div>
    <div style= "height: 25px; width: 700px;">
      <div style="position: absolute; top: 225px; left: 10px;">
        <span style="font-size: 12px;">{{this.formItem.shutokuSisanLst.length}}件</span>
      </div>
      <div style="position: absolute; top: 215px; right: 0px;">
        <el-pagination
          background
          @size-change="handleSizeChange"
          @current-change="handleCurrentChange"
          :current-page.sync="pageData.currentPage"
          :page-sizes="pageData.pageSizeArr"
          :page-size="pageData.pageSizeAct"
          layout="prev, pager, next"
          prev-text="前へ"
          next-text="次へ"
          :total="this.formItem.shutokuSisanLst.length">
        </el-pagination>
      </div>
    </div>
    <div style="margin-left: 10px;">
      <el-table
        :data="this.formItem.shutokuSisanLst"
        border
        max-height= 287>
        <el-table-column
          prop="rowNo"
          label="NO."
          min-width="70px">
        </el-table-column>
        <el-table-column
          prop="koteisisanno"
          label="固定資産番号"
          min-width="120px">
        </el-table-column>
        <el-table-column
          prop="koteisisanmeisho"
          label="固定資産名称"
          width="250px">
        </el-table-column>
        <el-table-column
          prop="syutokuymd"
          label="取得年月日"
          min-width="120px">
        </el-table-column>
        <el-table-column
          prop="syutokukagaku"
          label="取得価額"
          header-align=left
          align=right
          min-width="120px">
        </el-table-column >
      </el-table>
    </div>
    <div>
      <nsd-button-bar v-bind:buttons="buttonName" v-bind:formItem="formItem"></nsd-button-bar>
    </div>
  </div>
</template>
<script scoped>
import NSDButtonBar from '@/components/common/NSDButtonBar.vue'

export default {
  components: {
    'nsd-button-bar': NSDButtonBar
  },
  created: function () {
    this.loadShoninStatus()
    this.resetInitData = JSON.parse(JSON.stringify(this.$store.state.tableData))
    this.formItem = JSON.parse(JSON.stringify(this.$store.state.tableData))
  },
  methods: {
    loadShoninStatus () {
      var searchWhere = {
        cdShubetsu: this.$CONST_.cdShubetsu.SHONIN_STATUS,
        cd1Arr: [
          this.$CONST_.shoninStatus.TOROKU,
          this.$CONST_.shoninStatus.SHONIN
        ]
      }
      this.funcHttpPostComm('/comm-getCodeShubetsuList', searchWhere, this.loadShoninStatusCallBack)
    },
    loadShoninStatusCallBack (val) {
      this.shoninStatusList = val
    },
    handleSizeChange (index) {
      this.pageData.pageSizeAct = index
      this.initTableList(1)
    },
    handleCurrentChange (index) {
      this.initTableList(index)
    },
    initTableList (index) {
      this._initPageData(index)
      this.getPageData()
    },
    _initPageData (index) {
      this.pageData.pageNum = (index - 1) * this.pageData.pageSizeAct
      this.pageData.currentPage = index
    },
    getPageData () {
      this.$store.state.currentPageData = this.$store.state.tableData.shutokuSisanLst.slice(this.pageData.pageSizeAct * (this.pageData.currentPage - 1), this.pageData.pageSizeAct * this.pageData.currentPage)
    }
  },
  data () {
    return {
      buttonName: [
        {name: this.$CONST_.buttonName.UPDATE, primary: true, show: true, action: 'popup', url: '/seisanshoshutokuShoninkosin-updateInfo', backUrl: 'nsdstkshoninshokai', msg: '更新しますか？'},
        {name: this.$CONST_.buttonName.RESET, primary: true, show: true, action: 'reset', url: '', msg: 'リセットしますか？'},
        {name: this.$CONST_.buttonName.BACK, primary: true, show: true, action: 'back', url: '', backUrl: 'nsdstkshoninshokai', msg: ''}
      ],
      shoninStatusList: [],
      formItem: {},
      pageData: {
        total: 0,
        pageNum: 0,
        pageSizeArr: this.$CONST_.tableConst.PAGE_SIZES,
        pageSizeAct: this.$CONST_.tableConst.PAGE_SIZE,
        currentPage: 1
      }
    }
  }
}
</script>
<style scoped>
.page-style {
  font-size: 12px;
  width: 381px;
  height: 100%;
  line-height:30px;
  border: 1px solid;
  padding-top: 1px;
  margin-left: 10px;
}
.row-class {
  height: 30px;
  margin-bottom: 1px;
  margin-left: 1px;
  margin-right: 1px;
}
.lab-class {
  width: 140px;
  background-color: #77cad8;
  line-height: 30px;
  margin-right: 1px;
}
.span-class {
 color: red;
 float: right;
}
</style>
