<template>
  <div>
    <div class="page-style">
      <el-row class="row-class">
        <el-col style= "width: 474px; background-color: #2053cc; color: white;">　取得情報</el-col>
      </el-row>
      <el-row class="row-class">
        <el-col class="lab-class">　精算書番号</el-col>
        <el-col style= "width: 303px;">
          <el-input v-model="formItem.seisanShoNo" size="mini" :disabled="true"></el-input>
        </el-col>
      </el-row>
      <el-row class="row-class">
        <el-col class="lab-class">　処理NO</el-col>
        <el-col style= "width: 303px;">
          <input v-model="formItem.hansu" size="mini" class="nsd-input-class" disabled="disabled">
        </el-col>
      </el-row>
      <el-row class="row-class">
        <el-col class="lab-class">　使用開始年月日</el-col>
        <el-col style= "width: 303px;">
          <el-input v-model="formItem.siyoStartYmd" size="mini" :disabled="true"></el-input>
        </el-col>
      </el-row>
      <el-row class="row-class">
        <el-col class="lab-class">　取得価額合計</el-col>
          <el-col class="input-group" style= "width: 303px">
            <vue-numeric currency="\" separator="," v-model="formItem.shutokuKagakuGoke" size="mini" class="nsd-input-class label-input-class" disabled="disabled" style="cursor: default;"></vue-numeric>
            </input>
          </el-col>
      </el-row>
      <el-row class="row-class">
        <el-col class="lab-class">　承認状態<span class="span-class">（必須）</span></el-col>
        <el-col style= "width: 303px;">
            <el-select v-model="formItem.shoninStatus" size="mini" style="width: 303px;">
              <el-option
                v-for="item in shoninStatusList"
                :key="item.cd1"
                :label="item.cdKnj"
                :value="item.cd1">
              </el-option>
            </el-select>
        </el-col>
      </el-row>
      <el-row class="row-class">
        <el-col class="lab-class">　工事件名</el-col>
        <el-col style= "width: 303px;">
          <el-input v-model="formItem.kenmeiNm" size="mini" :disabled="true"></el-input>
        </el-col>
      </el-row>
    </div>
    <el-row>
      <el-col>
        <nsd-button-bar v-bind:buttons="buttonName" v-bind:formItem="this.formItem"></nsd-button-bar>
      </el-col>
    </el-row>
  </div>
</template>

<script>
import NSDButtonBar from '@/components/common/NSDButtonBar.vue'

export default {
  components: {
    'nsd-button-bar': NSDButtonBar
  },
  created: function () {
    this.loadShoninStatus()
    this.resetInitData = JSON.parse(JSON.stringify(this.$store.state.tableData))
    this.formItem = JSON.parse(JSON.stringify(this.$store.state.tableData))
  },
  methods: {
    loadShoninStatus () {
      var searchWhere = {
        cdShubetsu: this.$CONST_.cdShubetsu.SHONIN_STATUS,
        cd1Arr: [
          this.$CONST_.shoninStatus.TOROKU,
          this.$CONST_.shoninStatus.SHONIN
        ]
      }
      this.funcHttpPostComm('/comm-getCodeShubetsuList', searchWhere, this.loadShoninStatusCallBack)
    },
    loadShoninStatusCallBack (val) {
      this.shoninStatusList = val
    },
    resetInit () {
      this.formItem = {}
      this.formItem = JSON.parse(JSON.stringify(this.resetInitData))
    },
    handleSizeChange (index) {
      this.pageData.pageSizeAct = index
      this.initTableList(1)
    },
    handleCurrentChange (index) {
      this.initTableList(index)
    },
    initTableList (index) {
      this._initPageData(index)
      this.getPageData()
    },
    _initPageData (index) {
      this.pageData.pageNum = (index - 1) * this.pageData.pageSizeAct
      this.pageData.currentPage = index
    },
    getPageData () {
      this.$store.state.currentPageData = this.$store.state.tableData.koteiSisanLst.slice(this.pageData.pageSizeAct * (this.pageData.currentPage - 1), this.pageData.pageSizeAct * this.pageData.currentPage)
    }
  },
  data () {
    return {
      buttonName: [
        {name: this.$CONST_.buttonName.UPDATE, primary: true, show: true, action: 'popup', url: '/seisanshoShutokuShonin-updateInfo', backUrl: 'nsdnsssjkkshoninkensku', msg: '更新しますか？'},
        {name: this.$CONST_.buttonName.RESET, primary: true, show: true, action: 'resetInit', url: '', msg: 'リセットしますか？'},
        {name: this.$CONST_.buttonName.BACK, primary: true, show: true, action: 'back', url: '', backUrl: 'nsdstkshoninshokai', msg: ''}
      ],
      shoninStatusList: [],
      formItem: {},
      resetInitData: {}
    }
  }
}
</script>

<style scoped>
.page-style {
  font-size: 12px;
  width: 476px;
  height: 100%;
  margin:10px;
  line-height:30px;
  border: 1px solid;
  padding-top: 1px;
}
.row-class {
  height: 30px;
  margin-bottom: 1px;
  margin-left: 1px;
  margin-right: 1px;
}
.lab-class {
  width: 170px;
  background-color: #77cad8;
  line-height: 30px;
  margin-right: 1px;
}
.input-group {
  line-height: normal;
  display: inline-table;
  width: 100%;
  border-collapse: separate;
}
.label-input-class {
  border-top-right-radius: 0;
  border-bottom-right-radius: 0;
}
.span-class {
 color: red;
 float: right;
}
</style>
