<template>
  <div>
    <el-row>
      <el-col>
        <nsd-content-title v-bind:titlename="titlename" v-bind:message="message"></nsd-content-title>
      </el-col>
    </el-row>
    <el-row>
      <el-col>
        <nsd-update-input></nsd-update-input>
      </el-col>
    </el-row>
  </div>
</template>

<script>
import NsdContentTitle from '@/components/common/NSDContentTitle.vue'
import NSDUpdateInput from '@/components/seisanshoshutoku/shusei/NSDUpdateInput.vue'

export default {
  components: {
    'nsd-content-title': NsdContentTitle,
    'nsd-update-input': NSDUpdateInput
  },
  data () {
    return {
      titlename: '【取得】修正',
      message: ''
    }
  }
}
</script>

<style scoped>
</style>
