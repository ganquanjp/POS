<template>
  <div>
    <el-row>
      <el-col>
        <nsd-content-title v-bind:titlename="titlename" v-bind:message="this.$store.state.message"></nsd-content-title>
      </el-col>
    </el-row>
    <el-row>
      <el-col>
        <nsd-table></nsd-table>
      </el-col>
    </el-row>
  </div>
</template>

<script>
import NsdContentTitle from '@/components/common/NSDContentTitle.vue'
import NSDTable from '@/components/seisanshoshutoku/shoninshokai/NSDTable.vue'

export default {
  components: {
    'nsd-content-title': NsdContentTitle,
    'nsd-table': NSDTable
  },
  created: function () {
    console.log(this.$store.state.message)
  },
  data () {
    return {
      titlename: '【取得承認】照会'
    }
  }
}
</script>

<style scoped>
</style>
