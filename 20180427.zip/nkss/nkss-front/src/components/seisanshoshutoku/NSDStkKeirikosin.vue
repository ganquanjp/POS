<template>
  <div>
    <el-row>
      <el-col>
        <nsd-content-title v-bind:titlename="titlename" v-bind:message="message"></nsd-content-title>
      </el-col>
    </el-row>
    <el-row>
      <el-col>
        <nsd-UpdateInput-bar></nsd-UpdateInput-bar>
      </el-col>
    </el-row>
    <el-row>
      <el-col>
        <nsd-table></nsd-table>
      </el-col>
    </el-row>
  </div>
</template>

<script>
import NsdContentTitle from '@/components/common/NSDContentTitle.vue'
import NSDUpdateInput from '@/components/seisanshoshutoku/keirikosin/NSDUpdateInput.vue'
import NSDTable from '@/components/seisanshoshutoku/keirikosin/NSDTable.vue'

export default {
  components: {
    'nsd-content-title': NsdContentTitle,
    'nsd-UpdateInput-bar': NSDUpdateInput,
    'nsd-table': NSDTable
  },
  data () {
    return {
      titlename: '【取得経理審査/連係】更新',
      message: ''
    }
  }
}
</script>

<style scoped>
</style>
