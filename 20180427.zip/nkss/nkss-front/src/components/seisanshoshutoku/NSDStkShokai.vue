<template>
  <div class="page-style">
    <el-row>
      <el-col>
        <nsd-content-title v-bind:titlename="titlename" v-bind:message="message"></nsd-content-title>
      </el-col>
    </el-row>
    <el-row>
      <el-col>
        <nsd-kihon-jyouhou></nsd-kihon-jyouhou>
      </el-col>
    </el-row>
  </div>
</template>

<script>
import NsdContentTitle from '@/components/common/NSDContentTitle.vue'
import NSDKihonJyouhou from '@/components/seisanshoshutoku/shokai/NSDKihonJyouhou.vue'

export default {
  components: {
    'nsd-content-title': NsdContentTitle,
    'nsd-kihon-jyouhou': NSDKihonJyouhou
  },
  data () {
    return {
      titlename: '【取得】照会',
      message: ''
    }
  }
}
</script>

<style scoped>
</style>
