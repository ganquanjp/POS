<template>
  <transition name="modal">
    <div class="modal-mask">
      <div class="modal-wrapper">
        <div class="modal-container">
          <div class="close-btn-style">
            <el-button type="text" @click="$emit('close')" size="mini"><i class="close icon"></i></el-button>
          </div>
          <div>
            <el-row>
              <el-col>
                <nsd-content-title v-bind:titlename="titlename" v-bind:message="this.$store.state.message"></nsd-content-title>
              </el-col>
            </el-row>
            <div class="scroll-box">
              <el-row>
                <el-col>
                  <nsd-search-input></nsd-search-input>
                </el-col>
              </el-row>
              <el-row v-if="this.$store.state.tableData.length > 0">
                <el-col>
                  <div>
                    <div style="position: relative; padding-top: 10px;">
                     <span style="font-size: 12px;">{{this.$store.state.tableData.length}}件</span>
                      <div style="position: absolute; top: 5px; right: 0px;">
                        <el-pagination
                          background
                          @size-change="handleSizeChange"
                          @current-change="handleCurrentChange"
                          :current-page.sync="this.$store.state.currentPage"
                          :page-sizes="this.pageData.pageSizeArr"
                          :page-size="this.pageData.pageSizeAct"
                          small
                          layout="prev, pager, next"
                          prev-text="前へ"
                          next-text="次へ"
                          :total="this.$store.state.tableData.length">
                        </el-pagination>
                      </div>
                    </div>
                    <el-table style= "padding: -50px;" :data="this.$store.state.currentPageData" border max-height=320 @sort-change="handleSortChange">
                      <el-table-column 
                        prop="rowNo"
                        label="NO."
                        width="75px">
                      </el-table-column>
                      <el-table-column
                        prop="abbTorihkCod"
                        sortable
                        label="取引先コード"
                        width="100px">
                          <template slot-scope="scope">
                            <el-button type="text" size="medium" @click="move(scope.row)">{{substrAbbTorihkCod(scope.row.abbTorihkCod)}}</el-button>
                          </template>
                      </el-table-column >
                      <el-table-column
                         prop="abbTorihkKnj"
                         label="取引先名称"
                         width="300px">
                      </el-table-column>
                      <el-table-column
                         prop="abbTorihkKna"
                         label="取引先カナ名称"
                         width="200px">
                      </el-table-column>
                      <el-table-column
                         prop="abbTorihkYbn"
                         label="郵便番号"
                         width="80px">
                      </el-table-column>
                      <el-table-column
                         prop="abbTorihkAdr"
                         label="取引先住所"
                         width="350px">
                      </el-table-column>
                      <el-table-column
                         prop="abbTorihkTel"
                         label="電話番号"
                         width="150px">
                      </el-table-column>
                      <el-table-column
                         prop="abbTekiyfYmd"
                         sortable
                         label="適用期間(From)"
                         width="130px">
                      </el-table-column>
                      <el-table-column
                         prop="abbTekiytYmd"
                         sortable
                         label="適用期間(To)"
                         width="130px">
                      </el-table-column>
                    </el-table>
                  </div>
                </el-col>
              </el-row>
            </div>
          </div>
        </div>
      </div>
    </div>
  </transition>
</template>

<script scoped>
import NsdContentTitle from '@/components/common/NSDContentTitle.vue'
import NSDSearchInput from '@/components/common/modal/torihikisakikensaku/NSDSearchInput.vue'

export default {
  components: {
    'nsd-content-title': NsdContentTitle,
    'nsd-search-input': NSDSearchInput
  },
  created: function () {
    if (this.$store.state.tableData.length > 0) {
      this.getPageData()
    }
    this.$store.state.tableData = []
    this.$store.state.message.msgLevel = ''
    this.$store.state.message.content = this.$CONST_.msgContent.SEARCH
  },
  destroyed: function () {
    this.funcInitMessage(this.$store)
  },
  data () {
    return {
      titlename: '【取引先】検索',
      pageData: {
        total: 0,
        pageNum: 0,
        pageSizeArr: this.$CONST_.tableConst.PAGE_SIZES,
        pageSizeAct: this.$CONST_.tableConst.PAGE_SIZE,
        visible: false
      }
    }
  },
  methods: {
    move: function (rowData) {
      let para = Object.assign({}, rowData)
      this.$emit('backData', para)
      this.$emit('close')
    },
    handleSizeChange (index) {
      this.pageData.pageSizeAct = index
      this.initTableList(1)
    },
    handleCurrentChange (index) {
      this.initTableList(index)
    },
    initTableList (index) {
      this._initPageData(index)
      this.getPageData()
    },
    _initPageData (index) {
      this.pageData.pageNum = (index - 1) * this.pageData.pageSizeAct
      this.$store.state.currentPage = index
    },
    getPageData () {
      this.$store.state.currentPageData = this.$store.state.tableData.slice(this.pageData.pageSizeAct * (this.$store.state.currentPage - 1), this.pageData.pageSizeAct * this.$store.state.currentPage)
    },
    // ヘッダーにてソートボタンを押すとソート変更する
    handleSortChange ({ column, prop, order }) {
      this.funcSortChange(column, prop, order, this.$store)
      // ページデータ再設定
      this.getPageData()
    },
    substrAbbTorihkCod (abbTorihkCod) {
      if (abbTorihkCod !== undefined) {
        return abbTorihkCod.substring(1, abbTorihkCod.length - 3)
      }
    }
  }
}
</script>

<style scoped>
.modal-mask {
  position: fixed;
  z-index: 1;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background-color: rgba(0, 0, 0, .5);
  display: table;
  transition: opacity .3s ease;
}
.modal-wrapper {
  display: table-cell;
  vertical-align: middle;
}
.modal-container {
  position: relative;
  width: 1170px;
  height: 595px;
  margin: 0 auto;
  margin-top: 10px;
  padding: 10px 15px;
  background-color: #fff;
  border-radius: 2px;
  box-shadow: 0 2px 8px rgba(0, 0, 0, .33);
  transition: all .3s ease;
}
.modal-leave-active .modal-container {
  -webkit-transform: scale(1.1);
  transform: scale(1.1);
}
.close-btn-style {
  position: absolute;
  right: 0px;
  top: 0px;
  padding: 0px;
}
.scroll-box {
  height: 510px;
  overflow-y: auto;
  margin-bottom: 20px;
}
</style>
