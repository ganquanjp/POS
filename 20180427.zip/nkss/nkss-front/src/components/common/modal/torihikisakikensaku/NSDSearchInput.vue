<template>
  <div style="position: relative;">
    <div class="page-style">
      <el-row class="row-class">
        <el-col class="lab-class">　取引先コード</el-col>
        <el-col style= "width: 350px;">
          <el-input v-model="formItem.abbTorihkCod" size="mini"></el-input>
        </el-col>
      </el-row>
      <el-row class="row-class">
        <el-col class="lab-class">　取引先名称</el-col>
        <el-col style= "width: 350px;">
          <el-input v-model="formItem.abbTorihkKnj" size="mini"></el-input>
        </el-col>
      </el-row>
      <el-row class="row-class">
        <el-col class="lab-class">　使用開始年月日</el-col>
        <el-col style= "width: 163px;">
          <el-date-picker
            v-model="formItem.abbTekiyfYmd"
            size="mini"
            style="width: 163px;"
            type="date"
            value-format="yyyy-MM-dd">
          </el-date-picker>
        </el-col>
      </el-row>
    </div>
    <div>
      <el-row >
        <el-col>
          <nsd-button-bar v-bind:buttons="buttonName" v-bind:formItem="formItem"></nsd-button-bar>
        </el-col>
      </el-row>
    </div>
  </div>
</template>

<script>
import NSDButtonBar from '@/components/common/NSDButtonBar.vue'

export default {
  components: {
    'nsd-button-bar': NSDButtonBar
  },
  data () {
    return {
      buttonName: [
        {name: this.$CONST_.buttonName.SEARCH, primary: true, show: true, action: 'post', url: '/sansho-torihikisaki'},
        {name: this.$CONST_.buttonName.RESET, primary: true, show: true, action: 'reset', url: ''}
      ],
      formItem: {
        abbTorihkCod: '',
        abbTorihkKnj: '',
        abbTekiyfYmd: ''
      }
    }
  }
}
</script>

<style scoped>
.page-style {
  font-size: 12px;
  width: 523px;
  height: 100%;
  margin-bottom:10px;
  margin-top:5px;
  line-height:30px;
  border: 1px solid;
  padding-top: 1px;
  padding-right: 1px;
}
.row-class {
  height: 30px;
  margin-bottom: 1px;
  margin-left: 1px;
  margin-right: 1px;
}
.lab-class {
  width: 170px;
  background-color: #77cad8;
  line-height: 30px;
  margin-right: 1px;
}
.div-style {
  position: absolute;
  right: 70px;
  bottom: 0px;
  top: -5px;
}
</style>
