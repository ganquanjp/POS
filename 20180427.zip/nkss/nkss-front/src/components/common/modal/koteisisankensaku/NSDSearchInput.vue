<template>
  <div style="position: relative;">
    <div class="page-style">
     <el-row class="row-class">
       <el-col class="lab-class">　固定資産番号</el-col>
       <el-col style= "width: 350px;">
         <el-input v-model="formItem.koteiNo" size="mini"></el-input>
       </el-col>
     </el-row>
     <el-row class="row-class">
       <el-col class="lab-class">　親固定資産番号</el-col>
       <el-col style= "width: 350px;">
         <el-input v-model="formItem.koteioyaNo" size="mini"></el-input>
       </el-col>
     </el-row>
     <el-row class="row-class">
       <el-col class="lab-class">　固定資産名称</el-col>
       <el-col style= "width: 350px;">
         <el-input v-model="formItem.koteiKnj" size="mini"></el-input>
       </el-col>
     </el-row>
     <el-row class="row-class">
       <el-col class="lab-class">　取得年月日</el-col>
       <el-col style= "width: 163px;">
         <el-date-picker
           v-model="formItem.getYmdFrom"
           size="mini"
           style="width: 163px;"
           type="date"
           value-format="yyyy-MM-dd">
         </el-date-picker>
       </el-col>
       <el-col :span="1"style="line-height: 25px; margin-left: 5px; margin-right: -5px;">－</el-col>
       <el-col style= "width: 163px;">
         <el-date-picker
           v-model="formItem.getYmdTo"
           size="mini"
           style="width: 163px;"
           type="date"
           value-format="yyyy-MM-dd">
         </el-date-picker>
       </el-col>
     </el-row>
      <el-row class="row-class">
        <el-col class="lab-class">　管理箇所名称</el-col>
        <el-col style= "width: 350px;">
          <el-input v-model="formItem.kanriKnj" size="mini"></el-input>
        </el-col>
      </el-row>
      <el-row class="row-class">
        <el-col class="lab-class">　種類</el-col>
        <el-col style= "width: 350px;">
          <el-input v-model="formItem.syurui" size="mini"></el-input>
        </el-col>
      </el-row>
      <el-row class="row-class">
        <el-col class="lab-class">　構造</el-col>
        <el-col style= "width: 350px;">
          <el-input v-model="formItem.kouzo" size="mini"></el-input>
        </el-col>
      </el-row>
      <el-row class="row-class">
        <el-col class="lab-class">　資産単位</el-col>
        <el-col style= "width: 350px;">
          <el-input v-model="formItem.sisanTani" size="mini"></el-input>
        </el-col>
      </el-row>
      <el-row class="row-class">
        <el-col class="lab-class">　科目1</el-col>
        <el-col style= "width: 350px;">
          <el-input v-model="formItem.kamoku1" size="mini"></el-input>
        </el-col>
      </el-row>
      <el-row class="row-class">
        <el-col class="lab-class">　科目2</el-col>
        <el-col style= "width: 350px;">
          <el-input v-model="formItem.kamoku2" size="mini"></el-input>
        </el-col>
      </el-row>
      <el-row class="row-class">
        <el-col class="lab-class">　科目3</el-col>
        <el-col style= "width: 350px;">
          <el-input v-model="formItem.kamoku3" size="mini"></el-input>
        </el-col>
      </el-row>
      <el-row class="row-class">
        <el-col class="lab-class">　設置場所名称</el-col>
        <el-col style= "width: 350px;">
          <el-input v-model="formItem.bashoKnj" size="mini"></el-input>
        </el-col>
      </el-row>
      <el-row class="row-class">
        <el-col class="lab-class">　摘要(連結)</el-col>
        <el-col style= "width: 350px;">
          <el-input v-model="formItem.komkKnj" size="mini"></el-input>
        </el-col>
      </el-row>
      <el-row class="row-class">
        <el-col class="lab-class">　親子資産区分</el-col>
        <el-col style= "width: 350px;">
          <el-select size="mini" style= "width: 350px;" v-model="formItem.oyakosisankubun">
           <el-option
            v-for="item in options"
            :key="item.value"
            :label="item.label"
            :value="item.value">
           </el-option>
          </el-select>
        </el-col>
      </el-row>
      <div class="page-style div-style" style="height: 248px;">
        <el-row class="row-class">
          <el-col class="lab-class">　精算書番号</el-col>
          <el-col style= "width: 350px;">
            <el-input v-model="formItem.seisanShoNo" size="mini"></el-input>
          </el-col>
        </el-row>
        <el-row class="row-class">
          <el-col class="lab-class">　精算箇所</el-col>
          <el-col style= "width: 350px;">
            <el-input v-model="formItem.soshikiRenNm" size="mini"></el-input>
          </el-col>
        </el-row>
        <el-row class="row-class">
          <el-col class="lab-class">　使用開始年月日</el-col>
          <el-col style= "width: 163px;">
            <el-date-picker
              v-model="formItem.useYmdFrom"
              size="mini"
              style="width: 163px;"
              type="date"
              value-format="yyyy-MM-dd">
            </el-date-picker>
          </el-col>
          <el-col :span="1"style="line-height: 25px; margin-left: 5px; margin-right: -5px;">－</el-col>
          <el-col style= "width: 163px;">
            <el-date-picker
              v-model="formItem.useYmdTo"
              size="mini"
              style="width: 163px;"
              type="date"
              value-format="yyyy-MM-dd">
            </el-date-picker>
          </el-col>
        </el-row>
        <el-row class="row-class">
          <el-col class="lab-class">　担当者コード</el-col>
          <el-col style= "width: 350px;">
            <el-input v-model="formItem.seisanEntryUserId" size="mini"></el-input>
          </el-col>
        </el-row>
        <el-row class="row-class">
          <el-col class="lab-class">　登録者氏名</el-col>
          <el-col style= "width: 350px;">
            <el-input v-model="formItem.torokusyaNm" size="mini"></el-input>
          </el-col>
        </el-row>
        <el-row class="row-class">
          <el-col class="lab-class">　工事件名</el-col>
          <el-col style= "width: 350px;">
            <el-input v-model="formItem.kmouwkKnj" size="mini"></el-input>
          </el-col>
        </el-row>
        <el-row class="row-class">
          <el-col class="lab-class">　工事担当箇所</el-col>
          <el-col style= "width: 350px;">
            <el-input v-model="formItem.kojiTantokasyo" size="mini"></el-input>
          </el-col>
        </el-row>
        <el-row class="row-class">
          <el-col class="lab-class">　工事担当者</el-col>
          <el-col style= "width: 350px;">
            <el-input v-model="formItem.kojiTantosya" size="mini"></el-input>
          </el-col>
        </el-row>
      </div>
    </div>
     <el-row >
      <el-col>
        <nsd-button-bar v-bind:buttons="buttonName" v-bind:formItem="formItem"></nsd-button-bar>
      </el-col>
    </el-row>
  </div>
</template>

<script>
import NSDButtonBar from '@/components/common/NSDButtonBar.vue'
export default {
  components: {
    'nsd-button-bar': NSDButtonBar
  },
  data () {
    return {
      buttonName: [
        {name: this.$CONST_.buttonName.SEARCH, primary: true, show: true, action: 'post', url: '/sansho-koteishisan'},
        {name: this.$CONST_.buttonName.RESET, primary: true, show: true, action: 'reset', url: ''}
      ],
      options: [
        {value: '', label: ''},
        {value: '0', label: '親資産'},
        {value: '1', label: '子資産'},
        {value: '2', label: '親無子資産'},
        {value: '3', label: '全資産'}
      ],
      formItem: {
        koteiNo: '',
        koteioyaNo: '',
        koteiKnj: '',
        getYmdFrom: '',
        getYmdTo: '',
        kanriKnj: '',
        syurui: '',
        kouzo: '',
        sisanTani: '',
        kamoku1: '',
        kamoku2: '',
        kamoku3: '',
        bashoKnj: '',
        komkKnj: '',
        oyakosisankubun: '',
        seisanShoNo: '',
        soshikiRenNm: '',
        useYmdFrom: '',
        useYmdTo: '',
        seisanEntryUserId: '',
        torokusyaNm: '',
        kmouwkKnj: '',
        kojiTantokasyo: '',
        kojiTantosya: ''
      }
    }
  }
}
</script>

<style scoped>
.page-style {
  font-size: 12px;
  width: 523px;
  height: 100%;
  margin-bottom:10px;
  margin-top:5px;
  line-height:30px;
  border: 1px solid;
  padding-top: 1px;
  padding-right: 1px;
}
.row-class {
  height: 30px;
  margin-bottom: 1px;
  margin-left: 1px;
  margin-right: 1px;
}
.lab-class {
  width: 170px;
  background-color: #77cad8;
  line-height: 30px;
  margin-right: 1px;
}
.div-style {
  position: absolute;
  right: 70px;
  bottom: 0px;
  top: -5px;
}
</style>
