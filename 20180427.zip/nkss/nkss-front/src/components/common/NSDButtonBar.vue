<template>
  <div style= "padding: 10px;">
    <el-row>
      <el-col style="width:300px">
        <el-button
          v-for="(btn, key) in buttons"
          v-if="btn.show"
          class="button-style"
          size="mini"
          v-bind:disabled=btn.disabled
          v-bind:type="btn.primary ? 'primary' : '' "
          v-bind:key="key"
          @click="btnClick(btn.action, btn.url, btn.backUrl, btn.msg, btn.callBack)">
          {{ btn.name }}
        </el-button>
        <!-- 更新ボタン制御用、除去不可-->
        <el-input v-if="notshow" size="mini"></el-input>
      </el-col>
    </el-row>
  </div>
</template>

<script>
export default {
  props: ['buttons', 'formItem'],
  created () {
    this.btnUpdateDisable()
  },
  computed: {
    notshow: function () {
      if (this.$store.state.tableData.length === 0) {
        return false
      } else {
        return false
      }
    }
  },
  updated () {
    this.btnUpdateDisable()
  },
  methods: {
    // 更新ボタン制御
    btnUpdateDisable: function () {
      var disabledFlg = this.$store.state.tableData.length === 0
      for (var i in this.buttons) {
        if (this.buttons[i].id === 'update') {
          this.buttons[i].disabled = disabledFlg
        }
      }
    },
    // ボタン押下
    btnClick: function (action, url, backUrl, msg, callBack) {
      if (action === 'post') {
        this.funcClearStoreData()
        this.funcInputSave(this.formItem)
        this.funcHttpPost(url, this.formItem)
      } else if (action === 'resetInit') {
        this.$confirm(msg, '確認', {
          confirmButtonText: 'OK',
          cancelButtonText: 'キャンセル',
          type: 'info',
          showClose: false
        }).then(() => {
          this.$emit('resetInit')
        }).catch(() => {
          /*
          this.$message({
            type: 'info',
            message: 'キャンセルしました。'
          })
          */
        })
      } else if (action === 'reset') {
        this.$confirm(msg, '確認', {
          confirmButtonText: 'OK',
          cancelButtonText: 'キャンセル',
          type: 'info',
          showClose: false
        }).then(() => {
          this.funcFormReset(this.formItem)
        }).catch(() => {
          /*
          this.$message({
            type: 'info',
            message: 'キャンセルしました。'
          })
          */
        })
      } else if (action === 'insert') {
        this.$confirm(msg, '確認', {
          confirmButtonText: 'OK',
          cancelButtonText: 'キャンセル',
          type: 'info',
          showClose: false
        }).then(() => {
          this.funcHttpPostComm(url, this.formItem, callBack, 'I')
        }).catch(() => {
          /*
          this.$message({
            type: 'info',
            message: 'キャンセルしました。'
          })
          */
        })
      } else if (action === 'httpPost') {
        this.funcInitMessage(this.$store)
        this.funcHttpPostComm(url, this.formItem, callBack)
      } else if (action === 'back') {
        this.funcInitMessage(this.$store)
        this.$router.push(backUrl)
      } else if (action === 'popup') {
        this.$confirm(msg, '確認', {
          confirmButtonText: 'OK',
          cancelButtonText: 'キャンセル',
          type: 'info',
          showClose: false
        }).then(() => {
          this.funcHttpPost(url, this.formItem, backUrl)
          this.funcClearStoreData()
        }).catch(() => {
          /*
          this.$message({
            type: 'info',
            message: 'キャンセルしました。'
          })
          */
        })
      } else {
        console.log('action null ok!')
      }
    }
  }
}
</script>

<style scoped>
.button-style {
  width: 80px;
}
</style>
