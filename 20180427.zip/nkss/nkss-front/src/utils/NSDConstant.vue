<script type="text/javascript">
const tableConst = {
  PAGE_SIZES: [5, 10, 25, 50],
  PAGE_SIZE: 25
}

const buttonName = {
  SEARCH: '検索',
  RESET: 'リセット',
  INSERT: '登録',
  UPDATE: '更新',
  MODIFY: '修正',
  DELETE: '削除',
  PRINT: '印刷',
  BACK: '戻る',
  EXEC: '実行',
  REDO: '再作成'
}

const msgContent = {
  SEARCH: '検索キーを入力してください。',
  INSERT: '登録内容を入力してください。',
  UPDATE: '更新内容を入力してください。',
  RENKEI: '連携する対象を選択してください。',
  DAICHO: '再作成ボタンを押下してください。'
}

/*
const shoninStatus = {
  TOROKU: {CD: '00', NAME: '登録中'},
  TEISHUTSU: {CD: '01', NAME: '承認済(経理提出)'},
  SHINSA: {CD: '02', NAME: 'データ連係済'},
  JYOKYA: {CD: '03', NAME: '除却済'},
  HININ: {CD: '20', NAME: '経理審査否認'}
}
*/

const cdShubetsu = {
  SHONIN_STATUS: 'CD0005' // 承認状態
}

const shoninStatus = {
  TOROKU: '00', // 登録中
  SHONIN: '01', // 承認済(経理提出)
  RENKEI: '02', // データ連係済
  JYOKYA: '03', // 除却済
  HININ: '20' // 経理審査否認
}

const urlPath = {
  OUTPUT_EXCEL: '/download/excel/',
  OUTPUT_PDF: '/download/pdf/'
}

export default
{
  tableConst,
  buttonName,
  msgContent,
  cdShubetsu,
  shoninStatus,
  urlPath
}
</script>
