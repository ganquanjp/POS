import qs from 'qs'

export default{
  install (Vue, options) {
    Vue.prototype.$baseURL = '/nkss-web'
    Vue.prototype.headers = {'Content-Type': 'application/x-www-form-urlencoded'}
    Vue.prototype.$formObj = null

    Vue.prototype.funcHttpPost = function (url, requestData, moveUrl) {
      url = this.$baseURL + url
      var _store = this.$store
      var _router = this.$router
      var _alert = this.$alert
      var _const = this.$CONST_

      this.$http.post(url, qs.stringify(requestData), this.headers)
      .then(function (response) {
        console.log(response.data)
        if (typeof (response.data.msg) === 'undefined') {
          Vue.prototype.funcInitMessage(_store)
        } else {
          _store.state.message = response.data.msg
        }
        console.log(_store.state.message.msgLevel)
        if (_store.state.message.msgLevel !== 'E') {
          _store.state.tableData = response.data.resultData
          console.log(response.data.resultData)
          if (typeof (response.data.resultData) !== 'undefined') {
            console.log(response.data.resultData.length)
            if (response.data.resultData.length > 0) {
              _store.state.currentPageData = response.data.resultData.slice(0, _const.tableConst.PAGE_SIZE)
            }
          }
          console.log(moveUrl)
          if (moveUrl !== undefined) {
            _router.push({name: moveUrl})
          }
        }
      })
      .catch(function (error) {
        funcHttpError(_store, _alert, error, _router)
        console.log(error)
      })
    }

    Vue.prototype.funcHttpGet = function (url, action) {
      url = this.$baseURL + url
      var _store = this.$store
      var _router = this.$router
      var _alert = this.$alert

      this.$http.get(url)
      .then(function (response) {
        if (action === 'filedownload') {
          window.location.href = url
        }
      })
      .catch(function (error) {
        funcHttpError(_store, _alert, error, _router)
      })
    }

    Vue.prototype.funcGetDropDownValue = function (url, itemNames) {
      url = this.$baseURL + url
      var _store = this.$store
      var _router = this.$router
      var _alert = this.$alert
      var resultArray = []

      this.$http.get(url).then(function (response) {
        response.data.resultData.forEach(function (row, index, array) {
          var obj = {}
          obj['value'] = row[itemNames[0]]
          for (var item in itemNames) {
            if (item > 0) {
              obj[itemNames[item]] = row[itemNames[item]]
            }
          }
          resultArray[index] = obj
        })
      })
      .catch(function (error) {
        funcHttpError(_store, _alert, error, _router)
        console.log(error)
      })
      return resultArray
    }

    Vue.prototype.funcHttpPostComm = function (url, requestData, funcCallBack, kbn = 'R') {
      url = this.$baseURL + url
      var _store = this.$store
      var _router = this.$router
      var _alert = this.$alert
      this.$http.post(url, qs.stringify(requestData), this.headers)
      .then(function (response) {
        if (typeof (response.data.msg) !== 'undefined') {
          _store.state.message = response.data.msg
        }
        // 検索の場合
        if (kbn === 'R') {
          funcCallBack(response.data.resultData)
        } else {
          if (_store.state.message.msgLevel !== 'E') {
            funcCallBack(response.data.resultData)
          }
        }
      })
      .catch(function (error) {
        funcHttpError(_store, _alert, error, _router)
        console.log(error)
      })
    }

    // サーバーに接続できない場合
    function funcHttpError (_store, _alert, error, _router) {
      if (error.response) {
        _store.state.message.msgLevel = 'E'
        if (error.response.status === 401) {
          _store.state.message.content = 'セッションを切断しました。再度ログインしてください。'
          _router.push({name: 'nsdlogininput'})
          return
        } else if (error.response.status === 404) {
          _store.state.message.content = '該当ファイルは存在しません。'
        } else {
          _store.state.message.content = 'サーバーメンテナンス中......'
        }
      }

      _alert(_store.state.message.content, 'エラー', {
        confirmButtonText: 'OK',
        callback: action => {
          /* 動作なし */
        }
      })
    }

    // messageの初期化
    Vue.prototype.funcInitMessage = function (_store) {
      _store.state.message = {msgId: '', msgLevel: '', content: ''}
    }

    Vue.prototype.funcClearData = function () {
      var _store = this.$store
      _store.state.tableData = []
      _store.state.currentPageData = []
      _store.state.currentPage = 1
      _store.state.sortItem = {}
      _store.state.preGamenData = {}
    }

    Vue.prototype.funcClear = function () {
      var _store = this.$store
      Vue.prototype.funcInitMessage(_store)
      _store.state.tableData = []
      _store.state.currentPageData = []
      _store.state.currentPage = 1
      _store.state.sortItem = {}
    }

    Vue.prototype.funcFormReset = function (formItem) {
      for (var key in formItem) {
        if (formItem[key] instanceof Array) {
          var itemLst = JSON.parse(JSON.stringify(formItem[key]))
          formItem[key] = []
          for (var lstkey in itemLst) {
            itemLst[lstkey] = {}
            itemLst[lstkey] = {rowNo: parseInt(lstkey) + 1}
          }
          formItem[key] = itemLst
        } else {
          formItem[key] = ''
        }
      }
    }

    // storeに保存したデータをクリアする
    Vue.prototype.funcClearStoreData = function () {
      var _store = this.$store
      Vue.prototype.funcInitMessage(_store)
      _store.state.tableData = []
      _store.state.currentPageData = []
      _store.state.currentPage = 1
      _store.state.sortItem = {}
      _store.state.preGamenData = {}
    }

    // storeに画面の入力項目値を保存する
    Vue.prototype.funcInputSave = function (formItem) {
      this.$store.state.preGamenData.inputData = formItem
    }

    // storeに画面の一覧データを保存する
    Vue.prototype.funcDataSave = function () {
      this.$store.state.preGamenData.tableData = this.$store.state.tableData
    }

    // storeに前画面のデータを復旧する
    Vue.prototype.funcDataRestore = function () {
      var _store = this.$store
      var _const = this.$CONST_

      if (typeof (_store.state.preGamenData.tableData) !== 'undefined' &&
      _store.state.preGamenData.tableData.length > 0) {
        _store.state.tableData = _store.state.preGamenData.tableData
        _store.state.currentPageData = _store.state.tableData.slice(0, _const.tableConst.PAGE_SIZE)
        _store.state.preGamenData.tableData = []
      }
    }
  }
}
