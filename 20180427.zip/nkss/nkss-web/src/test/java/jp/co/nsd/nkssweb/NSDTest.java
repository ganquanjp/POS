package jp.co.nsd.nkssweb;

import java.io.UnsupportedEncodingException;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import org.apache.commons.lang.time.DateUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import jp.co.nsd.nkssweb.utils.NSDDateUtils;
import net.sf.jasperreports.engine.JREmptyDataSource;
import net.sf.jasperreports.engine.JasperCompileManager;
import net.sf.jasperreports.engine.JasperExportManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;

public class NSDTest {

	private static final Logger logger = LoggerFactory.getLogger(NSDTest.class);

	public static void main(String[] args) throws UnsupportedEncodingException {
		// TODO 自動生成されたメソッド・スタブ
		logger.info("NSDTest.main start!");
		test2();

		// createPDF();
	}

	private static void test2() throws UnsupportedEncodingException {
		String date = NSDDateUtils.Now("yyyy-MM-dd HH:mm:ss.SSS");
		String str = "○あああああ";

		String bb = new String(str.getBytes("ISO-8859-1"), "shift-jis");
		String cc = new String(str.getBytes("ISO-8859-1"), "UTF-8");

		logger.info("shift-jis : " + String.valueOf(bb));
		logger.info("utf-8 : " + String.valueOf(cc));
		logger.info("shift-jis to ISO-8859-1 : " + new String(bb.getBytes("shift-jis"), "ISO-8859-1"));
		logger.info("utf-8 to ISO-8859-1 : " + new String(cc.getBytes("UTF-8"), "ISO-8859-1"));

		int dd = str.getBytes("shift-jis").length;
		int ee = str.getBytes("utf-8").length;
		logger.info("ISO-8859-1 : " + str.getBytes().length);
		logger.info("shift-jis : " + String.valueOf(dd));
		logger.info("utf-8 : " + String.valueOf(ee));
	}

	private void test1() {
		Calendar calendar = Calendar.getInstance();

		java.text.SimpleDateFormat format = new java.text.SimpleDateFormat("yyyy-MM-01");
		java.util.Date beginDate = DateUtils.addMonths(calendar.getTime(), -4);
		logger.info(format.format(beginDate));

		java.util.Date ddd = DateUtils.addDays(calendar.getTime(), +7);
		logger.info(ddd.toString());
		java.util.Date eee = DateUtils.addMonths(ddd, -2);
		logger.info(format.format(eee));
	}

	public static final Date stringToDate(String ymd, String format) {
		Date date = new Date();
		System.out.println(date);
		return date;
	}

	public static void createPDF() {

		String path = "C:\\workspace\\nkss\\nkss-web\\src\\main\\resources\\reports\\";
		String jrxmlFile = path.concat("SamplePDF.jrxml");
		String jasperFile = path.concat("SamplePDF.jasper");
		String outputfile = path.concat("SamplePDF.pdf");

		try {
			// InputStream employeeReportStream =
			// getClass().getResourceAsStream(jrxmlFile);
			// JasperReport jasperReport
			// = JasperCompileManager.compileReport(employeeReportStream);
			JasperCompileManager.compileReportToFile(jrxmlFile, jasperFile);
			// JRPdfExporter exporter = new JRPdfExporter();
			JasperPrint jasperPrint = (JasperPrint) JasperFillManager.fillReport(jasperFile, data(),
					new JREmptyDataSource());
			// JasperRunManager.runReportToPdf(jasperFile, data());
			JasperExportManager.exportReportToPdfFile(jasperPrint, outputfile);

		} catch (Exception e) {
			// TODO 自動生成された catch ブロック
			e.printStackTrace();
		}

	}

	public static Map<String, Object> data() {
		Map<String, Object> data = new HashMap<String, Object>();
		data.put("user_id", "0001");
		return data;
	}

}
