package jp.co.nsd.nkssweb.dao;

import java.math.BigDecimal;
import java.util.List;

public class SeisanshoShutokuKrsk {

	// 精算書番号
	private String SeisanShoNo;

	// 精算箇所
	private String soshikiRenNm;

	// 処理No
	private BigDecimal hansu;

	// 取得価額合計
	private String shutokuKagakuGoke;

	// 承認ステータス
	private String shoninStatus;

	// 経理審査否認理由
	private String riyu;

	// 工事件名
	private String kenmeiNm;

	// 工事件名コード
	private String kenmeiCd;

	// 決算スケジュール情報

	// 会計整理年月日
	private String kaikeiYm;

	// 入力開始日
	private String infromYmd;

	// 入力終了日
	private String intoYmd;

	// 承認期限日
	private String snkigYmd;

	// 月次締切日
	private String getsjsYmd;

	// 月次締切通告日時
	private String getsmtDh;

	// 年度末処理日
	private String nendmtYmd;

	// 更新カウンタ
	private BigDecimal updateCnt;

	// 登録日時
	private String torokDh;

	// 登録者コード
	private String torshaCod;

	// 更新日時
	private String updateDh;

	// 更新者コード
	private String updshaCod;

	//組織定数情報

	// 組織コード
	private String ksSoshikCod;

	// 適用期間(From)
	private String ksTekiyfYmd;

	// 適用期間(To)
	private String ksTekiytYmd;

	// 発行組織フラグ
	private String ksSiyoFlg;

	// 責任組織使用可能フラグ
	private String ksSeksokFlg;

	// 責任組織初期値
	private String ksSeksosDef;

	// 組織名称
	private String ksSoshikKnj;

	// 資金予算代行権限フラグ
	private String ksSydaikFlg;

	// 上位組織コード
	private String ksJoisosCod;

	// 検索可能上位組織コード
	private String ksShuyk1Cod;

	// 管理会計上位組織コード
	private String ksShuyk2Cod;

	// 集約組織コード３
	private String ksShuyk3Cod;

	// 経理審査承認組織コード
	private String ksKsssosCod;

	// 小払精算方法区分
	private String ksKossanCbn;

	// 出納組織区分
	private String ksStsoshCbn;

	// 出納組織コード
	private String ksStsoshCod;

	// 出納先組織使用可能フラグ
	private String ksStssosFlg;

	// 組織区分
	private String ksSoshikKbn;

	// 適用期間(To)無効フラグ
	private String ksTekingFlg;

	// 更新カウンタ
	private BigDecimal ksUpdateCnt;

	// 登録日時
	private String ksTorokDh;

	// 登録者コード
	private String ksTorshaCod;

	// 更新日時
	private String ksUpdateDh;

	// 更新者コード
	private String ksUpdshaCod;

	// 決算スケジュール情報
	private List<Aads01> keSanLst;

	// 組織定数情報
	private List<Abda09> soSkLst;

	public String getSeisanShoNo() {
		return SeisanShoNo;
	}

	public void setSeisanShoNo(String seisanShoNo) {
		SeisanShoNo = seisanShoNo;
	}

	public String getSoshikiRenNm() {
		return soshikiRenNm;
	}

	public void setSoshikiRenNm(String soshikiRenNm) {
		this.soshikiRenNm = soshikiRenNm;
	}

	public BigDecimal getHansu() {
		return hansu;
	}

	public void setHansu(BigDecimal hansu) {
		this.hansu = hansu;
	}

	public String getShutokuKagakuGoke() {
		return shutokuKagakuGoke;
	}

	public void setShutokuKagakuGoke(String shutokuKagakuGoke) {
		this.shutokuKagakuGoke = shutokuKagakuGoke;
	}

	public String getShoninStatus() {
		return shoninStatus;
	}

	public void setShoninStatus(String shoninStatus) {
		this.shoninStatus = shoninStatus;
	}

	public String getRiyu() {
		return riyu;
	}

	public void setRiyu(String riyu) {
		this.riyu = riyu;
	}

	public String getKenmeiNm() {
		return kenmeiNm;
	}

	public void setKenmeiNm(String kenmeiNm) {
		this.kenmeiNm = kenmeiNm;
	}

	public String getKenmeiCd() {
		return kenmeiCd;
	}

	public void setKenmeiCd(String kenmeiCd) {
		this.kenmeiCd = kenmeiCd;
	}

	public String getKaikeiYm() {
		return kaikeiYm;
	}

	public void setKaikeiYm(String kaikeiYm) {
		this.kaikeiYm = kaikeiYm;
	}

	public String getInfromYmd() {
		return infromYmd;
	}

	public void setInfromYmd(String infromYmd) {
		this.infromYmd = infromYmd;
	}

	public String getIntoYmd() {
		return intoYmd;
	}

	public void setIntoYmd(String intoYmd) {
		this.intoYmd = intoYmd;
	}

	public String getSnkigYmd() {
		return snkigYmd;
	}

	public void setSnkigYmd(String snkigYmd) {
		this.snkigYmd = snkigYmd;
	}

	public String getGetsjsYmd() {
		return getsjsYmd;
	}

	public void setGetsjsYmd(String getsjsYmd) {
		this.getsjsYmd = getsjsYmd;
	}

	public String getGetsmtDh() {
		return getsmtDh;
	}

	public void setGetsmtDh(String getsmtDh) {
		this.getsmtDh = getsmtDh;
	}

	public String getNendmtYmd() {
		return nendmtYmd;
	}

	public void setNendmtYmd(String nendmtYmd) {
		this.nendmtYmd = nendmtYmd;
	}

	public BigDecimal getUpdateCnt() {
		return updateCnt;
	}

	public void setUpdateCnt(BigDecimal updateCnt) {
		this.updateCnt = updateCnt;
	}

	public String getTorokDh() {
		return torokDh;
	}

	public void setTorokDh(String torokDh) {
		this.torokDh = torokDh;
	}

	public String getTorshaCod() {
		return torshaCod;
	}

	public void setTorshaCod(String torshaCod) {
		this.torshaCod = torshaCod;
	}

	public String getUpdateDh() {
		return updateDh;
	}

	public void setUpdateDh(String updateDh) {
		this.updateDh = updateDh;
	}

	public String getUpdshaCod() {
		return updshaCod;
	}

	public void setUpdshaCod(String updshaCod) {
		this.updshaCod = updshaCod;
	}

	public String getKsSoshikCod() {
		return ksSoshikCod;
	}

	public void setKsSoshikCod(String ksSoshikCod) {
		this.ksSoshikCod = ksSoshikCod;
	}

	public String getKsTekiyfYmd() {
		return ksTekiyfYmd;
	}

	public void setKsTekiyfYmd(String ksTekiyfYmd) {
		this.ksTekiyfYmd = ksTekiyfYmd;
	}

	public String getKsTekiytYmd() {
		return ksTekiytYmd;
	}

	public void setKsTekiytYmd(String ksTekiytYmd) {
		this.ksTekiytYmd = ksTekiytYmd;
	}

	public String getKsSiyoFlg() {
		return ksSiyoFlg;
	}

	public void setKsSiyoFlg(String ksSiyoFlg) {
		this.ksSiyoFlg = ksSiyoFlg;
	}

	public String getKsSeksokFlg() {
		return ksSeksokFlg;
	}

	public void setKsSeksokFlg(String ksSeksokFlg) {
		this.ksSeksokFlg = ksSeksokFlg;
	}

	public String getKsSeksosDef() {
		return ksSeksosDef;
	}

	public void setKsSeksosDef(String ksSeksosDef) {
		this.ksSeksosDef = ksSeksosDef;
	}

	public String getKsSoshikKnj() {
		return ksSoshikKnj;
	}

	public void setKsSoshikKnj(String ksSoshikKnj) {
		this.ksSoshikKnj = ksSoshikKnj;
	}

	public String getKsSydaikFlg() {
		return ksSydaikFlg;
	}

	public void setKsSydaikFlg(String ksSydaikFlg) {
		this.ksSydaikFlg = ksSydaikFlg;
	}

	public String getKsJoisosCod() {
		return ksJoisosCod;
	}

	public void setKsJoisosCod(String ksJoisosCod) {
		this.ksJoisosCod = ksJoisosCod;
	}

	public String getKsShuyk1Cod() {
		return ksShuyk1Cod;
	}

	public void setKsShuyk1Cod(String ksShuyk1Cod) {
		this.ksShuyk1Cod = ksShuyk1Cod;
	}

	public String getKsShuyk2Cod() {
		return ksShuyk2Cod;
	}

	public void setKsShuyk2Cod(String ksShuyk2Cod) {
		this.ksShuyk2Cod = ksShuyk2Cod;
	}

	public String getKsShuyk3Cod() {
		return ksShuyk3Cod;
	}

	public void setKsShuyk3Cod(String ksShuyk3Cod) {
		this.ksShuyk3Cod = ksShuyk3Cod;
	}

	public String getKsKsssosCod() {
		return ksKsssosCod;
	}

	public void setKsKsssosCod(String ksKsssosCod) {
		this.ksKsssosCod = ksKsssosCod;
	}

	public String getKsKossanCbn() {
		return ksKossanCbn;
	}

	public void setKsKossanCbn(String ksKossanCbn) {
		this.ksKossanCbn = ksKossanCbn;
	}

	public String getKsStsoshCbn() {
		return ksStsoshCbn;
	}

	public void setKsStsoshCbn(String ksStsoshCbn) {
		this.ksStsoshCbn = ksStsoshCbn;
	}

	public String getKsStsoshCod() {
		return ksStsoshCod;
	}

	public void setKsStsoshCod(String ksStsoshCod) {
		this.ksStsoshCod = ksStsoshCod;
	}

	public String getKsStssosFlg() {
		return ksStssosFlg;
	}

	public void setKsStssosFlg(String ksStssosFlg) {
		this.ksStssosFlg = ksStssosFlg;
	}

	public String getKsSoshikKbn() {
		return ksSoshikKbn;
	}

	public void setKsSoshikKbn(String ksSoshikKbn) {
		this.ksSoshikKbn = ksSoshikKbn;
	}

	public String getKsTekingFlg() {
		return ksTekingFlg;
	}

	public void setKsTekingFlg(String ksTekingFlg) {
		this.ksTekingFlg = ksTekingFlg;
	}

	public BigDecimal getKsUpdateCnt() {
		return ksUpdateCnt;
	}

	public void setKsUpdateCnt(BigDecimal ksUpdateCnt) {
		this.ksUpdateCnt = ksUpdateCnt;
	}

	public String getKsTorokDh() {
		return ksTorokDh;
	}

	public void setKsTorokDh(String ksTorokDh) {
		this.ksTorokDh = ksTorokDh;
	}

	public String getKsTorshaCod() {
		return ksTorshaCod;
	}

	public void setKsTorshaCod(String ksTorshaCod) {
		this.ksTorshaCod = ksTorshaCod;
	}

	public String getKsUpdateDh() {
		return ksUpdateDh;
	}

	public void setKsUpdateDh(String ksUpdateDh) {
		this.ksUpdateDh = ksUpdateDh;
	}

	public String getKsUpdshaCod() {
		return ksUpdshaCod;
	}

	public void setKsUpdshaCod(String ksUpdshaCod) {
		this.ksUpdshaCod = ksUpdshaCod;
	}

	public List<Aads01> getKeSanLst() {
		return keSanLst;
	}

	public void setKeSanLst(List<Aads01> keSanLst) {
		this.keSanLst = keSanLst;
	}

	public List<Abda09> getSoSkLst() {
		return soSkLst;
	}

	public void setSoSkLst(List<Abda09> soSkLst) {
		this.soSkLst = soSkLst;
	}













}