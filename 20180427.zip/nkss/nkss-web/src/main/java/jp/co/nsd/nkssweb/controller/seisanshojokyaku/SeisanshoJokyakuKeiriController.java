/***********************************************************************
*
*業務名: 工事精算システム
*機能名: 除却（経理審査/連携）(ログ出力処理)
*
*機能概要: 除却情報を処理する。
*
*JavaＶｅｒ：J2SE1.8.0準拠
*
*更新履歴: Ver.1.00 2018/03/06　NSD　新規作成
***********************************************************************/

package jp.co.nsd.nkssweb.controller.seisanshojokyaku;

import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.beanutils.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import jp.co.nsd.nkssweb.controller.BaseController;
import jp.co.nsd.nkssweb.dao.Kss006;
import jp.co.nsd.nkssweb.dao.SeisanshoJokyakuKeiri;
import jp.co.nsd.nkssweb.service.SystemService;
import jp.co.nsd.nkssweb.service.seisanshojokyaku.SeisanshoJokyakuKeiriService;
import jp.co.nsd.nkssweb.utils.NSDCommUtils;
import jp.co.nsd.nkssweb.utils.NSDConstant;

/**
 * 除却（経理審査/連携）処理
 *
 * @version 1.00
 */
@RestController
public class SeisanshoJokyakuKeiriController extends BaseController {

	@Autowired
	private SeisanshoJokyakuKeiriService seisanshoJokyakuKeiriService;

	protected SystemService systemService;

	/**
	 * 除却（経理審査/連携）処理
	 *
	 * @param reqMap
	 *            INPUTパラメータ
	 * @return 除却情報データ
	 * @exception Exception
	 * @version 1.00
	 */
	@RequestMapping(value = "/seisanshoJokyakuKeiri-selectByWhere", method = RequestMethod.POST)
	public Map<String, Object> selectByWhere(@RequestParam Map<String, Object> reqMap) throws Exception {

		Map<String, Object> resultMap = new HashMap<String, Object>();

		SeisanshoJokyakuKeiri seisanshoJokyakuKeiri = new SeisanshoJokyakuKeiri();

		List<SeisanshoJokyakuKeiri> sssJkkKrLst = new ArrayList<>();

		// Mapの情報をBeanのプロパティにセット
		BeanUtils.populate(seisanshoJokyakuKeiri, reqMap);

		// 除却年月日（From）と除却年月日（To）の大小比較チェック
		if (NSDCommUtils.chkDateFromTo(seisanshoJokyakuKeiri.getJokyakuYmdFrom(),
				seisanshoJokyakuKeiri.getJokyakuYmdTo())) {

			// エラーメッセージを返却Mapに設定する
			return setMsgToResultMap(resultMap, NSDConstant.MSGID_INPUT_ERROR);

		}

		// サービス呼び出し
		sssJkkKrLst = seisanshoJokyakuKeiriService.getJokyakuKeiriInfo(seisanshoJokyakuKeiri);

		// 検索結果を返却Mapに設定する
		return setDataToResultMap(resultMap, sssJkkKrLst);
	}

	/**
	 * 除却（経理審査/連携）更新処理
	 *
	 * @param reqMap
	 *            INPUTパラメータ
	 * @return 除却情報データ
	 * @exception IllegalAccessException
	 * @exception InvocationTargetException
	 * @version 1.00
	 * @throws Exception
	 */
	@RequestMapping(value = "/seisanshoJokyakuKeiri-updateInfo", method = RequestMethod.POST)
	public Map<String, Object> updateInfo(HttpServletRequest request, @RequestParam Map<String, Object> reqMap) throws Exception {

		Map<String, Object> resultMap = new HashMap<String, Object>();

		// 除却資産件数
		Set<String> set = new HashSet<String>();
		for (Entry<String, Object> entry : reqMap.entrySet()) {
			System.out.println(entry.getKey());
			String[] record = entry.getKey().replace("[", ",").replace("]", "").split(",");
			if (record.length == 3) {
				set.add(record[1]);
			}
		}

		// 入力チェック
		// 発行組織コード
		String hakouSoshikiCd = (String) reqMap.get("hakouSoshikiCd");
		// 会計整理年月
		String kaikeiSeiriYm = (String) reqMap.get("kaikeiSeiriYm");

		// 発行組織コード
		if (StringUtils.isEmpty(hakouSoshikiCd)) {
			return setMsgToResultMap(resultMap, NSDConstant.MSGID_SHONIN_STATUS_ERROR);
		}
		// 会計整理年月
		if (StringUtils.isEmpty(kaikeiSeiriYm)) {
			return setMsgToResultMap(resultMap, NSDConstant.MSGID_SHONIN_STATUS_ERROR);
		}

		Date date = new Date();
		// 更新チェック
		boolean updChk;
		List<Kss006> kss006UpdLst = new ArrayList<Kss006>();
		// 除却資産情報を取得
		for (int i = 0; i < set.size(); i++) {
			Kss006 kss006 = new Kss006();
			updChk = false;
			String keyUpd = "sisanInfoLst".concat("[" + i + "]").concat("[upd]");
			if (null != reqMap.get(keyUpd)) {
				updChk = Boolean.valueOf((String) reqMap.get(keyUpd));
			}
			if (!updChk) {
				continue;
			}

			// 承認状態
			String shoninStatus = (String) reqMap.get("sisanInfoLst".concat("[" + i + "]").concat("[shoninStatus]"));

			if (StringUtils.isEmpty(shoninStatus)) {
				return setMsgToResultMap(resultMap, NSDConstant.MSGID_SHONIN_STATUS_ERROR);
			}

			// 理由
			String riyu = (String) reqMap.get("sisanInfoLst".concat("[" + i + "]").concat("[riyu]"));
			// 除却資産書ＩＤ
			String jokyakuSeisanShoId = (String) reqMap
					.get("sisanInfoLst".concat("[" + i + "]").concat("[jokyakuSeisanShoId]"));

			// 除却資産書ＩＤ
			kss006.setJokyakuSeisanShoId(jokyakuSeisanShoId);
			// 承認状態
			kss006.setShoninStatus(shoninStatus);
			// 理由
			kss006.setRiyu(riyu);
			// 更新年月日
			kss006.setUpdateDate(date);
			// 更新ユーザーＩＤ
			kss006.setUpdateUserId(this.getLoginUserInfo(request).getUserId());

			kss006UpdLst.add(kss006);
		}

		if (kss006UpdLst.size() == 0) {
			return setMsgToResultMap(resultMap, NSDConstant.MSGID_INPUT_ERROR);
		}

		// サービス呼び出し
		seisanshoJokyakuKeiriService.updateInfo(kss006UpdLst, hakouSoshikiCd, kaikeiSeiriYm);

		// 処理結果データ
		resultMap.put(NSDConstant.RESULT_DATA_NAME, "");

		return setMsgToResultMapNoLog(resultMap, NSDConstant.MSGID_UPDATE_SUCCES);

	}
}
