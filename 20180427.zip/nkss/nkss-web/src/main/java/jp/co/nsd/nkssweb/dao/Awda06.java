package jp.co.nsd.nkssweb.dao;

import java.util.Date;

public class Awda06 {
    private String aw6ShuCod;

    private String aw6KouCod;

    private String aw6SaiCod;

    private String aw6Shu4Cod;

    private String aw6Shu5Cod;

    private String aw6Shu6Cod;

    private String aw6Shu6Knj;

    private Integer aw6UpdateCnt;

    private Date aw6TorokDh;

    private String aw6TorshaCod;

    private Date aw6UpdateDh;

    private String aw6UpdshaCod;

    public String getAw6ShuCod() {
        return aw6ShuCod;
    }

    public void setAw6ShuCod(String aw6ShuCod) {
        this.aw6ShuCod = aw6ShuCod == null ? null : aw6ShuCod.trim();
    }

    public String getAw6KouCod() {
        return aw6KouCod;
    }

    public void setAw6KouCod(String aw6KouCod) {
        this.aw6KouCod = aw6KouCod == null ? null : aw6KouCod.trim();
    }

    public String getAw6SaiCod() {
        return aw6SaiCod;
    }

    public void setAw6SaiCod(String aw6SaiCod) {
        this.aw6SaiCod = aw6SaiCod == null ? null : aw6SaiCod.trim();
    }

    public String getAw6Shu4Cod() {
        return aw6Shu4Cod;
    }

    public void setAw6Shu4Cod(String aw6Shu4Cod) {
        this.aw6Shu4Cod = aw6Shu4Cod == null ? null : aw6Shu4Cod.trim();
    }

    public String getAw6Shu5Cod() {
        return aw6Shu5Cod;
    }

    public void setAw6Shu5Cod(String aw6Shu5Cod) {
        this.aw6Shu5Cod = aw6Shu5Cod == null ? null : aw6Shu5Cod.trim();
    }

    public String getAw6Shu6Cod() {
        return aw6Shu6Cod;
    }

    public void setAw6Shu6Cod(String aw6Shu6Cod) {
        this.aw6Shu6Cod = aw6Shu6Cod == null ? null : aw6Shu6Cod.trim();
    }

    public String getAw6Shu6Knj() {
        return aw6Shu6Knj;
    }

    public void setAw6Shu6Knj(String aw6Shu6Knj) {
        this.aw6Shu6Knj = aw6Shu6Knj == null ? null : aw6Shu6Knj.trim();
    }

    public Integer getAw6UpdateCnt() {
        return aw6UpdateCnt;
    }

    public void setAw6UpdateCnt(Integer aw6UpdateCnt) {
        this.aw6UpdateCnt = aw6UpdateCnt;
    }

    public Date getAw6TorokDh() {
        return aw6TorokDh;
    }

    public void setAw6TorokDh(Date aw6TorokDh) {
        this.aw6TorokDh = aw6TorokDh;
    }

    public String getAw6TorshaCod() {
        return aw6TorshaCod;
    }

    public void setAw6TorshaCod(String aw6TorshaCod) {
        this.aw6TorshaCod = aw6TorshaCod == null ? null : aw6TorshaCod.trim();
    }

    public Date getAw6UpdateDh() {
        return aw6UpdateDh;
    }

    public void setAw6UpdateDh(Date aw6UpdateDh) {
        this.aw6UpdateDh = aw6UpdateDh;
    }

    public String getAw6UpdshaCod() {
        return aw6UpdshaCod;
    }

    public void setAw6UpdshaCod(String aw6UpdshaCod) {
        this.aw6UpdshaCod = aw6UpdshaCod == null ? null : aw6UpdshaCod.trim();
    }
}