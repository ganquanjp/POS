/***********************************************************************
*
*業務名: 工事精算システム
*機能名: 除却（経理審査/連携）(サービス処理)
*
*機能概要: 除却情報を処理する。
*
*JavaＶｅｒ：J2SE1.8.0準拠
*
*更新履歴: Ver.1.00 2018/03/06　NSD　新規作成
***********************************************************************/
package jp.co.nsd.nkssweb.service.seisanshojokyaku;

import java.util.List;

import jp.co.nsd.nkssweb.dao.Kss006;
import jp.co.nsd.nkssweb.dao.SeisanshoJokyakuKeiri;

/**
 * 除却（経理審査/連携）処理
 *
 * @version 1.00
 */
public interface SeisanshoJokyakuKeiriService {

	/**
	 * 除却（経理審査/連携）検索
	 *
	 * @param seisanshoJokyakuKeiri
	 *            INPUTパラメータ
	 * @return　検索結果
	 */
	List<SeisanshoJokyakuKeiri> getJokyakuKeiriInfo(SeisanshoJokyakuKeiri seisanshoJokyakuKeiri);

	/**
	 * 除却（経理審査/連携）更新
	 *
	 * @param kss006
	 *            INPUTパラメータ
	 * @param hakouSoshikiCd
	 *            発行組織コード
	 * @param kaikeiSeiriYm
	 *            会計整理年月
	 * @return　結果
	 */
	int updateInfo(List<Kss006> kss006UpdLst, String hakouSoshikiCd, String kaikeiSeiriYm) throws Exception ;
}
