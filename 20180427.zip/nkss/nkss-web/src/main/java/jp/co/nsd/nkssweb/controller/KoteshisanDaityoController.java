/***********************************************************************
*
*業務名: 工事精算システム
*機能名: 【固定資産台帳出力】作成指示処理
*
*機能概要: 【固定資産台帳出力】作成指示処理
*
*JavaＶｅｒ：J2SE1.8.0準拠
*
*更新履歴: Ver.1.00 2018/04/11　NSD　新規作成
***********************************************************************/
package jp.co.nsd.nkssweb.controller;


import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import jp.co.nsd.nkssweb.dao.KoteshisanDaityoFileInfo;
import jp.co.nsd.nkssweb.service.KoteshisanDaityoService;
import jp.co.nsd.nkssweb.utils.NSDConstant;

/**
 * 【固定資産台帳出力】作成指示用コントロール
 *
 * @version 1.00
 */
@RestController
public class KoteshisanDaityoController extends BaseController {

	@Autowired
	private KoteshisanDaityoService koteshisanDaityoService;

	/**
	 * 【固定資産台帳出力】作成指示の初期表示
	 *
	 * @param reqMap
	 *            INPUTパラメータ
	 * @return 作成日時
	 * @version 1.00
	 */
	@RequestMapping(value = "/koteshisanDaityo-selectSakuseiTimestamp", method = RequestMethod.POST)
	public Map<String, Object> selectSakuseiTimestamp(@RequestParam Map<String, Object> reqMap) throws Exception {

		Map<String, Object> resultMap = new HashMap<String, Object>();

		String sakuseiTimestamp =  koteshisanDaityoService.getSakuseiTimestamp();

		if (null == sakuseiTimestamp) {
			// データなしの場合
			setMsgToResultMap(resultMap, NSDConstant.MSGID_NOT_FOUND_DATA_DAITYO);
		} else {
			// 検索結果を返却Mapに設定する
			sakuseiTimestamp = sakuseiTimestamp.substring(0, 10).concat("/").concat(sakuseiTimestamp.substring(11,19));
			setDataToResultMap(resultMap, Arrays.asList(sakuseiTimestamp));
			setMsgToResultMap(resultMap, NSDConstant.MSGID_FOUND_DATA_DAITYO);
		}

		return resultMap;
	}

	/**
	 * 【固定資産台帳出力】作成指示の再作成ボッタン
	 *
	 * @param reqMap
	 *            INPUTパラメータ
	 * @return 固定資産台帳出力情報データ
	 * @version 1.00
	 */
	@RequestMapping(value = "/koteshisanDaityo-selectByWhere", method = RequestMethod.POST)
	public Map<String, Object> selectByBat(@RequestParam Map<String, Object> reqMap) throws Exception {

		Map<String, Object> resultMap = new HashMap<String, Object>();

    	// 帳票出力処理を呼び出し
		koteshisanDaityoService.getKenmeiInfo(NSDConstant.CODE_SAKUSEI_KBN_WEB);

		// 検索結果を返却Mapに設定する
		String sakuseiTimestamp =  koteshisanDaityoService.getSakuseiTimestamp();

		// 検索結果を返却Mapに設定する
		sakuseiTimestamp = sakuseiTimestamp.substring(0, 10).concat("/").concat(sakuseiTimestamp.substring(11,19));
		setDataToResultMap(resultMap, Arrays.asList(sakuseiTimestamp));

		return resultMap;
	}

	/**
	 * 【固定資産台帳出力】出力の初期表示
	 *
	 * @param reqMap
	 *            INPUTパラメータ
	 * @return 固定資産台帳出力ファイル情報データ
	 * @version 1.00
	 */
	@RequestMapping(value = "/koteshisanDaityo-getKoteishisanDaityoFileInfo", method = RequestMethod.POST)
	public Map<String, Object> getKoteishisanDaityoFileInfo(@RequestParam Map<String, Object> reqMap) throws Exception {

		Map<String, Object> resultMap = new HashMap<String, Object>();

		// 帳票出力処理を呼び出し
		List<KoteshisanDaityoFileInfo> fileInfoList = koteshisanDaityoService.getKoteishisanDaityoFileInfo();

		if (null == fileInfoList) {
			// データなしの場合
			setMsgToResultMap(resultMap, NSDConstant.MSGID_NOT_FOUND_FILE_DAITYO);
		} else {
			// 検索結果を返却Mapに設定する
			setDataToResultMap(resultMap, fileInfoList);
		}

		return resultMap;
	}
}
