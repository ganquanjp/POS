package jp.co.nsd.nkssweb.dao.mapper;

import jp.co.nsd.nkssweb.dao.Kss017;

public interface Kss017Mapper {
    int deleteByPrimaryKey(String messageId);

    int insert(Kss017 record);

    int insertSelective(Kss017 record);

    Kss017 selectByPrimaryKey(String messageId);

    int updateByPrimaryKeySelective(Kss017 record);

    int updateByPrimaryKey(Kss017 record);
}