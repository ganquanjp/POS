package jp.co.nsd.nkssweb.controller.seisanshotoroku;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.lang.time.DateUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.ibm.icu.text.SimpleDateFormat;

import jp.co.nsd.nkssweb.controller.BaseController;
import jp.co.nsd.nkssweb.dao.Kss002;
import jp.co.nsd.nkssweb.dao.Kss004;
import jp.co.nsd.nkssweb.dao.LoginUserInfo;
import jp.co.nsd.nkssweb.dao.SeisanshoToroku;
import jp.co.nsd.nkssweb.dao.mapper.SeisanshoTorokuMapper;
import jp.co.nsd.nkssweb.service.seisanshotoroku.SeisanshoTorokuService;
import jp.co.nsd.nkssweb.utils.NSDCommUtils;
import jp.co.nsd.nkssweb.utils.NSDConstant;

@RestController
public class SeisanshoTorokuController extends BaseController {

	@Autowired
	private SeisanshoTorokuService seisanshoTorokuService;

	@Autowired
	private SeisanshoTorokuMapper sssTrkMapper;
	/*
	 * 精算書登録・検索
	 */
	@RequestMapping(value = "/seisanshoToroku-kensaku", method = RequestMethod.POST)
	public Map<String, Object> getSeisanshoTorokuKensaku(@RequestParam Map<String, Object> reqMap) throws Exception {

		Map<String, Object> resultMap = new HashMap<String, Object>();

		SeisanshoToroku selectCondition = new SeisanshoToroku();
		List<SeisanshoToroku> sssTrkList = new ArrayList<SeisanshoToroku>();

		// 画面入力した検索条件をBeanのプロパティにセット
		BeanUtils.populate(selectCondition, reqMap);

		// 使用開始年月日（From）と使用開始年月日（To）の大小比較チェック
		if (NSDCommUtils.chkDateFromTo(selectCondition.getSiyoStartYmdFrom(),
				selectCondition.getSiyoStartYmdTo())) {

			// エラーメッセージを返却Mapに設定する
			return setMsgToResultMap(resultMap, NSDConstant.MSGID_INPUT_ERROR);

		}

		// 適用期間（From）と適用期間（To）の大小比較チェック
		if (NSDCommUtils.chkDateFromTo(selectCondition.getTekiyoStartYmd(),
				selectCondition.getTekiyoEndYmd())) {

			// エラーメッセージを返却Mapに設定する
			return setMsgToResultMap(resultMap, NSDConstant.MSGID_INPUT_ERROR);

		}

		// サービスを呼び出す
		sssTrkList = seisanshoTorokuService.getSeisanshoTorokuKensaku(selectCondition);

		// 検索結果を返却Mapに設定する
		setDataToResultMap(resultMap, sssTrkList);

		return resultMap;
	}

	/*
	 * 精算書登録・照会
	 */
	@RequestMapping(value = "/seisanshoToroku-shokai", method = RequestMethod.POST)
	public Map<String, Object> getSeisanshoTorokuShokai(@RequestParam Map<String, Object> reqMap) throws Exception {

		Map<String, Object> resultMap = new HashMap<String, Object>();

		SeisanshoToroku selectCondition = new SeisanshoToroku();

		List<SeisanshoToroku> sssTrkList = new ArrayList<SeisanshoToroku>();

		// 画面入力した検索条件をBeanのプロパティにセット
		BeanUtils.populate(selectCondition, reqMap);

		// サービスを呼び出す
		sssTrkList = seisanshoTorokuService.getSeisanshoTorokuShokai(selectCondition);

		// 検索結果を返却Mapに設定する
		setDataToResultMap(resultMap, sssTrkList);

		// 処理結果データ
		if (sssTrkList.size() > 0) {
			setDataToResultMap(resultMap, sssTrkList);
		} else {
			setMsgToResultMap(resultMap, NSDConstant.MSGID_NOT_FOUND_DATA);
		}

		return resultMap;
	}

	/**
	 * 精算書登録・削除
	 * @param reqMap
	 *            INPUTパラメータ
	 * @return 除却情報データ
	 * @throws Exception
	 * @version 1.00
	 */
	@RequestMapping(value = "/seisanshoToroku-delByPyKey", method = RequestMethod.POST)
	public Map<String, Object> delByPyKey(@RequestParam Map<String, Object> reqMap)  throws Exception {

		Map<String, Object> resultMap = new HashMap<String, Object>();

		// 件名ＩＤ
		Long kenmeiId = Long.valueOf((String) reqMap.get("kenmeiId"));
		// 件名コード
		String kenmeiCd = (String) reqMap.get("kenmeiCd");
		// 件名
		String kenmeiNm = (String) reqMap.get("kenmeiNm");
		// 適用開始年月日
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd");
		Date tekiyoStartYmd =sdf.parse(((String) reqMap.get("tekiyoStartYmd")).replaceAll("-", "/"));
		// 精算書ID
		String seisanShoId = (String) reqMap.get("seisanShoId");
		// 固定資産ID
		String koteiShisanId = (String) reqMap.get("koteiShisanId");

		Map<String, Object> selectMap = new HashMap<String, Object>();
		selectMap.put("kenmeiId", kenmeiId);
		selectMap.put("kenmeiCd", kenmeiCd);
		selectMap.put("kenmeiNm", kenmeiNm);
		selectMap.put("tekiyoStartYmd", tekiyoStartYmd);
		String selectrenkeiStatus = sssTrkMapper.selectRenkeiStatus(selectMap);

		selectMap = new HashMap<String, Object>();
		selectMap.put("seisanShoId", seisanShoId);
		selectMap.put("koteiShisanId", koteiShisanId);
		String selectshoninStatus = sssTrkMapper.selectShoninStatus(selectMap);


		String selectkensu = sssTrkMapper.selectConut(selectMap);

		if (NSDConstant.STRING_0.equals(selectrenkeiStatus) && NSDConstant.SHONIN_STATUS_CODE_TOROKU.equals(selectshoninStatus) && !NSDConstant.STRING_0.equals(selectkensu)){
			//件名マスタ内容削除
			seisanshoTorokuService.delkmmstByPyKey(kenmeiId, kenmeiCd, kenmeiNm, tekiyoStartYmd);

			//精算書内容削除
			seisanshoTorokuService.delByPyKey(seisanShoId, koteiShisanId);

			//取得資産明細削除
			seisanshoTorokuService.delmesaiByPyKey(seisanShoId, koteiShisanId);

		} else if (NSDConstant.STRING_1.equals(selectrenkeiStatus) && NSDConstant.SHONIN_STATUS_CODE_TOROKU.equals(selectshoninStatus) && !NSDConstant.STRING_0.equals(selectkensu)){
			//精算書内容削除
			seisanshoTorokuService.delByPyKey(seisanShoId, koteiShisanId);

			//取得資産明細削除
			seisanshoTorokuService.delmesaiByPyKey(seisanShoId, koteiShisanId);

		} else if (NSDConstant.STRING_1.equals(selectrenkeiStatus) && NSDConstant.SHONIN_STATUS_CODE_HININ.equals(selectshoninStatus) && !NSDConstant.STRING_0.equals(selectkensu)){
			//精算書内容削除
			seisanshoTorokuService.delByPyKey(seisanShoId, koteiShisanId);

			//取得資産明細削除
			seisanshoTorokuService.delmesaiByPyKey(seisanShoId, koteiShisanId);

		}

		// 処理結果データ
		resultMap.put(NSDConstant.RESULT_DATA_NAME, "");

		return setMsgToResultMapNoLog(resultMap, NSDConstant.MSGID_DELETE_SUCCES);
	}

	/**
	 * 精算書登録（新規登録・初期表示）処理
	 *
	 * @param reqMap
	 *            INPUTパラメータ
	 * @return 除却情報データ
	 * @throws Exception
	 * @version 1.00
	 */
	@RequestMapping(value = "/seisanshotoroku-toroku-initShow", method = RequestMethod.POST)
	public Map<String, Object> initShowForInsert(HttpServletRequest request) throws Exception {

		Map<String, Object> resultMap = new HashMap<String, Object>();

		// 画面初期表示情報格納するマップ
		Map<String, Object> infoMap = new HashMap<String, Object>();

		// 当日日付の２か月前の1日を取得
		java.text.SimpleDateFormat format = new java.text.SimpleDateFormat("yyyy-MM-01");
		String firstDayBefore2Month = format.format(DateUtils.addMonths(Calendar.getInstance().getTime(), -2));

		// 画面適用開始日 ＝ 当日日付の２か月前の1日
		infoMap.put("tekiyoStartYmd", firstDayBefore2Month);

		// 画面適用終了日 ＝ 当日日付の２か月前の1日
		infoMap.put("tekiyoEndYmd", NSDConstant.DEFAULT_END_DATE);

		LoginUserInfo loginUserInfo = getLoginUserInfo(request);

		// 画面適用終了日 ＝ 当日日付の２か月前の1日
		infoMap.put("loginUserInfo", loginUserInfo);

		// 検索結果を返却Mapに設定する
		return setDataToResultMap(resultMap, infoMap);
	}

	/**
	 * 精算書登録（新規登録・登録）処理
	 *
	 * @param reqMap
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value = "/seisanshoToroku-insertSeisansho", method = RequestMethod.POST)
	public Map<String, Object> insertSeisansho(@RequestParam Map<String, Object> reqMap) throws Exception {

		Map<String, Object> resultMap = new HashMap<String, Object>();

		Kss004 kss004 = new Kss004();
		Kss002 kss002 = new Kss002();

		// 画面入力した検索条件をBeanのプロパティにセット
		BeanUtils.populate(kss004, reqMap);
		BeanUtils.populate(kss002, reqMap);

		// サービスを呼び出す
		seisanshoTorokuService.insertSeisansho(kss002, kss004);

		// 登録正常完了
		setMsgToResultMap(resultMap, NSDConstant.MSGID_INSERT_SUCCESS);

		return resultMap;
	}
}
