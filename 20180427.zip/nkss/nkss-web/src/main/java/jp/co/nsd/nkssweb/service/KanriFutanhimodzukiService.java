/***********************************************************************
*
*業務名: 工事精算システム
*機能名: 除却（登録・修正・削除）(サービス処理)
*
*機能概要: 除却情報を処理する。
*
*JavaＶｅｒ：J2SE1.8.0準拠
*
*更新履歴: Ver.1.00 2018/03/06　NSD　新規作成
***********************************************************************/
package jp.co.nsd.nkssweb.service;

import java.util.List;

import jp.co.nsd.nkssweb.dao.KanriFutanhimodzuki;

/**
 * 管理箇所/負担箇所紐付（検索・修正・新規）処理
 *
 * @version 1.00
 */
public interface KanriFutanhimodzukiService {

	/**
	 * 管理箇所/負担箇所情報取得
	 *
	 * @param selectCondition
	 *            INPUTパラメータ
	 * @return　検索結果
	 */
	List<KanriFutanhimodzuki> getKanriFutanInfo(KanriFutanhimodzuki selectCondition);

    /**
     * 管理箇所/負担箇所紐付（新規登録画面）
     *
     * @param kss006
     *            INPUTパラメータ
     * @param kss007Lst
     *            INPUTパラメータ
     * @return　登録件数
     */
    int insertInfo(List<KanriFutanhimodzuki> krFtLst);

    int updateInfo(List<KanriFutanhimodzuki> krFtLst);

}
