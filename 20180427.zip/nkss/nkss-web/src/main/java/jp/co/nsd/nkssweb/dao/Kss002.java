package jp.co.nsd.nkssweb.dao;

import java.util.Date;

public class Kss002 extends Kss002Key {
    private Date tekiyoEndYmd;

    private String renkeiStatus;

    private Date entryDate;

    private String entryUserId;

    private Date updateDate;

    private String updateUserId;

    public Date getTekiyoEndYmd() {
        return tekiyoEndYmd;
    }

    public void setTekiyoEndYmd(Date tekiyoEndYmd) {
        this.tekiyoEndYmd = tekiyoEndYmd;
    }

    public String getRenkeiStatus() {
        return renkeiStatus;
    }

    public void setRenkeiStatus(String renkeiStatus) {
        this.renkeiStatus = renkeiStatus == null ? null : renkeiStatus.trim();
    }

    public Date getEntryDate() {
        return entryDate;
    }

    public void setEntryDate(Date entryDate) {
        this.entryDate = entryDate;
    }

    public String getEntryUserId() {
        return entryUserId;
    }

    public void setEntryUserId(String entryUserId) {
        this.entryUserId = entryUserId == null ? null : entryUserId.trim();
    }

    public Date getUpdateDate() {
        return updateDate;
    }

    public void setUpdateDate(Date updateDate) {
        this.updateDate = updateDate;
    }

    public String getUpdateUserId() {
        return updateUserId;
    }

    public void setUpdateUserId(String updateUserId) {
        this.updateUserId = updateUserId == null ? null : updateUserId.trim();
    }
}