package jp.co.nsd.nkssweb.interceptor;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.method.HandlerMethod;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;

import jp.co.nsd.nkssweb.utils.NSDConstant;

public class LogHandlerInterceptor extends HandlerInterceptorAdapter {

	private Logger logger = LoggerFactory.getLogger(this.getClass());

    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {
    	logMethodBeginEnd(handler, NSDConstant.LOG_INFO_METHOD_BEGIN);
        return true;
    }

    @Override
    public void postHandle(HttpServletRequest request, HttpServletResponse response, Object handler, ModelAndView modelAndView)
            throws Exception {
    	logMethodBeginEnd(handler, NSDConstant.LOG_INFO_METHOD_END);
    }

    @Override
    public void afterCompletion(HttpServletRequest request, HttpServletResponse response, Object handler, Exception ex)
            throws Exception {
        // TODO Auto-generated method stub
    }

    /**
     * コントロール呼出、終了時のログ出力
     *
     * @param handler
     * @param logStr
     */
    private void logMethodBeginEnd (Object handler, String logStr) {

    	// クラス名、メソッド名を取得する
    	HandlerMethod handlerMethod = (HandlerMethod) handler;
    	String classMethodName = handlerMethod.getBeanType().toString().concat(".").concat(handlerMethod.getMethod().getName());

//		try {
//			logger.info(NSDCommUtils.converISO8859ToUTF8(classMethodName.concat(logStr)));
			logger.info(classMethodName.concat(logStr));
//		} catch (UnsupportedEncodingException e) {
//			logger.error(e.getMessage());
//			logger.error(e.getStackTrace().toString());
//		}
    }
}