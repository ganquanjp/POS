package jp.co.nsd.nkssweb.service;

import jp.co.nsd.nkssweb.dao.Kss011;

public interface InputCheckService {

	/**
	 * 組織連結名で組織マスタを検索、データ存在の確認
	 * 取得件数は１件以外の場合、入力チェックエラーとなる。
	 *
	 * @param selectCondition
	 * @return
	 */
	Kss011 getSoshikiInfoForInputCheck (String soshikiRenNm);

}
