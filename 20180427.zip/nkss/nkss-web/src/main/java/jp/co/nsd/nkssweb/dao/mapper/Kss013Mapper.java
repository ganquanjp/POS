package jp.co.nsd.nkssweb.dao.mapper;

import jp.co.nsd.nkssweb.dao.Kss013;

public interface Kss013Mapper {
    int deleteByPrimaryKey(String userId);

    int insert(Kss013 record);

    int insertSelective(Kss013 record);

    Kss013 selectByPrimaryKey(String userId);

    int updateByPrimaryKeySelective(Kss013 record);

    int updateByPrimaryKey(Kss013 record);
}