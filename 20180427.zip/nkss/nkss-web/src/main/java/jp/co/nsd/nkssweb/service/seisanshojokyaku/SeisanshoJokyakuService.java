/***********************************************************************
*
*業務名: 工事精算システム
*機能名: 除却（登録・修正・削除）(サービス処理)
*
*機能概要: 除却情報を処理する。
*
*JavaＶｅｒ：J2SE1.8.0準拠
*
*更新履歴: Ver.1.00 2018/03/06　NSD　新規作成
***********************************************************************/
package jp.co.nsd.nkssweb.service.seisanshojokyaku;

import java.util.List;

import jp.co.nsd.nkssweb.dao.Kss006;
import jp.co.nsd.nkssweb.dao.Kss007;
import jp.co.nsd.nkssweb.dao.SeisanshoJokyaku;
import jp.co.nsd.nkssweb.dao.SeisanshoJokyakuShokai;
import jp.co.nsd.nkssweb.dao.SeisanshoJokyakuShokaiList;

/**
 * 除却（登録・修正・削除）処理
 *
 * @version 1.00
 */
public interface SeisanshoJokyakuService {

	/**
	 * 除却情報取得
	 *
	 * @param selectCondition
	 *            INPUTパラメータ
	 * @return 検索結果
	 */
	List<SeisanshoJokyaku> getJokyakuInfo(SeisanshoJokyaku seisanshoJokyaku);

	/**
	 * 除却情報取得（照会画面）
	 *
	 * @param seisanshoJokyakuShokai
	 *            INPUTパラメータ
	 * @return 検索結果
	 * @throws Exception
	 */
	SeisanshoJokyakuShokaiList getJokyakuInfoBySeisanShoNo(SeisanshoJokyakuShokai seisanshoJokyakuShokai)
			throws Exception;

	/**
	 * 除却情報削除（照会画面）
	 *
	 * @param jokyakuSeisanShoId
	 *            INPUTパラメータ
	 * @return 削除件数
	 */
	int delByPyKey(String jokyakuSeisanShoId);

	/**
	 * 除却情報登録（新規登録画面）
	 *
	 * @param kss006
	 *            INPUTパラメータ
	 * @param kss007Lst
	 *            INPUTパラメータ
	 * @return 登録件数
	 * @throws Exception
	 */
	int insertInfo(Kss006 kss006, List<Kss007> kss007Lst) throws Exception;

	/**
	 * 除却情報更新（更新画面）
	 *
	 * @param kss006
	 *            INPUTパラメータ
	 * @param kss007UpdLst
	 *            INPUTパラメータ
	 * @param kss007DelLst
	 *            INPUTパラメータ
	 * @return 登録件数
	 * @throws Exception
	 */
	int updateInfo(Kss006 kss006, List<Kss007> kss007UpdLst, List<Kss007> kss007DelLst) throws Exception;
}
