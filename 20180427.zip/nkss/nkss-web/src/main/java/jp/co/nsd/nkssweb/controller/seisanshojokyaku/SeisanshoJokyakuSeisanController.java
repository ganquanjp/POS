/***********************************************************************
*
*業務名: 工事精算システム
*機能名: 除却（精算通告）(ログ出力処理)
*
*機能概要: 除却情報を処理する。
*
*JavaＶｅｒ：J2SE1.8.0準拠
*
*更新履歴: Ver.1.00 2018/03/06　NSD　新規作成
***********************************************************************/

package jp.co.nsd.nkssweb.controller.seisanshojokyaku;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.beanutils.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import jp.co.nsd.nkssweb.controller.BaseController;
import jp.co.nsd.nkssweb.dao.Kss006;
import jp.co.nsd.nkssweb.dao.SeisanshoJokyakuSeisan;
import jp.co.nsd.nkssweb.dao.SeisanshoJokyakuSeisanShokai;
import jp.co.nsd.nkssweb.dao.mapper.Kss006Mapper;
import jp.co.nsd.nkssweb.service.SystemService;
import jp.co.nsd.nkssweb.service.seisanshojokyaku.SeisanshoJokyakuSeisanService;
import jp.co.nsd.nkssweb.utils.NSDCommUtils;
import jp.co.nsd.nkssweb.utils.NSDConstant;

/**
 * 除却（精算通告）処理
 *
 * @version 1.00
 */
@RestController
public class SeisanshoJokyakuSeisanController extends BaseController {

	@Autowired
	private SeisanshoJokyakuSeisanService seisanshoJokyakuSeisanService;

	protected SystemService systemService;

	@Autowired
	private Kss006Mapper kss006Mapper;

	/**
	 * 除却（精算通告）検索処理
	 *
	 * @param reqMap
	 *            INPUTパラメータ
	 * @return 除却情報データ
	 * @throws Exception
	 * @version 1.00
	 */
	@RequestMapping(value = "/seisanshoJokyakuSeisan-selectByWhere", method = RequestMethod.POST)
	public Map<String, Object> selectByWhere(@RequestParam Map<String, Object> reqMap) throws Exception {

		Map<String, Object> resultMap = new HashMap<String, Object>();

		SeisanshoJokyakuSeisan seisanshoJokyakuSeisan = new SeisanshoJokyakuSeisan();

		List<SeisanshoJokyakuSeisan> sssJkkSsLst = new ArrayList<>();

		// Mapの情報をBeanのプロパティにセット
		BeanUtils.populate(seisanshoJokyakuSeisan, reqMap);

		// 除却年月日（From）と除却年月日（To）の大小比較チェック
		if (NSDCommUtils.chkDateFromTo(seisanshoJokyakuSeisan.getJokyakuYmdFrom(),
				seisanshoJokyakuSeisan.getJokyakuYmdTo())) {
			// エラーメッセージを返却Mapに設定する
			return setMsgToResultMap(resultMap, NSDConstant.MSGID_INPUT_ERROR);

		}

		// サービス呼び出し
		sssJkkSsLst = seisanshoJokyakuSeisanService.getJokyakuSeisanInfo(seisanshoJokyakuSeisan);
		// 検索結果を返却Mapに設定する
		return setDataToResultMap(resultMap, sssJkkSsLst);
	}

	/**
	 * 除却（精算通告）照会処理
	 *
	 * @param reqMap
	 *            INPUTパラメータ
	 * @return 除却情報データ
	 * @throws Exception
	 * @version 1.00
	 */
	@RequestMapping(value = "/seisanshoJokyakuSeisan-selectBySeisanShoNo", method = RequestMethod.POST)
	public Map<String, Object> selectBySeisanShoNo(@RequestParam Map<String, Object> reqMap) throws Exception {

		Map<String, Object> resultMap = new HashMap<String, Object>();

		SeisanshoJokyakuSeisanShokai seisanshoJokyakuSeisanShokai = new SeisanshoJokyakuSeisanShokai();

		// Mapの情報をBeanのプロパティにセット
		BeanUtils.populate(seisanshoJokyakuSeisanShokai, reqMap);

		// サービス呼び出し
		SeisanshoJokyakuSeisanShokai sssJkkSsSkDto = seisanshoJokyakuSeisanService
				.getJokyakuInfoBySeisanShoNo(seisanshoJokyakuSeisanShokai);

		// 検索結果を返却Mapに設定する
		return setDataToResultMap(resultMap, sssJkkSsSkDto);
	}

	/**
	 * 除却（精算通告）更新処理
	 *
	 * @param reqMap
	 *            INPUTパラメータ
	 * @throws Exception
	 * @version 1.00
	 */
	@RequestMapping(value = "/seisanshoJokyakuSeisan-updateInfo", method = RequestMethod.POST)
	public Map<String, Object> updateInfo(HttpServletRequest request, @RequestParam Map<String, Object> reqMap) throws Exception {

		Map<String, Object> resultMap = new HashMap<String, Object>();

		// 除却資産書ＩＤ
		String jokyakuSeisanShoId = (String) reqMap.get("jokyakuSeisanShoId");

		Date date = new Date();

		SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd");

		// 除却年月日
		String jokyakuYmd = (String) reqMap.get("jokyakuYmd");

		Kss006 kss006 = new Kss006();
		// 除却資産書ＩＤ
		kss006.setJokyakuSeisanShoId(jokyakuSeisanShoId);
		// 除却年月日
		if (StringUtils.isEmpty(jokyakuYmd)) {
			kss006.setJokyakuYmd(null);
		} else {
			kss006.setJokyakuYmd(sdf.parse(jokyakuYmd.replaceAll("-", "/")));
		}

		// 更新年月日
		kss006.setUpdateDate(date);
		// 更新ユーザーＩＤ
		kss006.setUpdateUserId(this.getLoginUserInfo(request).getUserId());

		// 更新年月日を取得
		Date updDate = kss006Mapper.selectByPrimaryKey(jokyakuSeisanShoId).getUpdateDate();
		// 排他チェック
		if(null == updDate || !(reqMap.get("updateDate").toString().equals(updDate.toString()))){
			return setMsgToResultMap(resultMap, NSDConstant.MSGID_SUPDATE_LOCK);
		}

		// サービス呼び出し
		seisanshoJokyakuSeisanService.updateInfo(kss006);

		// 処理結果データ
		resultMap.put(NSDConstant.RESULT_DATA_NAME, "");

		return setMsgToResultMapNoLog(resultMap, NSDConstant.MSGID_UPDATE_SUCCES);
	}
}
