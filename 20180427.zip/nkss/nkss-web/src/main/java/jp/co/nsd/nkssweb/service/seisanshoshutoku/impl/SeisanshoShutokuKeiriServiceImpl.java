/***********************************************************************
*
*業務名: 工事精算システム
*機能名: 除却（経理審査/連携）(サービス処理)
*
*機能概要: 除却（経理審査/連携）情報を処理する。
*
*JavaＶｅｒ：J2SE1.8.0準拠
*
*更新履歴: Ver.1.00 2018/03/06　NSD　新規作成
***********************************************************************/
package jp.co.nsd.nkssweb.service.seisanshoshutoku.impl;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.beanutils.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import jp.co.nsd.nkssweb.dao.Aads01;
import jp.co.nsd.nkssweb.dao.Aads01Collection;
import jp.co.nsd.nkssweb.dao.SeisanshoShutokuKeiri;
import jp.co.nsd.nkssweb.dao.SeisanshoShutokuKrsk;
import jp.co.nsd.nkssweb.dao.mapper.SeisanshoShutokuKeiriMapper;
import jp.co.nsd.nkssweb.service.seisanshoshutoku.SeisanshoShutokuKeiriService;
import jp.co.nsd.nkssweb.utils.NSDConstant;

/**
 * 取得（経理審査/連携）処理
 *
 * @see SeisanshoShutokuKeiriService
 * @version 1.00
 */
@Service
public class SeisanshoShutokuKeiriServiceImpl implements SeisanshoShutokuKeiriService {

	@Autowired
	private SeisanshoShutokuKeiriMapper seisanshoShutokuKeiriMapper;

	/**
	 * 取得（経理審査/連携）検索処理
	 *
	 * @param seisanshoShutokuKeiri
	 *            INPUTパラメータ
	 * @return sssStkKrList 取得情報データリスト
	 * @version 1.00
	 */
	public List<SeisanshoShutokuKeiri> getshutokuKeiriInfo(SeisanshoShutokuKeiri seisanshoShutokuKeiri) {

		// 除却情報を取得する
		List<SeisanshoShutokuKeiri> sssStkKrList = seisanshoShutokuKeiriMapper.selectByWhere(seisanshoShutokuKeiri);

		if (sssStkKrList.size() > 0) {
			for (int i = 0; i < sssStkKrList.size(); i++) {

				SeisanshoShutokuKeiri sssStkkr = sssStkKrList.get(i);

				// ROWNOを設定する
				sssStkkr.setRowNo(i + 1);

				// 承認状態名称を設定する
				sssStkkr.setShoninStatusNm(NSDConstant.getShoninStatus(sssStkkr.getShoninStatusCd()));

			}
		} else {
			sssStkKrList = null;
		}

		return sssStkKrList;
	}

	/**
	 * 取得（経理審査/連携）（照会）処理
	 *
	 * @param seisanshoShutokuKrsk
	 *            INPUTパラメータ
	 * @return seisanshoShutokuKrsk 取得承認情報データ
	 * @version 1.00
	 * @throws Exception
	 */
	public SeisanshoShutokuKrsk getshutokuInfoBySeisanShoNo(SeisanshoShutokuKrsk seisanshoShutokuKrsk)
			throws Exception {

		// 取得情報
		SeisanshoShutokuKrsk resultDao = new SeisanshoShutokuKrsk();

		// 取得情報を取得する
		List<SeisanshoShutokuKrsk> sssStkKrskList = seisanshoShutokuKeiriMapper
				.selectBySeisanShoNo(seisanshoShutokuKrsk);

		if (sssStkKrskList.size() > 0) {

			resultDao = sssStkKrskList.get(0);

			// 取得資産明細リストの初期化
			resultDao.setKeSanLst(new ArrayList<Aads01>());

			// 取得資産明細情報
			for (int i = 0; i < sssStkKrskList.size(); i++) {

				Aads01Collection aads01 = new Aads01Collection();

				aads01.setRowNo(i + 1);

				BeanUtils.copyProperties(aads01, sssStkKrskList.get(i));

				resultDao.getKeSanLst().add(aads01);

			}
		} else {
			resultDao = null;
		}

		return resultDao;
	}

}
