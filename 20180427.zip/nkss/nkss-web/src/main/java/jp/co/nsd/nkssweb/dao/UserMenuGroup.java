package jp.co.nsd.nkssweb.dao;

import java.util.List;

public class UserMenuGroup {

	private String groupId;

	private String groupName;

	private List<UserSubMenu> usmList;

	public String getGroupId() {
		return groupId;
	}

	public void setGroupId(String groupId) {
		this.groupId = groupId;
	}

	public String getGroupName() {
		return groupName;
	}

	public void setGroupName(String groupName) {
		this.groupName = groupName;
	}

	public List<UserSubMenu> getUsmList() {
		return usmList;
	}

	public void setUsmList(List<UserSubMenu> usmList) {
		this.usmList = usmList;
	}

}