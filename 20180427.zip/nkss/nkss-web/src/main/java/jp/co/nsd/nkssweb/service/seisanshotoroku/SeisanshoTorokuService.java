package jp.co.nsd.nkssweb.service.seisanshotoroku;

import java.util.Date;
import java.util.List;

import jp.co.nsd.nkssweb.dao.Kss002;
import jp.co.nsd.nkssweb.dao.Kss004;
import jp.co.nsd.nkssweb.dao.SeisanshoToroku;

public interface SeisanshoTorokuService {

	/**
	 * 精算書登録・検索
	 *
	 * @return
	 */
	List<SeisanshoToroku> getSeisanshoTorokuKensaku(SeisanshoToroku selectCondition);

	/**
	 * 精算書登録・照会
	 *
	 * @return
	 */
	List<SeisanshoToroku> getSeisanshoTorokuShokai(SeisanshoToroku selectCondition);

	/**
	 * 精算書登録削除（照会画面）
	 *
	 * @param kenmeiId
	 *            INPUTパラメータ
	 * @param kenmeiCd
	 *            INPUTパラメータ
	 * @param kenmeiNm
	 *            INPUTパラメータ
	 * @param tekiyoStartYmd
	 *            INPUTパラメータ
	 * @return 削除件数
	 */
	int delkmmstByPyKey(Long kenmeiId, String kenmeiCd, String kenmeiNm, Date tekiyoStartYmd);

	/**
	 * 精算書登録削除（照会画面）
	 *
	 * @param seisanShoId
	 *            INPUTパラメータ
	 * @param koteiShisanId
	 *            INPUTパラメータ
	 * @return 削除件数
	 */
	int delByPyKey(String seisanShoId, String koteiShisanId);

	/**
	 * 精算書登録削除（照会画面）
	 *
	 * @param seisanShoId
	 *            INPUTパラメータ
	 * @param koteiShisanId
	 *            INPUTパラメータ
	 * @return 削除件数
	 */
	int delmesaiByPyKey(String seisanShoId, String koteiShisanId);


	/**
	 * 精算書登録
	 *
	 * @param kss004
	 */
	void insertSeisansho(Kss002 kss002, Kss004 kss004);

}
