package jp.co.nsd.nkssweb.service;

import java.util.List;

import jp.co.nsd.nkssweb.dao.KanriFutanks;
import jp.co.nsd.nkssweb.dao.KoteiSisan;
import jp.co.nsd.nkssweb.dao.SechiBasho;
import jp.co.nsd.nkssweb.dao.TorihikiSaki;

public interface SanshoService {

	/**
	 * 固定資産情報取得
	 *
	 * @param selectCondition
	 * @return
	 */
	List<KoteiSisan> getKoteiSisanInfo (KoteiSisan selectCondition);

	/**
	 * 取引先情報取得
	 *
	 * @param selectCondition
	 * @return
	 */
	List<TorihikiSaki> getTorihikiSakiInfo (TorihikiSaki selectCondition);

	/**
	 * 管理箇所/負担箇所情報取得
	 *
	 * @param selectCondition
	 *            INPUTパラメータ
	 * @return　検索結果
	 */
	List<KanriFutanks> getKanriFutanInfo(KanriFutanks selectCondition);

	/**
	 * 設置場所情報取得
	 *
	 * @param selectCondition
	 * @return
	 */
	List<SechiBasho> getSechiBashoInfo (SechiBasho selectCondition);

}
