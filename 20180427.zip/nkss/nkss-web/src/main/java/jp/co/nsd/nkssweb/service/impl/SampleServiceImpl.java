package jp.co.nsd.nkssweb.service.impl;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import jp.co.nsd.nkssweb.dao.Sample;
import jp.co.nsd.nkssweb.dao.mapper.SampleMapper;
import jp.co.nsd.nkssweb.service.SampleService;

@Service
public class SampleServiceImpl implements SampleService {

	// ログ
	private Logger logger = LoggerFactory.getLogger(this.getClass());

    @Autowired
    private SampleMapper sampleMapper;

    public Sample selectByPrimaryKey(String userId) throws Exception {
    	logger.info("SampleServiceImpl.selectByPrimaryKey start");
        return sampleMapper.selectByPrimaryKey(userId);
    }

    public List<Sample> selectAll() {
        return sampleMapper.selectAll();
    }

    public List<Sample> selectByWhere() {
    	Sample sample = new Sample();

    	sample.setUserId("0001");
    	sample.setUserName("甘");
        return sampleMapper.selectByWhere(sample);
    }

    public void callTestFunction(String userId) {
    	System.out.println("start callTestFunction");
    	Sample sample = new Sample();

    	sample.setUserId(userId);
    	sample.setUserName("ユーザー名");
    	sampleMapper.callTestFunction(sample);
    	System.out.println("end callTestFunction");
    }
}
