package jp.co.nsd.nkssweb.service.seisanshotoroku.impl;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import jp.co.nsd.nkssweb.dao.Kss002;
import jp.co.nsd.nkssweb.dao.Kss002Key;
import jp.co.nsd.nkssweb.dao.Kss004;
import jp.co.nsd.nkssweb.dao.Kss004Key;
import jp.co.nsd.nkssweb.dao.Kss005Key;
import jp.co.nsd.nkssweb.dao.SeisanshoToroku;
import jp.co.nsd.nkssweb.dao.mapper.Kss002Mapper;
import jp.co.nsd.nkssweb.dao.mapper.Kss004Mapper;
import jp.co.nsd.nkssweb.dao.mapper.SeisanshoTorokuMapper;
import jp.co.nsd.nkssweb.service.seisanshotoroku.SeisanshoTorokuService;
import jp.co.nsd.nkssweb.utils.NSDConstant;

@Service
public class SeisanshoTorokuServiceImpl implements SeisanshoTorokuService {

	@Autowired
	private SeisanshoTorokuMapper sssTrkMapper;

	@Autowired
	private Kss002Mapper kss002Mapper;

	@Autowired
	private Kss004Mapper kss004Mapper;

	@Override
	public List<SeisanshoToroku> getSeisanshoTorokuKensaku(SeisanshoToroku selectCondition) {

		List<SeisanshoToroku> sssTrkList = new ArrayList<SeisanshoToroku>();

		sssTrkList = sssTrkMapper.selectByWhere(selectCondition);

		if (sssTrkList.size() > 0) {
			for (int i = 1; i <= sssTrkList.size(); i++) {
				sssTrkList.get(i - 1).setRowNo(i);
			}
		} else {
			sssTrkList = null;
		}

		return sssTrkList;

	}

	@Override
	public List<SeisanshoToroku> getSeisanshoTorokuShokai(SeisanshoToroku selectCondition) {

		List<SeisanshoToroku> sssTrkList = new ArrayList<SeisanshoToroku>();

		sssTrkList = sssTrkMapper.selectByKey(selectCondition);

		if (sssTrkList.size() > 0) {
			for (int i = 1; i <= sssTrkList.size(); i++) {
				sssTrkList.get(i - 1).setRowNo(i);

				SeisanshoToroku sssTrkDto = sssTrkList.get(i-1);

				// 連携対象
				if (NSDConstant.STRING_0.equals(sssTrkDto.getRenkeiStatus())) {
					// 0:未連携
					sssTrkDto.setRenkeiStatus(NSDConstant.MIRENKEI);
				} else if (NSDConstant.STRING_1.equals(sssTrkDto.getRenkeiStatus())) {
					// 1:連携済
					sssTrkDto.setRenkeiStatus(NSDConstant.RENKEIZUMI);
				} else if (NSDConstant.STRING_9.equals(sssTrkDto.getRenkeiStatus())) {
					// 9：対象外
					sssTrkDto.setRenkeiStatus(NSDConstant.TAISYOGAI);
				} else {
					// 処理なし
				}
			}
		} else {
			sssTrkList = null;
		}

		return sssTrkList;

	}


	/**
	 * 除却（削除）処理
	 *
	 * @param seisanshoToroku
	 *            INPUTパラメータ
	 * @return cnt
	 * @version 1.00
	 */

	public int delkmmstByPyKey(Long kenmeiId, String kenmeimstCd, String kenmeiNm, Date tekiyoStartYmd) {



		Kss002Key kss002Key = new Kss002Key();
		// 除却精算書ＩＤ
		kss002Key.setKenmeiId(kenmeiId);
		// 除却資産ＩＤ
		kss002Key.setKenmeiCd(kenmeimstCd);
		// 除却資産ＩＤ
		kss002Key.setKenmeiNm(kenmeiNm);
		// 除却資産ＩＤ
		kss002Key.setTekiyoStartYmd(tekiyoStartYmd);

		sssTrkMapper.deleteKenMeByPyKey(kss002Key);

		return 0;
	}
	public int delByPyKey(String seisanShoId, String koteiShisanId) {

		Kss004Key kss004Key = new Kss004Key();
		// 除却精算書ＩＤ
		kss004Key.setSeisanShoId(seisanShoId);
		// 除却資産ＩＤ
		kss004Key.setKoteiShisanId(koteiShisanId);

		sssTrkMapper.deleteByPyKey(kss004Key);

		return 0;
	}

	public int delmesaiByPyKey(String seisanShoId, String koteiShisanId) {

		Kss005Key kss005Key = new Kss005Key();
		// 除却精算書ＩＤ
		kss005Key.setSeisanShoId(seisanShoId);
		// 除却資産ＩＤ
		kss005Key.setKoteiShisanId(koteiShisanId);

		sssTrkMapper.deletemesaiByPyKey(kss005Key);

		return 0;
	}

	@Override
	public void insertSeisansho(Kss002 kss002, Kss004 kss004) {

		kss002Mapper.insert(kss002);

		kss004Mapper.insert(kss004);

	}

}
