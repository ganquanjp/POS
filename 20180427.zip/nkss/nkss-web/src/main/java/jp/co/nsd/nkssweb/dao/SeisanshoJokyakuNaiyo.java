package jp.co.nsd.nkssweb.dao;

public class SeisanshoJokyakuNaiyo {

	// 行番号
	private int rowNo;

	// 除却精算書ＩＤ
	private String jokyakuSeisanShoId;

	// 除却資産ＩＤ
	private String jokyakuShisanId;

	// 除却精算書番号
	private String jokyakuSeisanShoNo;

	// 件名
	private String kenmeiNm;

	// 除却予定年月日(FROM)
	private String jokyakuYoteYmdFrom;

	// 除却予定年月日(TO)
	private String jokyakuYoteYmdTo;

	// 除却予定年月日
	private String jokyakuYoteYmd;

	// 組織連結略名
	private String soshikiRenNm;

	public int getRowNo() {
		return rowNo;
	}

	public void setRowNo(int rowNo) {
		this.rowNo = rowNo;
	}

	public String getJokyakuSeisanShoId() {
		return jokyakuSeisanShoId;
	}

	public void setJokyakuSeisanShoId(String jokyakuSeisanShoId) {
		this.jokyakuSeisanShoId = jokyakuSeisanShoId;
	}

	public String getJokyakuShisanId() {
		return jokyakuShisanId;
	}

	public void setJokyakuShisanId(String jokyakuShisanId) {
		this.jokyakuShisanId = jokyakuShisanId;
	}

	public String getJokyakuSeisanShoNo() {
		return jokyakuSeisanShoNo;
	}

	public void setJokyakuSeisanShoNo(String jokyakuSeisanShoNo) {
		this.jokyakuSeisanShoNo = jokyakuSeisanShoNo;
	}

	public String getKenmeiNm() {
		return kenmeiNm;
	}

	public void setKenmeiNm(String kenmeiNm) {
		this.kenmeiNm = kenmeiNm;
	}

	public String getJokyakuYoteYmdFrom() {
		return jokyakuYoteYmdFrom;
	}

	public void setJokyakuYoteYmdFrom(String jokyakuYoteYmdFrom) {
		this.jokyakuYoteYmdFrom = jokyakuYoteYmdFrom;
	}

	public String getJokyakuYoteYmdTo() {
		return jokyakuYoteYmdTo;
	}

	public void setJokyakuYoteYmdTo(String jokyakuYoteYmdTo) {
		this.jokyakuYoteYmdTo = jokyakuYoteYmdTo;
	}

	public String getJokyakuYoteYmd() {
		return jokyakuYoteYmd;
	}

	public void setJokyakuYoteYmd(String jokyakuYoteYmd) {
		this.jokyakuYoteYmd = jokyakuYoteYmd;
	}

	public String getSoshikiRenNm() {
		return soshikiRenNm;
	}

	public void setSoshikiRenNm(String soshikiRenNm) {
		this.soshikiRenNm = soshikiRenNm;
	}





}