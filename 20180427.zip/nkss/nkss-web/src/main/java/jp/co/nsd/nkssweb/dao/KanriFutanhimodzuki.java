package jp.co.nsd.nkssweb.dao;

import java.util.Date;

public class KanriFutanhimodzuki {

	// 行番号
	private int rowNo;

	// 管理箇所
	private String kanriSoshikiKnj;

	// 管理箇所コード
	private String kanriSoshikiCd;

	// 管理箇所適用期間（FROM）
	private Date kanriTekiyoStartYmd;

	// 管理箇所適用期間（TO）
	private Date kanriTekiyoEndYmd;

	// 負担箇所
	private String futanSoshikiKnj;

	// 管理箇所コード
	private String futanSoshikiCd;

	// 負担箇所適用期間（FROM）
	private Date futanTekiyoStartYmd;

	// 負担箇所適用期間（TO）
	private Date futanTekiyoEndYmd;

	// 登録年月日
	private String entryDate;

	// 登録ユーザーＩＤ
	private String entryUserId;

	// 更新年月日
	private String updateDate;

	// 更新ユーザーＩＤ
	private String updateUserId;

	public int getRowNo() {
		return rowNo;
	}

	public void setRowNo(int rowNo) {
		this.rowNo = rowNo;
	}

	public String getKanriSoshikiKnj() {
		return kanriSoshikiKnj;
	}

	public void setKanriSoshikiKnj(String kanriSoshikiKnj) {
		this.kanriSoshikiKnj = kanriSoshikiKnj;
	}

	public String getKanriSoshikiCd() {
		return kanriSoshikiCd;
	}

	public void setKanriSoshikiCd(String kanriSoshikiCd) {
		this.kanriSoshikiCd = kanriSoshikiCd;
	}

	public Date getKanriTekiyoStartYmd() {
		return kanriTekiyoStartYmd;
	}

	public void setKanriTekiyoStartYmd(Date kanriTekiyoStartYmd) {
		this.kanriTekiyoStartYmd = kanriTekiyoStartYmd;
	}

	public Date getKanriTekiyoEndYmd() {
		return kanriTekiyoEndYmd;
	}

	public void setKanriTekiyoEndYmd(Date kanriTekiyoEndYmd) {
		this.kanriTekiyoEndYmd = kanriTekiyoEndYmd;
	}

	public String getFutanSoshikiKnj() {
		return futanSoshikiKnj;
	}

	public void setFutanSoshikiKnj(String futanSoshikiKnj) {
		this.futanSoshikiKnj = futanSoshikiKnj;
	}

	public String getFutanSoshikiCd() {
		return futanSoshikiCd;
	}

	public void setFutanSoshikiCd(String futanSoshikiCd) {
		this.futanSoshikiCd = futanSoshikiCd;
	}

	public Date getFutanTekiyoStartYmd() {
		return futanTekiyoStartYmd;
	}

	public void setFutanTekiyoStartYmd(Date futanTekiyoStartYmd) {
		this.futanTekiyoStartYmd = futanTekiyoStartYmd;
	}

	public Date getFutanTekiyoEndYmd() {
		return futanTekiyoEndYmd;
	}

	public void setFutanTekiyoEndYmd(Date futanTekiyoEndYmd) {
		this.futanTekiyoEndYmd = futanTekiyoEndYmd;
	}

	public String getEntryDate() {
		return entryDate;
	}

	public void setEntryDate(String entryDate) {
		this.entryDate = entryDate;
	}

	public String getEntryUserId() {
		return entryUserId;
	}

	public void setEntryUserId(String entryUserId) {
		this.entryUserId = entryUserId;
	}

	public String getUpdateDate() {
		return updateDate;
	}

	public void setUpdateDate(String updateDate) {
		this.updateDate = updateDate;
	}

	public String getUpdateUserId() {
		return updateUserId;
	}

	public void setUpdateUserId(String updateUserId) {
		this.updateUserId = updateUserId;
	}





}