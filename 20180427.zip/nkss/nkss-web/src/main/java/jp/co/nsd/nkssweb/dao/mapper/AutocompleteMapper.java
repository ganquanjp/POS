package jp.co.nsd.nkssweb.dao.mapper;

import java.util.List;

import jp.co.nsd.nkssweb.dao.Aads01;
import jp.co.nsd.nkssweb.dao.Abda09;
import jp.co.nsd.nkssweb.dao.Kss002;
import jp.co.nsd.nkssweb.dao.Kss011;
import jp.co.nsd.nkssweb.dao.Kss013;

public interface AutocompleteMapper {

    List<Kss002> selectAllKss002();

    List<Kss011> selectAllKss011();

	List<Kss013> selectAllKss013();

	List<Abda09> selectAllAbda09();

	List<Aads01> selectAllAads01();

}