package jp.co.nsd.nkssweb.service.seisanshoshutoku.impl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import jp.co.nsd.nkssweb.dao.Kss005;
import jp.co.nsd.nkssweb.dao.Kss005Key;
import jp.co.nsd.nkssweb.dao.SeisanshoShutokuKensaku;
import jp.co.nsd.nkssweb.dao.SeisanshoShutokuShokai;
import jp.co.nsd.nkssweb.dao.mapper.Kss005Mapper;
import jp.co.nsd.nkssweb.dao.mapper.SeisanshoShutokuMapper;
import jp.co.nsd.nkssweb.service.seisanshoshutoku.SeisanshoShutokuService;

@Service
public class SeisanshoShutokuServiceImpl implements SeisanshoShutokuService {

	@Autowired
	private SeisanshoShutokuMapper seisanshoShutokuMapper;

	@Autowired
	private Kss005Mapper kss005Mapper;

	@Override
	public List<SeisanshoShutokuKensaku> getSeisanshoShutokuKensaku(SeisanshoShutokuKensaku selectCondition) {
		List<SeisanshoShutokuKensaku> sssStkList = new ArrayList<SeisanshoShutokuKensaku>();

		sssStkList = seisanshoShutokuMapper.kensaku(selectCondition);

		if (sssStkList.size() > 0) {
			for (int i = 1; i <= sssStkList.size(); i++) {
				sssStkList.get(i - 1).setRowNo(i);
			}
		} else {
			sssStkList = null;
		}

		return sssStkList;

	}

	@Override
	public List<SeisanshoShutokuShokai> getSeisanshoShutokuShokai(SeisanshoShutokuShokai selectCondition) {

		List<SeisanshoShutokuShokai> sssStkList = new ArrayList<SeisanshoShutokuShokai>();

		sssStkList = seisanshoShutokuMapper.shokai(selectCondition);

		if (sssStkList.size() > 0) {
			for (int i = 1; i <= sssStkList.size(); i++) {
				sssStkList.get(i - 1).setRowNo(i);
			}
		} else {
			sssStkList = null;
		}

		return sssStkList;

	}

	/**
	 * 取得・削除処理
	 *
	 * @param seisanshoShutoku
	 *            INPUTパラメータ
	 * @return cnt
	 * @version 1.00
	 */
	public int delByPyKey(String seisanShoId, String koteiShisanId) {

		Kss005Key kss005Key = new Kss005Key();
		// 精算書ＩＤ
		kss005Key.setSeisanShoId(seisanShoId);
		// 固定資産ＩＤ
		kss005Key.setKoteiShisanId(koteiShisanId);
		// 取得資産明細情報を削除
		seisanshoShutokuMapper.deleteByPyKey(kss005Key);

		return 0;
	}

	/**
	 * 取得新規登録を処理
	 *
	 * @param kss005
	 *            INPUTパラメータ
	 * @param shuruiInfo
	 *            INPUTパラメータ
	 * @return cnt
	 * @version 1.00
	 * @throws Exception
	 */
	@Override
	public void insert(Kss005 kss005, Kss005 shuruiInfo) throws Exception {

		//耐用月数＿商
		kss005.setTaiyoTsukisuSho(kss005.getTaiyoTsukisuZei());

//		kss005Mapper.insert(record);

	}

}
