package jp.co.nsd.nkssweb.dao;

public class SeisanshoToroku {

	private int rowNo;
	private String seisanShoId;
	private String koteiShisanId;
	private String seisanShoNo;
	private String soshikiNm;
	private String siyoStartYmd;
	private String siyoStartYmdFrom;
	private String siyoStartYmdTo;
	private String tekiyo;
	private String yoyakusu;
	private String torokushaName;
	private String kenmeiCd;
	private String kenmeiId;
	private String kenmeimstCd;
	private String kenmeiNm;
	private String tekiyoStartYmd;
	private String tekiyoEndYmd;
	private String renkeiStatus;
	private String shoninStatus;




	public int getRowNo() {
		return rowNo;
	}
	public void setRowNo(int rowNo) {
		this.rowNo = rowNo;
	}
	public String getSeisanShoId() {
		return seisanShoId;
	}
	public void setSeisanShoId(String seisanShoId) {
		this.seisanShoId = seisanShoId;
	}
	public String getKoteiShisanId() {
		return koteiShisanId;
	}
	public void setKoteiShisanId(String koteiShisanId) {
		this.koteiShisanId = koteiShisanId;
	}
	public String getSeisanShoNo() {
		return seisanShoNo;
	}
	public void setSeisanShoNo(String seisanShoNo) {
		this.seisanShoNo = seisanShoNo;
	}
	public String getSoshikiNm() {
		return soshikiNm;
	}
	public void setSoshikiNm(String soshikiNm) {
		this.soshikiNm = soshikiNm;
	}
	public String getSiyoStartYmd() {
		return siyoStartYmd;
	}
	public void setSiyoStartYmd(String siyoStartYmd) {
		this.siyoStartYmd = siyoStartYmd;
	}
	public String getSiyoStartYmdFrom() {
		return siyoStartYmdFrom;
	}
	public void setSiyoStartYmdFrom(String siyoStartYmdFrom) {
		this.siyoStartYmdFrom = siyoStartYmdFrom;
	}
	public String getSiyoStartYmdTo() {
		return siyoStartYmdTo;
	}
	public void setSiyoStartYmdTo(String siyoStartYmdTo) {
		this.siyoStartYmdTo = siyoStartYmdTo;
	}
	public String getTekiyo() {
		return tekiyo;
	}
	public void setTekiyo(String tekiyo) {
		this.tekiyo = tekiyo;
	}
	public String getYoyakusu() {
		return yoyakusu;
	}
	public void setYoyakusu(String yoyakusu) {
		this.yoyakusu = yoyakusu;
	}
	public String getTorokushaName() {
		return torokushaName;
	}
	public void setTorokushaName(String torokushaName) {
		this.torokushaName = torokushaName;
	}
	public String getKenmeiCd() {
		return kenmeiCd;
	}
	public void setKenmeiCd(String kenmeiCd) {
		this.kenmeiCd = kenmeiCd;
	}
	public String getKenmeiId() {
		return kenmeiId;
	}
	public void setKenmeiId(String kenmeiId) {
		this.kenmeiId = kenmeiId;
	}
	public String getKenmeimstCd() {
		return kenmeimstCd;
	}
	public void setKenmeimstCd(String kenmeimstCd) {
		this.kenmeimstCd = kenmeimstCd;
	}
	public String getKenmeiNm() {
		return kenmeiNm;
	}
	public void setKenmeiNm(String kenmeiNm) {
		this.kenmeiNm = kenmeiNm;
	}
	public String getTekiyoStartYmd() {
		return tekiyoStartYmd;
	}
	public void setTekiyoStartYmd(String tekiyoStartYmd) {
		this.tekiyoStartYmd = tekiyoStartYmd;
	}
	public String getTekiyoEndYmd() {
		return tekiyoEndYmd;
	}
	public void setTekiyoEndYmd(String tekiyoEndYmd) {
		this.tekiyoEndYmd = tekiyoEndYmd;
	}
	public String getRenkeiStatus() {
		return renkeiStatus;
	}
	public void setRenkeiStatus(String renkeiStatus) {
		this.renkeiStatus = renkeiStatus;
	}
	public String getShoninStatus() {
		return shoninStatus;
	}
	public void setShoninStatus(String shoninStatus) {
		this.shoninStatus = shoninStatus;
	}



}