package jp.co.nsd.nkssweb.dao.mapper;

import jp.co.nsd.nkssweb.dao.KoteiSisan;

public interface KoteiSisanJyohoMapper {

	/**
	 * 固定資産情報検索
	 *
	 * @param koteiSisan
	 *            INPUTパラメータ
	 * @return　検索結果
	 */
	KoteiSisan selectKoteiSisanByKoteiCod(KoteiSisan koteiSisan);

}