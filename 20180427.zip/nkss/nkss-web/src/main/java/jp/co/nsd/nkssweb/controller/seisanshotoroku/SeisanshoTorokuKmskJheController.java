package jp.co.nsd.nkssweb.controller.seisanshotoroku;


import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import jp.co.nsd.nkssweb.service.seisanshotoroku.SeisanshoTorokuKmskJheService;
import jp.co.nsd.nkssweb.utils.NSDConstant;


@RestController
public class SeisanshoTorokuKmskJheController {
	// ログ
	private Logger logger = LoggerFactory.getLogger(this.getClass());

	@Autowired
	private SeisanshoTorokuKmskJheService seisanshoTorokuKmskJheService;
	/*
	 * 精算書登録・件名即時反映
	 */
	@RequestMapping(value = "/seisanshoTorokuKmskJhe-selectByWhere", method = RequestMethod.POST)
	public Map<String, Object> selectByBat(@RequestParam Map<String, Object> reqMap)  throws Exception {

		// 開始ログ
		logger.info("SeisanshoTorokuKmskJheController.selectByBat 開始します。");

		Map<String, Object> returnMap = new HashMap<String, Object>();

		// サービス呼び出し
		seisanshoTorokuKmskJheService.getKenmeiInfo(NSDConstant.CODE_SAKUSEI_KBN_WEB);
		// 処理結果データ
		returnMap.put("dataList", "");
		// メッセージ内容
		returnMap.put("msg", "");

		// 終了ログ
		logger.info("SeisanshoTorokuKmskJheController.selectByWhere 終了します。");

		return returnMap;
	}

}
