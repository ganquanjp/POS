package jp.co.nsd.nkssweb.dao.mapper;

import java.util.List;

import jp.co.nsd.nkssweb.dao.SeisanshoTorokuKmskJhe;

public interface SeisanshoTorokuKmskJheMapper {

    List<SeisanshoTorokuKmskJhe> selectByWhere();

    int updateByPrimaryKey(SeisanshoTorokuKmskJhe record);

    int updateBySeqNo(SeisanshoTorokuKmskJhe record);

    int insertBySeqNo(SeisanshoTorokuKmskJhe record);

	int selectSeqNo();

    String selectFileName();

    String selectFileCreateYmd();


}