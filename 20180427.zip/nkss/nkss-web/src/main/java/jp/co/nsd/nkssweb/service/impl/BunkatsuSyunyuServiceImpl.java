package jp.co.nsd.nkssweb.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import jp.co.nsd.nkssweb.dao.BunkatsuSyunyu;
import jp.co.nsd.nkssweb.dao.mapper.BunkatsuSyunyuMapper;
import jp.co.nsd.nkssweb.service.BunkatsuSyunyuService;
import jp.co.nsd.nkssweb.utils.NSDConstant;

@Service
public class BunkatsuSyunyuServiceImpl implements BunkatsuSyunyuService {

	@Autowired
	private BunkatsuSyunyuMapper bunkatsuSyunyuMapper;

	/**
	 * 分割収入画面内容取得
	 *
	 */
	public List<BunkatsuSyunyu> getBunkatsuInfo(BunkatsuSyunyu selectCondition) {
		List<BunkatsuSyunyu> bktSnList = new ArrayList<BunkatsuSyunyu>();

		bktSnList = bunkatsuSyunyuMapper.selectByWhere(selectCondition);

		if (bktSnList.size() > 0) {
			for (int i = 1; i <= bktSnList.size(); i++) {

				BunkatsuSyunyu bktSnDto = bktSnList.get(i-1);
				// ROWNOを設定する
				bktSnDto.setRowNo(i);

				// 連携対象
				if (NSDConstant.SHONIN_STATUS_CODE_TOROKU.equals(bktSnDto.getShoninStatus())) {
					// 承認状態コード(00:登録中)
					bktSnDto.setShoninStatus(NSDConstant.SHONIN_STATUS_NAME_TOROKU);
				} else if (NSDConstant.SHONIN_STATUS_CODE_SHINSA.equals(bktSnDto.getShoninStatus())) {
					// 承認状態コード(02:経理審査済)
					bktSnDto.setShoninStatus(NSDConstant.SHONIN_STATUS_NAME_SHINSA);
				} else if (NSDConstant.SHONIN_STATUS_CODE_HININ.equals(bktSnDto.getShoninStatus())) {
					// 承認状態コード(20:経理審査否認)
					bktSnDto.setShoninStatus(NSDConstant.SHONIN_STATUS_NAME_HININ);
				} else {
					// 処理なし
				}

			}
		} else {
			bktSnList = null;
		}

		return bktSnList;

	}
}
