/***********************************************************************
*
*業務名: 工事精算システム
*機能名: 除却（登録・修正・削除）(サービス処理)
*
*機能概要: 除却情報を処理する。
*
*JavaＶｅｒ：J2SE1.8.0準拠
*
*更新履歴: Ver.1.00 2018/03/06　NSD　新規作成
***********************************************************************/
package jp.co.nsd.nkssweb.service.seisanshojokyaku.impl;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.beanutils.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import jp.co.nsd.nkssweb.dao.KoteiSisan;
import jp.co.nsd.nkssweb.dao.Kss007;
import jp.co.nsd.nkssweb.dao.Kss016;
import jp.co.nsd.nkssweb.dao.Kss016Key;
import jp.co.nsd.nkssweb.dao.SeisanshoJokyakuKoteiSisan;
import jp.co.nsd.nkssweb.dao.SeisanshoJokyakuNaiyo;
import jp.co.nsd.nkssweb.dao.SeisanshoJokyakuNaiyoShokai;
import jp.co.nsd.nkssweb.dao.mapper.KoteiSisanJyohoMapper;
import jp.co.nsd.nkssweb.dao.mapper.Kss007Mapper;
import jp.co.nsd.nkssweb.dao.mapper.Kss016Mapper;
import jp.co.nsd.nkssweb.dao.mapper.SeisanshoJokyakuNaiyoMapper;
import jp.co.nsd.nkssweb.dao.mapper.StoredMapper;
import jp.co.nsd.nkssweb.service.seisanshojokyaku.SeisanshoJokyakuNaiyoService;
import jp.co.nsd.nkssweb.utils.NSDConstant;

/**
 * 除却（内容入力）処理
 *
 * @see SeisanshoJokyakuNaiyoService
 * @version 1.00
 */
@Service
public class SeisanshoJokyakuNaiyoServiceImpl implements SeisanshoJokyakuNaiyoService {

	@Autowired
	private SeisanshoJokyakuNaiyoMapper seisanshoJokyakuNaiyoMapper;

	@Autowired
	private KoteiSisanJyohoMapper koteiSisanJyohoMapper;

	@Autowired
	private Kss007Mapper kss007Mapper;

	@Autowired
	private Kss016Mapper kss016Mapper;

	@Autowired
	private StoredMapper storedMapper;

	/**
	 * 除却（内容入力）処理
	 *
	 * @param seisanshoJokyakuNaiyo
	 *            INPUTパラメータ
	 * @return sssJykList 除却情報データリスト
	 * @version 1.00
	 */
	public List<SeisanshoJokyakuNaiyo> getJokyakuNaiyoInfo(SeisanshoJokyakuNaiyo seisanshoJokyakuNaiyo) {

		// 除却情報を取得する
		List<SeisanshoJokyakuNaiyo> sssJykNyList = seisanshoJokyakuNaiyoMapper.selectByWhere(seisanshoJokyakuNaiyo);

		if (sssJykNyList.size() > 0) {
			for (int i = 1; i <= sssJykNyList.size(); i++) {
				// ROWNOを設定する
				sssJykNyList.get(i - 1).setRowNo(i);
			}

		} else {
			sssJykNyList = null;
		}

		return sssJykNyList;
	}

	/**
	 * 除却内容入力（照会）処理
	 *
	 * @param seisanshoJokyakuNaiyoShokai
	 *            INPUTパラメータ
	 * @return SeisanshoJokyakuNaiyoShokai 除却情報データ
	 * @throws Exception
	 * @version 1.00
	 */
	public SeisanshoJokyakuNaiyoShokai getJokyakuInfoBySeisanShoNo(
			SeisanshoJokyakuNaiyoShokai seisanshoJokyakuNaiyoShokai) throws Exception {

		// 除却情報
		SeisanshoJokyakuNaiyoShokai resultDto = new SeisanshoJokyakuNaiyoShokai();
		// 除却固定資産情報
		SeisanshoJokyakuKoteiSisan sssJykKsDto;

		// 除却資産情報を取得する
		List<SeisanshoJokyakuNaiyoShokai> sssJykNySkList = seisanshoJokyakuNaiyoMapper
				.selectBySeisanShoNo(seisanshoJokyakuNaiyoShokai);

		List<SeisanshoJokyakuKoteiSisan> sssJykKsLst = new ArrayList<>();

		for (int i = 0; i < sssJykNySkList.size(); i++) {
			// 除却資産情報
			SeisanshoJokyakuNaiyoShokai sssJykNySkDto = sssJykNySkList.get(i);

			// Mapの情報をBeanのプロパティにセット
			BeanUtils.copyProperties(resultDto, sssJykNySkDto);

			// 除却区分
			String jokyakuKbn = sssJykNySkDto.getJokyakuKbn();
			// 除却種別コード
			String jokyakuShubetsuCd = sssJykNySkDto.getJokyakuShubetsuCd();

			if (NSDConstant.STRING_1.equals(jokyakuKbn)) {
				if (NSDConstant.STRING_5.equals(jokyakuShubetsuCd)) {
					jokyakuShubetsuCd = NSDConstant.STRING_1;
				} else if (NSDConstant.STRING_6.equals(jokyakuShubetsuCd)) {
					jokyakuShubetsuCd = NSDConstant.STRING_2;
				} else if (NSDConstant.STRING_7.equals(jokyakuShubetsuCd)) {
					jokyakuShubetsuCd = NSDConstant.STRING_4;
				} else {
					jokyakuShubetsuCd = NSDConstant.BLANK_STRING;
				}
			}

			// 除却区分名称
			String jokyakuKbnNm = getKss016("CD0006", jokyakuKbn);

			// 除却種別名称
			String jokyakuShubetsuNm = getKss016("CD0008", jokyakuShubetsuCd);

			KoteiSisan koteiSisan = new KoteiSisan();
			// 固定ID
			koteiSisan.setKoteiCod(sssJykNySkDto.getMotoKoteiShisanId());
			// 履歴ID
			koteiSisan.setRrkCod(sssJykNySkDto.getRirekiNo());
			// 固定資産情報を取得する
			KoteiSisan ksDto = koteiSisanJyohoMapper.selectKoteiSisanByKoteiCod(koteiSisan);

			// 固定資産情報取得できないの場合
			if (null != ksDto) {

				sssJykKsDto = new SeisanshoJokyakuKoteiSisan();
				// ROWNO
				sssJykKsDto.setRowNo(i + 1);
				// 固定資産ID
				sssJykKsDto.setKoteiCod(ksDto.getKoteiCod());
				// 履歴ID
				sssJykKsDto.setRrkCod(ksDto.getRrkCod());
				// 除却精算書ID
				sssJykKsDto.setJokyakuSeisanShoId(sssJykNySkDto.getJokyakuSeisanShoId());
				// 除却資産ID
				sssJykKsDto.setJokyakuShisanId(sssJykNySkDto.getJokyakuShisanId());
				// 固定資産番号
				sssJykKsDto.setKoteiNo(ksDto.getKoteiNo());
				// 固定資産名称
				sssJykKsDto.setKoteiKnj(ksDto.getKoteiKnj());
				// 取得年月日
				sssJykKsDto.setGetYmd(ksDto.getGetYmd());
				// 元_数量
				sssJykKsDto.setMeiSu(ksDto.getMeiSu());
				// 単位
				sssJykKsDto.setTaniKnj(ksDto.getTaniKnj());
				// 元_取得価額
				sssJykKsDto.setGetkgkYen(ksDto.getGetkgkYen());
				// 除却区分名称
				sssJykKsDto.setJokyakuKbnNm(jokyakuKbnNm);
				// 除却区分コード
				sssJykKsDto.setJokyakuKbn(jokyakuKbn);
				// 除却種別コード
				sssJykKsDto.setJokyakuShubetsuCd(jokyakuShubetsuCd);
				// 除却種別名称
				sssJykKsDto.setJokyakuShubetsuNm(jokyakuShubetsuNm);
				// 除_数量
				sssJykKsDto.setJokyakuSuryo(sssJykNySkDto.getJokyakuSuryo());
				// 除_取得価額
				sssJykKsDto.setJokyakuGaku(sssJykNySkDto.getJokyakuGaku());
				// 固定資産情報を追加
				sssJykKsLst.add(sssJykKsDto);
			}

		}

		if (sssJykKsLst.size() > 0) {
			// 固定資産情報リスト
			resultDto.setKoteiSisanLst(sssJykKsLst);
		} else {
			return null;
		}

		return resultDto;
	}

	/**
	 * 除却（更新）処理
	 *
	 * @param kss007UpdLst
	 *            INPUTパラメータ
	 * @return cnt
	 * @version 1.00
	 * @throws Exception
	 */
	public int updateInfo(List<Kss007> kss007UpdLst) throws Exception {

		// 除却資産明細(更新)
		for (Kss007 kss007 : kss007UpdLst) {

			// 除却区分
			String jokyakuKbn = kss007.getJokyakuKbn();
			// 除却種別コード
			String jokyakuShubetsuCd = kss007.getJokyakuShubetsuCd();

			if (NSDConstant.STRING_1.equals(jokyakuKbn)) {
				if (NSDConstant.STRING_1.equals(jokyakuShubetsuCd)) {
					jokyakuShubetsuCd = NSDConstant.STRING_5;
				} else if (NSDConstant.STRING_2.equals(jokyakuShubetsuCd)) {
					jokyakuShubetsuCd = NSDConstant.STRING_6;
				} else if (NSDConstant.STRING_4.equals(jokyakuShubetsuCd)) {
					jokyakuShubetsuCd = NSDConstant.STRING_7;
				} else {
					jokyakuShubetsuCd = NSDConstant.BLANK_STRING;
				}
			}

			// 除却区分
			kss007.setJokyakuKbn(jokyakuKbn);
			// 除却種別コード
			kss007.setJokyakuShubetsuCd(jokyakuShubetsuCd);

			// 除却資産明細登録
			kss007Mapper.updateByPrimaryKeySelective(kss007);

//			// 除却内容入力（更新）ストアド処理
//			try {
//				Map<String, Object> map = new HashMap<String, Object>();
//				map.put("jokyakuSeisanShoId", kss007.getJokyakuSeisanShoId());
//				map.put("jokyakuShisanId", kss007.getJokyakuShisanId());
//				map.put("shoriKbn", 0);
//				// 更新後の処理
//				storedMapper.setAllKs2030(map);
//			} catch (Exception e) {
//				throw new Exception("減価償却計算処理でエラーが発生しました. error=[" + e.getMessage() + "]");
//			}
		}

		return 0;
	}

	/**
	 * コードマスタ名称取得を処理
	 *
	 * @param cdShubetsu
	 *            INPUTパラメータ
	 * @param cd1
	 *            INPUTパラメータ
	 * @version 1.00
	 */
	protected String getKss016(String cdShubetsu, String cd1) {

		Kss016Key kss016Key = new Kss016Key();
		kss016Key.setCdShubetsu(cdShubetsu);
		kss016Key.setCd1(cd1);
		kss016Key.setCd2(NSDConstant.BLANK_STRING);
		Kss016 kss016 = kss016Mapper.selectByPrimaryKey(kss016Key);
		if (null == kss016) {
			return NSDConstant.BLANK_STRING;
		}
		return kss016.getCdKnj();
	}
}
