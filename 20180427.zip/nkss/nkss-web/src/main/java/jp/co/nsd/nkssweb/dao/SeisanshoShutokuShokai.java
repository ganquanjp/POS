package jp.co.nsd.nkssweb.dao;

public class SeisanshoShutokuShokai extends Kss005 {

	private int rowNo;
	private String soshikiNm;
	private String siyoStartYmd;
	private String torokushaName;
	private String koteiShisanNo;
	private String koteiShisanName;
	private String sechiBashoName;
	private String kenmeiCd;
	private String kenmeiNm;
	private Long shutokuGaku;
	private String shoninStatus;
	private String torihikiSakiNm;
	private String shuKnj;
	private String kouKnj;
	private String saiKnj;
	private String shu4Knj;
	private String shu5Knj;
	private String shu6Knj;
	private String taniNm;
	private String kanriSoshikiNm;
	private String futanSoshikiNm;
	private String sechiBashoNm;
	private String shutokuRiyuNm;


	public int getRowNo() {
		return rowNo;
	}
	public void setRowNo(int rowNo) {
		this.rowNo = rowNo;
	}
	public String getSoshikiNm() {
		return soshikiNm;
	}
	public void setSoshikiNm(String soshikiNm) {
		this.soshikiNm = soshikiNm;
	}
	public String getSiyoStartYmd() {
		return siyoStartYmd;
	}
	public void setSiyoStartYmd(String siyoStartYmd) {
		this.siyoStartYmd = siyoStartYmd;
	}
	public String getTorokushaName() {
		return torokushaName;
	}
	public void setTorokushaName(String torokushaName) {
		this.torokushaName = torokushaName;
	}
	public String getKoteiShisanNo() {
		return koteiShisanNo;
	}
	public void setKoteiShisanNo(String koteiShisanNo) {
		this.koteiShisanNo = koteiShisanNo;
	}
	public String getKoteiShisanName() {
		return koteiShisanName;
	}
	public void setKoteiShisanName(String koteiShisanName) {
		this.koteiShisanName = koteiShisanName;
	}
	public String getSechiBashoName() {
		return sechiBashoName;
	}
	public void setSechiBashoName(String sechiBashoName) {
		this.sechiBashoName = sechiBashoName;
	}
	public String getKenmeiCd() {
		return kenmeiCd;
	}
	public void setKenmeiCd(String kenmeiCd) {
		this.kenmeiCd = kenmeiCd;
	}
	public String getKenmeiNm() {
		return kenmeiNm;
	}
	public void setKenmeiNm(String kenmeiNm) {
		this.kenmeiNm = kenmeiNm;
	}
	public Long getShutokuGaku() {
		return shutokuGaku;
	}
	public void setShutokuGaku(Long shutokuGaku) {
		this.shutokuGaku = shutokuGaku;
	}
	public String getShoninStatus() {
		return shoninStatus;
	}
	public void setShoninStatus(String shoninStatus) {
		this.shoninStatus = shoninStatus;
	}
	public String getTorihikiSakiNm() {
		return torihikiSakiNm;
	}
	public void setTorihikiSakiNm(String torihikiSakiNm) {
		this.torihikiSakiNm = torihikiSakiNm;
	}
	public String getShuKnj() {
		return shuKnj;
	}
	public void setShuKnj(String shuKnj) {
		this.shuKnj = shuKnj;
	}
	public String getKouKnj() {
		return kouKnj;
	}
	public void setKouKnj(String kouKnj) {
		this.kouKnj = kouKnj;
	}
	public String getSaiKnj() {
		return saiKnj;
	}
	public void setSaiKnj(String saiKnj) {
		this.saiKnj = saiKnj;
	}
	public String getShu4Knj() {
		return shu4Knj;
	}
	public void setShu4Knj(String shu4Knj) {
		this.shu4Knj = shu4Knj;
	}
	public String getShu5Knj() {
		return shu5Knj;
	}
	public void setShu5Knj(String shu5Knj) {
		this.shu5Knj = shu5Knj;
	}
	public String getShu6Knj() {
		return shu6Knj;
	}
	public void setShu6Knj(String shu6Knj) {
		this.shu6Knj = shu6Knj;
	}
	public String getTaniNm() {
		return taniNm;
	}
	public void setTaniNm(String taniNm) {
		this.taniNm = taniNm;
	}
	public String getKanriSoshikiNm() {
		return kanriSoshikiNm;
	}
	public void setKanriSoshikiNm(String kanriSoshikiNm) {
		this.kanriSoshikiNm = kanriSoshikiNm;
	}
	public String getFutanSoshikiNm() {
		return futanSoshikiNm;
	}
	public void setFutanSoshikiNm(String futanSoshikiNm) {
		this.futanSoshikiNm = futanSoshikiNm;
	}
	public String getSechiBashoNm() {
		return sechiBashoNm;
	}
	public void setSechiBashoNm(String sechiBashoNm) {
		this.sechiBashoNm = sechiBashoNm;
	}
	public String getShutokuRiyuNm() {
		return shutokuRiyuNm;
	}
	public void setShutokuRiyuNm(String shutokuRiyuNm) {
		this.shutokuRiyuNm = shutokuRiyuNm;
	}







}