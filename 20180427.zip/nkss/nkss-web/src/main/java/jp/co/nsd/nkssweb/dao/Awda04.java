package jp.co.nsd.nkssweb.dao;

import java.util.Date;

public class Awda04 {
    private String aw4ShuCod;

    private String aw4KouCod;

    private String aw4SaiCod;

    private String aw4Shu4Cod;

    private String aw4Shu4Knj;

    private Integer aw4UpdateCnt;

    private Date aw4TorokDh;

    private String aw4TorshaCod;

    private Date aw4UpdateDh;

    private String aw4UpdshaCod;

    public String getAw4ShuCod() {
        return aw4ShuCod;
    }

    public void setAw4ShuCod(String aw4ShuCod) {
        this.aw4ShuCod = aw4ShuCod == null ? null : aw4ShuCod.trim();
    }

    public String getAw4KouCod() {
        return aw4KouCod;
    }

    public void setAw4KouCod(String aw4KouCod) {
        this.aw4KouCod = aw4KouCod == null ? null : aw4KouCod.trim();
    }

    public String getAw4SaiCod() {
        return aw4SaiCod;
    }

    public void setAw4SaiCod(String aw4SaiCod) {
        this.aw4SaiCod = aw4SaiCod == null ? null : aw4SaiCod.trim();
    }

    public String getAw4Shu4Cod() {
        return aw4Shu4Cod;
    }

    public void setAw4Shu4Cod(String aw4Shu4Cod) {
        this.aw4Shu4Cod = aw4Shu4Cod == null ? null : aw4Shu4Cod.trim();
    }

    public String getAw4Shu4Knj() {
        return aw4Shu4Knj;
    }

    public void setAw4Shu4Knj(String aw4Shu4Knj) {
        this.aw4Shu4Knj = aw4Shu4Knj == null ? null : aw4Shu4Knj.trim();
    }

    public Integer getAw4UpdateCnt() {
        return aw4UpdateCnt;
    }

    public void setAw4UpdateCnt(Integer aw4UpdateCnt) {
        this.aw4UpdateCnt = aw4UpdateCnt;
    }

    public Date getAw4TorokDh() {
        return aw4TorokDh;
    }

    public void setAw4TorokDh(Date aw4TorokDh) {
        this.aw4TorokDh = aw4TorokDh;
    }

    public String getAw4TorshaCod() {
        return aw4TorshaCod;
    }

    public void setAw4TorshaCod(String aw4TorshaCod) {
        this.aw4TorshaCod = aw4TorshaCod == null ? null : aw4TorshaCod.trim();
    }

    public Date getAw4UpdateDh() {
        return aw4UpdateDh;
    }

    public void setAw4UpdateDh(Date aw4UpdateDh) {
        this.aw4UpdateDh = aw4UpdateDh;
    }

    public String getAw4UpdshaCod() {
        return aw4UpdshaCod;
    }

    public void setAw4UpdshaCod(String aw4UpdshaCod) {
        this.aw4UpdshaCod = aw4UpdshaCod == null ? null : aw4UpdshaCod.trim();
    }
}