/***********************************************************************
*
*業務名: 工事精算システム
*機能名: ストアドプロシージャ
*
*機能概要: ストアドプロシージャを処理する。
*
*JavaＶｅｒ：J2SE1.8.0準拠
*
*更新履歴: Ver.1.00 2018/03/06　NSD　新規作成
***********************************************************************/
package jp.co.nsd.nkssweb.dao.mapper;

import java.util.Map;

/**
 * ストアドプロシージャ処理
 *
 * @version 1.00
 */
public interface StoredMapper {

	/**
	 * 除却新規処理（ストアド）
	 *
	 * @param map
	 *            INPUTDATA
	 */
	void setAllKs2020(Map<String, Object> map);

	/**
	 * 除却内容入力更新処理（ストアド）
	 *
	 * @param map
	 *            INPUTDATA
	 */
	void setAllKs2030(Map<String, Object> map);

	/**
	 * 除却精算通告更新処理（ストアド）
	 *
	 * @param map
	 *            INPUTDATA
	 */
	void setAllKs2040(Map<String, Object> map);

	/**
	 * 除却経理審査／連係更新処理（更新前ストアド１）
	 *
	 */
	void clearSisanIdListKs2070();

	/**
	 * 除却経理審査／連係更新処理（更新前ストアド２）
	 *
	 * @param map
	 *            INPUTDATA
	 */
	void addSisanIdKs2070(Map<String, Object> map);

	/**
	 * 除却精算通告更新処理（更新後ストアド）
	 *
	 * @param map
	 *            INPUTDATA
	 */
	void setAllKs2070(Map<String, Object> map);
}