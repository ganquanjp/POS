package jp.co.nsd.nkssweb.interceptor;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;

import jp.co.nsd.nkssweb.dao.LoginUserInfo;
import jp.co.nsd.nkssweb.service.SystemService;

public class UserLoginHandlerInterceptor extends HandlerInterceptorAdapter {

	@Autowired
	protected SystemService systemService;

	@Override
	public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler)
			throws Exception {
		// ログイン状態判定
		if (!this.isLogined(request.getSession())){
			response.sendError(401);
			return false;
		}
		return true;
	}

	@Override
	public void postHandle(HttpServletRequest request, HttpServletResponse response, Object handler,
			ModelAndView modelAndView) throws Exception {

	}

	@Override
	public void afterCompletion(HttpServletRequest request, HttpServletResponse response, Object handler, Exception ex)
			throws Exception {
		// TODO Auto-generated method stub
	}

	/**
	 * ログイン状態判定
	 *
	 * @param session
	 * @return
	 */
	private boolean isLogined(HttpSession session) {

		boolean isLogined = false;

		LoginUserInfo loginUserInfo = (LoginUserInfo) session.getAttribute("LoginUserInfo");

		if (null == loginUserInfo) {
			isLogined = false;
		} else {
			isLogined = true;
		}

		return isLogined;
	}
}