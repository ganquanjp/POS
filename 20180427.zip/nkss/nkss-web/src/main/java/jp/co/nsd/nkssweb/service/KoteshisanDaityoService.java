package jp.co.nsd.nkssweb.service;

import java.util.List;

import org.springframework.stereotype.Service;

import jp.co.nsd.nkssweb.dao.KoteshisanDaityo;
import jp.co.nsd.nkssweb.dao.KoteshisanDaityoFileInfo;
import net.sf.jasperreports.engine.JRException;

@Service
public interface KoteshisanDaityoService {

	/**
	 * 固定資産台帳ファイル情報取得
	 *
	 * @param sakuseiKbn
	 *            1：夜間（バッチ）/2：昼間（画面）
	 * @throws JRException
	 * @throws Exception
	 *
	 */
	List<KoteshisanDaityo> getKenmeiInfo(String sakuseiKbn) throws Exception;

	/**
	 * 固定資産台帳ファイル生成日時取得
	 *
	 *
	 */
	String getSakuseiTimestamp();

	/**
	 * 固定資産台帳ファイル情報取得
	 *
	 * @return
	 */
	List<KoteshisanDaityoFileInfo> getKoteishisanDaityoFileInfo();
}
