package jp.co.nsd.nkssweb.dao;

import java.math.BigDecimal;
import java.util.Date;

public class Kss005 extends Kss005Key {
    private String oyaKoteiShisanNo;

    private String oyaKoteiShisanEda;

    private Date shutokuYmd;

    private String koteiShisanNm;

    private String shuruiCd;

    private String kouzouCd;

    private String shisanTaniCd;

    private String kamokuCd1;

    private String kamokuCd2;

    private String kamokuCd3;

    private String jitaShisanKbn;

    private String torihikiSakiCd;

    private String seizoKaishaNm;

    private String seihinNm;

    private String kataban;

    private BigDecimal suryo;

    private String taniCd;

    private Long buppinGaku;

    private Long kouhiGaku;

    private Long souKeihiGaku;

    private String kanriSoshikiCd;

    private String futanSoshikiCd;

    private String sechiBashoCd;

    private String shutokuRiyuCd;

    private Short taiyoNensuZei;

    private String tekiyo1;

    private String tekiyo2;

    private String tekiyo3;

    private String tekiyo4;

    private String tekiyo5;

    private String kojiTantoUserNm;

    private String kojiTantoSoshikiCd;

    private Long biboKagakuZei;

    private Long biboKagakuSho;

    private Long shokyakuGendoZei;

    private Long shokyakuGendoSho;

    private String syokyakuHohoZei;

    private String syokyakuHohoSho;

    private Short zanzonRitsuZei;

    private Short zanzonRitsuSho;

    private Short taiyoTsukisuZei;

    private Short taiyoTsukisuSho;

    private Date entryDate;

    private String entryUserId;

    private Date updateDate;

    private String updateUserId;

    public String getOyaKoteiShisanNo() {
        return oyaKoteiShisanNo;
    }

    public void setOyaKoteiShisanNo(String oyaKoteiShisanNo) {
        this.oyaKoteiShisanNo = oyaKoteiShisanNo == null ? null : oyaKoteiShisanNo.trim();
    }

    public String getOyaKoteiShisanEda() {
        return oyaKoteiShisanEda;
    }

    public void setOyaKoteiShisanEda(String oyaKoteiShisanEda) {
        this.oyaKoteiShisanEda = oyaKoteiShisanEda == null ? null : oyaKoteiShisanEda.trim();
    }

    public Date getShutokuYmd() {
        return shutokuYmd;
    }

    public void setShutokuYmd(Date shutokuYmd) {
        this.shutokuYmd = shutokuYmd;
    }

    public String getKoteiShisanNm() {
        return koteiShisanNm;
    }

    public void setKoteiShisanNm(String koteiShisanNm) {
        this.koteiShisanNm = koteiShisanNm == null ? null : koteiShisanNm.trim();
    }

    public String getShuruiCd() {
        return shuruiCd;
    }

    public void setShuruiCd(String shuruiCd) {
        this.shuruiCd = shuruiCd == null ? null : shuruiCd.trim();
    }

    public String getKouzouCd() {
        return kouzouCd;
    }

    public void setKouzouCd(String kouzouCd) {
        this.kouzouCd = kouzouCd == null ? null : kouzouCd.trim();
    }

    public String getShisanTaniCd() {
        return shisanTaniCd;
    }

    public void setShisanTaniCd(String shisanTaniCd) {
        this.shisanTaniCd = shisanTaniCd == null ? null : shisanTaniCd.trim();
    }

    public String getKamokuCd1() {
        return kamokuCd1;
    }

    public void setKamokuCd1(String kamokuCd1) {
        this.kamokuCd1 = kamokuCd1 == null ? null : kamokuCd1.trim();
    }

    public String getKamokuCd2() {
        return kamokuCd2;
    }

    public void setKamokuCd2(String kamokuCd2) {
        this.kamokuCd2 = kamokuCd2 == null ? null : kamokuCd2.trim();
    }

    public String getKamokuCd3() {
        return kamokuCd3;
    }

    public void setKamokuCd3(String kamokuCd3) {
        this.kamokuCd3 = kamokuCd3 == null ? null : kamokuCd3.trim();
    }

    public String getJitaShisanKbn() {
        return jitaShisanKbn;
    }

    public void setJitaShisanKbn(String jitaShisanKbn) {
        this.jitaShisanKbn = jitaShisanKbn == null ? null : jitaShisanKbn.trim();
    }

    public String getTorihikiSakiCd() {
        return torihikiSakiCd;
    }

    public void setTorihikiSakiCd(String torihikiSakiCd) {
        this.torihikiSakiCd = torihikiSakiCd == null ? null : torihikiSakiCd.trim();
    }

    public String getSeizoKaishaNm() {
        return seizoKaishaNm;
    }

    public void setSeizoKaishaNm(String seizoKaishaNm) {
        this.seizoKaishaNm = seizoKaishaNm == null ? null : seizoKaishaNm.trim();
    }

    public String getSeihinNm() {
        return seihinNm;
    }

    public void setSeihinNm(String seihinNm) {
        this.seihinNm = seihinNm == null ? null : seihinNm.trim();
    }

    public String getKataban() {
        return kataban;
    }

    public void setKataban(String kataban) {
        this.kataban = kataban == null ? null : kataban.trim();
    }

    public BigDecimal getSuryo() {
        return suryo;
    }

    public void setSuryo(BigDecimal suryo) {
        this.suryo = suryo;
    }

    public String getTaniCd() {
        return taniCd;
    }

    public void setTaniCd(String taniCd) {
        this.taniCd = taniCd == null ? null : taniCd.trim();
    }

    public Long getBuppinGaku() {
        return buppinGaku;
    }

    public void setBuppinGaku(Long buppinGaku) {
        this.buppinGaku = buppinGaku;
    }

    public Long getKouhiGaku() {
        return kouhiGaku;
    }

    public void setKouhiGaku(Long kouhiGaku) {
        this.kouhiGaku = kouhiGaku;
    }

    public Long getSouKeihiGaku() {
        return souKeihiGaku;
    }

    public void setSouKeihiGaku(Long souKeihiGaku) {
        this.souKeihiGaku = souKeihiGaku;
    }

    public String getKanriSoshikiCd() {
        return kanriSoshikiCd;
    }

    public void setKanriSoshikiCd(String kanriSoshikiCd) {
        this.kanriSoshikiCd = kanriSoshikiCd == null ? null : kanriSoshikiCd.trim();
    }

    public String getFutanSoshikiCd() {
        return futanSoshikiCd;
    }

    public void setFutanSoshikiCd(String futanSoshikiCd) {
        this.futanSoshikiCd = futanSoshikiCd == null ? null : futanSoshikiCd.trim();
    }

    public String getSechiBashoCd() {
        return sechiBashoCd;
    }

    public void setSechiBashoCd(String sechiBashoCd) {
        this.sechiBashoCd = sechiBashoCd == null ? null : sechiBashoCd.trim();
    }

    public String getShutokuRiyuCd() {
        return shutokuRiyuCd;
    }

    public void setShutokuRiyuCd(String shutokuRiyuCd) {
        this.shutokuRiyuCd = shutokuRiyuCd == null ? null : shutokuRiyuCd.trim();
    }

    public Short getTaiyoNensuZei() {
        return taiyoNensuZei;
    }

    public void setTaiyoNensuZei(Short taiyoNensuZei) {
        this.taiyoNensuZei = taiyoNensuZei;
    }

    public String getTekiyo1() {
        return tekiyo1;
    }

    public void setTekiyo1(String tekiyo1) {
        this.tekiyo1 = tekiyo1 == null ? null : tekiyo1.trim();
    }

    public String getTekiyo2() {
        return tekiyo2;
    }

    public void setTekiyo2(String tekiyo2) {
        this.tekiyo2 = tekiyo2 == null ? null : tekiyo2.trim();
    }

    public String getTekiyo3() {
        return tekiyo3;
    }

    public void setTekiyo3(String tekiyo3) {
        this.tekiyo3 = tekiyo3 == null ? null : tekiyo3.trim();
    }

    public String getTekiyo4() {
        return tekiyo4;
    }

    public void setTekiyo4(String tekiyo4) {
        this.tekiyo4 = tekiyo4 == null ? null : tekiyo4.trim();
    }

    public String getTekiyo5() {
        return tekiyo5;
    }

    public void setTekiyo5(String tekiyo5) {
        this.tekiyo5 = tekiyo5 == null ? null : tekiyo5.trim();
    }

    public String getKojiTantoUserNm() {
        return kojiTantoUserNm;
    }

    public void setKojiTantoUserNm(String kojiTantoUserNm) {
        this.kojiTantoUserNm = kojiTantoUserNm == null ? null : kojiTantoUserNm.trim();
    }

    public String getKojiTantoSoshikiCd() {
        return kojiTantoSoshikiCd;
    }

    public void setKojiTantoSoshikiCd(String kojiTantoSoshikiCd) {
        this.kojiTantoSoshikiCd = kojiTantoSoshikiCd == null ? null : kojiTantoSoshikiCd.trim();
    }

    public Long getBiboKagakuZei() {
        return biboKagakuZei;
    }

    public void setBiboKagakuZei(Long biboKagakuZei) {
        this.biboKagakuZei = biboKagakuZei;
    }

    public Long getBiboKagakuSho() {
        return biboKagakuSho;
    }

    public void setBiboKagakuSho(Long biboKagakuSho) {
        this.biboKagakuSho = biboKagakuSho;
    }

    public Long getShokyakuGendoZei() {
        return shokyakuGendoZei;
    }

    public void setShokyakuGendoZei(Long shokyakuGendoZei) {
        this.shokyakuGendoZei = shokyakuGendoZei;
    }

    public Long getShokyakuGendoSho() {
        return shokyakuGendoSho;
    }

    public void setShokyakuGendoSho(Long shokyakuGendoSho) {
        this.shokyakuGendoSho = shokyakuGendoSho;
    }

    public String getSyokyakuHohoZei() {
        return syokyakuHohoZei;
    }

    public void setSyokyakuHohoZei(String syokyakuHohoZei) {
        this.syokyakuHohoZei = syokyakuHohoZei == null ? null : syokyakuHohoZei.trim();
    }

    public String getSyokyakuHohoSho() {
        return syokyakuHohoSho;
    }

    public void setSyokyakuHohoSho(String syokyakuHohoSho) {
        this.syokyakuHohoSho = syokyakuHohoSho == null ? null : syokyakuHohoSho.trim();
    }

    public Short getZanzonRitsuZei() {
        return zanzonRitsuZei;
    }

    public void setZanzonRitsuZei(Short zanzonRitsuZei) {
        this.zanzonRitsuZei = zanzonRitsuZei;
    }

    public Short getZanzonRitsuSho() {
        return zanzonRitsuSho;
    }

    public void setZanzonRitsuSho(Short zanzonRitsuSho) {
        this.zanzonRitsuSho = zanzonRitsuSho;
    }

    public Short getTaiyoTsukisuZei() {
        return taiyoTsukisuZei;
    }

    public void setTaiyoTsukisuZei(Short taiyoTsukisuZei) {
        this.taiyoTsukisuZei = taiyoTsukisuZei;
    }

    public Short getTaiyoTsukisuSho() {
        return taiyoTsukisuSho;
    }

    public void setTaiyoTsukisuSho(Short taiyoTsukisuSho) {
        this.taiyoTsukisuSho = taiyoTsukisuSho;
    }

    public Date getEntryDate() {
        return entryDate;
    }

    public void setEntryDate(Date entryDate) {
        this.entryDate = entryDate;
    }

    public String getEntryUserId() {
        return entryUserId;
    }

    public void setEntryUserId(String entryUserId) {
        this.entryUserId = entryUserId == null ? null : entryUserId.trim();
    }

    public Date getUpdateDate() {
        return updateDate;
    }

    public void setUpdateDate(Date updateDate) {
        this.updateDate = updateDate;
    }

    public String getUpdateUserId() {
        return updateUserId;
    }

    public void setUpdateUserId(String updateUserId) {
        this.updateUserId = updateUserId == null ? null : updateUserId.trim();
    }
}