package jp.co.nsd.nkssweb.utils;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

/**
 * プロパティファイルの値を読込
 *
 * @author nsdH272059
 *
 */
@Component
public class NSDProperties {

	@Value("${template.path}")
	private String templateFilePath;

	@Value("${template.filename}")
	private String templateFileName;

	@Value("${output.path.excel}")
	private String excelPath;

	@Value("${output.path.pdf}")
	private String pdfPath;

	@Value("${page.size}")
	private int pageSize;

	public String getTemplateFilePath() {
		return templateFilePath;
	}

	public void setTemplateFilePath(String templateFilePath) {
		this.templateFilePath = templateFilePath;
	}

	public String getTemplateFileName() {
		return templateFileName;
	}

	public void setTemplateFileName(String templateFileName) {
		this.templateFileName = templateFileName;
	}

	public String getExcelPath() {
		return excelPath;
	}

	public void setExcelPath(String excelPath) {
		this.excelPath = excelPath;
	}

	public String getPdfPath() {
		return pdfPath;
	}

	public void setPdfPath(String pdfPath) {
		this.pdfPath = pdfPath;
	}

	public int getPageSize() {
		return pageSize;
	}

	public void setPageSize(int pageSize) {
		this.pageSize = pageSize;
	}

}
