package jp.co.nsd.nkssweb.dao;

public class Kss016Key {
    private String cdShubetsu;

    private String cd1;

    private String cd2;

    public String getCdShubetsu() {
        return cdShubetsu;
    }

    public void setCdShubetsu(String cdShubetsu) {
        this.cdShubetsu = cdShubetsu == null ? null : cdShubetsu.trim();
    }

    public String getCd1() {
        return cd1;
    }

    public void setCd1(String cd1) {
        this.cd1 = cd1 == null ? null : cd1.trim();
    }

    public String getCd2() {
        return cd2;
    }

    public void setCd2(String cd2) {
        this.cd2 = cd2 == null ? null : cd2.trim();
    }
}