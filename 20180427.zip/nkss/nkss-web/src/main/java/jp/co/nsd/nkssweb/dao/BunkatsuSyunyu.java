package jp.co.nsd.nkssweb.dao;

public class BunkatsuSyunyu {

	// 行番号
	private int rowNo;

	// 工事件名コード
	private String kenmeiCd;

	// 工事件名
	private String kmouwkKnj;

	// 精算箇所
	private String soshikiRenNm;

	// 精算書番号
	private String seisanShoNo;

	// サービス開始年月日
	private String serviceStartYmd;

	// サービス開始年月日
	private String serviceStartYmdF;

	// サービス開始年月日
	private String serviceStartYmdT;

	// 承認状態
	private String shoninStatus;

	// 経理審査否認理由
	private String riyu;

	public int getRowNo() {
		return rowNo;
	}

	public void setRowNo(int rowNo) {
		this.rowNo = rowNo;
	}

	public String getKenmeiCd() {
		return kenmeiCd;
	}

	public void setKenmeiCd(String kenmeiCd) {
		this.kenmeiCd = kenmeiCd;
	}

	public String getKmouwkKnj() {
		return kmouwkKnj;
	}

	public void setKmouwkKnj(String kmouwkKnj) {
		this.kmouwkKnj = kmouwkKnj;
	}

	public String getSoshikiRenNm() {
		return soshikiRenNm;
	}

	public void setSoshikiRenNm(String soshikiRenNm) {
		this.soshikiRenNm = soshikiRenNm;
	}

	public String getSeisanShoNo() {
		return seisanShoNo;
	}

	public void setSeisanShoNo(String seisanShoNo) {
		this.seisanShoNo = seisanShoNo;
	}

	public String getServiceStartYmd() {
		return serviceStartYmd;
	}

	public void setServiceStartYmd(String serviceStartYmd) {
		this.serviceStartYmd = serviceStartYmd;
	}

	public String getServiceStartYmdF() {
		return serviceStartYmdF;
	}

	public void setServiceStartYmdF(String serviceStartYmdF) {
		this.serviceStartYmdF = serviceStartYmdF;
	}

	public String getServiceStartYmdT() {
		return serviceStartYmdT;
	}

	public void setServiceStartYmdT(String serviceStartYmdT) {
		this.serviceStartYmdT = serviceStartYmdT;
	}

	public String getShoninStatus() {
		return shoninStatus;
	}

	public void setShoninStatus(String shoninStatus) {
		this.shoninStatus = shoninStatus;
	}

	public String getRiyu() {
		return riyu;
	}

	public void setRiyu(String riyu) {
		this.riyu = riyu;
	}






}