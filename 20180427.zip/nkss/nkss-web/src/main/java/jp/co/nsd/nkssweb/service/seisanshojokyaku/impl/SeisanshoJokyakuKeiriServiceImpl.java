/***********************************************************************
*
*業務名: 工事精算システム
*機能名: 除却（経理審査/連携）(サービス処理)
*
*機能概要: 除却（経理審査/連携）情報を処理する。
*
*JavaＶｅｒ：J2SE1.8.0準拠
*
*更新履歴: Ver.1.00 2018/03/06　NSD　新規作成
***********************************************************************/
package jp.co.nsd.nkssweb.service.seisanshojokyaku.impl;

import java.math.BigDecimal;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import jp.co.nsd.nkssweb.controller.CommController;
import jp.co.nsd.nkssweb.dao.Kss006;
import jp.co.nsd.nkssweb.dao.SeisanshoJokyakuKeiri;
import jp.co.nsd.nkssweb.dao.mapper.Kss006Mapper;
import jp.co.nsd.nkssweb.dao.mapper.SeisanshoJokyakuKeiriMapper;
import jp.co.nsd.nkssweb.dao.mapper.StoredMapper;
import jp.co.nsd.nkssweb.service.seisanshojokyaku.SeisanshoJokyakuKeiriService;
import jp.co.nsd.nkssweb.utils.NSDConstant;

/**
 * 除却（経理審査/連携）処理
 *
 * @see SeisanshoJokyakuKeiriService
 * @version 1.00
 */
@Service
public class SeisanshoJokyakuKeiriServiceImpl implements SeisanshoJokyakuKeiriService {

	@Autowired
	private SeisanshoJokyakuKeiriMapper seisanshoJokyakuKeiriMapper;

	@Autowired
	private CommController commController;

	@Autowired
	private Kss006Mapper kss006Mapper;

	@Autowired
	private StoredMapper storedMapper;

	/**
	 * 除却（経理審査/連携）検索処理
	 *
	 * @param seisanshoJokyakuKeiri
	 *            INPUTパラメータ
	 * @return sssJykKrList 除却情報データリスト
	 * @version 1.00
	 */
	public List<SeisanshoJokyakuKeiri> getJokyakuKeiriInfo(SeisanshoJokyakuKeiri seisanshoJokyakuKeiri) {

		// 除却情報を取得する
		List<SeisanshoJokyakuKeiri> sssJykKrList = seisanshoJokyakuKeiriMapper.selectByWhere(seisanshoJokyakuKeiri);

		if (sssJykKrList.size() > 0) {
			for (int i = 0; i < sssJykKrList.size(); i++) {

				SeisanshoJokyakuKeiri sssJykSn = sssJykKrList.get(i);

				// ROWNOを設定する
				sssJykSn.setRowNo(i + 1);

				// 承認状態名称
				sssJykSn.setShoninJotai(NSDConstant.getShoninStatus(sssJykSn.getShoninStatus()));

			}

		} else {
			sssJykKrList = null;
		}

		return sssJykKrList;
	}

	/**
	 * 除却（経理審査/連携）更新
	 *
	 * @param kss006
	 *            INPUTパラメータ
	 * @param hakouSoshikiCd
	 *            発行組織コード
	 * @param kaikeiSeiriYm
	 *            会計整理年月
	 * @return 結果
	 */
	public int updateInfo(List<Kss006> kss006UpdLst, String hakouSoshikiCd, String kaikeiSeiriYm) throws Exception {

		// 除却経理審査／連係更新処理（更新前ストアド１）の処理
		// storedMapper.clearSisanIdListKs2070();

		// 除却資産(更新)
		for (Kss006 kss006 : kss006UpdLst) {

			// try {
			// Map<String, Object> map = new HashMap<String, Object>();
			// map.put("jokyakuSeisanShoId", kss006.getJokyakuSeisanShoId());
			// // 除却経理審査／連係更新処理（更新前ストアド２）の処理
			// storedMapper.addSisanIdKs2070(map);
			// } catch (Exception e) {
			// throw new Exception("ファイル出力前処理でエラーが発生しました. error=[" +
			// e.getMessage() + "]");
			// }

			// 版数採番
			String seqHansu = commController.getSequence(NSDConstant.KSS_SEQ_HANSU);
			// 版数
			kss006.setHansu(new BigDecimal(seqHansu));

			// 除却資産更新
			kss006Mapper.updateByPrimaryKeySelective(kss006);
		}

		// try {
		// Map<String, Object> map = new HashMap<String, Object>();
		// map.put("hakouSoshikiCd", hakouSoshikiCd);
		// map.put("renkeidataSakuseiYmd", new
		// java.sql.Date(Calendar.getInstance().getTimeInMillis()));
		// map.put("kaikeiSeiriYm", kaikeiSeiriYm);
		// // 除却経理審査／連係更新処理（更新前ストアド２）の処理
		// storedMapper.setAllKs2070(map);
		// } catch (Exception e) {
		// throw new Exception("ファイル出力前処理でエラーが発生しました. error=[" + e.getMessage()
		// + "]");
		// }

		return 0;
	}

}
