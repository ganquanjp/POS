/***********************************************************************
*
*業務名: システム共通処理
*機能名: システム共通処理(サービス処理)
*
*機能概要: システム共通処理
*
*JavaＶｅｒ：J2SE1.8.0準拠
*
*更新履歴: Ver.1.00 2018/03/06　NSD　新規作成
***********************************************************************/
package jp.co.nsd.nkssweb.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import jp.co.nsd.nkssweb.dao.Kss017;
import jp.co.nsd.nkssweb.dao.LoginUserInfo;
import jp.co.nsd.nkssweb.dao.Message;
import jp.co.nsd.nkssweb.dao.UserMenuGroup;
import jp.co.nsd.nkssweb.dao.UserPrivilegeInfo;
import jp.co.nsd.nkssweb.dao.UserSubMenu;
import jp.co.nsd.nkssweb.dao.mapper.Kss017Mapper;
import jp.co.nsd.nkssweb.dao.mapper.SystemMapper;
import jp.co.nsd.nkssweb.service.SystemService;
import jp.co.nsd.nkssweb.utils.NSDCommUtils;
import jp.co.nsd.nkssweb.utils.NSDConstant;

/**
 * システム処理用サービス
 *
 * @see SystemService
 * @version 1.00
 */
@Service
public class SystemServiceImpl implements SystemService {

	@Autowired
	private Kss017Mapper kss017Mapper;

	@Autowired
	private SystemMapper systemMapper;

	/**
	 * ログインユーザー情報の取得
	 */
	public LoginUserInfo userLogin(String userId) throws Exception {

		// ログインユーザー情報の取得
		LoginUserInfo loginUserInfo = this.getUserInfo(userId);

		// ユーザー存在してない または
		if (null == loginUserInfo) {
			return null;
		}


		if (NSDConstant.BLANK_STRING.equals(loginUserInfo.getRoleId())) {

			// ロールID取得できない場合
			loginUserInfo.setUmgList(null);

		} else{
			// ログインユーザー権限確認サービス呼び出し
			loginUserInfo.setUmgList(getUserPrivilege(loginUserInfo.getRoleId()));
		}

		return loginUserInfo;
	}

	/**
	 * ログインユーザーのロールIDを取得する。
	 *
	 * @param userId
	 * @return
	 */
	private LoginUserInfo getUserInfo(String userId) {

		LoginUserInfo loginUserInfo = new LoginUserInfo();

		List<LoginUserInfo> loginUserInfoList = new ArrayList<LoginUserInfo>();

		// ログインユーザーのロール情報を取得する
		loginUserInfoList = systemMapper.selectUserInfo(userId);

		if (loginUserInfoList.size() != 1) {
			return null;
		} else {
			loginUserInfo.setUserId(userId);
			loginUserInfo.setSei(loginUserInfoList.get(0).getSei());
			loginUserInfo.setMei(loginUserInfoList.get(0).getMei());
			loginUserInfo.setNyushaYmd(loginUserInfoList.get(0).getNyushaYmd());
			loginUserInfo.setTaishokuYmd(loginUserInfoList.get(0).getTaishokuYmd());
			loginUserInfo.setZaisekiKbn(loginUserInfoList.get(0).getZaisekiKbn());
			loginUserInfo.setSoshikiCd(loginUserInfoList.get(0).getSoshikiCd());
			loginUserInfo.setSoshikiRenNm(loginUserInfoList.get(0).getSoshikiRenNm());
			loginUserInfo.setRoleId(loginUserInfoList.get(0).getRoleId());
		}

		return loginUserInfo;
	}

	/**
	 * ログインユーザーの権限を取得
	 *
	 * @param roleId
	 * @return
	 */
	private List<UserMenuGroup> getUserPrivilege(String roleId) {

		List<UserMenuGroup> umgList = new ArrayList<UserMenuGroup>();

		List<UserPrivilegeInfo> upiList = new ArrayList<UserPrivilegeInfo>();

		// ログインユーザーの権限を取得
		upiList = systemMapper.selectUserPrivilege(roleId);

		if (upiList.size() > 0) {
			umgList = this.setUserMenu(upiList);
		} else {
			umgList = null;
		}

		return umgList;
	}

	/**
	 * ユーザーメニューを作成する。
	 *
	 * @param allMenuList
	 * @return
	 */
	private List<UserMenuGroup> setUserMenu(List<UserPrivilegeInfo> allMenuList) {

		List<UserMenuGroup> menuList = new ArrayList<UserMenuGroup>();
		UserMenuGroup userMenuGroup = new UserMenuGroup();

		List<UserSubMenu> subMenuList = null;
		UserSubMenu userSubMenu = null;

		String preGroupId = NSDConstant.BLANK_STRING;

		for (int i = 0; i < allMenuList.size(); i++) {

			UserPrivilegeInfo subMenu = allMenuList.get(i);
			userSubMenu = new UserSubMenu();

			if (!preGroupId.equals(subMenu.getMenuGroupId())) {

				if (i > 0) {
					userMenuGroup.setUsmList(subMenuList);
					menuList.add(userMenuGroup);
					userMenuGroup = new UserMenuGroup();
				}
				// グループメニューIDをセット
				userMenuGroup.setGroupId(subMenu.getMenuGroupId());
				// グループメニュー名をセット
				userMenuGroup.setGroupName(this.getMenuGroupName(subMenu.getMenuGroupId()));

				// サブメニューを作成
				subMenuList = new ArrayList<UserSubMenu>();
			}

			// サブメニュー値をセット
			userSubMenu.setMenuId(subMenu.getMenuId());
			userSubMenu.setMenuLinkNm(subMenu.getMenuLinkNm());
			userSubMenu.setRouterName(this.getRouter(subMenu.getMenuId()));
			subMenuList.add(userSubMenu);

			if (i == allMenuList.size() - 1) {
				userMenuGroup.setUsmList(subMenuList);
				menuList.add(userMenuGroup);
			} else {
				preGroupId = subMenu.getMenuGroupId();
			}
		}

		return menuList;
	}

	private String getMenuGroupName(String menuGroupId) {

		String groupName = NSDConstant.BLANK_STRING;
		if (NSDConstant.MENU_GROUP_ID_KSS02.equals(menuGroupId)) {
			groupName = NSDConstant.MENU_GROUP_NAME_KSS02;
		} else if (NSDConstant.MENU_GROUP_ID_KSS03.equals(menuGroupId)) {
			groupName = NSDConstant.MENU_GROUP_NAME_KSS03;
		} else if (NSDConstant.MENU_GROUP_ID_KSS04.equals(menuGroupId)) {
			groupName = NSDConstant.MENU_GROUP_NAME_KSS04;
		} else if (NSDConstant.MENU_GROUP_ID_KSS05.equals(menuGroupId)) {
			groupName = NSDConstant.MENU_GROUP_NAME_KSS05;
		} else if (NSDConstant.MENU_GROUP_ID_KSS06.equals(menuGroupId)) {
			groupName = NSDConstant.MENU_GROUP_NAME_KSS06;
		} else if (NSDConstant.MENU_GROUP_ID_KSS07.equals(menuGroupId)) {
			groupName = NSDConstant.MENU_GROUP_NAME_KSS07;
		}

		return groupName;
	}

	private String getRouter(String menuId) {

		String resultRouter = NSDConstant.BLANK_STRING;

		if (menuId.equals(NSDConstant.KSS020_G010)) {
			resultRouter = NSDConstant.NSDSSSTRK_KENSAKU;
		} else if (menuId.equals(NSDConstant.KSS020_G060)) {
			resultRouter = NSDConstant.NSDSSSTRK_SINKI;
		} else if (menuId.equals(NSDConstant.KSS020_G120)) {
			resultRouter = NSDConstant.NSDSSSTRK_KMSKJHE;
		} else if (menuId.equals(NSDConstant.KSS030_G010)) {
			resultRouter = NSDConstant.NSDSTK_MAIN;
		} else if (menuId.equals(NSDConstant.KSS030_G040)) {
			resultRouter = NSDConstant.NSDSTK_SHINKI;
		} else if (menuId.equals(NSDConstant.KSS031_G010)) {
			resultRouter = NSDConstant.NSDSTK_SHONIN;
		} else if (menuId.equals(NSDConstant.KSS032_G010)) {
			resultRouter = NSDConstant.NSDSTK_KEIRISINSA;
		} else if (menuId.equals(NSDConstant.KSS040_G010)) {
			resultRouter = NSDConstant.NSDSSSJKK_KENSAKU;
		} else if (menuId.equals(NSDConstant.KSS040_G040)) {
			resultRouter = NSDConstant.NSDSSSJKK_SINKI;
		} else if (menuId.equals(NSDConstant.KSS041_G010)) {
			resultRouter = NSDConstant.NSDSSSJKK_NAIYOKENSAKU;
		} else if (menuId.equals(NSDConstant.KSS042_G010)) {
			resultRouter = NSDConstant.NSDSSSJKK_SEISANKENSAKU;
		} else if (menuId.equals(NSDConstant.KSS043_G010)) {
			resultRouter = NSDConstant.NSDNSSSJKK_SHONINKENSKU;
		} else if (menuId.equals(NSDConstant.KSS044_G010)) {
			resultRouter = NSDConstant.NSDSSSJKK_KEIRIKENSAKU;
		} else if (menuId.equals(NSDConstant.KSS050_G010)) {
			resultRouter = NSDConstant.NSDBKTSN_KENSAKU;
		} else if (menuId.equals(NSDConstant.KSS060_G030)) {
			resultRouter = NSDConstant.NSDKTSSDT_SAKUSEI;
		} else if (menuId.equals(NSDConstant.KSS060_G040)) {
			resultRouter = NSDConstant.NSDKTSSDT_SHUTSURYOKU;
		} else if (menuId.equals(NSDConstant.KSS070_G010)) {
			resultRouter = NSDConstant.NSDKRFTKS_KENSAKU;
		} else if (menuId.equals(NSDConstant.KSS070_G050)) {
			resultRouter = NSDConstant.NSDKRFTKS_SINKI;
		}

		return resultRouter;
	}

	/**
	 * メッセージIDよりメッセージ内容を取得する
	 *
	 * @param msgId
	 * @return
	 */
	@Override
	public Message getMessage(String msgId) {

		Message message = new Message();
		String messageContent = NSDConstant.BLANK_STRING;

		message.setMsgId(msgId);

		Kss017 kss017 = kss017Mapper.selectByPrimaryKey(msgId);
		if (null != kss017) {
			messageContent = NSDCommUtils.nullToBlankStr(kss017.getMessage());
		}

		if (NSDConstant.BLANK_STRING.equals(messageContent)) {
			// メッセージIDは存在してない場合
			message.setMsgId(NSDConstant.LOG_LEVEL_ERROR);
			messageContent = NSDConstant.MSG_NOT_FOUND_MSGID.concat(NSDCommUtils.setKakoToStr(msgId));
		}

		message.setContent(messageContent);

		return message;
	}

}
