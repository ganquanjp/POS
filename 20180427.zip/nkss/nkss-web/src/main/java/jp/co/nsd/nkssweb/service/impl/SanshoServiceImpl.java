/***********************************************************************
*
*業務名: 参照ボタン処理
*機能名: 参照ボタン処理(サービス処理)
*
*機能概要: 参照ボタンを処理する。
*
*JavaＶｅｒ：J2SE1.8.0準拠
*
*更新履歴: Ver.1.00 2018/03/06　NSD　新規作成
***********************************************************************/
package jp.co.nsd.nkssweb.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import jp.co.nsd.nkssweb.dao.KanriFutanks;
import jp.co.nsd.nkssweb.dao.KoteiSisan;
import jp.co.nsd.nkssweb.dao.SechiBasho;
import jp.co.nsd.nkssweb.dao.TorihikiSaki;
import jp.co.nsd.nkssweb.dao.mapper.SanshoMapper;
import jp.co.nsd.nkssweb.service.SanshoService;
import jp.co.nsd.nkssweb.service.seisanshoshutoku.SeisanshoShoninService;
import jp.co.nsd.nkssweb.utils.NSDConstant;

/**
 * 参照ボタン処理用サービス
 *
 * @see SeisanshoShoninService
 * @version 1.00
 */
@Service
public class SanshoServiceImpl implements SanshoService {

	@Autowired
	private SanshoMapper sanshoMapper;

	/**
	 * 固定資産（検索）処理
	 *
	 * @param koteiSisan
	 *            INPUTパラメータ
	 * @return KSList 固定資産情報データリスト
	 * @version 1.00
	 */
	public List<KoteiSisan> getKoteiSisanInfo(KoteiSisan koteiSisan) {

		// 親子資産区分
		if (StringUtils.isEmpty(koteiSisan.getOyakosisankubun())) {
			koteiSisan.setOyakosisankubun(NSDConstant.STRING_9);
		}

		List<KoteiSisan> ksList = new ArrayList<KoteiSisan>();

		if (NSDConstant.STRING_1.equals(koteiSisan.getHanteFlg())) {


			// 精算書情報を取得する
			ksList = sanshoMapper.selectSeSanSho(koteiSisan);

		} else {

			// 固定資産情報を取得する
			ksList = sanshoMapper.selectKoTeSiSan(koteiSisan);

		}


		if (ksList.size() > 0) {
			for (int i = 1; i <= ksList.size(); i++) {
				// ROWNOを設定する
				ksList.get(i - 1).setRowNo(i);
			}
		} else {
			ksList = null;
		}

		return ksList;
	}

	/**
	 * 取引先（検索）処理
	 *
	 * @param torihikiSaki
	 * @return
	 */
	public List<TorihikiSaki> getTorihikiSakiInfo(TorihikiSaki torihikiSaki) {

		// 取引先情報を取得する
		List<TorihikiSaki> trhksList = sanshoMapper.selectTorihikiSaki(torihikiSaki);

		if (trhksList.size() > 0) {
			for (int i = 1; i <= trhksList.size(); i++) {
				// ROWNOを設定する
				trhksList.get(i - 1).setRowNo(i);
			}
		} else {
			trhksList = null;
		}

		return trhksList;
	}

	/**
	 * 管理箇所/負担箇所検索処理
	 *
	 * @param kanriFutanks
	 *            INPUTパラメータ
	 * @return kfhList 管理箇所/負担箇所情報データリスト
	 * @version 1.00
	 */
	public List<KanriFutanks> getKanriFutanInfo(KanriFutanks kanriFutanks) {

		// 管理箇所/負担箇所情報を取得する
		List<KanriFutanks> krftList = sanshoMapper.selectKanriFutanks(kanriFutanks);

		if (krftList.size() > 0) {
			for (int i = 1; i <= krftList.size(); i++) {
				// ROWNOを設定する
				krftList.get(i - 1).setRowNo(i);
			}
		} else {
			krftList = null;
		}

		return krftList;
	}

	/**
	 * 設置場所（検索）処理
	 *
	 * @param sechiBasho
	 *            INPUTパラメータ
	 * @return KSList 設置場所情報データリスト
	 * @version 1.00
	 */
	public List<SechiBasho> getSechiBashoInfo(SechiBasho sechiBasho) {

		// 設置場所情報を取得する
		List<SechiBasho> scbsList = sanshoMapper.selectSechiBasho(sechiBasho);

		if (scbsList.size() > 0) {
			for (int i = 1; i <= scbsList.size(); i++) {
				// ROWNOを設定する
				scbsList.get(i - 1).setRowNo(i);
			}
		} else {
			scbsList = null;
		}

		return scbsList;
	}
}
