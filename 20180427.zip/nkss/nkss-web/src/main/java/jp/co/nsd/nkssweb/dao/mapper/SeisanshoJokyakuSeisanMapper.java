/***********************************************************************
*
*業務名: 工事精算システム
*機能名: 除却（精算通告）(DB処理)
*
*機能概要: 除却情報を処理する。
*
*JavaＶｅｒ：J2SE1.8.0準拠
*
*更新履歴: Ver.1.00 2018/03/06　NSD　新規作成
***********************************************************************/
package jp.co.nsd.nkssweb.dao.mapper;

import java.util.List;

import jp.co.nsd.nkssweb.dao.Kss006;
import jp.co.nsd.nkssweb.dao.SeisanshoJokyakuSeisan;
import jp.co.nsd.nkssweb.dao.SeisanshoJokyakuSeisanShokai;

/**
 * 除却（精算通告）DB処理
 *
 * @version 1.00
 */
public interface SeisanshoJokyakuSeisanMapper {

	/**
	 * 除却（精算通告）情報取得（検索）
	 *
	 * @param seisanshoJokyaku
	 *            INPUTパラメータ
	 * @return　検索結果
	 */
	List<SeisanshoJokyakuSeisan> selectByWhere(SeisanshoJokyakuSeisan seisanshoJokyakuSeisan);

	/**
	 * 除却（精算通告）情報取得（照会）
	 *
	 * @param seisanshoJokyakuSeisanShokai
	 *            INPUTパラメータ
	 * @return　検索結果
	 */
	List<SeisanshoJokyakuSeisanShokai> selectBySeisanShoNo(SeisanshoJokyakuSeisanShokai seisanshoJokyakuSeisanShokai);

	/**
	 * 除却（精算通告）情報取得（更新）
	 *
	 * @param kss006
	 *            INPUTパラメータ
	 * @return　検索結果
	 */
	int updateByPrimaryKey(Kss006 kss006);

}