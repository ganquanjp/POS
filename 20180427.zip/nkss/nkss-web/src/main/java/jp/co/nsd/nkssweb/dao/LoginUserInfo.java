package jp.co.nsd.nkssweb.dao;

import java.util.List;

public class LoginUserInfo extends Kss013 {

	private String soshikiCd;

	private String soshikiRenNm;

	private String roleId;

	private List<UserMenuGroup> umgList;

	public String getSeiMei() {
		return getSei().concat(getMei());
	}

	public String getSoshikiCd() {
		return soshikiCd;
	}

	public void setSoshikiCd(String soshikiCd) {
		this.soshikiCd = soshikiCd;
	}

	public String getSoshikiRenNm() {
		return soshikiRenNm;
	}

	public void setSoshikiRenNm(String soshikiRenNm) {
		this.soshikiRenNm = soshikiRenNm;
	}

	public String getRoleId() {
		return roleId;
	}

	public void setRoleId(String roleId) {
		this.roleId = roleId;
	}

	public List<UserMenuGroup> getUmgList() {
		return umgList;
	}

	public void setUmgList(List<UserMenuGroup> umgList) {
		this.umgList = umgList;
	}

}