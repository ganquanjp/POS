package jp.co.nsd.nkssweb.controller.seisanshoshutoku;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import jp.co.nsd.nkssweb.controller.BaseController;
import jp.co.nsd.nkssweb.dao.InputCheck;
import jp.co.nsd.nkssweb.dao.Kss005;
import jp.co.nsd.nkssweb.dao.SeisanshoShutokuKensaku;
import jp.co.nsd.nkssweb.dao.SeisanshoShutokuShokai;
import jp.co.nsd.nkssweb.dao.mapper.SeisanshoShutokuMapper;
import jp.co.nsd.nkssweb.service.seisanshoshutoku.SeisanshoShutokuService;
import jp.co.nsd.nkssweb.utils.NSDCommUtils;
import jp.co.nsd.nkssweb.utils.NSDConstant;
import jp.co.nsd.nkssweb.utils.NSDDataCheck;
import jp.co.nsd.nkssweb.utils.NSDDateUtils;

@RestController
public class SeisanshoShutokuController extends BaseController {

	@Autowired
	private SeisanshoShutokuService seisanshoShutokuService;

	@Autowired
	private NSDDataCheck nsdDataCheck;

	@Autowired
	private SeisanshoShutokuMapper seisanshoShutokuMapper;

	/*
	 * 精算書取得・検索
	 */
	@RequestMapping(value = "/seisanshoShutoku-kensaku", method = RequestMethod.POST)
	public Map<String, Object> getSeisanshoShutokuKensaku(@RequestParam Map<String, Object> reqMap) throws Exception {

		Map<String, Object> resultMap = new HashMap<String, Object>();

		SeisanshoShutokuKensaku selectCondition = new SeisanshoShutokuKensaku();
		List<SeisanshoShutokuKensaku> stkKsList = new ArrayList<SeisanshoShutokuKensaku>();

		// 画面入力した検索条件をBeanのプロパティにセット
		BeanUtils.populate(selectCondition, reqMap);

		// 使用開始年月日（From）と使用開始年月日（To）の大小比較チェック
		if (NSDCommUtils.chkDateFromTo(selectCondition.getSiyoStartYmdFrom(), selectCondition.getSiyoStartYmdTo())) {

			// エラーメッセージを返却Mapに設定する
			return setMsgToResultMap(resultMap, NSDConstant.MSGID_INPUT_ERROR);

		}

		// 取得年月日（From）と取得年月日（To）の大小比較チェック
		if (NSDCommUtils.chkDateFromTo(selectCondition.getShutokuYmdFrom(), selectCondition.getShutokuYmdTo())) {

			// エラーメッセージを返却Mapに設定する
			return setMsgToResultMap(resultMap, NSDConstant.MSGID_INPUT_ERROR);

		}

		// サービスを呼び出す
		stkKsList = seisanshoShutokuService.getSeisanshoShutokuKensaku(selectCondition);

		// 検索結果を返却Mapに設定する
		setDataToResultMap(resultMap, stkKsList);

		return resultMap;

	}

	/*
	 * 精算書取得・照会
	 */
	@RequestMapping(value = "/seisanshoShutoku-shokai", method = RequestMethod.POST)
	public Map<String, Object> getSeisanshoShutokuShokai(@RequestParam Map<String, Object> reqMap) throws Exception {

		Map<String, Object> resultMap = new HashMap<String, Object>();

		SeisanshoShutokuShokai selectCondition = new SeisanshoShutokuShokai();
		List<SeisanshoShutokuShokai> stkskList = new ArrayList<SeisanshoShutokuShokai>();

		// 画面入力した検索条件をBeanのプロパティにセット
		BeanUtils.populate(selectCondition, reqMap);

		// サービスを呼び出す
		stkskList = seisanshoShutokuService.getSeisanshoShutokuShokai(selectCondition);

		// 検索結果を返却Mapに設定する
		setDataToResultMap(resultMap, stkskList);

		return resultMap;
	}

	/**
	 * 精算書取得・削除
	 *
	 * @param reqMap
	 *            INPUTパラメータ
	 * @return 除却情報データ
	 * @throws Exception
	 * @version 1.00
	 */
	@RequestMapping(value = "/seisanshoShutoku-delByPyKey", method = RequestMethod.POST)
	public Map<String, Object> delByPyKey(@RequestParam Map<String, Object> reqMap) {

		Map<String, Object> resultMap = new HashMap<String, Object>();

		// 精算書ＩＤ
		String seisanShoId = (String) reqMap.get("seisanShoId");
		// 固定資産ＩＤ
		String koteiShisanId = (String) reqMap.get("koteiShisanId");

		// サービス呼び出し
		seisanshoShutokuService.delByPyKey(seisanShoId, koteiShisanId);

		// 処理結果データ
		resultMap.put(NSDConstant.RESULT_DATA_NAME, "");

		return setMsgToResultMapNoLog(resultMap, NSDConstant.MSGID_DELETE_SUCCES);
	}

	/*
	 * 精算書取得・新規
	 */
	@RequestMapping(value = "/seisanshoShutoku-insert", method = RequestMethod.POST)
	public Map<String, Object> insert(HttpServletRequest request, @RequestParam Map<String, Object> reqMap)
			throws Exception {

		Map<String, Object> resultMap = new HashMap<String, Object>();

		// 入力チェック
		String errStr = inputCheckForInsert(reqMap);

		if (StringUtils.isNotEmpty(errStr)) {
			return setMsgToResultMap(resultMap, NSDConstant.MSGID_INPUT_ERROR, errStr);
		}

		// 使用開始年月日
		Calendar getYmd = NSDDateUtils.parseStrToCal(reqMap.get("getYmd").toString());
		// 種類コード
		String shuruiCd = reqMap.get("shuruiCd").toString().trim();
		// 項目１コード
		String kamokuCd1 = reqMap.get("kamokuCd1").toString().trim();
		// 項目３コード
		String kamokuCd3 = reqMap.get("kamokuCd3").toString().trim();
		// 取引先の判断
		if ("42".equals(shuruiCd) || "43".equals(shuruiCd) || "51".equals(shuruiCd) || "61".equals(shuruiCd)
				|| "12".equals(shuruiCd) || "305".equals(kamokuCd1) || "99".equals(kamokuCd3)) {

			// 取引先適用期間(From)
			Calendar torihikiSakifYmd = NSDDateUtils.parseStrToCal(reqMap.get("torihikiSakifYmd").toString());
			// 取引先適用期間(To)
			Calendar torihikiSakitYmd = NSDDateUtils.parseStrToCal(reqMap.get("torihikiSakitYmd").toString());

			if (torihikiSakifYmd.after(getYmd) || torihikiSakitYmd.before(getYmd)) {
				// TODO E00005
				// エラーメッセージを返却Mapに設定する
				return setMsgToResultMap(resultMap, NSDConstant.MSGID_INPUT_ERROR);
			}
		}

		// 管理箇所適用期間(From)
		Calendar kanriSoshikiF = NSDDateUtils.parseStrToCal(reqMap.get("kanriSoshikiF").toString());
		// 管理箇所適用期間(To)
		Calendar kanriSoshikiT = NSDDateUtils.parseStrToCal(reqMap.get("kanriSoshikiT").toString());

		if (kanriSoshikiF.after(getYmd) || kanriSoshikiT.before(getYmd)) {
			// TODO E00004
			// エラーメッセージを返却Mapに設定する
			return setMsgToResultMap(resultMap, NSDConstant.MSGID_INPUT_ERROR);
		}

		// 管理箇所適用期間(From)
		Calendar futanSoshikiF = NSDDateUtils.parseStrToCal(reqMap.get("futanSoshikiF").toString());
		// 管理箇所適用期間(To)
		Calendar futanSoshikiT = NSDDateUtils.parseStrToCal(reqMap.get("futanSoshikiT").toString());

		if (futanSoshikiF.after(getYmd) || futanSoshikiT.before(getYmd)) {
			// TODO E00009
			// エラーメッセージを返却Mapに設定する
			return setMsgToResultMap(resultMap, NSDConstant.MSGID_INPUT_ERROR);
		}

		// 取得年月日
		Calendar shutokuYmd = NSDDateUtils.parseStrToCal(reqMap.get("shutokuYmd").toString());

		if (shutokuYmd.after(getYmd)) {
			// TODO E00015
			// エラーメッセージを返却Mapに設定する
			return setMsgToResultMap(resultMap, NSDConstant.MSGID_INPUT_ERROR);
		}
		if (futanSoshikiF.after(shutokuYmd) || futanSoshikiT.before(shutokuYmd)) {
			// エラーメッセージを返却Mapに設定する
			// TODO E00028
			return setMsgToResultMap(resultMap, NSDConstant.MSGID_INPUT_ERROR);
		}

		Kss005 kss005 = new Kss005();

		// 画面情報を設定
		for (Entry<String, Object> itReq : reqMap.entrySet()) {
			// 取得年月日
			if ("shutokuYmd".equals(itReq.getKey())) {
				kss005.setShutokuYmd(shutokuYmd.getTime());
			} else {
				BeanUtils.copyProperty(kss005, itReq.getKey(), itReq.getValue());
			}
		}

		// 種類情報を取得
		List<Kss005> shuruiInfo = seisanshoShutokuMapper.getShuruiInfo(kss005);

		if (null == shuruiInfo || shuruiInfo.size() == 0) {
			// TODO E00010
			return setMsgToResultMap(resultMap, NSDConstant.MSGID_INPUT_ERROR);
		}
		Date date = new Date();
		String loginUserId = getLoginUserInfo(request).getUserId();

		// 登録ユーザーＩＤ
		kss005.setEntryUserId(loginUserId);
		// 登録年月日
		kss005.setEntryDate(date);
		// 更新ユーザーＩＤ
		kss005.setUpdateUserId(loginUserId);
		// 更新年月日
		kss005.setUpdateDate(date);

		// サービスを呼び出す
		seisanshoShutokuService.insert(kss005, shuruiInfo.get(0));

		// 登録正常完了
		setMsgToResultMap(resultMap, NSDConstant.MSGID_INSERT_SUCCESS);

		return resultMap;
	}

	/**
	 * 取得登録の入力データチェック
	 *
	 * @param reqMap
	 *            INPUTパラメータ
	 * @return エラーメッセージID
	 * @version 1.00
	 */
	private String inputCheckForInsert(Map<String, Object> reqMap) {

		List<InputCheck> inputCheckList = new ArrayList<InputCheck>();

		Map<Integer, Object> args;

		args = new HashMap<Integer, Object>();
		args.put(NSDConstant.CHECK_ITEM.EMPTY_CHECK.ordinal(), null);
		inputCheckList.add(setInputCheck(reqMap, "koteiShisanId", "固定資産番号：", args));

		args = new HashMap<Integer, Object>();
		args.put(NSDConstant.CHECK_ITEM.EMPTY_CHECK.ordinal(), null);
		inputCheckList.add(setInputCheck(reqMap, "oyaKoteiShisanNo", "親固定資産番号：", args));

		args = new HashMap<Integer, Object>();
		args.put(NSDConstant.CHECK_ITEM.EMPTY_CHECK.ordinal(), null);
		args.put(NSDConstant.CHECK_ITEM.DATE_FORMAT_CHECK.ordinal(), null);
		inputCheckList.add(setInputCheck(reqMap, "shutokuYmd", "取得年月日：", args));

		args = new HashMap<Integer, Object>();
		args.put(NSDConstant.CHECK_ITEM.EMPTY_CHECK.ordinal(), null);
		args.put(NSDConstant.CHECK_ITEM.DATE_FORMAT_CHECK.ordinal(), null);
		inputCheckList.add(setInputCheck(reqMap, "getYmd", "使用開始年月日：", args));

		args = new HashMap<Integer, Object>();
		args.put(NSDConstant.CHECK_ITEM.EMPTY_CHECK.ordinal(), null);
		inputCheckList.add(setInputCheck(reqMap, "koteiShisanNm", "固定資産名称：", args));

		args = new HashMap<Integer, Object>();
		args.put(NSDConstant.CHECK_ITEM.EMPTY_CHECK.ordinal(), null);
		inputCheckList.add(setInputCheck(reqMap, "shuruiCd", "種類：", args));

		args = new HashMap<Integer, Object>();
		args.put(NSDConstant.CHECK_ITEM.EMPTY_CHECK.ordinal(), null);
		inputCheckList.add(setInputCheck(reqMap, "suryo", "物品数量：", args));

		args = new HashMap<Integer, Object>();
		args.put(NSDConstant.CHECK_ITEM.EMPTY_CHECK.ordinal(), null);
		inputCheckList.add(setInputCheck(reqMap, "taniCd", "単位：", args));

		args = new HashMap<Integer, Object>();
		args.put(NSDConstant.CHECK_ITEM.EMPTY_CHECK.ordinal(), null);
		inputCheckList.add(setInputCheck(reqMap, "buppinGaku", "物品：", args));

		args = new HashMap<Integer, Object>();
		args.put(NSDConstant.CHECK_ITEM.EMPTY_CHECK.ordinal(), null);
		inputCheckList.add(setInputCheck(reqMap, "kouhiGaku", "工費：", args));

		args = new HashMap<Integer, Object>();
		args.put(NSDConstant.CHECK_ITEM.EMPTY_CHECK.ordinal(), null);
		inputCheckList.add(setInputCheck(reqMap, "kanriSoshikiCd", "管理箇所名称：", args));

		args = new HashMap<Integer, Object>();
		args.put(NSDConstant.CHECK_ITEM.EMPTY_CHECK.ordinal(), null);
		inputCheckList.add(setInputCheck(reqMap, "futanSoshikiCd", "負担箇所：", args));

		args = new HashMap<Integer, Object>();
		args.put(NSDConstant.CHECK_ITEM.EMPTY_CHECK.ordinal(), null);
		inputCheckList.add(setInputCheck(reqMap, "sechiBashoCd", "設置場所名称：", args));

		args = new HashMap<Integer, Object>();
		args.put(NSDConstant.CHECK_ITEM.EMPTY_CHECK.ordinal(), null);
		inputCheckList.add(setInputCheck(reqMap, "shutokuRiyuCd", "取得事由：", args));

		// 種類コード
		String shuruiCd = reqMap.get("shuruiCd").toString().trim();
		// 項目１コード
		String kamokuCd1 = reqMap.get("kamokuCd1").toString().trim();
		// 項目３コード
		String kamokuCd3 = reqMap.get("kamokuCd3").toString().trim();
		// 取引先の判断
		if ("42".equals(shuruiCd) || "43".equals(shuruiCd) || "51".equals(shuruiCd) || "61".equals(shuruiCd)
				|| "12".equals(shuruiCd) || "305".equals(kamokuCd1) || "99".equals(kamokuCd3)) {

			args = new HashMap<Integer, Object>();
			args.put(NSDConstant.CHECK_ITEM.EMPTY_CHECK.ordinal(), null);
			inputCheckList.add(setInputCheck(reqMap, "taiyoNensuZei", "耐用月数：", args));

			args = new HashMap<Integer, Object>();
			args.put(NSDConstant.CHECK_ITEM.EMPTY_CHECK.ordinal(), null);
			inputCheckList.add(setInputCheck(reqMap, "torihikiSakiCd", "取引先名称：", args));

			args = new HashMap<Integer, Object>();
			args.put(NSDConstant.CHECK_ITEM.EMPTY_CHECK.ordinal(), null);
			args.put(NSDConstant.CHECK_ITEM.DATE_FORMAT_CHECK.ordinal(), null);
			inputCheckList.add(setInputCheck(reqMap, "shutokuYmd", "取得年月日：", args));

			args = new HashMap<Integer, Object>();
			args.put(NSDConstant.CHECK_ITEM.EMPTY_CHECK.ordinal(), null);
			args.put(NSDConstant.CHECK_ITEM.DATE_FORMAT_CHECK.ordinal(), null);
			inputCheckList.add(setInputCheck(reqMap, "torihikiSakifYmd", "取引先適用期間(From)：", args));

			args = new HashMap<Integer, Object>();
			args.put(NSDConstant.CHECK_ITEM.EMPTY_CHECK.ordinal(), null);
			args.put(NSDConstant.CHECK_ITEM.DATE_FORMAT_CHECK.ordinal(), null);
			inputCheckList.add(setInputCheck(reqMap, "torihikiSakitYmd", "取引先適用期間(To)：", args));

		} else {
			args = new HashMap<Integer, Object>();
			args.put(NSDConstant.CHECK_ITEM.EMPTY_CHECK.ordinal(), null);
			inputCheckList.add(setInputCheck(reqMap, "taiyoNensuZei", "耐用年数：", args));
		}

		args = new HashMap<Integer, Object>();
		args.put(NSDConstant.CHECK_ITEM.EMPTY_CHECK.ordinal(), null);
		args.put(NSDConstant.CHECK_ITEM.DATE_FORMAT_CHECK.ordinal(), null);
		inputCheckList.add(setInputCheck(reqMap, "kanriSoshikiF", "管理箇所適用期間(From)：", args));

		args = new HashMap<Integer, Object>();
		args.put(NSDConstant.CHECK_ITEM.EMPTY_CHECK.ordinal(), null);
		args.put(NSDConstant.CHECK_ITEM.DATE_FORMAT_CHECK.ordinal(), null);
		inputCheckList.add(setInputCheck(reqMap, "kanriSoshikiT", "管理箇所適用期間(To)：", args));

		args = new HashMap<Integer, Object>();
		args.put(NSDConstant.CHECK_ITEM.EMPTY_CHECK.ordinal(), null);
		args.put(NSDConstant.CHECK_ITEM.DATE_FORMAT_CHECK.ordinal(), null);
		inputCheckList.add(setInputCheck(reqMap, "futanSoshikiF", "管理箇所適用期間(From)：", args));

		args = new HashMap<Integer, Object>();
		args.put(NSDConstant.CHECK_ITEM.EMPTY_CHECK.ordinal(), null);
		args.put(NSDConstant.CHECK_ITEM.DATE_FORMAT_CHECK.ordinal(), null);
		inputCheckList.add(setInputCheck(reqMap, "futanSoshikiT", "管理箇所適用期間(To)：", args));

		String errStr = nsdDataCheck.dataCheck(inputCheckList);

		return errStr;

	}
}
