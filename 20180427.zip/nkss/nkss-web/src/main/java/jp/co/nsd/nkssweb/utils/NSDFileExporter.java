package jp.co.nsd.nkssweb.utils;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JasperCompileManager;
import net.sf.jasperreports.engine.JasperExportManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.data.JRBeanCollectionDataSource;
import net.sf.jasperreports.engine.export.ooxml.JRXlsxExporter;
import net.sf.jasperreports.export.SimpleExporterInput;
import net.sf.jasperreports.export.SimpleOutputStreamExporterOutput;
import net.sf.jasperreports.export.SimpleXlsxReportConfiguration;


/**
 * 帳票出力共通処理
 *
 */
@Component
public class NSDFileExporter {

	@Autowired
	private NSDProperties nsdProperties;

	/**
	 * PDF帳票を出力する
	 *
	 * @param ds
	 *            出力情報
	 * @param fileName
	 *            出力ファイル名
	 * @throws JRException
	 */
	public void exportPdf(JRBeanCollectionDataSource ds, String templateFile, String outputFile) throws JRException {

		// 出力ファイルのパス＋ファイル名
		outputFile = nsdProperties.getExcelPath().concat(outputFile);
		String jrxmlFile = templateFile.concat(NSDConstant.FILE_TEMPLATE_JRXML);
		String jasperFile = templateFile.concat(NSDConstant.FILE_TEMPLATE_JASPER);
		String outputfile = outputFile.concat(NSDConstant.FILE_TYPE_PDF);

		JasperCompileManager.compileReportToFile(jrxmlFile, jasperFile);
		JasperPrint jasperPrint = (JasperPrint) JasperFillManager.fillReport(jasperFile, null, ds);
		JasperExportManager.exportReportToPdfFile(jasperPrint, outputfile);

	}

	/**
	 * Excel帳票を出力する
	 *
	 * @param ds
	 *            出力情報
	 * @param fileName
	 *            出力ファイル名
	 * @throws JRException
	 */
	public void exportXlsx(JRBeanCollectionDataSource ds, String templateFile, String outputFile) throws JRException {

		// 出力ファイルのパス＋ファイル名
		outputFile = nsdProperties.getExcelPath().concat(outputFile);

		String jrxmlFile = templateFile.concat(NSDConstant.FILE_TEMPLATE_JRXML);
		String jasperFile = templateFile.concat(NSDConstant.FILE_TEMPLATE_JASPER);

		String outputfile = outputFile.concat(NSDConstant.FILE_TYPE_XLSX);

		JasperCompileManager.compileReportToFile(jrxmlFile, jasperFile);
		JasperPrint jasperPrint = (JasperPrint) JasperFillManager.fillReport(jasperFile, null, ds);
		JRXlsxExporter exporter = new JRXlsxExporter();
		exporter.setExporterInput(new SimpleExporterInput(jasperPrint));
		exporter.setExporterOutput(new SimpleOutputStreamExporterOutput(outputfile));
		SimpleXlsxReportConfiguration configuration = new SimpleXlsxReportConfiguration();
		configuration.setOnePagePerSheet(true);
		configuration.setDetectCellType(true);
		configuration.setCollapseRowSpan(false);
		exporter.setConfiguration(configuration);
		exporter.exportReport();

	}
}
