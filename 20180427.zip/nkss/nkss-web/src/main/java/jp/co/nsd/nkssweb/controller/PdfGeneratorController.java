package jp.co.nsd.nkssweb.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import jp.co.nsd.nkssweb.service.PdfGeneratorService;

@RestController
public class PdfGeneratorController {

	// ログ
	private Logger logger = LoggerFactory.getLogger(this.getClass());

	@Autowired
	private PdfGeneratorService pdfGeneratorService;

	@RequestMapping(value = "/pdf-create", method = RequestMethod.GET)
	public void createPDF() throws Exception {
		logger.info("PdfGeneratorController createPDF start");
		pdfGeneratorService.CreatePDF();
		return;
	}
}
