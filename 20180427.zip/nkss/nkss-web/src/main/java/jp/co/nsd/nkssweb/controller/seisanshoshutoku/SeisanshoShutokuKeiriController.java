/***********************************************************************
*
*業務名: 工事精算システム
*機能名: 除却（経理審査/連携）(ログ出力処理)
*
*機能概要: 除却情報を処理する。
*
*JavaＶｅｒ：J2SE1.8.0準拠
*
*更新履歴: Ver.1.00 2018/03/06　NSD　新規作成
***********************************************************************/

package jp.co.nsd.nkssweb.controller.seisanshoshutoku;

import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.beanutils.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import jp.co.nsd.nkssweb.controller.BaseController;
import jp.co.nsd.nkssweb.dao.SeisanshoShutokuKeiri;
import jp.co.nsd.nkssweb.dao.SeisanshoShutokuKrsk;
import jp.co.nsd.nkssweb.service.SystemService;
import jp.co.nsd.nkssweb.service.seisanshoshutoku.SeisanshoShutokuKeiriService;
import jp.co.nsd.nkssweb.utils.NSDCommUtils;
import jp.co.nsd.nkssweb.utils.NSDConstant;

/**
 * 取得（経理審査/連携）処理
 *
 * @version 1.00
 */
@RestController
public class SeisanshoShutokuKeiriController extends BaseController {

	@Autowired
	private SeisanshoShutokuKeiriService seisanshoShutokuKeiriService;

	protected SystemService systemService;

	/**
	 * 取得（経理審査/連携）検索処理
	 *
	 * @param reqMap
	 *            INPUTパラメータ
	 * @return 取得情報データ
	 * @exception IllegalAccessException
	 * @exception InvocationTargetException
	 * @version 1.00
	 */
	@RequestMapping(value = "/seisanshoShutokuKeiri-selectByWhere", method = RequestMethod.POST)
	public Map<String, Object> selectByWhere(@RequestParam Map<String, Object> reqMap) throws Exception {

		Map<String, Object> resultMap = new HashMap<String, Object>();

		SeisanshoShutokuKeiri seisanshoShutokuKeiri = new SeisanshoShutokuKeiri();

		List<SeisanshoShutokuKeiri> sssStkKrLst = new ArrayList<>();

		// Mapの情報をBeanのプロパティにセット
		BeanUtils.populate(seisanshoShutokuKeiri, reqMap);

		// 除却年月日（From）と除却年月日（To）の大小比較チェック
		if (NSDCommUtils.chkDateFromTo(seisanshoShutokuKeiri.getSiyoStartYmdFrom(),
				seisanshoShutokuKeiri.getSiyoStartYmdTo())) {

			// エラーメッセージを返却Mapに設定する
			return setMsgToResultMap(resultMap, NSDConstant.MSGID_INPUT_ERROR);

		}

		// サービス呼び出し
		sssStkKrLst = seisanshoShutokuKeiriService.getshutokuKeiriInfo(seisanshoShutokuKeiri);

		// 検索結果を返却Mapに設定する
		setDataToResultMap(resultMap, sssStkKrLst);

		// 画面へ返却値を返却する
		return resultMap;
	}

	/**
	 * 取得（経理審査/連携）更新処理
	 *
	 * @param reqMap
	 *            INPUTパラメータ
	 * @return 取得情報データ
	 * @exception IllegalAccessException
	 * @exception InvocationTargetException
	 * @version 1.00
	 */
	@RequestMapping(value = "/seisanshoShutokuKrsk-selectBySeisanShoNo", method = RequestMethod.POST)
	public Map<String, Object> selectBySeisanShoNo(@RequestParam Map<String, Object> reqMap) throws Exception {

		Map<String, Object> resultMap = new HashMap<String, Object>();

		SeisanshoShutokuKrsk seisanshoShutokuKrsk = new SeisanshoShutokuKrsk();
		SeisanshoShutokuKrsk sssSNSkDto = new SeisanshoShutokuKrsk();

		// Mapの情報をBeanのプロパティにセット
		BeanUtils.populate(seisanshoShutokuKrsk, reqMap);

		// サービス呼び出し
		sssSNSkDto = seisanshoShutokuKeiriService.getshutokuInfoBySeisanShoNo(seisanshoShutokuKrsk);

		// 検索結果を返却Mapに設定する
		setDataToResultMap(resultMap, sssSNSkDto);

		// 画面へ返却値を返却する
		return resultMap;

	}
}
