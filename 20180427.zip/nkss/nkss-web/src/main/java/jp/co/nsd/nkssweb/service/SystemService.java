package jp.co.nsd.nkssweb.service;

import jp.co.nsd.nkssweb.dao.LoginUserInfo;
import jp.co.nsd.nkssweb.dao.Message;

public interface SystemService {

	/**
	 * ログインユーザーの確認
	 *
	 * @param userId
	 * @return
	 * @throws Exception
	 */
	LoginUserInfo userLogin(String userId) throws Exception;

	/**
	 * メッセージの取得
	 *
	 * @param msgId
	 * @return
	 */
	Message getMessage(String msgId);

}
