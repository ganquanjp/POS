/***********************************************************************
*
*業務名: 工事精算システム
*機能名: 除却（登録・修正・削除）(ログ出力処理)
*
*機能概要: 除却情報を処理する。
*
*JavaＶｅｒ：J2SE1.8.0準拠
*
*更新履歴: Ver.1.00 2018/03/06　NSD　新規作成
***********************************************************************/

package jp.co.nsd.nkssweb.controller;

import java.lang.reflect.InvocationTargetException;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.beanutils.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import jp.co.nsd.nkssweb.dao.Kss013;
import jp.co.nsd.nkssweb.dao.LoginUserInfo;
import jp.co.nsd.nkssweb.service.SystemService;
import jp.co.nsd.nkssweb.utils.NSDConstant;

/**
 * 固定資産検索処理
 *
 * @version 1.00
 */
@RestController
public class SystemController extends BaseController {

	@Autowired
	protected SystemService systemService;

	/**
	 * ユーザーログイン処理
	 *
	 * @param reqMap
	 * @return
	 * @throws InvocationTargetException
	 * @throws IllegalAccessException
	 */
	@RequestMapping(value = "/system-userlogin", method = RequestMethod.POST)
	public Map<String, Object> userLogin(HttpServletRequest request, @RequestParam Map<String, Object> reqMap)
			throws Exception {

		Map<String, Object> resultMap = new HashMap<String, Object>();

		Kss013 kss013 = new Kss013();

		// 画面入力した検索条件を取得する
		BeanUtils.populate(kss013, reqMap);

		LoginUserInfo loginUserInfo = systemService.userLogin(kss013.getUserId());

		if (null == loginUserInfo) {
			// ユーザー情報取得できない場合
			this.setLoginUserInfo(request, null);
			return setMsgToResultMap(resultMap, NSDConstant.MSGID_USER_NOT_EXIST);
		} else if (null == loginUserInfo.getUmgList()) {
			// ユーザー権限取得できない場合
			this.setLoginUserInfo(request, null);
			return setMsgToResultMap(resultMap, NSDConstant.MSGID_LOGIN_FAILED);
		} else {
			// ログインユーザー情報をセッションに書込
			this.setLoginUserInfo(request, loginUserInfo);
		}

		// 検索結果を返却Mapに設定する
		setDataToResultMap(resultMap, loginUserInfo.getUmgList());
		setMsgToResultMapNoLog(resultMap, NSDConstant.MSGID_LOGIN_SUCCES);

		return resultMap;
	}

}
