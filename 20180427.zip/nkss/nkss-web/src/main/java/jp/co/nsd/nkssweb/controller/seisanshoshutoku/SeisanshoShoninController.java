/***********************************************************************
*
*業務名: 工事精算システム
*機能名: 除却（登録・修正・削除）(ログ出力処理)
*
*機能概要: 除却情報を処理する。
*
*JavaＶｅｒ：J2SE1.8.0準拠
*
*更新履歴: Ver.1.00 2018/03/06　NSD　新規作成
***********************************************************************/

package jp.co.nsd.nkssweb.controller.seisanshoshutoku;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.beanutils.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import jp.co.nsd.nkssweb.controller.BaseController;
import jp.co.nsd.nkssweb.dao.SeisanshoShonin;
import jp.co.nsd.nkssweb.dao.SeisanshoShoninShokai;
import jp.co.nsd.nkssweb.service.SystemService;
import jp.co.nsd.nkssweb.service.seisanshoshutoku.SeisanshoShoninService;
import jp.co.nsd.nkssweb.utils.NSDCommUtils;
import jp.co.nsd.nkssweb.utils.NSDConstant;

/**
 * 承認（検索・照会・更新）処理
 *
 * @version 1.00
 */
@RestController
public class SeisanshoShoninController extends BaseController {

	@Autowired
	private SeisanshoShoninService seisanshoShoninService;

	protected SystemService systemService;

	/**
	 * 取得承認（検索）処理
	 *
	 * @param reqMap
	 *            INPUTパラメータ
	 * @return 承認情報データ
	 * @exception Exception
	 * @version 1.00
	 */
	@RequestMapping(value = "/seisanshoShonin-selectByWhere", method = RequestMethod.POST)
	public Map<String, Object> selectByWhere(@RequestParam Map<String, Object> reqMap) throws Exception {

		Map<String, Object> resultMap = new HashMap<String, Object>();

		SeisanshoShonin seisanshoShonin = new SeisanshoShonin();

		List<SeisanshoShonin> sssSNLst = new ArrayList<SeisanshoShonin>();

		// Mapの情報をBeanのプロパティにセット
		BeanUtils.populate(seisanshoShonin, reqMap);

		// 使用開始年月日（From）と使用開始年月日（To）の大小比較チェック
		if (NSDCommUtils.chkDateFromTo(seisanshoShonin.getSiyoStartYmdFrom(), seisanshoShonin.getSiyoStartYmdTo())) {

			// エラーメッセージを返却Mapに設定する
			return setMsgToResultMap(resultMap, NSDConstant.MSGID_INPUT_ERROR);

		}

		// サービス呼び出し
		sssSNLst = seisanshoShoninService.getshoninInfo(seisanshoShonin);

		// 検索結果を返却Mapに設定する
		setDataToResultMap(resultMap, sssSNLst);

		return resultMap;
	}

	/**
	 * 取得承認（照会）処理
	 *
	 * @param reqMap
	 *            INPUTパラメータ
	 * @return 承認情報データ
	 * @exception Exception
	 * @version 1.00
	 */
	@RequestMapping(value = "/seisanshoShonin-selectBySeisanShoNo", method = RequestMethod.POST)
	public Map<String, Object> selectBySeisanShoNo(@RequestParam Map<String, Object> reqMap) throws Exception {

		Map<String, Object> resultMap = new HashMap<String, Object>();

		SeisanshoShoninShokai seisanshoShoninShokai = new SeisanshoShoninShokai();
		SeisanshoShoninShokai sssSnSk = new SeisanshoShoninShokai();

		// Mapの情報をBeanのプロパティにセット
		BeanUtils.populate(seisanshoShoninShokai, reqMap);

		// サービス呼び出し
		sssSnSk = seisanshoShoninService.getshutokuInfoBySeisanShoNo(seisanshoShoninShokai);

		// 検索結果を返却Mapに設定する
		setDataToResultMap(resultMap, sssSnSk);

		return resultMap;
	}
}
