/***********************************************************************
*
*業務名: 工事精算システム
*機能名: 除却（精算通告）(サービス処理)
*
*機能概要: 除却（精算通告）情報を処理する。
*
*JavaＶｅｒ：J2SE1.8.0準拠
*
*更新履歴: Ver.1.00 2018/03/06　NSD　新規作成
***********************************************************************/
package jp.co.nsd.nkssweb.service.seisanshojokyaku.impl;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.beanutils.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import jp.co.nsd.nkssweb.controller.CommController;
import jp.co.nsd.nkssweb.dao.KoteiSisan;
import jp.co.nsd.nkssweb.dao.Kss006;
import jp.co.nsd.nkssweb.dao.Kss016;
import jp.co.nsd.nkssweb.dao.Kss016Key;
import jp.co.nsd.nkssweb.dao.SeisanshoJokyakuKoteiSisan;
import jp.co.nsd.nkssweb.dao.SeisanshoJokyakuSeisan;
import jp.co.nsd.nkssweb.dao.SeisanshoJokyakuSeisanShokai;
import jp.co.nsd.nkssweb.dao.mapper.KoteiSisanJyohoMapper;
import jp.co.nsd.nkssweb.dao.mapper.Kss016Mapper;
import jp.co.nsd.nkssweb.dao.mapper.SeisanshoJokyakuSeisanMapper;
import jp.co.nsd.nkssweb.dao.mapper.StoredMapper;
import jp.co.nsd.nkssweb.service.seisanshojokyaku.SeisanshoJokyakuSeisanService;
import jp.co.nsd.nkssweb.utils.NSDConstant;

/**
 * 除却（精算通告）処理
 *
 * @see SeisanshoJokyakuSeisanService
 * @version 1.00
 */
@Service
public class SeisanshoJokyakuSeisanServiceImpl implements SeisanshoJokyakuSeisanService {

	@Autowired
	private SeisanshoJokyakuSeisanMapper seisanshoJokyakuSeisanMapper;

	@Autowired
	private KoteiSisanJyohoMapper koteiSisanJyohoMapper;

	@Autowired
	private Kss016Mapper kss016Mapper;

	@Autowired
	private CommController commController;

	@Autowired
	private StoredMapper storedMapper;

	/**
	 * 除却（精算通告）検索処理
	 *
	 * @param seisanshoJokyakuSeisan
	 *            INPUTパラメータ
	 * @return sssJykList 除却情報データリスト
	 * @version 1.00
	 */
	public List<SeisanshoJokyakuSeisan> getJokyakuSeisanInfo(SeisanshoJokyakuSeisan seisanshoJokyakuSeisan) {

		// 除却情報を取得する
		List<SeisanshoJokyakuSeisan> sssJykSsList = seisanshoJokyakuSeisanMapper.selectByWhere(seisanshoJokyakuSeisan);

		if (sssJykSsList.size() > 0) {
			for (int i = 1; i <= sssJykSsList.size(); i++) {
				// ROWNOを設定する
				sssJykSsList.get(i - 1).setRowNo(i);
			}

		} else {
			sssJykSsList = null;
		}

		return sssJykSsList;
	}

	/**
	 * 除却（精算通告）照会処理
	 *
	 * @param SeisanshoJokyakuSeisanShokai
	 *            INPUTパラメータ
	 * @return SeisanshoJokyakuShokaiList 除却情報データ
	 * @throws Exception
	 * @version 1.00
	 */
	@Override
	public SeisanshoJokyakuSeisanShokai getJokyakuInfoBySeisanShoNo(
			SeisanshoJokyakuSeisanShokai seisanshoJokyakuSeisanShokai) throws Exception {

		// 除却情報
		SeisanshoJokyakuSeisanShokai resultDto = new SeisanshoJokyakuSeisanShokai();

		// 除却固定資産情報
		SeisanshoJokyakuKoteiSisan sssJykKsDto;

		// 除却資産情報を取得する
		List<SeisanshoJokyakuSeisanShokai> sssJykSsSkList = seisanshoJokyakuSeisanMapper
				.selectBySeisanShoNo(seisanshoJokyakuSeisanShokai);

		List<SeisanshoJokyakuKoteiSisan> sssJykKsLst = new ArrayList<>();

		for (int i = 0; i < sssJykSsSkList.size(); i++) {
			// 除却資産情報
			SeisanshoJokyakuSeisanShokai sssJykSsSkDto = sssJykSsSkList.get(i);

			// Mapの情報をBeanのプロパティにセット
			BeanUtils.copyProperties(resultDto, sssJykSsSkDto);

			// 除却区分
			String jokyakuKbn = sssJykSsSkDto.getJokyakuKbn();
			// 除却種別コード
			String jokyakuShubetsuCd = sssJykSsSkDto.getJokyakuShubetsuCd();

			if (NSDConstant.STRING_1.equals(jokyakuKbn)) {
				if (NSDConstant.STRING_5.equals(jokyakuShubetsuCd)) {
					jokyakuShubetsuCd = NSDConstant.STRING_1;
				} else if (NSDConstant.STRING_6.equals(jokyakuShubetsuCd)) {
					jokyakuShubetsuCd = NSDConstant.STRING_2;
				} else if (NSDConstant.STRING_7.equals(jokyakuShubetsuCd)) {
					jokyakuShubetsuCd = NSDConstant.STRING_4;
				} else {
					jokyakuShubetsuCd = NSDConstant.BLANK_STRING;
				}
			}

			// 除却区分名称
			String jokyakuKbnNm = getKss016("CD0006", jokyakuKbn);

			// 除却種別名称
			String jokyakuShubetsuNm = getKss016("CD0008", jokyakuShubetsuCd);

			KoteiSisan koteiSisan = new KoteiSisan();
			// 固定ID
			koteiSisan.setKoteiCod(sssJykSsSkDto.getMotoKoteiShisanId());
			// 履歴ID
			koteiSisan.setRrkCod(sssJykSsSkDto.getRirekiNo());
			// 固定資産情報を取得する
			KoteiSisan ksDto = koteiSisanJyohoMapper.selectKoteiSisanByKoteiCod(koteiSisan);

			// 固定資産情報取得できないの場合
			if (null != ksDto) {

				sssJykKsDto = new SeisanshoJokyakuKoteiSisan();
				// ROWNO
				sssJykKsDto.setRowNo(i + 1);
				// 固定資産ID
				sssJykKsDto.setKoteiCod(ksDto.getKoteiCod());
				// 履歴ID
				sssJykKsDto.setRrkCod(ksDto.getRrkCod());
				// 除却精算書ID
				sssJykKsDto.setJokyakuSeisanShoId(sssJykSsSkDto.getJokyakuSeisanShoId());
				// 除却資産ID
				sssJykKsDto.setJokyakuShisanId(sssJykSsSkDto.getJokyakuShisanId());
				// 固定資産番号
				sssJykKsDto.setKoteiNo(ksDto.getKoteiNo());
				// 固定資産名称
				sssJykKsDto.setKoteiKnj(ksDto.getKoteiKnj());
				// 取得年月日
				sssJykKsDto.setGetYmd(ksDto.getGetYmd());
				// 元_数量
				sssJykKsDto.setMeiSu(ksDto.getMeiSu());
				// 単位
				sssJykKsDto.setTaniKnj(ksDto.getTaniKnj());
				// 元_取得価額
				sssJykKsDto.setGetkgkYen(ksDto.getGetkgkYen());
				// 除却区分名称
				sssJykKsDto.setJokyakuKbnNm(jokyakuKbnNm);
				// 除却区分コード
				sssJykKsDto.setJokyakuKbn(jokyakuKbn);
				// 除却種別コード
				sssJykKsDto.setJokyakuShubetsuCd(jokyakuShubetsuCd);
				// 除却種別名称
				sssJykKsDto.setJokyakuShubetsuNm(jokyakuShubetsuNm);
				// 除_数量
				sssJykKsDto.setJokyakuSuryo(sssJykSsSkDto.getJokyakuSuryo());
				// 除_取得価額
				sssJykKsDto.setJokyakuGaku(sssJykSsSkDto.getJokyakuGaku());
				// 固定資産情報を追加
				sssJykKsLst.add(sssJykKsDto);
			}

		}

		if (sssJykKsLst.size() > 0) {
			// 固定資産情報リスト
			resultDto.setKoteiSisanLst(sssJykKsLst);
		} else {
			return null;
		}

		return resultDto;
	}

	/**
	 * 除却（精算通告）更新処理
	 *
	 * @param kss006
	 *            INPUTパラメータ
	 * @return cnt
	 * @version 1.00
	 * @throws Exception
	 */
	public int updateInfo(Kss006 kss006) throws Exception {

		// 版数採番
		String seqHansu = commController.getSequence(NSDConstant.KSS_SEQ_HANSU);
		// 版数
		kss006.setHansu(new BigDecimal(seqHansu));

		seisanshoJokyakuSeisanMapper.updateByPrimaryKey(kss006);

		// 除却年月日
		if (!StringUtils.isEmpty(kss006.getJokyakuYmd())) {
			// 除却精算通告（更新）ストアド処理
//			try {
//				Map<String, Object> map = new HashMap<String, Object>();
//				map.put("JokyakuSeisanShoId", kss006.getJokyakuSeisanShoId());
//				map.put("shoriKbn", 1);
//				// 更新後の処理
//				storedMapper.setAllKs2040(map);
//			} catch (Exception e) {
//				throw new Exception("減価償却計算処理でエラーが発生しました. error=[" + e.getMessage() + "]");
//			}
		}

		return 0;
	}

	/**
	 * コードマスタ名称取得を処理
	 *
	 * @param cdShubetsu
	 *            INPUTパラメータ
	 * @param cd1
	 *            INPUTパラメータ
	 * @version 1.00
	 */
	protected String getKss016(String cdShubetsu, String cd1) {

		Kss016Key kss016Key = new Kss016Key();
		kss016Key.setCdShubetsu(cdShubetsu);
		kss016Key.setCd1(cd1);
		kss016Key.setCd2(NSDConstant.BLANK_STRING);
		Kss016 kss016 = kss016Mapper.selectByPrimaryKey(kss016Key);
		if (null == kss016) {
			return NSDConstant.BLANK_STRING;
		}
		return kss016.getCdKnj();
	}
}
