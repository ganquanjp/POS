package jp.co.nsd.nkssweb.dao;

import java.util.Date;

public class Kss002Key {
    private Long kenmeiId;

    private String kenmeiCd;

    private String kenmeiNm;

    private Date tekiyoStartYmd;

    public Long getKenmeiId() {
        return kenmeiId;
    }

    public void setKenmeiId(Long kenmeiId) {
        this.kenmeiId = kenmeiId;
    }

    public String getKenmeiCd() {
        return kenmeiCd;
    }

    public void setKenmeiCd(String kenmeiCd) {
        this.kenmeiCd = kenmeiCd == null ? null : kenmeiCd.trim();
    }

    public String getKenmeiNm() {
        return kenmeiNm;
    }

    public void setKenmeiNm(String kenmeiNm) {
        this.kenmeiNm = kenmeiNm == null ? null : kenmeiNm.trim();
    }

    public Date getTekiyoStartYmd() {
        return tekiyoStartYmd;
    }

    public void setTekiyoStartYmd(Date tekiyoStartYmd) {
        this.tekiyoStartYmd = tekiyoStartYmd;
    }
}