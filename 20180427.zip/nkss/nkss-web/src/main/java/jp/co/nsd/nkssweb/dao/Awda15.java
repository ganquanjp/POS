package jp.co.nsd.nkssweb.dao;

import java.util.Date;

public class Awda15 {
    private String awfTaniCod;

    private String awfTaniKnj;

    private Integer awfUpdateCnt;

    private Date awfTorokDh;

    private String awfTorshaCod;

    private Date awfUpdateDh;

    private String awfUpdshaCod;

    public String getAwfTaniCod() {
        return awfTaniCod;
    }

    public void setAwfTaniCod(String awfTaniCod) {
        this.awfTaniCod = awfTaniCod == null ? null : awfTaniCod.trim();
    }

    public String getAwfTaniKnj() {
        return awfTaniKnj;
    }

    public void setAwfTaniKnj(String awfTaniKnj) {
        this.awfTaniKnj = awfTaniKnj == null ? null : awfTaniKnj.trim();
    }

    public Integer getAwfUpdateCnt() {
        return awfUpdateCnt;
    }

    public void setAwfUpdateCnt(Integer awfUpdateCnt) {
        this.awfUpdateCnt = awfUpdateCnt;
    }

    public Date getAwfTorokDh() {
        return awfTorokDh;
    }

    public void setAwfTorokDh(Date awfTorokDh) {
        this.awfTorokDh = awfTorokDh;
    }

    public String getAwfTorshaCod() {
        return awfTorshaCod;
    }

    public void setAwfTorshaCod(String awfTorshaCod) {
        this.awfTorshaCod = awfTorshaCod == null ? null : awfTorshaCod.trim();
    }

    public Date getAwfUpdateDh() {
        return awfUpdateDh;
    }

    public void setAwfUpdateDh(Date awfUpdateDh) {
        this.awfUpdateDh = awfUpdateDh;
    }

    public String getAwfUpdshaCod() {
        return awfUpdshaCod;
    }

    public void setAwfUpdshaCod(String awfUpdshaCod) {
        this.awfUpdshaCod = awfUpdshaCod == null ? null : awfUpdshaCod.trim();
    }
}