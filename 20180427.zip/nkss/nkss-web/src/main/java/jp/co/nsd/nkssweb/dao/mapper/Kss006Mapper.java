package jp.co.nsd.nkssweb.dao.mapper;

import jp.co.nsd.nkssweb.dao.Kss006;

public interface Kss006Mapper {
    int deleteByPrimaryKey(String jokyakuSeisanShoId);

    int insert(Kss006 record);

    int insertSelective(Kss006 record);

    Kss006 selectByPrimaryKey(String jokyakuSeisanShoId);

    int updateByPrimaryKeySelective(Kss006 record);

    int updateByPrimaryKey(Kss006 record);
}