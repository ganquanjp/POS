/***********************************************************************
*
*業務名: 工事精算システム
*機能名: 除却（登録・修正・削除）(ログ出力処理)
*
*機能概要: 除却情報を処理する。
*
*JavaＶｅｒ：J2SE1.8.0準拠
*
*更新履歴: Ver.1.00 2018/03/06　NSD　新規作成
***********************************************************************/

package jp.co.nsd.nkssweb.controller.seisanshojokyaku;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.ibm.icu.text.SimpleDateFormat;

import jp.co.nsd.nkssweb.controller.BaseController;
import jp.co.nsd.nkssweb.dao.InputCheck;
import jp.co.nsd.nkssweb.dao.Kss006;
import jp.co.nsd.nkssweb.dao.Kss007;
import jp.co.nsd.nkssweb.dao.Kss011;
import jp.co.nsd.nkssweb.dao.LoginUserInfo;
import jp.co.nsd.nkssweb.dao.SeisanshoJokyaku;
import jp.co.nsd.nkssweb.dao.SeisanshoJokyakuShokai;
import jp.co.nsd.nkssweb.dao.SeisanshoJokyakuShokaiList;
import jp.co.nsd.nkssweb.dao.mapper.Kss006Mapper;
import jp.co.nsd.nkssweb.dao.mapper.Kss011Mapper;
import jp.co.nsd.nkssweb.service.seisanshojokyaku.SeisanshoJokyakuService;
import jp.co.nsd.nkssweb.utils.NSDCommUtils;
import jp.co.nsd.nkssweb.utils.NSDConstant;
import jp.co.nsd.nkssweb.utils.NSDDataCheck;
import jp.co.nsd.nkssweb.utils.NSDDateUtils;
import jp.co.nsd.nkssweb.utils.NSDProperties;

/**
 * 除却（登録・修正・削除）処理
 *
 * @version 1.00
 */
@RestController
public class SeisanshoJokyakuController extends BaseController {

	@Autowired
	private SeisanshoJokyakuService seisanshoJokyakuService;

	@Autowired
	private NSDProperties nsdProperties;

	@Autowired
	private NSDDataCheck nsdDataCheck;

	@Autowired
	private Kss006Mapper kss006Mapper;

	@Autowired
	private Kss011Mapper kss011Mapper;

	/**
	 * 除却（検索）処理
	 *
	 * @param reqMap
	 *            INPUTパラメータ
	 * @return 除却情報データ
	 * @throws Exception
	 * @version 1.00
	 */
	@RequestMapping(value = "/seisanshoJokyaku-selectByWhere", method = RequestMethod.POST)
	public Map<String, Object> selectByWhere(@RequestParam Map<String, Object> reqMap) throws Exception {

		Map<String, Object> resultMap = new HashMap<String, Object>();

		// 入力チェック
		String errStr = this.inputCheckForSearch(reqMap);
		if (StringUtils.isNotEmpty(errStr)) {
			return setMsgToResultMap(resultMap, NSDConstant.MSGID_INPUT_ERROR, errStr);
		}

		SeisanshoJokyaku seisanshoJokyaku = new SeisanshoJokyaku();

		List<SeisanshoJokyaku> sssJkkLst = new ArrayList<>();

		// Mapの情報をBeanのプロパティにセット
		BeanUtils.populate(seisanshoJokyaku, reqMap);

		// サービス呼び出し
		sssJkkLst = seisanshoJokyakuService.getJokyakuInfo(seisanshoJokyaku);

		// 検索結果を返却Mapに設定する
		return setDataToResultMap(resultMap, sssJkkLst);
	}

	/**
	 * 除却（照会）処理
	 *
	 * @param reqMap
	 *            INPUTパラメータ
	 * @return 除却情報データ
	 * @throws Exception
	 * @version 1.00
	 */
	@RequestMapping(value = "/seisanshoJokyaku-selectBySeisanShoNo", method = RequestMethod.POST)
	public Map<String, Object> selectBySeisanShoNo(@RequestParam Map<String, Object> reqMap) throws Exception {

		Map<String, Object> resultMap = new HashMap<String, Object>();

		SeisanshoJokyakuShokai shokaiCondition = new SeisanshoJokyakuShokai();

		// Mapの情報をBeanのプロパティにセット
		BeanUtils.populate(shokaiCondition, reqMap);

		// サービス呼び出し
		SeisanshoJokyakuShokaiList sssJkkSkDto = seisanshoJokyakuService.getJokyakuInfoBySeisanShoNo(shokaiCondition);

		return setDataToResultMap(resultMap, sssJkkSkDto);
	}

	/**
	 * 除却（削除）処理
	 *
	 * @param reqMap
	 *            INPUTパラメータ
	 * @return 除却情報データ
	 * @throws Exception
	 * @version 1.00
	 */
	@RequestMapping(value = "/seisanshoJokyaku-delByPyKey", method = RequestMethod.POST)
	public Map<String, Object> delByPyKey(@RequestParam Map<String, Object> reqMap) {

		Map<String, Object> resultMap = new HashMap<String, Object>();

		// 除却精算書ＩＤ
		String jokyakuSeisanShoId = (String) reqMap.get("jokyakuSeisanShoId");

		// サービス呼び出し
		seisanshoJokyakuService.delByPyKey(jokyakuSeisanShoId);

		// 処理結果データ
		resultMap.put(NSDConstant.RESULT_DATA_NAME, "");

		return setMsgToResultMapNoLog(resultMap, NSDConstant.MSGID_UPDATE_SUCCES);
	}

	/**
	 * 除却（新規登録・初期表示）処理
	 *
	 * @param reqMap
	 *            INPUTパラメータ
	 * @return 除却情報データ
	 * @throws Exception
	 * @version 1.00
	 */
	@RequestMapping(value = "/seisanshojokyaku-toroku-initShow", method = RequestMethod.POST)
	public Map<String, Object> initShowForInsert(HttpServletRequest request) throws Exception {

		Map<String, Object> resultMap = new HashMap<String, Object>();

		LoginUserInfo loginUserInfo = getLoginUserInfo(request);

		// 検索結果を返却Mapに設定する
		return setDataToResultMap(resultMap, loginUserInfo);
	}

	/**
	 * 除却（登録）処理
	 *
	 * @param reqMap
	 *            INPUTパラメータ
	 * @return 除却情報データ
	 * @throws Exception
	 * @version 1.00
	 */
	@RequestMapping(value = "/seisanshoJokyaku-insertInfo", method = RequestMethod.POST)
	public Map<String, Object> insertInfo(HttpServletRequest request, @RequestParam Map<String, Object> reqMap)
			throws Exception {

		Map<String, Object> resultMap = new HashMap<String, Object>();

		// 入力チェック
		String errStr = inputCheckForInsert(reqMap);
		if (StringUtils.isNotEmpty(errStr)) {
			return setMsgToResultMap(resultMap, NSDConstant.MSGID_INPUT_ERROR, errStr);
		}

		Date date = new Date();
		String loginUserId = getLoginUserInfo(request).getUserId();

		// 除却資産
		Kss006 kss006 = setKss006(reqMap, date, loginUserId, 0);

		// 除却資産明細
		List<Kss007> kss007List = setKss007ListForInsert(reqMap, date, loginUserId);

		// サービス呼び出し
		seisanshoJokyakuService.insertInfo(kss006, kss007List);

		// 処理結果データ
		resultMap.put(NSDConstant.RESULT_DATA_NAME, "");

		return setMsgToResultMapNoLog(resultMap, NSDConstant.MSGID_INSERT_SUCCES);
	}

	/**
	 * 除却更新画面（更新・削除・登録）処理
	 *
	 * @param reqMap
	 *            INPUTパラメータ
	 * @return 除却情報データ
	 * @throws Exception
	 * @version 1.00
	 */
	@RequestMapping(value = "/seisanshoJokyaku-updateInfo", method = RequestMethod.POST)
	public Map<String, Object> updateInfo(HttpServletRequest request, @RequestParam Map<String, Object> reqMap)
			throws Exception {

		Map<String, Object> resultMap = new HashMap<String, Object>();

		// 入力チェック
		String errStr = inputCheckForUpdate(reqMap);
		if (StringUtils.isNotEmpty(errStr)) {
			return setMsgToResultMap(resultMap, NSDConstant.MSGID_INPUT_ERROR, errStr);
		}

		Date date = new Date();
		String loginUserId = getLoginUserInfo(request).getUserId();

		// 除却資産明細(更新)
		List<Kss007> kss007UpdLst = new ArrayList<Kss007>();
		// 除却資産明細(削除)
		List<Kss007> kss007DelLst = new ArrayList<Kss007>();
		// MapKey
		String key;
		// 更新チェック
		boolean updChk = false;
		// 削除チェック
		boolean delChk = false;

		// 更新・削除処理判断
		for (int i = 0; i < nsdProperties.getPageSize(); i++) {
			// 固定資産番号KEY
			key = "koteiSisanLst".concat("[" + i + "]").concat("[koteiNo]");
			// 固定資産番号が空の場合
			if (StringUtils.isEmpty((String) reqMap.get(key))) {
				continue;
			}

			// 除却資産明細情報を設定
			Kss007 kss007 = setKss007(reqMap, i, date, loginUserId, NSDConstant.ACTION_UPDATE);

			String keyUpd = "koteiSisanLst".concat("[" + i + "]").concat("[upd]");
			String keyDel = "koteiSisanLst".concat("[" + i + "]").concat("[del]");

			if (null != reqMap.get(keyUpd)) {
				updChk = Boolean.valueOf((String) reqMap.get(keyUpd));
			}
			if (null != reqMap.get(keyDel)) {
				delChk = Boolean.valueOf((String) reqMap.get(keyDel));
			}

			if (updChk) {
				// 更新用
				kss007UpdLst.add(kss007);

			} else if (delChk) {
				// 削除用
				kss007DelLst.add(kss007);

			} else {
				// 処理なし
			}
		}

		// 除却資産
		Kss006 kss006 = setKss006(reqMap, date, loginUserId, NSDConstant.ACTION_UPDATE);

		// 更新年月日を取得
		Date updDate = kss006Mapper.selectByPrimaryKey(kss006.getJokyakuSeisanShoId()).getUpdateDate();
		// 排他チェック
		if (null == updDate || !(reqMap.get("updateDate").toString()
				.equals(NSDDateUtils.dateToString(updDate, "yyyy-MM-dd HH:mm:ss.SSS")))) {
			return setMsgToResultMap(resultMap, NSDConstant.MSGID_SUPDATE_LOCK);
		}

		// サービス呼び出し
		seisanshoJokyakuService.updateInfo(kss006, kss007UpdLst, kss007DelLst);

		// 処理結果データ
		resultMap.put(NSDConstant.RESULT_DATA_NAME, "");

		return setMsgToResultMapNoLog(resultMap, NSDConstant.MSGID_UPDATE_SUCCES);
	}

	/**
	 * 除却検索の入力データチェック
	 *
	 * @param reqMap
	 *            INPUTパラメータ
	 * @return エラーメッセージID
	 * @version 1.00
	 */
	private String inputCheckForSearch(Map<String, Object> reqMap) {

		List<InputCheck> inputCheckList = getCheckItemListForSearch(reqMap);
		return nsdDataCheck.dataCheck(inputCheckList);

	}

	/**
	 * 除却登録の入力データチェック
	 *
	 * @param reqMap
	 *            INPUTパラメータ
	 * @return エラーメッセージID
	 * @version 1.00
	 */
	private String inputCheckForInsert(Map<String, Object> reqMap) {

		String errStr = NSDConstant.BLANK_STRING;

		List<InputCheck> inputCheckList = getCheckItemListForInsertUpdate(reqMap, NSDConstant.ACTION_INSERT);

		// 前の５項目はヘッダ部の項目です。
		if (inputCheckList.size() <= 5) {
			errStr = NSDCommUtils.setKakoToStr(
					"固定資産情報：".concat(systemService.getMessage(NSDConstant.MSGID_CHECK_EMPTY).getContent()));

		} else {
			errStr = nsdDataCheck.dataCheck(inputCheckList);
		}

		return errStr;

	}

	/**
	 * 除却更新の入力データチェック
	 *
	 * @param reqMap
	 *            INPUTパラメータ
	 * @return エラーメッセージID
	 * @version 1.00
	 */
	private String inputCheckForUpdate(Map<String, Object> reqMap) {

		List<InputCheck> inputCheckList = getCheckItemListForInsertUpdate(reqMap, NSDConstant.ACTION_UPDATE);
		String errStr = nsdDataCheck.dataCheck(inputCheckList);

		return errStr;

	}

	/**
	 * 除却資産情報処理
	 *
	 * @param reqMap
	 *            INPUTパラメータ
	 * @param date
	 *            当日日付
	 * @param userId
	 *            ログインユーザー
	 * @param actionFlag
	 *            登録・更新フラグ 0:登録 1:更新
	 * @return 除却資産情報データ
	 * @throws Exception
	 */
	private Kss006 setKss006(Map<String, Object> reqMap, Date date, String userId, int actionFlag) throws Exception {

		SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd");
		// 除却資産
		Kss006 kss006 = new Kss006();
		// 精算箇所コード
		kss006.setSeisanSoshikiCd((String) reqMap.get("seisanSoshikiCd"));
		// 適用開始日
		Kss011 kss011 = kss011Mapper.selectByPrimaryKey(kss006.getSeisanSoshikiCd());
		// kss006.setTekiyoStartYmd(sdf.parse(reqMap.get("tekiyoStartYmd").toString().replaceAll("-",
		// "/")));
		kss006.setTekiyoStartYmd(sdf.parse(NSDDateUtils.dateToString(kss011.getTekiyoStartYmd(), "yyyy/MM/dd")));
		String jokyakuYoteYmd = (String) reqMap.get("jokyakuYoteYmd");
		jokyakuYoteYmd = jokyakuYoteYmd.length() == 10 ? jokyakuYoteYmd : jokyakuYoteYmd.concat("-01");
		// 除却予定年月
		kss006.setJokyakuYoteYmd(sdf.parse(jokyakuYoteYmd.replaceAll("-", "/")));
		// 登録者コード
		kss006.setSeisanEntryUserId((String) reqMap.get("userId"));
		// 摘要
		kss006.setTekiyo((String) reqMap.get("tekiyo"));
		// 工事件名
		kss006.setKenmeiNm((String) reqMap.get("kenmeiNm"));
		// 担当者適用開始日
		kss006.setTantoTekiyoStartYmd(sdf.parse(reqMap.get("nyushaYmd").toString().replaceAll("-", "/")));

		if (NSDConstant.ACTION_INSERT == actionFlag) {
			// 登録年月日
			kss006.setEntryDate(date);
			// 登録ユーザーＩＤ
			kss006.setEntryUserId(userId);
		} else {
			// 除却資産書ＩＤ
			kss006.setJokyakuSeisanShoId(reqMap.get("jokyakuSeisanShoId").toString());
		}

		// 更新年月日
		kss006.setUpdateDate(date);
		// 更新ユーザーＩＤ
		kss006.setUpdateUserId(userId);

		return kss006;
	}

	/**
	 * 除却資明細リストの取得(新規登録)
	 *
	 * @param reqMap
	 * @param date
	 * @param userId
	 * @return
	 * @throws Exception
	 */
	private List<Kss007> setKss007ListForInsert(Map<String, Object> reqMap, Date date, String userId) throws Exception {
		List<Kss007> kss007List = new ArrayList<Kss007>();

		for (int i = 0; i < nsdProperties.getPageSize(); i++) {
			Kss007 kss007 = setKss007(reqMap, i, date, userId, NSDConstant.ACTION_INSERT);
			if (null == kss007) {
				continue;
			}

			// 除却資産明細
			kss007List.add(kss007);
		}

		return kss007List;
	}

	/**
	 * 除却資明細産情報処理
	 *
	 * @param reqMap
	 *            INPUTパラメータ
	 * @param idx
	 *            行番
	 * @param date
	 *            当日日付
	 * @param userId
	 *            ログインユーザー
	 * @param actionFlag
	 *            登録・更新フラグ 0:登録 1:更新
	 * @throws Exception
	 * @version 1.00
	 */
	private Kss007 setKss007(Map<String, Object> reqMap, int idx, Date date, String userId, int actionFlag)
			throws Exception {

		// MapKey
		String key;
		// 固定資産IDKEY
		key = "koteiSisanLst".concat("[" + idx + "]").concat("[koteiCod]");
		// 固定資産IDが空の場合
		if (StringUtils.isEmpty((String) reqMap.get(key))) {
			return null;
		}

		Kss007 kss007 = new Kss007();
		// 除却元固定資産ＩＤ
		kss007.setMotoKoteiShisanId((String) reqMap.get(key));
		// 履歴IDKEY
		key = "koteiSisanLst".concat("[" + idx + "]").concat("[rrkCod]");
		kss007.setRirekiNo((String) reqMap.get(key));
		// 種類コードKEY
		key = "koteiSisanLst".concat("[" + idx + "]").concat("[shuCod]");
		kss007.setShuruiCd((String) reqMap.get(key));
		// 構造コードKEY
		key = "koteiSisanLst".concat("[" + idx + "]").concat("[kouCod]");
		kss007.setKouzouCd((String) reqMap.get(key));
		// 資産単位コードKEY
		key = "koteiSisanLst".concat("[" + idx + "]").concat("[saiCod]");
		kss007.setShisanTaniCd((String) reqMap.get(key));
		// 科目１コードKEY
		key = "koteiSisanLst".concat("[" + idx + "]").concat("[shu4Cod]");
		kss007.setKamokuCd1((String) reqMap.get(key));
		// 科目２コードKEY
		key = "koteiSisanLst".concat("[" + idx + "]").concat("[shu5Cod]");
		kss007.setKamokuCd2((String) reqMap.get(key));
		// 科目３コードKEY
		key = "koteiSisanLst".concat("[" + idx + "]").concat("[shu6Cod]");
		kss007.setKamokuCd3((String) reqMap.get(key));
		// 除＿数量KEY
		key = "koteiSisanLst".concat("[" + idx + "]").concat("[meiSu]");
		kss007.setJokyakuSuryo(new BigDecimal((String) reqMap.get(key)));
		// 除＿取得価額KEY
		key = "koteiSisanLst".concat("[" + idx + "]").concat("[getkgkYen]");
		kss007.setJokyakuGaku(Long.parseLong((String) reqMap.get(key)));

		if (NSDConstant.ACTION_INSERT == actionFlag) {
			// 登録年月日
			kss007.setEntryDate(date);
			// 登録ユーザーＩＤ
			kss007.setEntryUserId(userId);
		} else {
			// 除却資産書ＩＤ
			kss007.setJokyakuSeisanShoId(reqMap.get("jokyakuSeisanShoId").toString());
			// 除却資産ＩＤ
			kss007.setJokyakuShisanId(
					(String) reqMap.get("koteiSisanLst".concat("[" + idx + "]").concat("[jokyakuShisanId]")));
		}

		// 更新年月日
		kss007.setUpdateDate(date);
		// 更新ユーザーＩＤ
		kss007.setUpdateUserId(userId);

		return kss007;
	}

	/**
	 * 検索の入力チェック内容リストを定義
	 *
	 * @param reqMap
	 *            INPUTパラメータ
	 * @return
	 */
	private List<InputCheck> getCheckItemListForSearch(Map<String, Object> reqMap) {

		List<InputCheck> inputCheckList = new ArrayList<InputCheck>();
		Map<Integer, Object> args;

		args = new HashMap<Integer, Object>();
		args.put(NSDConstant.CHECK_ITEM.DATE_COMPARE_CHECK.ordinal(), ((String) reqMap.get("jokyakuYoteYmdTo")).trim());
		inputCheckList.add(setInputCheck(reqMap, "jokyakuYoteYmdFrom", "除却予定年月日：", args));

		return inputCheckList;
	}

	/**
	 * 除却(登録、更新・削除)項目のチェック内容リストを定義
	 *
	 * @param reqMap
	 *            INPUTパラメータ
	 * @param actionFlag
	 *            登録・更新フラグ 0:登録 1:更新
	 * @return
	 */
	private List<InputCheck> getCheckItemListForInsertUpdate(Map<String, Object> reqMap, int actionFlag) {

		List<InputCheck> inputCheckList = new ArrayList<InputCheck>();
		Map<Integer, Object> args;

		// 画面ヘッダ部
		args = new HashMap<Integer, Object>();
		args.put(NSDConstant.CHECK_ITEM.EMPTY_CHECK.ordinal(), null);
		args.put(NSDConstant.CHECK_ITEM.LENGTH_CHECK.ordinal(), 200);
		args.put(NSDConstant.CHECK_ITEM.IS_EXIST_SOSHIKIRENNM.ordinal(), null);
		inputCheckList.add(setInputCheck(reqMap, "soshikiRenNm", "精算箇所：", args));

		args = new HashMap<Integer, Object>();
		args.put(NSDConstant.CHECK_ITEM.EMPTY_CHECK.ordinal(), null);
		args.put(NSDConstant.CHECK_ITEM.DATE_YYYYMM_CHECK.ordinal(), null);
		inputCheckList.add(setInputCheck(reqMap, "jokyakuYoteYmd", "除却予定年月：", args));

		args = new HashMap<Integer, Object>();
		args.put(NSDConstant.CHECK_ITEM.EMPTY_CHECK.ordinal(), null);
		args.put(NSDConstant.CHECK_ITEM.LENGTH_CHECK.ordinal(), 40);
		inputCheckList.add(setInputCheck(reqMap, "userId", "登録者氏名：", args));

		args = new HashMap<Integer, Object>();
		args.put(NSDConstant.CHECK_ITEM.LENGTH_CHECK.ordinal(), 1000);
		inputCheckList.add(setInputCheck(reqMap, "tekiyo", "摘要：", args));

		args = new HashMap<Integer, Object>();
		args.put(NSDConstant.CHECK_ITEM.EMPTY_CHECK.ordinal(), null);
		args.put(NSDConstant.CHECK_ITEM.LENGTH_CHECK.ordinal(), 20);
		inputCheckList.add(setInputCheck(reqMap, "kenmeiNm", "工事件名：", args));

		// 画面明細部
		String id, name;
		for (int i = 0; i < nsdProperties.getPageSize(); i++) {
			id = "koteiSisanLst".concat("[" + i + "]").concat("[koteiNo]");
			// 固定資産番号が空の場合
			if (StringUtils.isEmpty(reqMap.get(id).toString())) {
				continue;
			}

			args = new HashMap<Integer, Object>();
			args.put(NSDConstant.CHECK_ITEM.EMPTY_CHECK.ordinal(), null);
			id = "koteiSisanLst".concat("[" + i + "]").concat("[koteiKnj]");
			name = "固定資産名称(行番号：".concat(String.valueOf(i + 1).concat(")："));
			inputCheckList.add(setInputCheck(reqMap, id, name, args));

			args = new HashMap<Integer, Object>();
			args.put(NSDConstant.CHECK_ITEM.EMPTY_CHECK.ordinal(), null);
			id = "koteiSisanLst".concat("[" + i + "]").concat("[getYmd]");
			name = "取得年月日(行番号：".concat(String.valueOf(i + 1).concat(")："));
			inputCheckList.add(setInputCheck(reqMap, id, name, args));

			args = new HashMap<Integer, Object>();
			args.put(NSDConstant.CHECK_ITEM.EMPTY_CHECK.ordinal(), null);
			id = "koteiSisanLst".concat("[" + i + "]").concat("[useYmd]");
			name = "使用開始年月日(行番号：".concat(String.valueOf(i + 1).concat(")："));
			inputCheckList.add(setInputCheck(reqMap, id, name, args));

			args = new HashMap<Integer, Object>();
			args.put(NSDConstant.CHECK_ITEM.EMPTY_CHECK.ordinal(), null);
			id = "koteiSisanLst".concat("[" + i + "]").concat("[koteioyaNo]");
			name = "親固定資産番号(行番号：".concat(String.valueOf(i + 1).concat(")："));
			inputCheckList.add(setInputCheck(reqMap, id, name, args));

			// 更新・削除の場合
			if (NSDConstant.ACTION_UPDATE == actionFlag) {
				args = new HashMap<Integer, Object>();
				String idUpd = "koteiSisanLst".concat("[" + i + "]").concat("[upd]");
				String idDel = "koteiSisanLst".concat("[" + i + "]").concat("[del]");
				name = "(行番号：".concat(String.valueOf(i + 1).concat(")："));
				args.put(NSDConstant.CHECK_ITEM.ONLYONE_SELECT.ordinal(), reqMap.get(idDel));
				inputCheckList.add(setInputCheck(reqMap, idUpd, name, args));
			}

		}

		return inputCheckList;
	}

}
