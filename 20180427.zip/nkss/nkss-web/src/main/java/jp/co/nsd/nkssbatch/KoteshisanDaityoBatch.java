/***********************************************************************
*
*業務名: 工事精算システム
*機能名: 【バッチ】固定資産台帳出力処理
*
*機能概要: 【バッチ】固定資産台帳出力処理
*
*JavaＶｅｒ：J2SE1.8.0準拠
*
*更新履歴: Ver.1.00 2018/04/11　NSD　新規作成
***********************************************************************/
package jp.co.nsd.nkssbatch;

import org.mybatis.spring.annotation.MapperScan;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.transaction.annotation.Transactional;

import jp.co.nsd.nkssweb.service.KoteshisanDaityoService;
import jp.co.nsd.nkssweb.utils.NSDConstant;

@SpringBootApplication
@MapperScan("jp.co.nsd.nkssweb.dao.mapper")
@ComponentScan("jp.co.nsd.nkssweb.service")
@ComponentScan("jp.co.nsd.nkssweb.controller")
@ComponentScan("jp.co.nsd.nkssweb.utils")
public class KoteshisanDaityoBatch implements CommandLineRunner {

    public static void main(String[] args) {
        SpringApplication application = new SpringApplication(KoteshisanDaityoBatch.class);
        application.setWebEnvironment(false);
        System.exit(SpringApplication.exit(application.run(args)));
    }
	@Autowired
	private KoteshisanDaityoService koteshisanDaityoService;

    public KoteshisanDaityoBatch(KoteshisanDaityoService koteshisanDaityoService) {
        this.koteshisanDaityoService = koteshisanDaityoService;
    }

    // Spring Boot起動時にCommandLineRunner#runメソッドが呼び出される
    @Transactional
    @Override
    public void run(String... args) throws Exception {

    	if(NSDConstant.BATCH_CLASS_NAME_KOTESHISANDAITYO.equals((String) args[0])){
        	// 帳票出力処理を呼び出し
        	// 作成区分 1：夜間（バッチ）/2：昼間（画面）
    		koteshisanDaityoService.getKenmeiInfo(NSDConstant.CODE_SAKUSEI_KBN_BATCH);
    	}
    }
}