package jp.co.nsd.nkssweb.utils;

import java.util.Iterator;
import java.util.List;
import java.util.Map.Entry;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import jp.co.nsd.nkssweb.dao.InputCheck;
import jp.co.nsd.nkssweb.dao.Kss011;
import jp.co.nsd.nkssweb.service.InputCheckService;
import jp.co.nsd.nkssweb.service.SystemService;

@Component
public class NSDDataCheck {

	@Autowired
	protected SystemService systemService;

	@Autowired
	private InputCheckService inputCheckService;

	/**
	 * 項目チェック
	 *
	 * @param checkItemList
	 *            チェックをしたい項目リスト
	 * @return
	 */
	public String dataCheck(List<InputCheck> checkItemList) {

		for (int i = 0; i < checkItemList.size(); i++) {
			InputCheck inputCheck = checkItemList.get(i);

			Iterator<Entry<Integer, Object>> iter = inputCheck.getArgs().entrySet().iterator();

			while (iter.hasNext()) {
				Entry<Integer, Object> entry = iter.next();
				int key = entry.getKey();
				Object value = entry.getValue();

				String errStr = NSDConstant.BLANK_STRING;

				if (key == NSDConstant.CHECK_ITEM.EMPTY_CHECK.ordinal()) {
					// 空文字チェック
					if (!checkEmpty(inputCheck.getItemValue())) {
						errStr = systemService.getMessage(NSDConstant.MSGID_CHECK_EMPTY).getContent();
					}
				} else if (key == NSDConstant.CHECK_ITEM.LENGTH_CHECK.ordinal()) {
					// 桁数のチェック
					if (!checkLength(inputCheck.getItemValue(), value)) {
						errStr = systemService.getMessage(NSDConstant.MSGID_CHECK_LENGTH).getContent();
					}
				} else if (key == NSDConstant.CHECK_ITEM.DATE_YYYYMM_CHECK.ordinal()) {
					// 年月の妥当性チェック
					if (!checkDateYYYYMM(inputCheck.getItemValue())) {
						errStr = systemService.getMessage(NSDConstant.MSGID_CHECK_DATE_FORMAT).getContent();
					}
				} else if (key == NSDConstant.CHECK_ITEM.DATE_FORMAT_CHECK.ordinal()) {
					// 日付の妥当性チェック
					if (!checkDateFormat(inputCheck.getItemValue())) {
						errStr = systemService.getMessage(NSDConstant.MSGID_CHECK_DATE_FORMAT).getContent();
					}
				} else if (key == NSDConstant.CHECK_ITEM.DATE_COMPARE_CHECK.ordinal()) {
					// 日付の大小比較チェック
					if (!checkDateCompare(inputCheck.getItemValue(), value)) {
						errStr = systemService.getMessage(NSDConstant.MSGID_CHECK_DATE_COMPARE).getContent();
					}
				} else if (key == NSDConstant.CHECK_ITEM.ONLYONE_SELECT.ordinal()) {
					// 一つのみ選択チェック
					if (!checkOnlyOneSelected(inputCheck.getItemValue(), value)) {
						errStr = systemService.getMessage(NSDConstant.MSGID_ONLYONE_SELECT_ERROR).getContent();
					}
				} else if (key == NSDConstant.CHECK_ITEM.IS_EXIST_SOSHIKIRENNM.ordinal()) {
					// 該当組織連結名はDBに存在チェック
					if (!isExistSoshikiRenNm(inputCheck.getItemValue())) {
						errStr = systemService.getMessage(NSDConstant.MSGID_NOT_EXIST_DATA).getContent();
					}
				} else {

				}
				if (!NSDConstant.BLANK_STRING.equals(errStr)) {
					return NSDCommUtils.setKakoToStr(inputCheck.getItemName().concat(errStr));
				}

			}
		}

		return NSDConstant.BLANK_STRING;
	}

	/**
	 * 空文字のチェック
	 *
	 * @param str
	 * @return
	 */
	private boolean checkEmpty(String str) {
		if (StringUtils.isEmpty(str)) {
			return false;
		}
		return true;
	}

	/**
	 * 桁数のチェック
	 *
	 * @param str
	 * @param value
	 * @return
	 */
	private boolean checkLength(String str, Object value) {

		int maxLength = Integer.parseInt(value.toString());

		if (str.length() > maxLength) {
			return false;
		}
		return true;
	}

	/**
	 * 年月の妥当性チェック
	 *
	 * @param dateStr
	 *            yyyy-MM or yyyy/MM
	 * @return
	 */
	private boolean checkDateYYYYMM(String dateStr) {

		String wkDate = dateStr.replace('-', '/');
		wkDate = wkDate.length() == 10 ? wkDate : wkDate.concat("/01");
		if (!NSDCommUtils.checkDate(wkDate)) {
			return false;
		}
		return true;
	}

	/**
	 * 日付の妥当性チェック
	 *
	 * @param dateStr
	 * @return
	 */
	private boolean checkDateFormat(String dateStr) {

		if (!NSDCommUtils.checkDate(dateStr)) {
			return false;
		}
		return true;
	}

	/**
	 * 日付の大小比較チェック
	 *
	 * @param dateFrom
	 * @param value
	 * @return
	 */
	private boolean checkDateCompare(String dateFrom, Object value) {

		String dateTo = value.toString();
		if (NSDCommUtils.chkDateFromTo(dateFrom, dateTo)) {
			return false;

		}
		return true;
	}

	/**
	 * 同時に選択チェック
	 *
	 * @param str
	 * @param value
	 * @return
	 */
	private boolean checkOnlyOneSelected(String str, Object value) {

		String str1 = (String) value;
		if ("true".equals(str) && str.equals(str1)) {
			return false;
		}
		return true;
	}

	/**
	 * 画面精算箇所入力した組織名はDBに存在チェック
	 *
	 * @param soshikiRenNm
	 * @return
	 */
	private boolean isExistSoshikiRenNm(String soshikiRenNm) {

		Kss011 kss011 = inputCheckService.getSoshikiInfoForInputCheck(soshikiRenNm);
		if (null == kss011) {
			return false;
		}
		return true;
	}

}