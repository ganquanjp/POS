package jp.co.nsd.nkssweb.dao;

public class SeisanshoJokyakuShokai {

	// 除却精算書ＩＤ
	private String jokyakuSeisanShoId;

	// 除却資産ＩＤ
	private String jokyakuShisanId;

	// 除却元固定資産ＩＤ
	private String motoKoteiShisanId;

	// 履歴番号
	private String rrkCod;

	// 除却精算書番号
	private String jokyakuSeisanShoNo;

	// 件名
	private String kenmeiNm;

	// 除却予定年月日
	private String jokyakuYoteYmd;

	// 除却年月日
	private String jokyakuYmd;

	// 承認状態
	private String shoninStatus;

	// 摘要
	private String tekiyo;

	// 組織連結略名
	private String soshikiRenNm;

	// 精算箇所コード
	private String seisanSoshikiCd;

	// 登録者氏名
	private String seiMei;

	// 登録者コード
	private String userId;

	// 適用開始日
	private String tekiyoStartYmd;

	// 担当者適用開始日
	private String nyushaYmd;

	// 更新年月日
	private String updateDate;

	public String getJokyakuSeisanShoId() {
		return jokyakuSeisanShoId;
	}

	public void setJokyakuSeisanShoId(String jokyakuSeisanShoId) {
		this.jokyakuSeisanShoId = jokyakuSeisanShoId;
	}

	public String getJokyakuShisanId() {
		return jokyakuShisanId;
	}

	public void setJokyakuShisanId(String jokyakuShisanId) {
		this.jokyakuShisanId = jokyakuShisanId;
	}

	public String getMotoKoteiShisanId() {
		return motoKoteiShisanId;
	}

	public void setMotoKoteiShisanId(String motoKoteiShisanId) {
		this.motoKoteiShisanId = motoKoteiShisanId;
	}

	public String getRrkCod() {
		return rrkCod;
	}

	public void setRrkCod(String rrkCod) {
		this.rrkCod = rrkCod;
	}

	public String getJokyakuSeisanShoNo() {
		return jokyakuSeisanShoNo;
	}

	public void setJokyakuSeisanShoNo(String jokyakuSeisanShoNo) {
		this.jokyakuSeisanShoNo = jokyakuSeisanShoNo;
	}

	public String getKenmeiNm() {
		return kenmeiNm;
	}

	public void setKenmeiNm(String kenmeiNm) {
		this.kenmeiNm = kenmeiNm;
	}

	public String getJokyakuYoteYmd() {
		return jokyakuYoteYmd;
	}

	public void setJokyakuYoteYmd(String jokyakuYoteYmd) {
		this.jokyakuYoteYmd = jokyakuYoteYmd;
	}

	public String getJokyakuYmd() {
		return jokyakuYmd;
	}

	public void setJokyakuYmd(String jokyakuYmd) {
		this.jokyakuYmd = jokyakuYmd;
	}

	public String getShoninStatus() {
		return shoninStatus;
	}

	public void setShoninStatus(String shoninStatus) {
		this.shoninStatus = shoninStatus;
	}

	public String getTekiyo() {
		return tekiyo;
	}

	public void setTekiyo(String tekiyo) {
		this.tekiyo = tekiyo;
	}

	public String getSoshikiRenNm() {
		return soshikiRenNm;
	}

	public void setSoshikiRenNm(String soshikiRenNm) {
		this.soshikiRenNm = soshikiRenNm;
	}

	public String getSeisanSoshikiCd() {
		return seisanSoshikiCd;
	}

	public void setSeisanSoshikiCd(String seisanSoshikiCd) {
		this.seisanSoshikiCd = seisanSoshikiCd;
	}

	public String getSeiMei() {
		return seiMei;
	}

	public void setSeiMei(String seiMei) {
		this.seiMei = seiMei;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getTekiyoStartYmd() {
		return tekiyoStartYmd;
	}

	public void setTekiyoStartYmd(String tekiyoStartYmd) {
		this.tekiyoStartYmd = tekiyoStartYmd;
	}

	public String getNyushaYmd() {
		return nyushaYmd;
	}

	public void setNyushaYmd(String nyushaYmd) {
		this.nyushaYmd = nyushaYmd;
	}

	public String getUpdateDate() {
		return updateDate;
	}

	public void setUpdateDate(String updateDate) {
		this.updateDate = updateDate;
	}

}