package jp.co.nsd.nkssweb.dao.mapper;

import jp.co.nsd.nkssweb.dao.Kss024;
import jp.co.nsd.nkssweb.dao.Kss024Key;

public interface Kss024Mapper {
    int deleteByPrimaryKey(Kss024Key key);

    int insert(Kss024 record);

    int insertSelective(Kss024 record);

    Kss024 selectByPrimaryKey(Kss024Key key);

    int updateByPrimaryKeySelective(Kss024 record);

    int updateByPrimaryKey(Kss024 record);
}