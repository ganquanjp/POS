/***********************************************************************
*
*業務名: 工事精算システム
*機能名: 各参照ボタン用検索処理
*
*機能概要: 各参照ボタン用検索処理
*
*JavaＶｅｒ：J2SE1.8.0準拠
*
*更新履歴: Ver.1.00 2018/03/06　NSD　新規作成
***********************************************************************/

package jp.co.nsd.nkssweb.controller;

import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.beanutils.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import jp.co.nsd.nkssweb.dao.KanriFutanks;
import jp.co.nsd.nkssweb.dao.KoteiSisan;
import jp.co.nsd.nkssweb.dao.SechiBasho;
import jp.co.nsd.nkssweb.dao.TorihikiSaki;
import jp.co.nsd.nkssweb.service.SanshoService;
import jp.co.nsd.nkssweb.utils.NSDCommUtils;
import jp.co.nsd.nkssweb.utils.NSDConstant;

/**
 * 参照ボタン用コントロール
 *
 * @version 1.00
 */
@RestController
public class SanshoController extends BaseController {

	@Autowired
	private SanshoService sanshoService;

	/**
	 * 固定資産（検索）処理
	 *
	 * @param reqMap
	 *            INPUTパラメータ
	 * @return 固定資産情報データ
	 * @version 1.00
	 */
	@RequestMapping(value = "/sansho-koteishisan", method = RequestMethod.POST)
	public Map<String, Object> getKoteiShisan(@RequestParam Map<String, Object> reqMap) throws Exception {

		Map<String, Object> resultMap = new HashMap<String, Object>();

		KoteiSisan koteiSisan = new KoteiSisan();

		List<KoteiSisan> ktssList = new ArrayList<KoteiSisan>();

		// Mapの情報をBeanのプロパティにセット
		BeanUtils.populate(koteiSisan, reqMap);

		// 取得年月日（From）と取得年月日（To）の大小比較チェック
		if (NSDCommUtils.chkDateFromTo(koteiSisan.getGetYmdFrom(), koteiSisan.getGetYmdTo())) {

			// エラーメッセージを返却Mapに設定する
			setMsgToResultMap(resultMap, NSDConstant.MSGID_INPUT_ERROR);

			return resultMap;
		}

		// 使用開始年月日（From）と使用開始年月日（To）の大小比較チェック
		if (NSDCommUtils.chkDateFromTo(koteiSisan.getUseYmdFrom(), koteiSisan.getUseYmdTo())) {

			// エラーメッセージを返却Mapに設定する
			setMsgToResultMap(resultMap, NSDConstant.MSGID_INPUT_ERROR);

			return resultMap;
		}

		// サービス呼び出し
		ktssList = sanshoService.getKoteiSisanInfo(koteiSisan);

		// 検索結果を返却Mapに設定する
		setDataToResultMap(resultMap, ktssList);

		return resultMap;
	}

	/**
	 * 取引先（検索）処理
	 *
	 * @param reqMap
	 * @return
	 */
	@RequestMapping(value = "/sansho-torihikisaki", method = RequestMethod.POST)
	public Map<String, Object> getTorihikiSaki(@RequestParam Map<String, Object> reqMap) throws Exception {

		Map<String, Object> resultMap = new HashMap<String, Object>();

		TorihikiSaki torihikiSaki = new TorihikiSaki();

		List<TorihikiSaki> trhksList = new ArrayList<TorihikiSaki>();

		// Mapの情報をBeanのプロパティにセット
		BeanUtils.populate(torihikiSaki, reqMap);

		// サービス呼び出し
		trhksList = sanshoService.getTorihikiSakiInfo(torihikiSaki);

		// 検索結果を返却Mapに設定する
		setDataToResultMap(resultMap, trhksList);

		return resultMap;
	}

	/**
	 * 管理箇所/負担箇所検索処理
	 *
	 * @param reqMap
	 *            INPUTパラメータ
	 * @return 管理箇所/負担箇所情報データ
	 * @exception IllegalAccessException
	 * @exception InvocationTargetException
	 * @version 1.00
	 */
	@RequestMapping(value = "/sansho-kanrifutanks", method = RequestMethod.POST)
	public Map<String, Object> getKanriFutanks(@RequestParam Map<String, Object> reqMap) throws Exception {

		Map<String, Object> resultMap = new HashMap<String, Object>();

		KanriFutanks kanriFutanks = new KanriFutanks();

		List<KanriFutanks> krftList = new ArrayList<KanriFutanks>();

		// Mapの情報をBeanのプロパティにセット
		BeanUtils.populate(kanriFutanks, reqMap);

		// サービス呼び出し
		krftList = sanshoService.getKanriFutanInfo(kanriFutanks);

		// 検索結果を返却Mapに設定する
		setDataToResultMap(resultMap, krftList);

		return resultMap;
	}

	/**
	 * 設置場所（検索）処理
	 *
	 * @param reqMap
	 * @return
	 */
	@RequestMapping(value = "/sansho-sechibasho", method = RequestMethod.POST)
	public Map<String, Object> getSechiBasho(@RequestParam Map<String, Object> reqMap) throws Exception {

		Map<String, Object> resultMap = new HashMap<String, Object>();

		SechiBasho sechiBasho = new SechiBasho();

		List<SechiBasho> scbsList = new ArrayList<SechiBasho>();

		// Mapの情報をBeanのプロパティにセット
		BeanUtils.populate(sechiBasho, reqMap);

		// サービス呼び出し
		scbsList = sanshoService.getSechiBashoInfo(sechiBasho);

		// 検索結果を返却Mapに設定する
		setDataToResultMap(resultMap, scbsList);

		return resultMap;
	}

}
