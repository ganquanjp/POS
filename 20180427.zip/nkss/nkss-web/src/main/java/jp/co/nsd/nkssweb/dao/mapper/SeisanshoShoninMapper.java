package jp.co.nsd.nkssweb.dao.mapper;

import java.util.List;

import jp.co.nsd.nkssweb.dao.SeisanshoShonin;
import jp.co.nsd.nkssweb.dao.SeisanshoShoninShokai;

public interface SeisanshoShoninMapper {
	/**
	 * 取得情報取得（検索画面）
	 *
	 * @param seisanshoShonin
	 *            INPUTパラメータ
	 * @return　検索結果
	 */
    List<SeisanshoShonin> selectByWhere(SeisanshoShonin record);

	/**
	 * 取得情報取得（照会画面）
	 *
	 * @param seisanshoJokyakuShokai
	 *            INPUTパラメータ
	 * @return　検索結果
	 */
	List<SeisanshoShoninShokai> selectBySeisanShoNo(SeisanshoShoninShokai seisanshoShoninShokai);

}