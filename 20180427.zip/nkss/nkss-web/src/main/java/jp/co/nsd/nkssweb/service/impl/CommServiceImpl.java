/***********************************************************************
*
*業務名: システム共通処理
*機能名: システム共通処理(サービス処理)
*
*機能概要: システム共通処理
*
*JavaＶｅｒ：J2SE1.8.0準拠
*
*更新履歴: Ver.1.00 2018/03/06　NSD　新規作成
***********************************************************************/
package jp.co.nsd.nkssweb.service.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import jp.co.nsd.nkssweb.dao.Abda09;
import jp.co.nsd.nkssweb.dao.Awda01;
import jp.co.nsd.nkssweb.dao.Awda02;
import jp.co.nsd.nkssweb.dao.Awda03;
import jp.co.nsd.nkssweb.dao.Awda04;
import jp.co.nsd.nkssweb.dao.Awda05;
import jp.co.nsd.nkssweb.dao.Awda06;
import jp.co.nsd.nkssweb.dao.Awda15;
import jp.co.nsd.nkssweb.dao.Awda20;
import jp.co.nsd.nkssweb.dao.CodeShubetsu;
import jp.co.nsd.nkssweb.dao.Kss016;
import jp.co.nsd.nkssweb.dao.mapper.CommMapper;
import jp.co.nsd.nkssweb.service.CommService;
import jp.co.nsd.nkssweb.utils.NSDConstant;

/**
 * 共通処理用サービス
 *
 * @see CommService
 * @version 1.00
 */
@Service
public class CommServiceImpl implements CommService {

	@Autowired
	private CommMapper commMapper;

	public String getSequence(String seqId) {

		Map<String, Object> seqMap = new HashMap<>();
		seqMap.put("seqId", seqId);
		seqMap.put("seqLen", NSDConstant.SEQ_LEN_MAP.get(seqId));

		// 採番処理サービス呼び出し
		return commMapper.getSequence(seqMap);
	}


	/**
	 * 条件よりコードマスタにコード情報を取得
	 *
	 * @param codeShubetsu
	 * @return
	 * @version 1.00
	 */
	@Override
	public List<Kss016> getCodeShubetsuList(CodeShubetsu codeShubetsu) {
		return commMapper.getCodeShubetsuList(codeShubetsu);
	}

	/**
	 * 条件よりパワー経理の発行組織を取得
	 *
	 * @param abda09
	 * @return
	 */
	@Override
	public List<Abda09> getHakouSoshiki(Abda09 abda09) {
		return commMapper.getHakouSoshiki(abda09);
	}

	/**
	 * 条件より種類を取得
	 *
	 * @param awda01
	 * @return
	 */
	@Override
	public List<Awda01> getShuNmLst(Awda01 awda01) {
		return commMapper.getShuNmLst(awda01);
	}

	/**
	 * 条件より構造を取得
	 *
	 * @param awda02
	 * @return
	 */
	@Override
	public List<Awda02> getKouNmLst(Awda02 awda02) {
		return commMapper.getKouNmLst(awda02);
	}

	/**
	 * 条件より細目を取得
	 *
	 * @param awda03
	 * @return
	 */
	@Override
	public List<Awda03> getSaiNmLst(Awda03 awda03) {
		return commMapper.getSaiNmLst(awda03);
	}

	/**
	 * 条件より種別４を取得
	 *
	 * @param awda04
	 * @return
	 */
	@Override
	public List<Awda04> getShu4NmLst(Awda04 awda04) {
		return commMapper.getShu4NmLst(awda04);
	}

	/**
	 * 条件より種別５を取得
	 *
	 * @param awda05
	 * @return
	 */
	@Override
	public List<Awda05> getShu5NmLst(Awda05 awda05) {
		return commMapper.getShu5NmLst(awda05);
	}

	/**
	 * 条件より種別６を取得
	 *
	 * @param awda06
	 * @return
	 */
	@Override
	public List<Awda06> getShu6NmLst(Awda06 awda06) {
		return commMapper.getShu6NmLst(awda06);
	}

	/**
	 * 条件より単位を取得
	 *
	 * @param awda15
	 * @return
	 */
	@Override
	public List<Awda15> getTaniLst(Awda15 awda15) {
		return commMapper.getTaniLst(awda15);
	}

	/**
	 * 条件より名称定数を取得
	 *
	 * @param awda20
	 * @return
	 */
	@Override
	public List<Awda20> getMeiShouLst(Awda20 awda20) {
		return commMapper.getMeiShouLst(awda20);
	}
}
