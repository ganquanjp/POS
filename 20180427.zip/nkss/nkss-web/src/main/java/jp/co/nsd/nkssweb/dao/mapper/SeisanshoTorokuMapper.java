package jp.co.nsd.nkssweb.dao.mapper;

import java.util.List;
import java.util.Map;

import jp.co.nsd.nkssweb.dao.Kss002Key;
import jp.co.nsd.nkssweb.dao.Kss004Key;
import jp.co.nsd.nkssweb.dao.Kss005Key;
import jp.co.nsd.nkssweb.dao.SeisanshoToroku;

public interface SeisanshoTorokuMapper {

    List<SeisanshoToroku> selectByWhere(SeisanshoToroku record);

    List<SeisanshoToroku> selectByKey(SeisanshoToroku record);

    /**
     * 除却情報取得（削除）
     *
     * @param key
     *            INPUTパラメータ
     * @return　検索結果
     */
    int deleteKenMeByPyKey(Kss002Key key);

    /**
     * 除却情報取得（削除）
     *
     * @param key
     *            INPUTパラメータ
     * @return　検索結果
     */
    int deleteByPyKey(Kss004Key key);


    /**
     * 除却情報取得（削除）
     *
     * @param key
     *            INPUTパラメータ
     * @return　検索結果
     */
    int deletemesaiByPyKey(Kss005Key key);

    String selectRenkeiStatus(Map<String, Object> selectMap);

    String selectShoninStatus(Map<String, Object> selectMap);

    String selectConut(Map<String, Object> selectMap);

}