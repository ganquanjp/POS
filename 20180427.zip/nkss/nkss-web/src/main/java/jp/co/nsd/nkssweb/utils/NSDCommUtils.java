package jp.co.nsd.nkssweb.utils;

import java.io.UnsupportedEncodingException;
import java.sql.Date;
import java.text.DateFormat;

import org.apache.commons.lang.StringUtils;

/**
 * システム共通ユーティリティ
 *
 * @author nsdH272059
 *
 */
public final class NSDCommUtils {

	/**
	 * 日付From-To大小比較チェック
	 *
	 * @param dateFrom
	 *            String
	 * @param dateTo
	 *            String
	 * @return boolean
	 */
	public static boolean chkDateFromTo(String dateFrom, String dateTo) {

		// 開始年月日（From）と終了年月日（To）存在の場合
		if (StringUtils.isNotEmpty(dateFrom) && StringUtils.isNotEmpty(dateTo)) {
			// 開始年月日（From）と終了年月日（To）の大小比較チェック
			if (Date.valueOf(dateFrom).compareTo(Date.valueOf(dateTo)) == 1) {
				return true;
			}
		}
		return false;
	}

	/**
	 * NULL値は空文字に変換する。
	 *
	 * @param str
	 *            String
	 * @return 空文字
	 */
	public static String nullToBlankStr(String str) {

		if (null == str) {
			str = NSDConstant.BLANK_STRING;
		}
		return str;
	}

	/**
	 * 文字列エンコードはISO-8859-1からUTF-8に変換する。
	 *
	 * @param str
	 * @return
	 * @throws UnsupportedEncodingException
	 */
	public static String converISO8859ToUTF8(String str) throws UnsupportedEncodingException {

		String resultStr = new String();

		resultStr = new String(str.getBytes("ISO-8859-1"), "UTF-8");

		return resultStr;
	}

	/**
	 * 日付の妥当性チェック
	 *
	 * @param in_Date
	 *            チェック対象の日付文字列："yyyy-mm-dd" or "yyyy/mm/dd"
	 *
	 * @return 存在する日付：True 存在しない日付：False
	 */
	public static boolean checkDate(String in_Date) {
		String wk_Date = in_Date.replace('-', '/');
		if (wk_Date.length() != 10)
			return false;
		DateFormat format = DateFormat.getDateInstance();
		format.setLenient(false);
		try {
			format.parse(wk_Date);
			return true;
		} catch (Exception e) {
			return false;
		}
	}

	public static String setKakoToStr(String str){
		return NSDConstant.STRING_KAKO_H.concat(str).concat(NSDConstant.STRING_KAKO_M);
	}
}
