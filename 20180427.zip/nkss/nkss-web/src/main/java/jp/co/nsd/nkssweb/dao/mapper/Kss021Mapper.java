package jp.co.nsd.nkssweb.dao.mapper;

import jp.co.nsd.nkssweb.dao.Kss021;

public interface Kss021Mapper {
    int deleteByPrimaryKey(String menuId);

    int insert(Kss021 record);

    int insertSelective(Kss021 record);

    Kss021 selectByPrimaryKey(String menuId);

    int updateByPrimaryKeySelective(Kss021 record);

    int updateByPrimaryKey(Kss021 record);
}