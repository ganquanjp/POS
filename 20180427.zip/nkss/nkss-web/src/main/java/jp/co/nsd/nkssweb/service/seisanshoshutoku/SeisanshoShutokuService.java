package jp.co.nsd.nkssweb.service.seisanshoshutoku;

import java.util.List;

import jp.co.nsd.nkssweb.dao.Kss005;
import jp.co.nsd.nkssweb.dao.SeisanshoShutokuKensaku;
import jp.co.nsd.nkssweb.dao.SeisanshoShutokuShokai;

public interface SeisanshoShutokuService {

	/**
	 * 精算書取得・検索
	 *
	 * @param selectCondition
	 * @return
	 */
	List<SeisanshoShutokuKensaku> getSeisanshoShutokuKensaku(SeisanshoShutokuKensaku selectCondition);

	/**
	 * 精算書取得・照会
	 *
	 * @param selectCondition
	 * @return
	 */
	List<SeisanshoShutokuShokai> getSeisanshoShutokuShokai(SeisanshoShutokuShokai selectCondition);

	/**
	 * 精算書取得・削除
	 *
	 * @param seisanShoId
	 *            INPUTパラメータ
	 * @param koteiShisanId
	 *            INPUTパラメータ
	 * @return 削除件数
	 */
	int delByPyKey(String seisanShoId, String koteiShisanId);

	/**
	 * 精算書取得・新規
	 *
	 * @param record
	 * @param shuruiInfo
	 * @throws Exception
	 */
	void insert(Kss005 record, Kss005 shuruiInfo) throws Exception;
}
