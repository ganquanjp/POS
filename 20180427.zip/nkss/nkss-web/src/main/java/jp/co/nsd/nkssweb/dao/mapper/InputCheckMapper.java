package jp.co.nsd.nkssweb.dao.mapper;

import java.util.List;

import jp.co.nsd.nkssweb.dao.Kss011;

public interface InputCheckMapper {

	/**
	 * 組織連結名で組織マスタを検索、データ存在の確認
	 *
	 * @param soshikiRenNm 組織連結名
	 * @return
	 */
	List<Kss011> getSoshikiInfoForInputCheck(String soshikiRenNm);

}