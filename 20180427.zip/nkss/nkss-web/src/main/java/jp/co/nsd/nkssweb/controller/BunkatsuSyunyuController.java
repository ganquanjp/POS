package jp.co.nsd.nkssweb.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.beanutils.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import jp.co.nsd.nkssweb.dao.BunkatsuSyunyu;
import jp.co.nsd.nkssweb.service.BunkatsuSyunyuService;
import jp.co.nsd.nkssweb.service.SystemService;
import jp.co.nsd.nkssweb.utils.NSDCommUtils;
import jp.co.nsd.nkssweb.utils.NSDConstant;

@RestController
public class BunkatsuSyunyuController extends BaseController {

	@Autowired
	private BunkatsuSyunyuService bunkatsuSyunyuService;

	protected SystemService systemService;

	/*
	 * 分割収入経理審査/連携（検索）画面から
	 *
	 * @param reqMap INPUTパラメータ
	 *
	 * @return 除却情報データ
	 *
	 * @exception IllegalAccessException
	 *
	 * @exception InvocationTargetException
	 *
	 * @version 1.00
	 */
	@RequestMapping(value = "/bunkatsuSyunyu-selectByWhere", method = RequestMethod.POST)
	public Map<String, Object> selectByWhere(@RequestParam Map<String, Object> reqMap) throws Exception {

		BunkatsuSyunyu bunkatsuSyunyu = new BunkatsuSyunyu();

		Map<String, Object> resultMap = new HashMap<String, Object>();

		List<BunkatsuSyunyu> bsLst = new ArrayList<>();
		// Mapの情報をBeanのプロパティにセット
		BeanUtils.populate(bunkatsuSyunyu, reqMap);

		// 除却予定年月日（From）と除却予定年月日（To）の大小比較チェック
		if (NSDCommUtils.chkDateFromTo(bunkatsuSyunyu.getServiceStartYmdF(), bunkatsuSyunyu.getServiceStartYmdT())) {
			// エラーメッセージを返却Mapに設定する
			return setMsgToResultMap(resultMap, NSDConstant.MSGID_INPUT_ERROR);
		}

		bsLst = bunkatsuSyunyuService.getBunkatsuInfo(bunkatsuSyunyu);

		// 検索結果を返却Mapに設定する
		return setDataToResultMap(resultMap, bsLst);

	}

}
