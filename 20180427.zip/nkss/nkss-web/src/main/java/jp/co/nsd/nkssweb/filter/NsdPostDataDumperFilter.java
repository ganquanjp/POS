package jp.co.nsd.nkssweb.filter;

import java.io.IOException;
import java.util.Enumeration;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@WebFilter(filterName = "post-data-dumper-filter", urlPatterns = "/*")
public final class NsdPostDataDumperFilter implements Filter {

    Logger logger = LoggerFactory.getLogger(getClass());

    private FilterConfig filterConfig = null;

    public void destroy() {
        this.filterConfig = null;
    }

    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
            throws IOException, ServletException {
        if (filterConfig == null)
            return;

        HttpServletRequest httpRequest= (HttpServletRequest)request;
        httpRequest.getSession().getId();
        HttpServletResponse  httpResponse = (HttpServletResponse)response;
        Enumeration<String> names = httpRequest.getParameterNames();
        StringBuilder output = new StringBuilder();
        while (names.hasMoreElements()) {
            String name = (String) names.nextElement();
            output.append(name).append("=");
            String values[] = httpRequest.getParameterValues(name);
            for (int i = 0; i < values.length; i++) {
                if (i > 0) {
                    output.append("' ");
                }

                output.append(values[i]);
            }
            if (names.hasMoreElements())
                output.append("&");
        }
        httpRequest.setAttribute("postdata", output);
        logger.debug("postdata: " + output);
        chain.doFilter(httpRequest, httpResponse);
    }

    public void init(FilterConfig filterConfig) throws ServletException {
        this.filterConfig = filterConfig;
    }
}
