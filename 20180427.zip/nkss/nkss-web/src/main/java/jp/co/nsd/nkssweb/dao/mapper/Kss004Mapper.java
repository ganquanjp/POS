package jp.co.nsd.nkssweb.dao.mapper;

import jp.co.nsd.nkssweb.dao.Kss004;
import jp.co.nsd.nkssweb.dao.Kss004Key;

public interface Kss004Mapper {
    int deleteByPrimaryKey(Kss004Key key);

    int insert(Kss004 record);

    int insertSelective(Kss004 record);

    Kss004 selectByPrimaryKey(Kss004Key key);

    int updateByPrimaryKeySelective(Kss004 record);

    int updateByPrimaryKey(Kss004 record);
}