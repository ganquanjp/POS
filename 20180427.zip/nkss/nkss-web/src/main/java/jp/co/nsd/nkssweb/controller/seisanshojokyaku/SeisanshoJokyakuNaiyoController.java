/***********************************************************************
*
*業務名: 工事精算システム
*機能名: 除却（内容入力）(ログ出力処理)
*
*機能概要: 除却情報を処理する。
*
*JavaＶｅｒ：J2SE1.8.0準拠
*
*更新履歴: Ver.1.00 2018/03/06　NSD　新規作成
***********************************************************************/

package jp.co.nsd.nkssweb.controller.seisanshojokyaku;

import java.math.BigDecimal;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.beanutils.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import jp.co.nsd.nkssweb.controller.BaseController;
import jp.co.nsd.nkssweb.dao.Kss007;
import jp.co.nsd.nkssweb.dao.SeisanshoJokyakuNaiyo;
import jp.co.nsd.nkssweb.dao.SeisanshoJokyakuNaiyoShokai;
import jp.co.nsd.nkssweb.service.seisanshojokyaku.SeisanshoJokyakuNaiyoService;
import jp.co.nsd.nkssweb.utils.NSDCommUtils;
import jp.co.nsd.nkssweb.utils.NSDConstant;

/**
 * 除却（内容入力）処理
 *
 * @version 1.00
 */
@RestController
public class SeisanshoJokyakuNaiyoController extends BaseController {

	@Autowired
	private SeisanshoJokyakuNaiyoService seisanshoJokyakuNaiyoService;

	/**
	 * 除却（内容入力）検索処理
	 *
	 * @param reqMap
	 *            INPUTパラメータ
	 * @return 除却情報データ
	 * @throws ParseException
	 * @version 1.00
	 */
	@RequestMapping(value = "/seisanshoJokyakuNaiyo-selectByWhere", method = RequestMethod.POST)
	public Map<String, Object> selectByWhere(@RequestParam Map<String, Object> reqMap) throws Exception {

		Map<String, Object> resultMap = new HashMap<String, Object>();

		SeisanshoJokyakuNaiyo seisanshoJokyakuNaiyo = new SeisanshoJokyakuNaiyo();

		List<SeisanshoJokyakuNaiyo> sssJkkNyLst = new ArrayList<>();

		// Mapの情報をBeanのプロパティにセット
		BeanUtils.populate(seisanshoJokyakuNaiyo, reqMap);

		// 除却予定年月日（From）と除却予定年月日（To）の大小比較チェック
		if (NSDCommUtils.chkDateFromTo(seisanshoJokyakuNaiyo.getJokyakuYoteYmdFrom(),
				seisanshoJokyakuNaiyo.getJokyakuYoteYmdTo())) {

			// エラーメッセージを返却Mapに設定する
			return setMsgToResultMap(resultMap, NSDConstant.MSGID_INPUT_ERROR);

		}

		// サービス呼び出し
		sssJkkNyLst = seisanshoJokyakuNaiyoService.getJokyakuNaiyoInfo(seisanshoJokyakuNaiyo);

		// 検索結果を返却Mapに設定する
		return setDataToResultMap(resultMap, sssJkkNyLst);

	}

	/**
	 * 除却（内容入力）照会処理
	 *
	 * @param reqMap
	 *            INPUTパラメータ
	 * @return 除却情報データ
	 * @throws Exception
	 * @version 1.00
	 */
	@RequestMapping(value = "/seisanshoJokyakuNaiyo-selectBySeisanShoNo", method = RequestMethod.POST)
	public Map<String, Object> selectBySeisanShoNo(@RequestParam Map<String, Object> reqMap) throws Exception {

		Map<String, Object> resultMap = new HashMap<String, Object>();

		SeisanshoJokyakuNaiyoShokai seisanshoJokyakuNaiyoShokai = new SeisanshoJokyakuNaiyoShokai();

		// Mapの情報をBeanのプロパティにセット
		BeanUtils.populate(seisanshoJokyakuNaiyoShokai, reqMap);

		// サービス呼び出し
		SeisanshoJokyakuNaiyoShokai sssJkkNySkDto = seisanshoJokyakuNaiyoService
				.getJokyakuInfoBySeisanShoNo(seisanshoJokyakuNaiyoShokai);

		// 検索結果を返却Mapに設定する
		return setDataToResultMap(resultMap, sssJkkNySkDto);
	}

	/**
	 * 除却内容入力（更新）処理
	 *
	 * @param reqMap
	 *            INPUTパラメータ
	 * @throws Exception
	 * @version 1.00
	 */
	@RequestMapping(value = "/seisanshoJokyakuNaiyo-updateInfo", method = RequestMethod.POST)
	public Map<String, Object> updateInfo(HttpServletRequest request, @RequestParam Map<String, Object> reqMap) throws Exception {

		Map<String, Object> resultMap = new HashMap<String, Object>();

		// 除却資産明細件数
		Set<String> set = new HashSet<String>();
		for (Entry<String, Object> entry : reqMap.entrySet()) {
			System.out.println(entry.getKey());
			String[] record = entry.getKey().replace("[", ",").replace("]", "").split(",");
			if (record.length == 3) {
				set.add(record[1]);
			}
		}
		Date date = new Date();
		List<Kss007> kss007UpdLst = new ArrayList<Kss007>();
		// 除却資産明細情報を取得
		for (int i = 0; i < set.size(); i++) {
			// MapKey
			String key;
			Kss007 kss007 = new Kss007();
			// 固定資産IDKEY
			key = "koteiSisanLst".concat("[" + i + "]").concat("[koteiCod]");
			kss007.setMotoKoteiShisanId((String) reqMap.get(key));
			// 履歴IDKEY
			key = "koteiSisanLst".concat("[" + i + "]").concat("[rrkCod]");
			kss007.setRirekiNo((String) reqMap.get(key));
			// 除却精算書IDKEY
			key = "koteiSisanLst".concat("[" + i + "]").concat("[jokyakuSeisanShoId]");
			kss007.setJokyakuSeisanShoId((String) reqMap.get(key));
			// 除却資産IDKEY
			key = "koteiSisanLst".concat("[" + i + "]").concat("[jokyakuShisanId]");
			kss007.setJokyakuShisanId((String) reqMap.get(key));
			// 除却種別コードKEY
			key = "koteiSisanLst".concat("[" + i + "]").concat("[jokyakuShubetsuCd]");
			kss007.setJokyakuShubetsuCd((String) reqMap.get(key));
			// 除却区分コードKEY
			key = "koteiSisanLst".concat("[" + i + "]").concat("[jokyakuKbn]");
			kss007.setJokyakuKbn((String) reqMap.get(key));
			// 除＿数量KEY
			key = "koteiSisanLst".concat("[" + i + "]").concat("[jokyakuSuryo]");
			kss007.setJokyakuSuryo(new BigDecimal((String) reqMap.get(key)));
			// 除＿取得価額KEY
			key = "koteiSisanLst".concat("[" + i + "]").concat("[jokyakuGaku]");
			kss007.setJokyakuGaku(Long.parseLong((String) reqMap.get(key)));

			// 残＿数量は元＿数量から除却数量を減算し残数量を算出します。
			kss007.setJokyakuSuryo(new BigDecimal((String) reqMap.get(key)).divide(kss007.getJokyakuSuryo()));
			// 更新年月日
			kss007.setUpdateDate(date);
			// 更新ユーザーＩＤ
			kss007.setUpdateUserId(this.getLoginUserInfo(request).getUserId());

			kss007UpdLst.add(kss007);
		}

		// サービス呼び出し
		seisanshoJokyakuNaiyoService.updateInfo(kss007UpdLst);

		// 処理結果データ
		resultMap.put(NSDConstant.RESULT_DATA_NAME, "");

		return setMsgToResultMapNoLog(resultMap, NSDConstant.MSGID_UPDATE_SUCCES);
	}
}
