package jp.co.nsd.nkssweb.utils;

import java.util.HashMap;
import java.util.Map;

public class NSDConstant {

	// 空文字
	public static final String BLANK_STRING = "";

	// ハイフン
	public static final String STRING_HAIFUN = "-";

	// 文字(,)
	public static final String STRING_KANMA = ",";

	// 文字(()
	public static final String STRING_KAKO_H = "(";

	// 文字())
	public static final String STRING_KAKO_M = ")";

	// 文字(0)
	public static final String STRING_0 = "0";
	// 文字(1)
	public static final String STRING_1 = "1";
	// 文字(2)
	public static final String STRING_2 = "2";
	// 文字(3)
	public static final String STRING_3 = "3";
	// 文字(4)
	public static final String STRING_4 = "4";
	// 文字(5)
	public static final String STRING_5 = "5";
	// 文字(6)
	public static final String STRING_6 = "6";
	// 文字(7)
	public static final String STRING_7 = "7";
	// 文字(8)
	public static final String STRING_8 = "8";
	// 文字(9)
	public static final String STRING_9 = "9";

	// 文字(\\)
	public static final String STRING_FUGO = "\\";

	// 文字(A9999)
	public static final String STRING_A9999 = "A9999";

	// 日本語文字コード
	public static final String SHIFT_JIS = "Shift_JIS";

	// フォント名
	public static final String STRING_FONT_NAME = "ＭＳ ゴシック";

	// 整数用のスタイル
	public static final String STRING_FORMAT = "#,##0;-#,##0";

	// 文字(100000000000001)
	public static final String STRING_100000000000001 = "100000000000001";

	// ファイル出力パス
	public static final String STRING_FILE_PATH = "D:\\";

	// CSVファイル名前
	public static final String STRING_FILE_NAME = "_kenmei.csv";

	// クラス名前（KoteshisanDaityoBatch）
	public static final String BATCH_CLASS_NAME_KOTESHISANDAITYO = "KoteshisanDaityoBatch";

	// クラス名前（SeisanshoTorokuKmskJheBatch）
	public static final String BATCH_CLASS_NAME_KENMEISOKUJIHANE = "SeisanshoTorokuKmskJheBatch";

	// EXCELファイル名前
	public static final String STRING_EXCEL_FILE_NAME = "-N_koteisisan.xlsx";

	// ディフォルト終了日
	public static final String DEFAULT_END_DATE = "2099-12-31";
	// 年月日フォマート
	public static final String STRING_YYYYMMDD = "yyyyMMdd";

	// 件名ID
	public static final String STRING_KENMEI_ID = "件名ID";

	// 件名コード
	public static final String STRING_KENMEI_CD = "件名コード";

	// 件名
	public static final String STRING_KENMEI = "件名";

	// 登録年月日
	public static final String STRING_TOROKU_YMD = "登録年月日";

	// 登録年氏名
	public static final String STRING_TOROKU_NAME = "登録者氏名";

	// 更新年月日
	public static final String STRING_KOSIN_YMD = "更新年月日";

	// 更新者氏名
	public static final String STRING_KOSIN_NAME = "更新者氏名";

	// 連携ステータス
	public static final String STRING_RENKEI_STATUS = "連携ステータス";

	// NO
	public static final String STRING_NO = "No.";

	// 工事件名
	public static final String STRING_KOJIKENMEI = "工事件名";

	// 精算書番号
	public static final String STRING_SEISAN_NO = "精算書番号";

	// 使用開始年月日
	public static final String STRING_START_YMD = "使用開始年月日";

	// 取得年月日
	public static final String STRING_GET_YMD = "取得年月日";

	// 固定資産番号
	public static final String STRING_KOTEI_NO = "固定資産番号";

	// 親固定資産番号
	public static final String STRING_OYAKOTEI_NO = "親固定資産番号";

	// 枝番
	public static final String STRING_EDABAN = "枝番";

	// 固定資産名称
	public static final String STRING_KOTEI_NAME = "固定資産名称";

	// 種類
	public static final String STRING_SHURUI = "種類";

	// 構造
	public static final String STRING_KOZO = "構造";

	// 資産単位
	public static final String STRING_SISANTANI = "資産単位";

	// 科目１
	public static final String STRING_KAMOKU1 = "科目１";

	// 科目２
	public static final String STRING_KAMOKU2 = "科目２";

	// 科目３
	public static final String STRING_KAMOKU3 = "科目３";

	// 取引先
	public static final String STRING_TORIHIKISAKI = "取引先";

	// 法定耐用年数
	public static final String STRING_HOTEI_TAIYO_YS = "法定耐用年数";

	// 残存耐用年数
	public static final String STRING_ZANZON_TAIYO_YS = "残存耐用年数";

	// 償却方法
	public static final String STRING_SYOKYAKU_HOHO = "償却方法";

	// 償却率
	public static final String STRING_SYOKYAKURITU = "償却率";

	// 物品
	public static final String STRING_BUTUHIN = "物品";

	// 工費
	public static final String STRING_KOBI = "工費";

	// 総係費
	public static final String STRING_SOKOBI = "総係費";

	// 取得価額
	public static final String STRING_GET_KAGAKU = "取得価額";

	// 前年度末簿価
	public static final String STRING_ZENNENDOMATU_KAGAKU = "前年度末簿価";

	// 当期償却額（予定）
	public static final String STRING_TOKISYOKYAKU_YOTEI = "当期償却額（予定）";

	// （差引）年度末簿価
	public static final String STRING_SB_NENDOMATU_KAGAKU = "（差引）年度末簿価";

	// 物品数量
	public static final String STRING_BUTUHIN_SURYO = "物品数量";

	// 単位名称
	public static final String STRING_TANI_NAME = "単位名称";

	// 管理箇所
	public static final String STRING_KANRI_KASYO = "管理箇所";

	// 負担箇所
	public static final String STRING_FUTAN_KASYO = "負担箇所";

	// 設置場所
	public static final String STRING_SETI_BASYO = "設置場所";

	// 製品名/型番/製品会社名称
	public static final String STRING_SE_KATA_NAME = "製品名/型番/製品会社名称";

	// 摘要１
	public static final String STRING_TEKIYO1 = "摘要１";

	// 摘要２
	public static final String STRING_TEKIYO2 = "摘要２";

	// 摘要３
	public static final String STRING_TEKIYO3 = "摘要３";

	// 摘要４
	public static final String STRING_TEKIYO4 = "摘要４";

	// 摘要５
	public static final String STRING_TEKIYO5 = "摘要５";

	// 旧資産コード
	public static final String STRING_KSISAN_CD = "旧資産コード";

	// 工事担当箇所
	public static final String STRING_KJ_TANTO_KASYO = "工事担当箇所";

	// 工事担当者
	public static final String STRING_KJ_TANTO_SYA = "工事担当者";

	// 会計整理年月
	public static final String STRING_KK_SEIRI_YMD = "会計整理年月";

	// 分割元固定資産番号
	public static final String STRING_BKM_KOTEISISAN_NO = "分割元固定資産番号";

	// 除却年月日
	public static final String STRING_JKYAKU_YMD = "除却年月日";

	// 新旧償却区分
	public static final String STRING_SK_SKYAKU_KUBUN = "新旧償却区分";

	// 残存価額
	public static final String STRING_ZANZON_KAGAKU = "残存価額";

	// 法定耐用年数（税法）
	public static final String STRING_HT_NAIYO_NENSU = "法定耐用年数（税法）";

	// 残存耐用年数（税法）
	public static final String STRING_ZZ_NAIYO_NENSU = "残存耐用年数（税法）";

	// 前年度末簿価（税法）
	public static final String STRING_MNDM_KAGAKU = "前年度末簿価（税法）";

	// 当期償却額（税法）
	public static final String STRING_TK_SYOKYSKU_GAKU = "当期償却額（税法）";

	// 年度末簿価（税法）
	public static final String STRING_NENDOMATU_GAKU = "年度末簿価（税法）";

	// 申告先名称
	public static final String STRING_SINKOSAKI_NAME = "申告先名称";

	// 申告種類
	public static final String STRING_SINKO_SYURUI = "申告種類";

	// 年始前年評価額
	public static final String STRING_NSZN_GAKU = "年始前年評価額";

	// 年始現在評価額
	public static final String STRING_NSGZ_GAKU = "年始現在評価額";

	// 返却データリスト対象名
	public static final String RESULT_DATA_NAME = "resultData";

	// 返却メッセージ対象名
	public static final String RESULT_MSG_NAME = "msg";

	// 承認状態コード(00:登録中)
	public static final String SHONIN_STATUS_CODE_TOROKU = "00";

	// 承認状態コード(01:承認済(経理提出))
	public static final String SHONIN_STATUS_CODE_TEISHUTSU = "01";

	// 承認状態コード(02:経理審査済)
	public static final String SHONIN_STATUS_CODE_SHINSA = "02";

	// 承認状態コード(03:除却済)
	public static final String SHONIN_STATUS_CODE_JYOKYA = "03";

	// 承認状態コード(20:経理審査否認)
	public static final String SHONIN_STATUS_CODE_HININ = "20";

	// 承認状態名称(00:登録中)
	public static final String SHONIN_STATUS_NAME_TOROKU = "登録中";

	// 承認状態名称(01:承認済(経理提出))
	public static final String SHONIN_STATUS_NAME_TEISHUTSU = "承認済(経理提出)";

	// 承認状態名称(02:データ連係済)
	public static final String SHONIN_STATUS_NAME_SHINSA = "データ連係済";

	// 承認状態名称(03:除却済)
	public static final String SHONIN_STATUS_NAME_JYOKYA = "除却済";

	// 承認状態名称(20:経理審査否認)
	public static final String SHONIN_STATUS_NAME_HININ = "経理審査否認";

	// 除却種別(1:売却)
	public static final String SHUBETU_CD_BAIKYAKU = "1";

	// 除却種別(2:滅失)
	public static final String SHUBETU_CD_MESISTU = "2";

	// 除却種別(4:その他)
	public static final String SHUBETU_CD_SONOTA = "4";

	// 除却精算制御区分(0)
	public static final String JYOKYAKU_SEISAN_SEIGYO_0 = "0";

	// 除却精算制御区分(1)
	public static final String JYOKYAKU_SEISAN_SEIGYO_1 = "1";

	/**
	 * 承認状態コードより承認状態名称を取得する
	 *
	 * @param statusCode
	 * @return
	 */
	public static String getShoninStatus(String statusCode) {

		String resultStr = "";

		if (SHONIN_STATUS_CODE_TOROKU.equals(statusCode)) {
			// 00:登録中
			resultStr = SHONIN_STATUS_NAME_TOROKU;

		} else if (SHONIN_STATUS_CODE_TEISHUTSU.equals(statusCode)) {
			// 01:承認済(経理提出)
			resultStr = SHONIN_STATUS_NAME_TEISHUTSU;

		} else if (SHONIN_STATUS_CODE_SHINSA.equals(statusCode)) {
			// 02:データ連係済
			resultStr = SHONIN_STATUS_NAME_SHINSA;

		} else if (SHONIN_STATUS_CODE_JYOKYA.equals(statusCode)) {
			// 03:除却済
			resultStr = SHONIN_STATUS_NAME_JYOKYA;

		} else if (SHONIN_STATUS_CODE_HININ.equals(statusCode)) {
			// 20:経理審査否認
			resultStr = SHONIN_STATUS_NAME_HININ;

		} else {
			// 処理なし
		}
		return resultStr;
	}

	// 0:未連携
	public static final String MIRENKEI = "未連携";

	// 1:連携済
	public static final String RENKEIZUMI = "連携済";

	// 9：対象外
	public static final String TAISYOGAI = "対象外";

	// 子資産区分(無)
	public static final String NASI = "無";

	// 子資産区分(有)
	public static final String ARI = "有";

	// 除却区分(0：全部除却)
	public static final String JOKYAKU_KBN_0 = "全部除却";

	// 除却区分(1：一部除却)
	public static final String JOKYAKU_KBN_1 = "一部除却";

	// ロール（0001：システム管理者）
	public static final String ROLE_SYSTEM = "0001";

	// ロール（0002：経理）
	public static final String ROLE_MANAGER = "0002";

	// ロール（0003：その他）
	public static final String ROLE_OTHER = "0003";

	// KSS020-G010
	public static final String KSS020_G010 = "KSS020-G010";

	// KSS020-G060
	public static final String KSS020_G060 = "KSS020-G060";

	// KSS020-G120
	public static final String KSS020_G120 = "KSS020-G120";

	// KSS030-G010
	public static final String KSS030_G010 = "KSS030-G010";

	// KSS030-G040
	public static final String KSS030_G040 = "KSS030-G040";

	// KSS031-G010
	public static final String KSS031_G010 = "KSS031-G010";

	// KSS032-G010
	public static final String KSS032_G010 = "KSS032-G010";

	// KSS040-G010
	public static final String KSS040_G010 = "KSS040-G010";

	// KSS040-G040
	public static final String KSS040_G040 = "KSS040-G040";

	// KSS041-G010
	public static final String KSS041_G010 = "KSS041-G010";

	// KSS042-G010
	public static final String KSS042_G010 = "KSS042-G010";

	// KSS043-G010
	public static final String KSS043_G010 = "KSS043-G010";

	// KSS044-G010
	public static final String KSS044_G010 = "KSS044-G010";

	// KSS050-G010
	public static final String KSS050_G010 = "KSS050-G010";

	// KSS060-G030
	public static final String KSS060_G030 = "KSS060-G030";

	// KSS060-G040
	public static final String KSS060_G040 = "KSS060-G040";

	// KSS070-G010
	public static final String KSS070_G010 = "KSS070-G010";

	// KSS070-G050
	public static final String KSS070_G050 = "KSS070-G050";

	// NSDSSSTRK_KENSAKU
	public static final String NSDSSSTRK_KENSAKU = "nsdssstrkkensaku";

	// NSDSSSTRK_SINKI
	public static final String NSDSSSTRK_SINKI = "nsdssstrksinki";

	// NSDSSSTRK_KMSKJHE
	public static final String NSDSSSTRK_KMSKJHE = "nsdssstrkkmskjhe";

	// NSDSTKMAIN
	public static final String NSDSTK_MAIN = "nsdstkmain";

	// NSDSTKSHINKI
	public static final String NSDSTK_SHINKI = "nsdstkshinki";

	// NSDSTKSHONIN
	public static final String NSDSTK_SHONIN = "nsdstkshonin";

	// NSDSTKKEIRISINSA
	public static final String NSDSTK_KEIRISINSA = "nsdstkkeirisinsa";

	// NSDSSSIKKKENSAKU
	public static final String NSDSSSJKK_KENSAKU = "nsdsssjkkkensaku";

	// NSDSSSJKKSINKI
	public static final String NSDSSSJKK_SINKI = "nsdsssjkksinki";

	// NSDSSSJKKNAIYOKENSAKU
	public static final String NSDSSSJKK_NAIYOKENSAKU = "nsdsssjkknaiyokensaku";

	// NSDSSSJKKSEISANKENSAKU
	public static final String NSDSSSJKK_SEISANKENSAKU = "nsdsssjkkseisankensaku";

	// NSDNSSSJKKSHONINKENSKU
	public static final String NSDNSSSJKK_SHONINKENSKU = "nsdnsssjkkshoninkensku";

	// NSDSSSJKKKEIRIKENSAKU
	public static final String NSDSSSJKK_KEIRIKENSAKU = "nsdsssjkkkeirikensaku";

	// NSDBKTSNKENSAKU
	public static final String NSDBKTSN_KENSAKU = "nsdbktsnkensaku";

	// NSDKTSSDTSAKUSEI
	public static final String NSDKTSSDT_SAKUSEI = "nsdktssdtsakusei";

	// NSDKTSSDTSHUTSURYOKU
	public static final String NSDKTSSDT_SHUTSURYOKU = "nsdktssdtshutsuryoku";

	// NSDKRFTKSKENSAKU
	public static final String NSDKRFTKS_KENSAKU = "nsdkrftkskensaku";

	// NSDKRFTKSSINKI
	public static final String NSDKRFTKS_SINKI = "nsdkrftkssinki";

	// グループメニューID
	public static final String MENU_GROUP_ID_KSS02 = "KSS02";

	public static final String MENU_GROUP_ID_KSS03 = "KSS03";

	public static final String MENU_GROUP_ID_KSS04 = "KSS04";

	public static final String MENU_GROUP_ID_KSS05 = "KSS05";

	public static final String MENU_GROUP_ID_KSS06 = "KSS06";

	public static final String MENU_GROUP_ID_KSS07 = "KSS07";

	// グループメニュー名
	public static final String MENU_GROUP_NAME_KSS02 = "● 精算書登録";

	public static final String MENU_GROUP_NAME_KSS03 = "● 取得";

	public static final String MENU_GROUP_NAME_KSS04 = "● 除却";

	public static final String MENU_GROUP_NAME_KSS05 = "● 分割収入";

	public static final String MENU_GROUP_NAME_KSS06 = "● 固定資産台帳出力";

	public static final String MENU_GROUP_NAME_KSS07 = "● 管理／負担箇所紐付";

	// エラーが発生しました
	public static final String MSGID_SYSTEM_ERROR = "E99999";

	public static final String MSGID_USER_NOT_EXIST = "E20001";

	public static final String MSGID_LOGIN_FAILED = "E20002";

	public static final String MSGID_INPUT_ERROR = "E20003";

	public static final String MSGID_NOT_FOUND_DATA = "E20004";

	public static final String MSGID_NOT_FOUND_FILE_DAITYO = "E20005";

	public static final String MSGID_NOT_FOUND_DATA_DAITYO = "E20006";

	public static final String MSGID_ONLYONE_SELECT_ERROR = "E20007";

	public static final String MSGID_SHONIN_STATUS_ERROR = "E20008";

	public static final String MSGID_CHECK_EMPTY = "E20009";

	public static final String MSGID_CHECK_LENGTH = "E20010";

	public static final String MSGID_CHECK_DATE_FORMAT = "E20011";

	public static final String MSGID_CHECK_DATE_COMPARE = "E20012";

	public static final String MSGID_NOT_EXIST_DATA = "E20013";

	public static final String MSGID_INSERT_SUCCESS = "I20010";

	public static final String MSGID_FOUND_DATA_DAITYO = "I20011";

	public static final String MSGID_LOGIN_SUCCES = "I20012";

	public static final String MSGID_UPDATE_SUCCES = "I20013";

	public static final String MSGID_DELETE_SUCCES = "I20014";

	public static final String MSGID_INSERT_SUCCES = "I20015";

	public static final String MSGID_SYSTEM_INFO = "I99999";

	public static final String MSGID_SUPDATE_LOCK = "E25004";

	// メッセージID存在しない時、ログ出力内容
	public static final String MSG_NOT_FOUND_MSGID = "該当メッセージIDは存在しません。";

	// ログレベル(ERROR)
	public static final String LOG_LEVEL_ERROR = "E";

	// ログレベル(WARN)
	public static final String LOG_LEVEL_WARN = "W";

	// ログレベル(INFO)
	public static final String LOG_LEVEL_INFO = "I";

	// ログレベル(DEBUG)
	public static final String LOG_LEVEL_DEBUG = "D";

	// ログレベル(TRACE)
	public static final String LOG_LEVEL_TRACE = "T";

	// ログ出力用メッセージ(INFO)
	public static final String LOG_INFO_METHOD_BEGIN = "開始します。";

	public static final String LOG_INFO_METHOD_END = "終了します。";

	// 精算書番号（シーケンスID）
	public static final String KSS_SEQ_SEISAN_SHO_NO = "kss_seq_seisan_sho_no";
	// 精算書番号（シーケンス桁数）
	public static final int KSS_SEQ_SEISAN_SHO_NO_LEN = 15;
	// 除却精算書番号（シーケンスID）
	public static final String KSS_SEQ_JOKYAKU_SEISAN_SHO_NO = "kss_seq_jokyaku_seisan_sho_no";
	// 除却精算書番号（シーケンス桁数）
	public static final int KSS_SEQ_JOKYAKU_SEISAN_SHO_NO_LEN = 15;
	// 精算書ＩＤ（シーケンスID）
	public static final String KSS_SEQ_SEISAN_SHO_ID = "kss_seq_seisan_sho_id";
	// 精算書ＩＤ（シーケンス桁数）
	public static final int KSS_SEQ_SEISAN_SHO_ID_LEN = 15;
	// 固定資産番号（シーケンスID）
	public static final String KSS_SEQ_KOTEI_SHISAN_NO = "kss_seq_kotei_shisan_no";
	// 固定資産番号（シーケンス桁数）
	public static final int KSS_SEQ_KOTEI_SHISAN_NO_LEN = 12;
	// 固定資産ＩＤ（シーケンスID）
	public static final String KSS_SEQ_KOTEI_SHISAN_ID = "kss_seq_kotei_shisan_id";
	// 固定資産ＩＤ（シーケンス桁数）
	public static final int KSS_SEQ_KOTEI_SHISAN_ID_LEN = 14;
	// 版数（シーケンスID）
	public static final String KSS_SEQ_HANSU = "kss_seq_hansu";
	// 件名ＩＤ（シーケンスID）
	public static final String KSS_SEQ_KENMEI_ID = "kss_seq_kenmei_id";
	// 件名ＩＤ（シーケンス桁数）
	public static final int KSS_SEQ_KENMEI_ID_LEN = 16;
	// 件名ＩＤ（シーケンスID）
	public static final String KSS_SEQ_DAICHO_ID = "kss_seq_daicho_id";
	// 件名ＩＤ（シーケンス桁数）
	public static final int KSS_SEQ_DAICHO_ID_LEN = 10;
	// シーケンスマップ(取得したシーケンスIDの先頭に0を埋める用のマップ)
	public static final Map<String, Object> SEQ_LEN_MAP = new HashMap<>();
	static {
		SEQ_LEN_MAP.put(KSS_SEQ_SEISAN_SHO_NO, KSS_SEQ_SEISAN_SHO_NO_LEN);
		SEQ_LEN_MAP.put(KSS_SEQ_JOKYAKU_SEISAN_SHO_NO, KSS_SEQ_JOKYAKU_SEISAN_SHO_NO_LEN);
		SEQ_LEN_MAP.put(KSS_SEQ_SEISAN_SHO_ID, KSS_SEQ_SEISAN_SHO_ID_LEN);
		SEQ_LEN_MAP.put(KSS_SEQ_KOTEI_SHISAN_NO, KSS_SEQ_KOTEI_SHISAN_NO_LEN);
		SEQ_LEN_MAP.put(KSS_SEQ_KOTEI_SHISAN_ID, KSS_SEQ_KOTEI_SHISAN_ID_LEN);
		SEQ_LEN_MAP.put(KSS_SEQ_KENMEI_ID, KSS_SEQ_KENMEI_ID_LEN);
		SEQ_LEN_MAP.put(KSS_SEQ_DAICHO_ID, KSS_SEQ_DAICHO_ID_LEN);
	}

	// JasperReportsで作成の帳票テンプレート
	public static final String FILE_TEMPLATE_JRXML = ".jrxml";
	// jrxmlから自動作成の帳票テンプレート
	public static final String FILE_TEMPLATE_JASPER = ".jasper";
	// PDF帳票
	public static final String FILE_TYPE_PDF = ".pdf";
	// Excel帳票
	public static final String FILE_TYPE_XLSX = ".xlsx";

	// 作成区分(固定資産台帳出力指示) :1 夜間（バッチ）
	public static final String CODE_SAKUSEI_KBN_BATCH = "1";
	// 作成区分(固定資産台帳出力指示) :2 昼間（画面）
	public static final String CODE_SAKUSEI_KBN_WEB = "2";
	// 固定資産台帳出力指示登録用ユーザーＩＤ
	public static final String STRING_SAKUSEI_USER_ID_BATCH = "BATCH";

	// 登録
	public static final int ACTION_INSERT = 0;

	// 更新
	public static final int ACTION_UPDATE = 1;

	public enum CHECK_ITEM {
		EMPTY_CHECK, // 空文字チェック
		LENGTH_CHECK, // 桁数のチェック
		DATE_YYYYMM_CHECK, // 年月の妥当性チェック
		DATE_FORMAT_CHECK, // 日付の妥当性チェック
		DATE_COMPARE_CHECK, // 日付の大小比較チェック
		ONLYONE_SELECT, // 一つのみ選択チェック
		IS_EXIST_SOSHIKIRENNM // 該当組織連結名はDBに存在チェック
	}
}
