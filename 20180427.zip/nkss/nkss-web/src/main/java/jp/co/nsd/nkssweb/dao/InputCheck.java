package jp.co.nsd.nkssweb.dao;

import java.util.Map;

public class InputCheck {


	// 項目ID
	private String itemId;

	// 項目名
	private String itemName;

	// 項目値
	private String itemValue;

	// チェック内容
	private Map<Integer, Object> args;

	public String getItemId() {
		return itemId;
	}

	public void setItemId(String itemId) {
		this.itemId = itemId;
	}

	public String getItemName() {
		return itemName;
	}

	public void setItemName(String itemName) {
		this.itemName = itemName;
	}

	public String getItemValue() {
		return itemValue;
	}

	public void setItemValue(String itemValue) {
		this.itemValue = itemValue;
	}

	public Map<Integer, Object> getArgs() {
		return args;
	}

	public void setArgs(Map<Integer, Object> args) {
		this.args = args;
	}

}