package jp.co.nsd.nkssweb.dao.mapper;

import jp.co.nsd.nkssweb.dao.Kss009;
import jp.co.nsd.nkssweb.dao.Kss009Key;

public interface Kss009Mapper {
    int deleteByPrimaryKey(Kss009Key key);

    int insert(Kss009 record);

    int insertSelective(Kss009 record);

    Kss009 selectByPrimaryKey(Kss009Key key);

    int updateByPrimaryKeySelective(Kss009 record);

    int updateByPrimaryKey(Kss009 record);
}