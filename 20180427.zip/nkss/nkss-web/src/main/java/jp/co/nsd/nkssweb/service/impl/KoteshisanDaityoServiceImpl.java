package jp.co.nsd.nkssweb.service.impl;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import jp.co.nsd.nkssweb.controller.CommController;
import jp.co.nsd.nkssweb.dao.KoteshisanDaityo;
import jp.co.nsd.nkssweb.dao.KoteshisanDaityoFileInfo;
import jp.co.nsd.nkssweb.dao.Kss009;
import jp.co.nsd.nkssweb.dao.mapper.KoteshisanDaityoMapper;
import jp.co.nsd.nkssweb.dao.mapper.Kss009Mapper;
import jp.co.nsd.nkssweb.service.KoteshisanDaityoService;
import jp.co.nsd.nkssweb.utils.NSDCommUtils;
import jp.co.nsd.nkssweb.utils.NSDConstant;
import jp.co.nsd.nkssweb.utils.NSDDateUtils;
import jp.co.nsd.nkssweb.utils.NSDFileExporter;
import jp.co.nsd.nkssweb.utils.NSDProperties;
import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.data.JRBeanCollectionDataSource;

@Service
public class KoteshisanDaityoServiceImpl implements KoteshisanDaityoService {

	@Autowired
	private KoteshisanDaityoMapper koteshisanDaityoMapper;

	@Autowired
	private Kss009Mapper kss009Mapper;

	@Autowired
	private CommController commController;

	@Autowired
	private NSDProperties nsdProperties;

	@Autowired
	private NSDFileExporter nsdFileExporter;

	/**
	 * 固定資産台帳出力指示
	 *
	 * @param sakuseiKbn
	 *            1：夜間（バッチ）/2：昼間（画面）
	 * @throws JRException
	 *
	 */
	@Override
	public List<KoteshisanDaityo> getKenmeiInfo(String sakuseiKbn) throws Exception {

		// 固定資産情報を取得
		List<KoteshisanDaityo> koteshisanDaityoList = new ArrayList<KoteshisanDaityo>();
		KoteshisanDaityo koteshisanDaityo = new KoteshisanDaityo();
		koteshisanDaityoList = koteshisanDaityoMapper.selectByWhere();

		String mw1GetM = NSDConstant.BLANK_STRING;
		String kaikeiY = NSDConstant.BLANK_STRING;
		for (int i = 0; i < koteshisanDaityoList.size(); i++) {
			koteshisanDaityo = koteshisanDaityoList.get(i);

			// 前年度末簿価を取得
			if (koteshisanDaityo.getMw1GetYmd() != null) {
				mw1GetM = NSDDateUtils.dateToMM(koteshisanDaityo.getMw1GetYmd(), 0);
				// 固定資産.取得年月日の月は１～３月の場合
				if (Arrays.asList("01", "02", "03").contains(mw1GetM)) {
					// 会計年＝固定資産.取得年月日の年ー１
					kaikeiY = NSDDateUtils.dateToMM(koteshisanDaityo.getMw1GetYmd(), -1);
				} else {
					// それ以外、会計年＝固定資産.取得年月日の年
					kaikeiY = NSDDateUtils.dateToYYYY(koteshisanDaityo.getMw1GetYmd(), 0);
				}
			} else {
				// それ以外、会計年＝固定資産.取得年月日の年
				kaikeiY = NSDDateUtils.dateToYYYY(koteshisanDaityo.getMw1GetYmd(), 0);
			}

			// 前年度末簿価と前年度末簿価（税法）を取得
			if (kaikeiY == koteshisanDaityo.getMwgKaikeiY()) {
				// 減価償却状態.MAX(会計整理年度) = 取得した会計年の場合、０に出力する
				koteshisanDaityo.setMaebkasYenS(BigDecimal.ZERO);
				koteshisanDaityo.setMaebkasYenZ(BigDecimal.ZERO);
			} else {
				// それ以外、明細.前期末簿価＿商を出力する
				koteshisanDaityo.setMaebkasYenS(koteshisanDaityo.getMw2MaebkasYen());
				// それ以外、明細.前期末簿価＿税を出力する
				koteshisanDaityo.setMaebkasYenZ(koteshisanDaityo.getMw2MaebkasYen());
			}
		}
		// 出力ファイル名を取得
		Date fileDate = new Date();
		String fileName = koteshisanDaityoMapper.selectFileName()
				.concat(NSDDateUtils.dateToString(fileDate, "yyyyMMdd_HHmmss"));

		// 帳票データ取得
		JRBeanCollectionDataSource ds = new JRBeanCollectionDataSource(koteshisanDaityoList);

		// テンプレートファイルを取得
		String templateFile = nsdProperties.getTemplateFilePath()
				.concat(NSDCommUtils.converISO8859ToUTF8(nsdProperties.getTemplateFileName()));

		// ファイルを出力
		nsdFileExporter.exportXlsx(ds, templateFile, fileName);

		// DBに登録
		insertDaicho(sakuseiKbn, fileDate, fileName);

		return koteshisanDaityoList;
	}

	/**
	 * 固定資産台帳出力指示情報を登録する
	 *
	 * @param sakuseiKbn
	 *            1：夜間（バッチ）/2：昼間（画面）
	 * @param fileDate
	 *            作成日時
	 * @param fileName
	 *            台帳ファイル名
	 */
	private void insertDaicho(String sakuseiKbn, Date fileDate, String fileName) {
		Kss009 kss009 = new Kss009();
		// 台帳ＩＤ
		kss009.setDaichoId(commController.getSequence(NSDConstant.KSS_SEQ_DAICHO_ID));
		// 台帳ファイル名
		kss009.setDaichoNm(fileName.concat(NSDConstant.FILE_TYPE_XLSX));
		// 作成日時
		kss009.setSakuseiTimestamp(fileDate);
		// 作成区分
		kss009.setSakuseiKbn(sakuseiKbn);
		// 登録年月日
		kss009.setEntryDate(fileDate);
		if (sakuseiKbn == NSDConstant.CODE_SAKUSEI_KBN_BATCH) {
			// 夜間の場合、"Batch" 固定
			// 作成ユーザーＩＤ
			kss009.setSakuseiUserId(NSDConstant.STRING_SAKUSEI_USER_ID_BATCH);
			// 登録ユーザーＩＤ
			kss009.setEntryUserId(NSDConstant.STRING_SAKUSEI_USER_ID_BATCH);
			// 更新ユーザーＩＤ
			kss009.setUpdateUserId(NSDConstant.STRING_SAKUSEI_USER_ID_BATCH);
		} else {
			// 昼間の場合、操作者のユーザーID
			// 作成ユーザーＩＤ
			kss009.setSakuseiUserId(NSDConstant.STRING_A9999); // TODO
																// 社員コード（実行ユーザーの社員コード）
			// 登録ユーザーＩＤ
			kss009.setEntryUserId(NSDConstant.STRING_A9999); // TODO
																// 社員コード（実行ユーザーの社員コード）
			// 更新ユーザーＩＤ
			kss009.setUpdateUserId(NSDConstant.STRING_A9999); // TODO
																// 社員コード（実行ユーザーの社員コード）
		}

		// 更新年月日
		kss009.setUpdateDate(fileDate);
		// 固定資産台帳出力指示登録
		kss009Mapper.insertSelective(kss009);
	}

	/**
	 * 固定資産台帳ファイル情報取得
	 *
	 * @return 最新固定資産台帳ファイル作成日時
	 *
	 */
	public String getSakuseiTimestamp() {
		return koteshisanDaityoMapper.selectSakuseiTimestamp();
	}

	@Override
	public List<KoteshisanDaityoFileInfo> getKoteishisanDaityoFileInfo() {

		// 固定資産台帳ファイル情報取得
		List<KoteshisanDaityoFileInfo> fileInfoList = koteshisanDaityoMapper.getKoteishisanDaityoFileInfo();

		if (fileInfoList.size() > 0) {
			for (int i = 1; i <= fileInfoList.size(); i++) {
				// rowNoを設定する
				fileInfoList.get(i - 1).setRowNo(i);
			}
		} else {
			fileInfoList = null;
		}

		return fileInfoList;
	}
}
