/***********************************************************************
*
*業務名: 工事精算システム
*機能名: 除却（登録・修正・削除）(サービス処理)
*
*機能概要: 除却情報を処理する。
*
*JavaＶｅｒ：J2SE1.8.0準拠
*
*更新履歴: Ver.1.00 2018/03/06　NSD　新規作成
***********************************************************************/
package jp.co.nsd.nkssweb.service.seisanshoshutoku.impl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import jp.co.nsd.nkssweb.dao.SeisanshoShonin;
import jp.co.nsd.nkssweb.dao.SeisanshoShoninShokai;
import jp.co.nsd.nkssweb.dao.SeisanshoShoninshutokuSisan;
import jp.co.nsd.nkssweb.dao.mapper.SeisanshoShoninMapper;
import jp.co.nsd.nkssweb.service.seisanshoshutoku.SeisanshoShoninService;
import jp.co.nsd.nkssweb.utils.NSDConstant;

/**
 * 承認（検索・照会・更新）処理
 *
 * @see SeisanshoShoninService
 * @version 1.00
 */
@Service
public class SeisanshoShoninServiceImpl implements SeisanshoShoninService {

	@Autowired
	private SeisanshoShoninMapper seisanshoShoninMapper;

	/**
	 * 承認（検索）処理
	 *
	 * @param seisanshoShonin
	 *            INPUTパラメータ
	 * @return sssSNList 承認情報データリスト
	 * @version 1.00
	 */
	public List<SeisanshoShonin> getshoninInfo(SeisanshoShonin seisanshoShonin) {

		// 除却情報を取得する
		List<SeisanshoShonin> sssSNList = seisanshoShoninMapper.selectByWhere(seisanshoShonin);

		if (sssSNList.size() > 0) {
			for (int i = 0; i < sssSNList.size(); i++) {

				SeisanshoShonin sssSNSn = sssSNList.get(i);

				// ROWNOを設定する
				sssSNSn.setRowNo(i + 1);

				// 承認状態を設定する
				sssSNSn.setShoninStatusNm(NSDConstant.getShoninStatus(sssSNSn.getShoninStatusCd()));

			}
		} else {
			sssSNList = null;
		}

		return sssSNList;
	}

	/**
	 * 取得承認（照会）処理
	 *
	 * @param seisanshoShoninShokai
	 *            INPUTパラメータ
	 * @return List<SeisanshoShoninShokai> 取得承認情報データ
	 * @version 1.00
	 */
	public SeisanshoShoninShokai getshutokuInfoBySeisanShoNo(SeisanshoShoninShokai seisanshoShoninShokai) {

		// 取得情報
		SeisanshoShoninShokai resultDao = new SeisanshoShoninShokai();

		// 取得情報を取得する
		List<SeisanshoShoninShokai> sssSnSkList = seisanshoShoninMapper.selectBySeisanShoNo(seisanshoShoninShokai);

		if (sssSnSkList.size() > 0) {
			resultDao = sssSnSkList.get(0);

			// 承認状態名称を設定する
			resultDao.setShoninStatusNm(NSDConstant.getShoninStatus(resultDao.getShoninStatusCd()));

			// 取得資産明細リストの初期化
			resultDao.setShutokuSisanLst(new ArrayList<SeisanshoShoninshutokuSisan>());

			// 取得資産明細情報
			for (int i = 0; i < sssSnSkList.size(); i++) {

				SeisanshoShoninshutokuSisan sssSnStkSs = new SeisanshoShoninshutokuSisan();

				sssSnStkSs.setRowNo(i + 1);

				sssSnStkSs.setKoteiShisanNo(sssSnSkList.get(i).getKoteiShisanNo());

				sssSnStkSs.setKoteiShisanNm(sssSnSkList.get(i).getKoteiShisanNm());

				sssSnStkSs.setShutokuKagaku(sssSnSkList.get(i).getShutokuKagaku());

				sssSnStkSs.setShutokuYmd(sssSnSkList.get(i).getShutokuYmd());

				resultDao.getShutokuSisanLst().add(sssSnStkSs);
			}
		} else {
			resultDao = null;
		}

		return resultDao;
	}

}
