<template>
  <div class="page-style">
    <el-row>
      <el-col>
        <el-menu
          style="height: 570px; width: 190px;"
          default-active="1"
          class="el-menu-vertical-demo"
          :router="true"
          :unique-opened="true"
          @open="handleOpen"
          @close="handleClose">
          <el-submenu v-for="(category, key) in categorys" :index="category.id" :key="category.id">
            <template slot="title">
              <span>{{ category.name }}</span>
            </template>
            <el-menu-item 
              v-for="(link, key) in category.links" 
              :route="{ name: link.routername, params: { id: link.id }}" 
              :index="link.index" 
              :key="key"
            >
              {{ link.script }}
            </el-menu-item>
          </el-submenu>
        </el-menu>
      </el-col>
    </el-row>
  </div>
</template>

<script>
export default {
  methods: {
    handleOpen (key, keyPath) {
      console.log(key, keyPath)
    },
    handleClose (key, keyPath) {
      console.log(key, keyPath)
    }
  },
  data () {
    return {
      categorys: [
        {
          id: '1',
          name: '● 精算書登録',
          links: [
            { index: '1-1', script: '検索（修正／削除）', routername: 'nsdssstrkkensaku', id: 't-search' },
            { index: '1-2', script: '新規登録', routername: 'nsdssstrksinki' },
            { index: '1-3', script: '連携結果一覧', routername: 'nsdssstrkrkkkichiran' }
          ]
        },
        {
          id: '2',
          name: '● 取得',
          links: [
            { index: '2-1', script: '検索（修正／削除）', routername: 'nsdstkmain', id: 's-search' },
            { index: '2-2', script: '新規登録', routername: 'nsdstkshinki' },
            { index: '2-3', script: '承認', routername: 'nsdstkshonin' },
            { index: '2-4', script: '経理審査／連携', routername: 'nsdstkkeirisinsa' }
          ]
        },
        {
          id: '3',
          name: '● 除却',
          links: [
            { index: '3-1', script: '検索（修正／削除）', routername: 'nsdsssjkkkensaku' },
            { index: '3-2', script: '新規登録', routername: 'nsdsssjkksinki' },
            { index: '3-3', script: '内容入力', routername: 'nsdsssjkknaiyokensaku' },
            { index: '3-4', script: '精算通告', routername: 'nsdsssjkkseisankensaku' },
            { index: '3-5', script: '承認', routername: 'nsdnsssjkkshoninkensku' },
            { index: '3-6', script: '経理審査／連携', routername: 'nsdsssjkkkeirikensaku' }
          ]
        },
        {
          id: '4',
          name: '● 分割収入',
          links: [
            { index: '4-1', script: '経理審査／連携', routername: 'nsdbktsnkensaku' }
          ]
        },
        {
          id: '5',
          name: '● 固定資産台帳出力',
          links: [
            { index: '5-1', script: '作成指示', routername: 'nsdktssdtsakusei' },
            { index: '5-2', script: '出力', routername: 'nsdktssdtsuturoku' }
          ]
        },
        {
          id: '6',
          name: '● 管理／負担箇所紐付',
          links: [
            { index: '6-1', script: '検索（修正／削除）', routername: 'nsdkrftkskensaku' },
            { index: '6-2', script: '新規登録', routername: 'nsdkrftkssinki' }
          ]
        }
      ]
    }
  }
}
</script>

<style scoped>
.page-style {
  /*background-color:#ff0fff;*/
  height: 400px;
  float:left;
}

</style>