<template>
<div class="page-style">
  <div><p>新 工 事 精 算 シ ス テ ム</p></div>
  <div class="lab-style1">XXXさん</div>
  <div class="lab-style2"><span>部門名称</span><span>　社員ID</span></div>
  <div class="btn-style">
    <el-popover
      ref="signOut"
      placement="bottom-end">
      <div style="text-align: left; margin: 0">
        <el-button type="text" size='mini' @click="logOut"><i class="sign out icon"></i>　ログアウト</el-button>
      </div>
    </el-popover>
    <el-button v-popover:signOut size='mini' type="primary"><i class="user icon"></i><i class="el-icon-caret-bottom"></i></el-button>
  </div>
</div>
</template>

<script>
export default {
  methods: {
    logOut: function () {
      this.$router.push({name: 'nsdlogininput'})
    }
  }
}
</script>

<style scoped>
  .page-style {
	position: relative;
    border-style:groove;
    color:white;
    text-align:center;
    margin:0px;
    height:60px;
    font-size:30px;
  }
  .btn-style {
    position: absolute;
    right: 2px;
    bottom: 2px;
    padding: 0px;
  }
  .lab-style1 {
    position: absolute;
    right: 70px;
    bottom: 30px;
    padding: 0px;
    font-size:20px;
  }
  .lab-style2 {
    position: absolute;
    right: 70px;
    bottom: 12px;
    padding: 0px;
    font-size:20px;
  }
</style>
