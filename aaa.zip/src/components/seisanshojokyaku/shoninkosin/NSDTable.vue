<template>
  <div style= "padding: 0px 10px 0px 10px; width: 850px;">
    <div style="position: relative;">
     <span style="font-size: 12px;">10件</span>
      <div style="position: absolute; top: -3px; right: 0px;">
        <el-pagination
          @size-change="handleSizeChange"
          @current-change="handleCurrentChange"
          :current-page.sync="currentPage1"
          :page-size="50"
          small
          layout="prev, pager, next"
          prev-text="前へ"
          next-text="次へ"
          :total="150">
        </el-pagination>
      </div>
    </div>
    <el-table
      :data="tableData"
      border
      height= 160
      :header-row-class-name="headerClassName">
      <el-table-column
        sortable
        prop="kouban"
        label="NO."
        width="70px">
      </el-table-column>
      <el-table-column
        sortable
        prop="koteisisanno"
        label="固定資産番号"
        min-width="120px">
      </el-table-column>
      <el-table-column
        sortable
        prop="koteisisanmeisho"
        label="固定資産名称"
        width="250px">
      </el-table-column>
      <el-table-column
        sortable
        prop="syutokuymd"
        label="取得年月日"
        width="120px">
      </el-table-column>
      <el-table-column
        sortable
        prop="ymd"
        label="使用開始年月日"
        width="120px">
      </el-table-column>
      <el-table-column
        sortable
        prop="syutokukagaku"
        label="除却取得原価"
        header-align=left
        align=right
        width="120px">
      </el-table-column >
    </el-table>
  </div>
</template>
<script scoped>
  export default {
    methods: {
      headerClassName ({row, rowIndex}) {
        return 'class-header'
      },
      handleSizeChange (val) {
        console.log(`每页 ${val} 条`)
      },
      handleCurrentChange (val) {
        console.log(`当前页: ${val}`)
      }
    },
    data () {
      return {
        currentPage1: 2,
        tableData: [{
          kouban: '1',
          koteisisanno: '300000000018',
          koteisisanmeisho: '固定資産名称Ａ18',
          syutokuymd: '2012-07-01',
          ymd: '2012-07-02',
          syutokukagaku: '8,000円'
        }, {
          kouban: '2',
          koteisisanno: '300000000019',
          koteisisanmeisho: '固定資産名称Ａ19',
          syutokuymd: '2012-07-01',
          ymd: '2012-07-02',
          syutokukagaku: '3,600円'
        }, {
          kouban: '3',
          koteisisanno: '300000000022',
          koteisisanmeisho: '固定資産名称Ａ22',
          syutokuymd: '2012-07-01',
          ymd: '2012-07-02',
          syutokukagaku: '400円'
        }, {
          kouban: '4',
          koteisisanno: '300000000022',
          koteisisanmeisho: '固定資産名称Ａ22',
          syutokuymd: '2012-07-01',
          ymd: '2012-07-02',
          syutokukagaku: '400円'
        }, {
          kouban: '5',
          koteisisanno: '300000000022',
          koteisisanmeisho: '固定資産名称Ａ22',
          syutokuymd: '2012-07-01',
          ymd: '2012-07-02',
          syutokukagaku: '400円'
        }, {
          kouban: '6',
          koteisisanno: '300000000022',
          koteisisanmeisho: '固定資産名称Ａ22',
          syutokuymd: '2012-07-01',
          ymd: '2012-07-02',
          syutokukagaku: '400円'
        }, {
          kouban: '7',
          koteisisanno: '300000000022',
          koteisisanmeisho: '固定資産名称Ａ22',
          syutokuymd: '2012-07-01',
          ymd: '2012-07-02',
          syutokukagaku: '400円'
        }, {
          kouban: '8',
          koteisisanno: '300000000022',
          koteisisanmeisho: '固定資産名称Ａ22',
          syutokuymd: '2012-07-01',
          ymd: '2012-07-02',
          syutokukagaku: '400円'
        }, {
          kouban: '9',
          koteisisanno: '300000000022',
          koteisisanmeisho: '固定資産名称Ａ22',
          syutokuymd: '2012-07-01',
          ymd: '2012-07-02',
          syutokukagaku: '400円'
        }, {
          kouban: '10',
          koteisisanno: '300000000022',
          koteisisanmeisho: '固定資産名称Ａ22',
          syutokuymd: '2012-07-01',
          ymd: '2012-07-02',
          syutokukagaku: '400円'
        }]
      }
    }
  }
</script>
<style scoped>
</style>
