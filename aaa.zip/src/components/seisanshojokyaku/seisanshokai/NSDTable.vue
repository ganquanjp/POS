<template>
  <div style= "padding-left: 10px; padding-right: 10px; width: 1039px;" >
    <div class="page-style">
        <el-row class="row-class">
          <el-col class="lab-class">　精算書番号</el-col>
          <el-col style= "width: 640px;">
            <el-input v-model="formItem.jokyakuSeisanShoNo" size="mini" :disabled="true"></el-input>
          </el-col>
        </el-row>
        <el-row class="row-class">
          <el-col class="lab-class">　除却年月日</el-col>
          <el-col style= "width: 640px;">
            <el-input v-model="formItem.jokyakuYmd" size="mini" :disabled="true"></el-input>
          </el-col>
        </el-row>
        <el-row class="row-class">
          <el-col class="lab-class">　精算箇所</el-col>
          <el-col style= "width: 640px;">
            <el-input v-model="formItem.soshikiRenRyakuNm" size="mini" :disabled="true""></el-input>
          </el-col>
        </el-row>
        <el-row class="row-class">
          <el-col class="lab-class">　摘要</el-col>
          <el-col style= "width: 640px;">
            <el-input v-model="formItem.tekiyo" size="mini" :disabled="true"></el-input>
          </el-col>
        </el-row>
        <el-row class="row-class">
          <el-col class="lab-class">　工事件名</el-col>
          <el-col style= "width: 640px;">
            <el-input v-model="formItem.kenmeiNm" size="mini" :disabled="true""></el-input>
          </el-col>
        </el-row>
    </div>
    <div ref="divScroll" class="scroll-box">
      <div style="position: relative;">
        <span style="font-size: 12px;">{{this.$store.state.tableData.koteiSisanLst.length}}件</span>
      </div>
      <div style="width: 750px;">
        <el-table
          :data="this.$store.state.tableData.koteiSisanLst"
          border>
          <el-table-column 
            prop="rowNo"
            label="NO."
            width="48px">
          </el-table-column>
          <el-table-column
            label="固定資産番号"
            width="110px">
            <template slot-scope="scope">
              <el-button type="text" size="medium" @click="move(scope.row.rowNo)">{{scope.row.koteiNo}}</el-button>
            </template>
          </el-table-column>
          <el-table-column
            prop="koteiKnj"
            label="固定資産名称"
            width="200px">
          </el-table-column>
          <el-table-column
            prop="getkgkYen"
            label="元_取得価額"
            header-align=left
            align=right
            width="150px">
          </el-table-column >
          <el-table-column
            prop="jokyakuGaku"
            label="除_取得価額"
            header-align=left
            align=right
            width="140px">
          </el-table-column>
          <el-table-column
            prop="jokyakuShubetsuNm"
            label="除却種別コード"
            min-width="100px">
          </el-table-column>
        </el-table>
        <div style="margin-top: 10px; border: 1px solid; padding-top: 1px; width: 404px; font-size: 12px;" v-if="display">
          <el-row class="row-class">
            <el-col class="lab-class">　固定資産番号</el-col>
            <el-col style= "width: 200px">
              <el-input v-model="koteiItem.koteiNo" size="mini" :disabled="true" />
            </el-col>
          </el-row>
          <el-row class="row-class">
            <el-col class="lab-class">　固定資産名称</el-col>
            <el-col style= "width: 200px">
              <el-input v-model="koteiItem.koteiKnj" size="mini" :disabled="true" />
            </el-col>
          </el-row>
          <el-row class="row-class">
            <el-col class="lab-class">　取得年月日</el-col>
            <el-col style= "width: 200px">
              <el-input v-model="koteiItem.getYmd" size="mini" :disabled="true" />
            </el-col>
          </el-row>
          <el-row class="row-class">
            <el-col class="lab-class">　元_数量</el-col>
            <el-col style= "width: 100px">
              <el-input v-model="koteiItem.meiSu" size="mini" :disabled="true" />
            </el-col>            
            <el-col style="width: 50px; line-height: 30px; background-color: #77cad8; margin-right: 1px; margin-left: 1px;">　単位</el-col>
            <el-col style= "width: 48px">
              <el-input v-model="koteiItem.taniKnj" size="mini" :disabled="true" />
            </el-col>
          </el-row>
          <el-row class="row-class">
            <el-col class="lab-class">　元_取得価額</el-col>
            <el-col class="input-group" style= "width: 200px">
              <input v-model="koteiItem.getkgkYen" size="mini" class="nsd-input-class label-input-class" disabled="disabled">
                <label class="label-group">円</label>
              </input>
            </el-col>
          </el-row>
          <el-row class="row-class">
            <el-col class="lab-class">　除却区分</el-col>
            <el-col style= "width: 200px">
              <el-input v-model="koteiItem.jokyakuKbnNm" size="mini" :disabled="true" />
            </el-col>
          </el-row>
          <el-row class="row-class">
            <el-col class="lab-class">　除却種別コード</el-col>
            <el-col style= "width: 200px">
              <el-input v-model="koteiItem.jokyakuShubetsuNm" size="mini" :disabled="true" />
            </el-col>
          </el-row>
          <el-row class="row-class">
            <el-col class="lab-class">　除_数量</el-col>
            <el-col style= "width: 100px">
              <el-input v-model="koteiItem.jokyakuSuryo" size="mini" :disabled="true" />
            </el-col>            
            <el-col style="width: 50px; line-height: 30px; background-color: #77cad8; margin-right: 1px; margin-left: 1px;">　単位</el-col>
            <el-col style= "width: 48px">
              <el-input v-model="koteiItem.taniKnj" size="mini" :disabled="true" />
            </el-col>
          </el-row>
          <el-row class="row-class">
            <el-col class="lab-class">　除_取得価額</el-col>
            <el-col class="input-group" style= "width: 200px">
              <input v-model="koteiItem.jokyakuGaku" size="mini" class="nsd-input-class label-input-class" disabled="disabled">
                <label class="label-group">円</label>
              </input>
            </el-col>
          </el-row>
        </div>
      </div>
    </div>
    <el-row>
      <el-col>
        <nsd-button-bar v-bind:buttons="buttonName" v-bind:formItem="formItem"></nsd-button-bar>
      </el-col>
    </el-row>
  </div>
</template>

<script scoped>
import NSDButtonBar from '@/components/common/NSDButtonBar.vue'

export default {
  components: {
    'nsd-button-bar': NSDButtonBar
  },
  created: function () {
    this.formItem = this.$store.state.tableData
    if (this.formItem.shoninSattus === '00') {
      this.buttonName[0].disabled = false
    } else {
      this.buttonName[0].disabled = true
    }
  },
  methods: {
    move: function (rowNo) {
      this.koteiItem = this.$store.state.tableData.koteiSisanLst[rowNo - 1]
      this.display = true
    },
    renderHeader (createElement, { column }) {
      return createElement(
        'el-lab',
        [
          '承認状態',
          createElement('span', {style: 'color: red;'}, '　　(必須)')
        ]
      )
    }
  },
  data () {
    return {
      display: false,
      buttonName: [
        {name: '更　新', primary: true, show: true, action: '', url: '', backUrl: '', msg: ''},
        {name: '戻　る', primary: true, show: true, action: 'back', url: '', backUrl: 'nsdsssjkkseisankensaku', msg: ''}
      ],
      formItem: '',
      koteiItem: ''
    }
  }
}
</script>

<style scoped>
.page-style {
  font-size: 12px;
  width: 843px;
  height: 100%;
  line-height:30px;
  border: 1px solid;
  padding-top: 1px;
}
.scroll-box {
  max-height: 310px;
  overflow-y: auto;
  margin-top: 10px; 
}
.row-class {
  height: 30px;
  margin-bottom: 1px;
  margin-left: 1px;
  margin-right: 1px;
}
.lab-class {
  line-height: 30px;
  width: 200px;
  background-color: #77cad8;
  margin-right: 1px;
}
.input-group {
  line-height: normal;
  display: inline-table;
  width: 200px;
  border-collapse: separate;
}
.label-input-class {
  border-top-right-radius: 0;
  border-bottom-right-radius: 0;
}
.label-group {
  background-color: #f5f7fa;
  color: #909399;
  display: table-cell;
  position: relative;
  border: 1px solid #dcdfe6;
  border-radius: 4px;
  padding: 0 20px;
  width: 1px;
  white-space: nowrap;
  position: relative;
  border-left: 0;
  border-top-left-radius: 0;
  border-bottom-left-radius: 0;
}
</style>