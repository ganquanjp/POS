<template>
  <div style= "padding: 0px 10px 0px 10px; width: 850px;">
    <div class="div-style1" v-if="formItem.shoninSattus != 'Y'">
      <el-row class="row-class">
        <el-col class="lab-class">　経理否認理由</el-col>
        <el-col style= "width: 303px;">
          <el-input v-model="formItem.riyu" size="mini" :disabled="true" />
        </el-col>
      </el-row>
    </div>
    <div class="div-style2">
      <el-row class="row-class">
        <el-col style= "width: 474px; background-color: #2053cc; color: white;">　除却資産</el-col>
      </el-row>
      <el-row class="row-class">
        <el-col class="lab-class">　精算書番号</el-col>
        <el-col style= "width: 303px;">
          <el-input v-model="formItem.jokyakuSeisanShoNo" size="mini" :disabled="true" />
        </el-col>
      </el-row>
      <el-row class="row-class">
        <el-col class="lab-class">　処理No</el-col>
        <el-col style= "width: 303px;">
          <input v-model="formItem.hansu" size="mini" class="nsd-input-class" disabled="disabled" style="cursor: default;" />
        </el-col>
      </el-row>
      <el-row class="row-class">
        <el-col class="lab-class">　除却年月日</el-col>
        <el-col style= "width: 303px;">
          <el-input v-model="formItem.jokyakuYmd" size="mini" :disabled="true" />
        </el-col>
      </el-row>
      <el-row class="row-class">
        <el-col class="lab-class">　除却取得価額合計</el-col>
          <el-col class="input-group" style= "width: 303px">
            <input v-model="formItem.jokyakuKagakuGokei" size="mini" class="nsd-input-class label-input-class" disabled="disabled" style="cursor: default;" />
              <label class="label-group">円</label>
            </input>
          </el-col>
      </el-row>
      <el-row class="row-class">
        <el-col class="lab-class">　承認状態</el-col>
        <el-col style= "width: 303px;">
          <el-input v-model="formItem.shoninJotai" size="mini" :disabled="true" />
        </el-col>
      </el-row>
      <el-row class="row-class">
        <el-col class="lab-class">　工事件名名称</el-col>
        <el-col style= "width: 303px;">
          <el-input v-model="formItem.kenmeiNm" size="mini" :disabled="true" />
        </el-col>
      </el-row>
    </div>
    <div style="position: relative;">
     <span style="font-size: 12px;">{{this.$store.state.tableData.koteiSisanLst.length}}件</span>
      <div style="position: absolute; top: -3px; right: 0px;">
        <el-pagination
          @size-change="handleSizeChange"
          @current-change="handleCurrentChange"
          :current-page.sync="pageData.currentPage"
          :page-sizes="pageData.pageSizeArr"
          :page-size="pageData.pageSizeAct"
          layout="prev, pager, next"
          prev-text="前へ"
          next-text="次へ"
          :total="this.$store.state.tableData.koteiSisanLst.length">
        </el-pagination>
      </div>
    </div>
    <el-table
      :data="this.$store.state.currentPageData"
      border
      max-height= 130>
      <el-table-column
        sortable
        prop="rowNo"
        label="NO."
        width="70px">
      </el-table-column>
      <el-table-column
        sortable
        prop="koteiNo"
        label="固定資産番号"
        min-width="120px">
      </el-table-column>
      <el-table-column
        sortable
        prop="koteiKnj"
        label="固定資産名称"
        width="250px">
      </el-table-column>
      <el-table-column
        sortable
        prop="getYmd"
        label="取得年月日"
        width="120px">
      </el-table-column>
      <el-table-column
        sortable
        prop="useYmd"
        label="使用開始年月日"
        width="120px">
      </el-table-column>
      <el-table-column
        sortable
        prop="jokyakuGaku"
        label="除却取得原価"
        header-align=left
        align=right
        width="120px">
      </el-table-column >
    </el-table>
    <el-row>
      <el-col>
        <nsd-button-bar v-bind:buttons="buttonName" v-bind:formItem="formItem"></nsd-button-bar>
      </el-col>
    </el-row>
  </div>
</template>
<script scoped>
import NSDButtonBar from '@/components/common/NSDButtonBar.vue'

export default {
  components: {
    'nsd-button-bar': NSDButtonBar
  },
  created: function () {
    this.formItem = this.$store.state.tableData
    this.$store.state.currentPageData = this.$store.state.tableData.koteiSisanLst.slice(0, 10)
  },
  methods: {
    handleSizeChange (index) {
      this.pageData.pageSizeAct = index
      this.initTableList(1)
    },
    handleCurrentChange (index) {
      this.initTableList(index)
    },
    initTableList (index) {
      this._initPageData(index)
      this.getPageData()
    },
    _initPageData (index) {
      this.pageData.pageNum = (index - 1) * this.pageData.pageSizeAct
      this.pageData.currentPage = index
    },
    getPageData () {
      this.$store.state.currentPageData = this.$store.state.tableData.koteiSisanLst.slice(this.pageData.pageSizeAct * (this.pageData.currentPage - 1), this.pageData.pageSizeAct * this.pageData.currentPage)
    }
  },
  data () {
    return {
      buttonName: [
        {name: '印　刷', primary: true, show: true, action: 'popup', url: '', backUrl: '', msg: ''},
        {name: '更　新', primary: true, show: true, action: '', url: '', backUrl: '', msg: ''},
        {name: '戻　る', primary: true, show: true, action: 'back', url: '', backUrl: 'nsdnsssjkkshoninkensku', msg: ''}
      ],
      formItem: '',
      pageData: {
        total: 0,
        pageNum: 0,
        pageSizeArr: [10, 50, 100, 200],
        pageSizeAct: 10,
        currentPage: 1,
        visible: false
      }
    }
  }
}
</script>
<style scoped>
.page-style {
  font-size: 12px;
  width: 476px;
  height: 100%;
  margin-left:10px;
  line-height:30px;
  border: 1px solid;
  padding-top: 1px;
}
.row-class {
  height: 30px;
  margin-bottom: 1px;
  margin-left: 1px;
  margin-right: 1px;
}
.lab-class {
  width: 170px;
  background-color: #77cad8;
  line-height: 30px;
  margin-right: 1px;
}
.div-style1 {
  font-size: 12px;
  width: 476px;
  height: 100%;
  margin-bottom: 10px;
  line-height:30px;
  border: 1px solid;
  padding-top: 1px;
}
.div-style2 {
  font-size: 12px;
  width: 476px;
  height: 100%;
  margin-bottom: 10px;
  line-height:30px;
  border: 1px solid;
  padding-top: 1px;
}
.label-group {
  background-color: #f5f7fa;
  color: #909399;
  display: table-cell;
  position: relative;
  border: 1px solid #dcdfe6;
  border-radius: 4px;
  padding: 0 20px;
  width: 1px;
  white-space: nowrap;
  position: relative;
  border-left: 0;
  border-top-left-radius: 0;
  border-bottom-left-radius: 0;
}
.input-group {
  line-height: normal;
  display: inline-table;
  width: 100%;
  border-collapse: separate;
}
.label-input-class {
  border-top-right-radius: 0;
  border-bottom-right-radius: 0;
}
</style>
