<template>
  <div style= "padding-left: 10px; padding-right: 10px; width: 850px;">
    <div style="position: relative;">
     <span style="font-size: 12px;">{{this.$store.state.tableData.length}}件</span>
      <div style="position: absolute; top: -3px; right: 0px;">
        <el-pagination
          @size-change="handleSizeChange"
          @current-change="handleCurrentChange"
          :current-page.sync="pageData.currentPage"
          :page-sizes="pageData.pageSizeArr"
          :page-size="pageData.pageSizeAct"
          layout="prev, pager, next"
          prev-text="前へ"
          next-text="次へ"
          :total="this.$store.state.tableData.length">
        </el-pagination>
      </div>
    </div>
    <el-table
      :data="this.$store.state.currentPageData"
      border
      max-height=298>
      <el-table-column
        sortable
        prop="rowNo"
        label="NO."
        width="70px">
      </el-table-column>
      <el-table-column
        sortable
        prop="jokyakuSeisanShoNo"
        label="精算書番号"
        width="180px">
          <template slot-scope="scope">
            <el-button type="text" size="medium" @click="move(scope.row.rowNo)">{{scope.row.jokyakuSeisanShoNo}}</el-button>
          </template>
      </el-table-column >
      <el-table-column
        sortable
        prop="jokyakuYoteYmd"
        label="除却予定年月日"
        width="120px">
      </el-table-column>
      <el-table-column
        sortable
        prop="kenmeiNm"
        label="工事件名"
        width="120px">
      </el-table-column>
      <el-table-column
        sortable
        prop="soshikiRenRyakuNm"
        label="精算箇所"
        width="200px">
      </el-table-column>
      <el-table-column
        sortable
        prop="tekiyo"
        label="摘要"
        min-width="80px">
      </el-table-column>
    </el-table>
  </div>
</template>
<script scoped>
  export default {
    created: function () {
      this.$store.state.currentPageData = this.tableData
    },
    data () {
      return {
        tableData: [],
        pageData: {
          total: 0,
          pageNum: 0,
          pageSizeArr: [10, 50, 100, 200],
          pageSizeAct: 10,
          currentPage: 1,
          visible: false
        }
      }
    },
    methods: {
      move: function (rowNo) {
        this.funcHttpPost('/seisanshoJokyaku-selectBySeisanShoNo', this.$store.state.currentPageData[rowNo - 1], 'nsdsssjkkshokai')
      },
      handleSizeChange (index) {
        this.pageData.pageSizeAct = index
        this.initTableList(1)
      },
      handleCurrentChange (index) {
        this.initTableList(index)
      },
      initTableList (index) {
        this._initPageData(index)
        this.getPageData()
      },
      _initPageData (index) {
        this.pageData.pageNum = (index - 1) * this.pageData.pageSizeAct
        this.pageData.currentPage = index
      },
      getPageData () {
        this.$store.state.currentPageData = this.$store.state.tableData.slice(this.pageData.pageSizeAct * (this.pageData.currentPage - 1), this.pageData.pageSizeAct * this.pageData.currentPage)
      }
    }
  }
</script>
<style scoped>
</style>
