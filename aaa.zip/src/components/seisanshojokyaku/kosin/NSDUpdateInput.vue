<template>
  <div class="page-style">
    <el-row class="row-class">
      <el-col class="lab-class">　精算書番号</el-col>
      <el-col style= "width: 170px;">
        <el-input v-model="input1" size="mini" :disabled="true"></el-input>
      </el-col>
    </el-row>
    <el-row class="row-class">
      <el-col class="lab-class">　除却予定年月<span class="span-class">（必須）</span></el-col>
      <el-col style= "width: 80px;">
        <el-input v-model="input2" size="mini"></el-input>
      </el-col>
    </el-row>
    <el-row class="row-class">
      <el-col class="lab-class">　工事件名コード<span class="span-class">（必須）</span></el-col>
      <el-col style= "width: 220px;">
        <el-input v-model="input3" size="mini"></el-input>
      </el-col>
    </el-row>
    <el-row class="row-class">
      <el-col class="lab-class">　工事件名名称<span class="span-class">（必須）</span></el-col>
      <el-col style= "width: 650px;">
        <el-input v-model="input4" size="mini"></el-input>
      </el-col>
    </el-row>
    <el-row class="row-class">
      <el-col class="lab-class">　精算箇所<span class="span-class">（必須）</span></el-col>
      <el-col style= "width: 650px;">
        <el-input v-model="input5" size="mini"></el-input>
      </el-col>
    </el-row>
    <el-row class="row-class">
      <el-col class="lab-class">　登録者氏名<span class="span-class">（必須）</span></el-col>
      <el-col style= "width: 170px;">
        <el-input v-model="input6" size="mini"></el-input>
      </el-col>
    </el-row>
    <el-row class="row-class">
      <el-col class="lab-class">　摘要</el-col>
      <el-col style= "width: 400px;">
        <el-input v-model="input7" size="mini"></el-input>
      </el-col>
    </el-row>
  </div>
</template>

<script>
export default {
  data () {
    return {
      input1: '1000000000000003',
      input2: '201204',
      input3: '1234567890ABCDE',
      input4: 'ＡＢＣＤＥＦＧＨＩＪＫＬＭＮＯＰＱＲＳＴＵＶＷＸＹＺＡＢＣＤＥＦＧＨＩＪＫＬＭＮＯＰＱＲＳＴＵＶＷＸ',
      input5: 'ＡＢＣＤＥＦＧＨＩＪＫＬＭＮＯＰＱＲＳＴＵＶＷＸＹＺＡＢＣＤＥＦＧＨＩＪＫＬＭＮＯＰＱＲＳＴＵＶＷＸ',
      input6: '鈴木　A太郎',
      input7: '摘要１'
    }
  },
  methods: {
    on1: function () {
      alert('工事件名コード参照')
    },
    on2: function () {
      alert('工事件名名称参照')
    },
    on3: function () {
      alert('精算箇所参照')
    }
  }
}
</script>

<style scoped>
.page-style {
  font-size: 12px;
  width: 824px;
  height: 100%;
  margin-left:10px;
  line-height:30px;
  border: 1px solid;
  padding-top: 1px;
}
.row-class {
  height: 30px;
  margin-bottom: 1px;
  margin-left: 1px;
  margin-right: 1px;
}
.lab-class {
  width: 170px;
  background-color: #77cad8;
  line-height: 30px;
  margin-right: 1px;
}
.span-class {
 color: red;
 float: right;
}
</style>
