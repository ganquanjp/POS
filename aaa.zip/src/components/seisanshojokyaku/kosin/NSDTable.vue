<template>
  <div style= "padding-left: 10px; padding-right: 10px; width: 1030px;">
    <div style="position: relative;">
     <span style="font-size: 12px;">10件</span>
    </div>
    <el-table
      :data="tableData"
      height="210"
      border
      :header-row-class-name="headerClassName"
      :row-class-name="tableRowClassName">
      <el-table-column 
        prop="kouban"
        label="NO."
        width="50px">
      </el-table-column>
      <el-table-column label="更新">
        <el-table-column 
          prop="kousin"
          width="45px"
          header-align=center
          :render-header="renderHeader6">
           <template slot-scope="scope">
             <el-checkbox v-model="scope.row.date" />
           </template>
        </el-table-column>
      </el-table-column>
      <el-table-column label="削除">
        <el-table-column 
          prop="sakujyo"
          width="45px"
          header-align=center
          :render-header="renderHeader7">
           <template slot-scope="scope">
             <el-checkbox v-model="scope.row.date2" />
           </template>
        </el-table-column>
      </el-table-column>
      <el-table-column label="固定資産">
        <el-table-column
          width="205px"
          header-align=center
          :render-header="renderHeader1">
          <template slot-scope="scope">
            <el-input v-model="scope.row.koteisisanno" size="mini"><el-button slot="append" style="position: absolute; top: 20px; left: 10px;" size="mini" @click="showModal = true">参照</el-button></el-input>
          </template>
        </el-table-column>
        <el-table-column
          width="225px"
          header-align=center
          :render-header="renderHeader2">
          <template slot-scope="scope">
            <el-input v-model="scope.row.koteisisanmeisyo" size="mini"><el-button slot="append" style="position: absolute; top: 20px; left: 10px;" size="mini" @click="showModal = true">参照</el-button></el-input>
          </template>
        </el-table-column>
        <el-table-column
          width="120px"
          header-align=center
          :render-header="renderHeader3"
          prop="syutokuymd">
        </el-table-column>
        <el-table-column
          width="130px"
          header-align=center
          :render-header="renderHeader4"
          prop="siyoukaisiymd">
        </el-table-column>
        <el-table-column
          width="140px"
          header-align=center
          :render-header="renderHeader5"
          prop="oyakoteisisanno">
        </el-table-column>
        <el-table-column
          prop="edaban"
          label="枝番"
          min-width="50px">
        </el-table-column>
      </el-table-column>
    </el-table>
  </div>
</template>
<script scoped>
  export default {
    methods: {
      headerClassName ({row, rowIndex}) {
        return 'class-header'
      },
      tableRowClassName ({row, rowIndex}) {
        return 'tab-row'
      },
      renderHeader1 (createElement, { column }) {
        return createElement(
          'el-lab',
          [
            '番号',
            createElement('span', {style: 'color: red;'}, '　(必須)')
          ]
        )
      },
      renderHeader2 (createElement, { column }) {
        return createElement(
          'el-lab',
          [
            '名称',
            createElement('span', {style: 'color: red;'}, '　(必須)')
          ]
        )
      },
      renderHeader3 (createElement, { column }) {
        return createElement(
          'el-lab',
          [
            '取得年月日',
            createElement('span', {style: 'color: red;'}, '　(必須)')
          ]
        )
      },
      renderHeader4 (createElement, { column }) {
        return createElement(
          'el-lab',
          [
            '使用開始年月日',
            createElement('span.row.', {style: 'color: red;'}, '　(必須)')
          ]
        )
      },
      renderHeader5 (createElement, { column }) {
        return createElement(
          'el-lab',
          [
            '親固定資産番号',
            createElement('span', {style: 'color: red;'}, '　(必須)')
          ]
        )
      },
      renderHeader6 (createElement, { column }) {
        return createElement(
          'el-checkbox'
        )
      },
      renderHeader7 (createElement, { column }) {
        return createElement(
          'el-checkbox'
        )
      },
      on1: function () {
        alert('固定資産番号参照')
      },
      on2: function () {
        alert('固定資産名称参照')
      }
    },
    data () {
      return {
        tableData: [{
          kouban: '1',
          koteisisanno: '300000000018',
          koteisisanmeisyo: '固定資産名称A18',
          syutokuymd: '2012-07-01',
          siyoukaisiymd: '2012-07-01',
          oyakoteisisanno: '300000000018',
          edaban: ''
        }, {
          kouban: '2',
          koteisisanno: '300000000019',
          koteisisanmeisyo: '固定資産名称A19',
          syutokuymd: '2012-07-01',
          siyoukaisiymd: '2012-07-01',
          oyakoteisisanno: '300000000018',
          edaban: '0001'
        }, {
          kouban: '3',
          koteisisanno: '300000000019',
          koteisisanmeisyo: '固定資産名称A19',
          syutokuymd: '2012-07-01',
          siyoukaisiymd: '2012-07-01',
          oyakoteisisanno: '300000000018',
          edaban: '0001'
        }, {
          kouban: '4',
          koteisisanno: '300000000019',
          koteisisanmeisyo: '固定資産名称A19',
          syutokuymd: '2012-07-01',
          siyoukaisiymd: '2012-07-01',
          oyakoteisisanno: '300000000018',
          edaban: '0001'
        }, {
          kouban: '5',
          koteisisanno: '300000000019',
          koteisisanmeisyo: '固定資産名称A19',
          syutokuymd: '2012-07-01',
          siyoukaisiymd: '2012-07-01',
          oyakoteisisanno: '300000000018',
          edaban: '0001'
        }, {
          kouban: '6',
          koteisisanno: '300000000019',
          koteisisanmeisyo: '固定資産名称A19',
          syutokuymd: '2012-07-01',
          siyoukaisiymd: '2012-07-01',
          oyakoteisisanno: '300000000018',
          edaban: '0001'
        }, {
          kouban: '7',
          koteisisanno: '300000000019',
          koteisisanmeisyo: '固定資産名称A19',
          syutokuymd: '2012-07-01',
          siyoukaisiymd: '2012-07-01',
          oyakoteisisanno: '300000000018',
          edaban: '0001'
        }, {
          kouban: '8',
          koteisisanno: '300000000019',
          koteisisanmeisyo: '固定資産名称A19',
          syutokuymd: '2012-07-01',
          siyoukaisiymd: '2012-07-01',
          oyakoteisisanno: '300000000018',
          edaban: '0001'
        }, {
          kouban: '9',
          koteisisanno: '300000000019',
          koteisisanmeisyo: '固定資産名称A19',
          syutokuymd: '2012-07-01',
          siyoukaisiymd: '2012-07-01',
          oyakoteisisanno: '300000000018',
          edaban: '0001'
        }, {
          kouban: '10',
          koteisisanno: '300000000019',
          koteisisanmeisyo: '固定資産名称A19',
          syutokuymd: '2012-07-01',
          siyoukaisiymd: '2012-07-01',
          oyakoteisisanno: '300000000018',
          edaban: '0001'
        }]
      }
    }
  }
</script>
<style scoped>
</style>
