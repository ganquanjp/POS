<template>
  <div style="padding: 10px; width: 1010px;">
    <el-table
      :data="tableData"
      height="275"
      border
      :header-row-class-name="headerClassName"
      :row-class-name="tableRowClassName">
      <el-table-column 
        prop="kouban"
        label="NO."
        width="50px">
      </el-table-column>
      <el-table-column
        width="185px"
        header-align=center
        :render-header="renderHeader1">
        <template slot-scope="scope">
          <el-input v-model="scope.row.futankasyo" size="mini"><el-button slot="append" style="position: absolute; top: 20px; left: 10px;" size="mini" @click="showModal = true">参照</el-button></el-input>
        </template>
      </el-table-column>
      <el-table-column
        width="225px"
        header-align=center
        :render-header="renderHeader2">
        <template slot-scope="scope">
          <el-input v-model="scope.row.futankasyo" size="mini"><el-button slot="append" style="position: absolute; top: 20px; left: 10px;" size="mini" @click="showModal = true">参照</el-button></el-input>
        </template>
      </el-table-column>
      <el-table-column
        width="120px"
        header-align=center
        :render-header="renderHeader3"
        prop="syutokuymd">
      </el-table-column>
      <el-table-column
        width="130px"
        header-align=center
        :render-header="renderHeader4"
        prop="siyoukaisiymd">
      </el-table-column>
      <el-table-column
        width="140px"
        header-align=center
        :render-header="renderHeader5"
        prop="oyakoteisisanno">
      </el-table-column>
      <el-table-column
        prop="edaban"
        label="枝番"
        min-width="50px">
      </el-table-column>
    </el-table>
  </div>
</template>
<script scoped>
  export default {
    methods: {
      headerClassName ({row, rowIndex}) {
        return 'class-header'
      },
      tableRowClassName ({row, rowIndex}) {
        return 'tab-row'
      },
      renderHeader1 (createElement, { column }) {
        return createElement(
          'el-lab',
          [
            '固定資産番号',
            createElement('span', {style: 'color: red;'}, '　(必須)')
          ]
        )
      },
      renderHeader2 (createElement, { column }) {
        return createElement(
          'el-lab',
          [
            '固定資産名称',
            createElement('span', {style: 'color: red;'}, '　(必須)')
          ]
        )
      },
      renderHeader3 (createElement, { column }) {
        return createElement(
          'el-lab',
          [
            '取得年月日',
            createElement('span', {style: 'color: red;'}, '　(必須)')
          ]
        )
      },
      renderHeader4 (createElement, { column }) {
        return createElement(
          'el-lab',
          [
            '使用開始年月日',
            createElement('span', {style: 'color: red;'}, '　(必須)')
          ]
        )
      },
      renderHeader5 (createElement, { column }) {
        return createElement(
          'el-lab',
          [
            '親固定資産番号',
            createElement('span', {style: 'color: red;'}, '　(必須)')
          ]
        )
      },
      on1: function () {
        alert('固定資産番号参照')
      },
      on2: function () {
        alert('固定資産名称参照')
      }
    },
    data () {
      return {
        tableData: [{
          kouban: '1',
          koteisisanno: '',
          koteisisanmeisyo: '',
          syutokuymd: '',
          siyoukaisiymd: '',
          oyakoteisisanno: '',
          edaban: ''
        }, {
          kouban: '2',
          koteisisanno: '',
          koteisisanmeisyo: '',
          syutokuymd: '',
          siyoukaisiymd: '',
          oyakoteisisanno: '',
          edaban: ''
        }, {
          kouban: '3',
          koteisisanno: '',
          koteisisanmeisyo: '',
          syutokuymd: '',
          siyoukaisiymd: '',
          oyakoteisisanno: '',
          edaban: ''
        }, {
          kouban: '4',
          koteisisanno: '',
          koteisisanmeisyo: '',
          syutokuymd: '',
          siyoukaisiymd: '',
          oyakoteisisanno: '',
          edaban: ''
        }, {
          kouban: '5',
          koteisisanno: '',
          koteisisanmeisyo: '',
          syutokuymd: '',
          siyoukaisiymd: '',
          oyakoteisisanno: '',
          edaban: ''
        }, {
          kouban: '6',
          koteisisanno: '',
          koteisisanmeisyo: '',
          syutokuymd: '',
          siyoukaisiymd: '',
          oyakoteisisanno: '',
          edaban: ''
        }, {
          kouban: '7',
          koteisisanno: '',
          koteisisanmeisyo: '',
          syutokuymd: '',
          siyoukaisiymd: '',
          oyakoteisisanno: '',
          edaban: ''
        }, {
          kouban: '8',
          koteisisanno: '',
          koteisisanmeisyo: '',
          syutokuymd: '',
          siyoukaisiymd: '',
          oyakoteisisanno: '',
          edaban: ''
        }, {
          kouban: '9',
          koteisisanno: '',
          koteisisanmeisyo: '',
          syutokuymd: '',
          siyoukaisiymd: '',
          oyakoteisisanno: '',
          edaban: ''
        }, {
          kouban: '10',
          koteisisanno: '',
          koteisisanmeisyo: '',
          syutokuymd: '',
          siyoukaisiymd: '',
          oyakoteisisanno: '',
          edaban: ''
        }]
      }
    }
  }
</script>
<style scoped>
</style>
