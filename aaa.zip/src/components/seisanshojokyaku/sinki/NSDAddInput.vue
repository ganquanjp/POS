<template>
  <div class="page-style">
    <el-row class="row-class">
      <el-col class="lab-class">　除却予定年月日<span class="span-class">（必須）</span></el-col>
      <el-col style= "width: 120px;">
        <el-input v-model="input1" size="mini" placeholder=""></el-input>
      </el-col>
    </el-row>
    <el-row class="row-class">
      <el-col class="lab-class">　件名（コード／名称）<span class="span-class">（必須）</span></el-col>
      <el-col style= "width: 170px;">
        <el-input v-model="input2" size="mini" placeholder=""></el-input>
      </el-col>
      <el-col :span="1"style="line-height: 30px;">　/</el-col>
      <el-col style= "width: 172px; margin-left:-1px;">
        <el-input v-model="input3" size="mini" placeholder=""></el-input>
      </el-col>
    </el-row>
    <el-row class="row-class">
      <el-col class="lab-class">　精算箇所<span class="span-class">（必須）</span></el-col>
      <el-col style= "width: 364px;">
        <el-input v-model="input4" size="mini"><el-button slot="append" style="position: absolute; top: 20px; left: 10px;" size="mini" @click="showModal = true">参照</el-button></el-input>
      </el-col>
    </el-row>
    <el-row class="row-class">
      <el-col class="lab-class">　登録者氏名<span class="span-class">（必須）</span></el-col>
      <el-col style= "width: 250px;">
        <el-input v-model="input5" size="mini" placeholder=""></el-input>
      </el-col>
    </el-row>
    <el-row class="row-class">
      <el-col class="lab-class">　摘要</el-col>
      <el-col style= "width: 364px;">
        <el-input v-model="input6" size="mini" placeholder=""></el-input>
      </el-col>
    </el-row>
  </div>
</template>

<script>
export default {
  data () {
    return {
      input1: '',
      input2: '',
      input3: '',
      input4: '',
      input5: '',
      input6: ''
    }
  },
  methods: {
    on1: function () {
      alert('件名コード参照')
    },
    on2: function () {
      alert('件名参照')
    },
    on3: function () {
      alert('精算場所参照')
    }
  }
}
</script>

<style scoped>
.page-style {
  font-size: 12px;
  width: 537px;
  height: 100%;
  margin-left:10px;
  line-height:30px;
  border: 1px solid;
  padding-top: 1px;
}
.row-class {
  height: 30px;
  margin-bottom: 1px;
  margin-left: 1px;
  margin-right: 1px;
}
.lab-class {
  width: 170px;
  background-color: #77cad8;
  line-height: 30px;
  margin-right: 1px;
}
.span-class {
 color: red;
 float: right;
}
</style>
