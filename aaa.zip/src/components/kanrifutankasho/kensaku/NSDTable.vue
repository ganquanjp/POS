<template>
  <div style= "padding: 10px;">
    <div style="position: relative;">
     <span style="font-size: 12px;">10件</span>
      <div style="position: absolute; top: -3px; right: 0px;">
        <el-pagination
          @size-change="handleSizeChange"
          @current-change="handleCurrentChange"
          :current-page.sync="currentPage1"
          :page-size="50"
          small
          layout="prev, pager, next"
          prev-text="前へ"
          next-text="次へ"
          :total="150">
        </el-pagination>
      </div>
    </div>
    <el-table style= "padding: -50px;" :data="this.$store.state.tableData" border height=235>
      <el-table-column 
        prop="rowNo"
        sortable
        label="NO."
        width="80px">
      </el-table-column>
      <el-table-column
        prop="kanrikasyo"
        sortable
        label="管理箇所"
        width="120px">
      </el-table-column >
      <el-table-column
        prop="kkikanF"
        sortable
        label="管理箇所適用期間（FROM）"
        width="180px">
      </el-table-column>
      <el-table-column
        prop="kkikanT"
        sortable
        label="管理箇所適用期間（TO）"
        width="160px">
      </el-table-column>
      <el-table-column
        prop="futankasyo"
        sortable
        label="負担箇所"
        width="120px">
      </el-table-column>
      <el-table-column
        prop="fkikanF"
        sortable
        label="負担箇所適用期間（FROM）"
        width="180px">
      </el-table-column>
      <el-table-column
        prop="fkikanT"
        sortable
        label="負担箇所適用期間（TO）"
        min-width="160px">
      </el-table-column>
    </el-table>
  </div>
</template>
<script scoped>
  export default {
    methods: {
      headerClassName ({row, rowIndex}) {
        return 'class-header'
      },
      handleSizeChange (val) {
        console.log(`每页 ${val} 条`)
      },
      handleCurrentChange (val) {
        console.log(`当前页: ${val}`)
      }
    }
  }
</script>
<style scoped>
.el-table .class-header {
  margin-left:15px;
  color: black;
  font-size: 12px;
}
</style>
