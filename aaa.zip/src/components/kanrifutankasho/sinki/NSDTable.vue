<template>
  <div style="padding: 10px;">
    <el-table
      :data="tableData"
      border
      :header-row-class-name="headerClassName"
      >
      <el-table-column 
        prop="kouban"
        label="NO."
        width="50px">
      </el-table-column>
      <el-table-column :render-header="renderHeader1">
        <el-table-column
          min-width="190px"
          label="名称">
          <template slot-scope="scope">
            <el-input v-model="scope.row.kanrikasyo" size="mini"><el-button slot="append" style="position: absolute; top: 20px; left: 10px; padding-top: 5px;" size="mini" @click="showModal = true">参照</el-button></el-input>
          </template>
        </el-table-column>
        <el-table-column 
          prop="kannrikasyotekiyokikanf"
          width="155px"
          label="適用期間（FROM）">
          <template slot-scope="scope">
            <el-date-picker
              v-model="scope.row.value1"
              type="date"
              clearable
              size="mini"
              style="width: 100%;">
            </el-date-picker>
          </template>
        </el-table-column>
        <el-table-column 
          prop="kannrikasyotekiyokikant"
          width="155px"
          label="適用期間（TO）">
          <template slot-scope="scope">
            <el-date-picker
              v-model="scope.row.value1"
              type="date"
              clearable
              size="mini"
              style="width: 100%;">
            </el-date-picker>
          </template>
        </el-table-column>
      </el-table-column>
      <el-table-column :render-header="renderHeader2">
        <el-table-column
          min-width="190px"
          label="名称">
          <template slot-scope="scope">
            <el-input v-model="scope.row.futankasyo" size="mini"><el-button slot="append" style="position: absolute; top: 20px; left: 10px; padding-top: 5px;" size="mini" @click="showModal = true">参照</el-button></el-input>
          </template>
        </el-table-column>
        <el-table-column
          prop="futankasyotekiyokikanf"
          width="155px"
          label="適用期間（FROM）">
          <template slot-scope="scope">
            <el-date-picker
              v-model="scope.row.value1"
              type="date"
              clearable
              size="mini"
              style="width: 100%;">
            </el-date-picker>
          </template>
        </el-table-column>
        <el-table-column
          prop="futankasyotekiyokikant"
          width="155px"
          label="適用期間（TO）">
          <template slot-scope="scope">
            <el-date-picker
              v-model="scope.row.value1"
              type="date"
              clearable
              size="mini"
              style="width: 100%;">
            </el-date-picker>
          </template>
        </el-table-column>
      </el-table-column>
    </el-table>
    <modal v-if="showModal" @close="showModal = false"></modal>
  </div>
</template>
<script scoped>
  import modal from '@/components/common/modal/NSDKanrifutankensaku'
  export default {
    components: { modal },
    methods: {
      headerClassName ({row, rowIndex}) {
        return 'class-header'
      },
      tableRowClassName ({row, rowIndex}) {
        return 'class-row'
      },
      renderHeader1 (createElement, { column }) {
        return createElement(
          'label',
          [
            '管理箇所',
            createElement('span', {style: 'color: red;'}, '　(必須)')
          ]
        )
      },
      renderHeader2 (createElement, { column }) {
        return createElement(
          'label',
          [
            '負担箇所',
            createElement('span', {style: 'color: red;'}, '　(必須)')
          ]
        )
      }
    },
    data () {
      return {
        showModal: false,
        value1: '',
        tableData: [{
          kouban: '01',
          value1: ''
        }, {
          kouban: '02'
        }, {
          kouban: '03'
        }, {
          kouban: '04'
        }, {
          kouban: '05'
        }, {
          kouban: '06'
        }, {
          kouban: '07'
        }, {
          kouban: '08'
        }, {
          kouban: '09'
        }, {
          kouban: '10'
        }]
      }
    }
  }
</script>
<style scoped>
.el-table .class-header {
  color: black;
  font-size: 12px;
}
</style>
