<template>
  <div style="padding: 10px;">
    <div style="position: relative;">
     <span style="font-size: 12px;">10件</span>
    </div>
    <el-table
      :data="tableData"
      border
      :header-row-class-name="headerClassName">
      <el-table-column 
        prop="kouban"
        label="NO."
        width="50px">
      </el-table-column>
      <el-table-column label="更新">
        <el-table-column 
          prop="kousin"
          width="45px"
          header-align=center
          :render-header="renderHeader5">
           <template slot-scope="scope">
             <el-checkbox v-model="scope.row.date" />
           </template>
        </el-table-column>
      </el-table-column>
      <el-table-column label="削除">
        <el-table-column 
          prop="sakujyo"
          width="45px"
          header-align=center
          :render-header="renderHeader6">
           <template slot-scope="scope">
             <el-checkbox v-model="scope.row.date2" />
           </template>
        </el-table-column>
      </el-table-column>
      <el-table-column :render-header="renderHeader1">
        <el-table-column
          min-width="220px"
          label="名称">
          <template slot-scope="scope">
            <el-input v-model="scope.row.kanrikasyo" size="mini"><el-button slot="append" style="position: absolute; top: 20px; left: 10px;" size="mini" @click="showModal = true">参照</el-button></el-input>
          </template>
        </el-table-column>
        <el-table-column 
          prop="kannrikasyotekiyokikanf"
          width="110px"
          :render-header="renderHeader3">
        </el-table-column>
        <el-table-column 
          prop="kannrikasyotekiyokikant"
          width="95px"
          :render-header="renderHeader4">
        </el-table-column>
      </el-table-column>
      <el-table-column :render-header="renderHeader2">
        <el-table-column
          min-width="220px"
          label="名称">>
          <template slot-scope="scope">
            <el-input v-model="scope.row.futankasyo" size="mini"><el-button slot="append" style="position: absolute; top: 20px; left: 10px;" size="mini" @click="showModal = true">参照</el-button></el-input>
          </template>
        </el-table-column>
        <el-table-column
          prop="futankasyotekiyokikanf"
          width="110px"
          :render-header="renderHeader3">
        </el-table-column>
        <el-table-column
          prop="futankasyotekiyokikant"
          width="95px"
          :render-header="renderHeader4">
        </el-table-column>
      </el-table-column>
    </el-table>
    <modal v-if="showModal" @close="showModal = false"></modal>
  </div>
</template>
<script scoped>
  import modal from '@/components/common/modal/NSDKanrifutankensaku'
  export default {
    components: { modal },
    methods: {
      headerClassName ({row, rowIndex}) {
        return 'class-header'
      },
      renderHeader1 (createElement, { column }) {
        return createElement(
          'label',
          [
            '管理箇所',
            createElement('span', {style: 'color: red;'}, '　(必須)')
          ]
        )
      },
      renderHeader2 (createElement, { column }) {
        return createElement(
          'label',
          [
            '負担箇所',
            createElement('span', {style: 'color: red;'}, '　(必須)')
          ]
        )
      },
      renderHeader3 (createElement, { column }) {
        return createElement(
          'label',
          [
            '適用期間', createElement('br'), '（FROM）'
          ]
        )
      },
      renderHeader4 (createElement, { column }) {
        return createElement(
          'label',
          [
            '適用期間', createElement('br'), '（TO）'
          ]
        )
      },
      renderHeader5 (createElement, { column }) {
        return createElement(
          'el-checkbox'
        )
      },
      renderHeader6 (createElement, { column }) {
        return createElement(
          'el-checkbox'
        )
      }
    },
    data () {
      return {
        showModal: false,
        tableData: [{
          kouban: '01',
          kanrikasyo: '総務部　一括',
          kannrikasyotekiyokikanf: '2011-10-12',
          kannrikasyotekiyokikant: '2099-12-31',
          futankasyo: '経営管理部　本社経理',
          futankasyotekiyokikanf: '2011-10-12',
          futankasyotekiyokikant: '2099-12-31'
        }, {
          kouban: '02',
          kanrikasyo: '総務部　一括',
          kannrikasyotekiyokikanf: '2011-10-13',
          kannrikasyotekiyokikant: '2099-12-31',
          futankasyo: '経営管理部　中央Ｃ',
          futankasyotekiyokikanf: '2011-10-13',
          futankasyotekiyokikant: '2099-12-31'
        }, {
          kouban: '03',
          kanrikasyo: '総務部　一括',
          kannrikasyotekiyokikanf: '2011-10-14',
          kannrikasyotekiyokikant: '2099-12-31',
          futankasyo: '経営管理部　第4Ｃ',
          futankasyotekiyokikanf: '2011-10-14',
          futankasyotekiyokikant: '2099-12-31'
        }, {
          kouban: '04',
          kanrikasyo: '総務部　一括',
          kannrikasyotekiyokikanf: '2011-10-15',
          kannrikasyotekiyokikant: '2099-12-31',
          futankasyo: '経営管理部　本社経理',
          futankasyotekiyokikanf: '2011-10-15',
          futankasyotekiyokikant: '2099-12-31'
        }, {
          kouban: '05',
          kanrikasyo: '総務部　一括',
          kannrikasyotekiyokikanf: '2011-10-16',
          kannrikasyotekiyokikant: '2099-12-31',
          futankasyo: '経営管理部　本社経理',
          futankasyotekiyokikanf: '2011-10-16',
          futankasyotekiyokikant: '2099-12-31'
        }, {
          kouban: '06',
          kanrikasyo: '総務部　一括',
          kannrikasyotekiyokikanf: '2011-10-17',
          kannrikasyotekiyokikant: '2099-12-31',
          futankasyo: '経営管理部　本社経理',
          futankasyotekiyokikanf: '2011-10-17',
          futankasyotekiyokikant: '2099-12-31'
        }, {
          kouban: '07',
          kanrikasyo: '総務部　一括',
          kannrikasyotekiyokikanf: '2011-10-18',
          kannrikasyotekiyokikant: '2099-12-31',
          futankasyo: '経営管理部　本社経理',
          futankasyotekiyokikanf: '2011-10-18',
          futankasyotekiyokikant: '2099-12-31'
        }, {
          kouban: '08',
          kanrikasyo: '総務部　一括',
          kannrikasyotekiyokikanf: '2011-10-19',
          kannrikasyotekiyokikant: '2099-12-31',
          futankasyo: '経営管理部　本社経理',
          futankasyotekiyokikanf: '2011-10-19',
          futankasyotekiyokikant: '2099-12-31'
        }, {
          kouban: '09',
          kanrikasyo: '総務部　一括',
          kannrikasyotekiyokikanf: '2011-10-20',
          kannrikasyotekiyokikant: '2099-12-31',
          futankasyo: '経営管理部　本社経理',
          futankasyotekiyokikanf: '2011-10-20',
          futankasyotekiyokikant: '2099-12-31'
        }, {
          kouban: '10',
          kanrikasyo: '総務部　一括',
          kannrikasyotekiyokikanf: '2011-10-21',
          kannrikasyotekiyokikant: '2099-12-31',
          futankasyo: '経営管理部　本社経理',
          futankasyotekiyokikanf: '2011-10-21',
          futankasyotekiyokikant: '2099-12-31'
        }]
      }
    }
  }
</script>
<style scoped>
</style>
