<template>
  <div>
    <div class="div-style-1">
      <div class="div-style-2"><p>新 工 事 精 算 シ ス テ ム</p></div>
    </div>
    <div style="padding-left: 15px;margin-top: 5px;">
      <span style="font-size: 26px;">ログイン</span>
    </div>
    <div>
      <div class="info-style"><hr/><label style="padding-left: 5px;">{{ message }}</label><hr/></div>
    </div>
    <div class="div-style-3">
      <el-form :model="loginForm" status-icon ref="loginForm" width="100px" label-width="80px" label-position="left" class="class-loginForm">
        <el-form-item label="ユーザーID" prop="userId">
          <el-input type="text" style= "width: 240px;" v-model="loginForm.userId"></el-input>
        </el-form-item>
        <el-form-item label="パスワード" prop="pwd">
          <el-input type="text" style= "width: 240px;" v-model="loginForm.pwd"></el-input>
        </el-form-item>
        <el-form-item style="padding-left: 170px;">
          <el-button size="mini" @click.native="login" type="primary">ログイン</el-button>
        </el-form-item>
      </el-form>
    </div>
  </div>
</template>

<script>
export default {
  data () {
    return {
      input1: '',
      input2: '',
      message: 'ユーザーIDまたは、パスワードに誤りがあります。',
      loginForm: {
        userId: ''
      }
    }
  },
  methods: {
    login: function () {
      this.$router.push({name: 'nsdmenu'})
    }
  }
}
</script>

<style scoped>
.div-style-1 {
  background-color: #B3C0D1;
  color: #333;
  text-align: center;
  line-height: 0px;
  padding: 2px;
  height: 70px;
}
.div-style-2 {
  sition: relative;
  border-style:groove;
  color:white;
  text-align:center;
  margin:0px;
  height:65px;
  font-size:30px;
}
.div-style-3 {
  padding-top: 100px;
  text-align: center;
}
.info-style {
  vertical-align: middle;
  color : red;
  font-size: 12px;
  width:100%;
}
.class-loginForm {
  display: inline-block;
}
</style>

