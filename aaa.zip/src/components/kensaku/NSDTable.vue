<template>
  <el-table
    :data="tableData"
    height="250"
    border
    style="width: 100%">
    <el-table-column v-for="(s1, key) in tableData"
      :key="s1.aaa.kouban"
      label="NO."
    >
      <template slot-scope="scope" v-for="(s2, key) in s1.aaa">{{ s2.kouban }}</template>
    </el-table-column>
<!--
    <el-table-column
      prop="koujikodo"
      label="工事件名コード"
      >
    </el-table-column>
    <el-table-column
      prop="koujikenme"
      label="工事件名"
      >
    </el-table-column>
    <el-table-column
      prop="seisankasyo"
      label="精算箇所"
       >
    </el-table-column v-for="(s2, key2) in tableData">
    <el-table-column
      prop="s1.seisansyono"
      label="精算書番号"
       >
    </el-table-column v-for="(s3, key3) in tableData">
    <el-table-column
      prop="s1.siyokaisiymd"
      label="使用開始年月日"
       >
    </el-table-column>

    <el-table-column
      prop="aaa.bbb.tourokusyasimei"
      label="登録者氏名"
       >
    </el-table-column>
    <el-table-column
      prop="aaa.bbb.koteisisanno"
      label="固定資産番号"
       >
    </el-table-column>
    <el-table-column
      prop="aaa.bbb.koteisisanmeisyo"
      label="固定資産名称"
       >
    </el-table-column>
        <el-table-column
      prop="aaa.bbb.syutokuymd"
      label="取得年月日"
       >
    </el-table-column>
    <el-table-column
      prop="aaa.bbb.address"
      label="設置場所名称">
    </el-table-column>
-->
  </el-table>
</template>

<script>
  export default {
    data () {
      return {
        tableData: [{
          koujikodo: '0C028002',
          koujikenme: '工事件名Ａ',
          seisankasyo: '事業推進本部情報システム部',
          aaa: [{
            kouban: '000',
            seisansyono: '000000000000012',
            siyokaisiymd: '2011-04-01',
            bbb: [{
              tourokusyasimei: 'AA AA',
              koteisisanno: '300000000065',
              koteisisanmeisyo: '固定資産名称ＡＡＡＡ',
              syutokuymd: '2011-03-01',
              address: 'ＣＣ１'
            }]
          }, {
            kouban: '001',
            seisansyono: '000000000000012',
            siyokaisiymd: '2011-04-01',
            bbb: [{
              tourokusyasimei: 'AA AA',
              koteisisanno: '300000000065',
              koteisisanmeisyo: '固定資産名称ＡＡＡＡ',
              syutokuymd: '2011-03-01',
              address: 'ＣＣ１'
            }]
          }]
        }]
      }
    },
    methods: {
      DataFormatter (p) {
      /*
        var dayList = row.dayList
        var ix = this.days.indexOf(column.label)
        if (ix==-1 || ix >= dayList.length) return
          return row.dayList[ix]
          */
        alert(p.aaa.length)
        alert(p.aaa[0].kouban)
        alert(p.aaa[1].kouban)
        return p.aaa[0].kouban
      }
    }
  }
</script>
