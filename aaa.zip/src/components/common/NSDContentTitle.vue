<template>
  <div>
    <el-row v-if="titlename!=''">
      <el-col>
        <span class="title-style">{{ titlename }}</span><hr/>
      </el-col>
    </el-row>
    <el-row v-if="message!=''">
      <el-col>
       <div class="info-style"><label style="padding-left: 5px;">{{ message }}</label><hr/></div>
      </el-col>
    </el-row>
  </div>
</template>

<script>
export default {
  props: ['titlename', 'message']
}
</script>

<style scoped>
.title-style {
  font-size: 20px;
  padding-left: 5px;
}
.info-style {
  vertical-align: middle;
  color : red;
  font-size: 12px;
  width:100%;
}
</style>
