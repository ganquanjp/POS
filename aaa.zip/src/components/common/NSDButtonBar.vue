<template>
  <div style= "padding: 10px;">
    <el-row>
      <el-col style="width:300px">
        <el-button
          v-for="(btn, key) in buttons"
          v-if="btn.show"
          class="button-style"
          size="mini"
          v-bind:disabled=btn.disabled
          v-bind:type="btn.primary ? 'primary' : '' "
          v-bind:key="key"
          @click="btnClick(btn.action, btn.url, btn.backUrl, btn.msg)">
          {{ btn.name }}
        </el-button>
      </el-col>
    </el-row>
  </div>
</template>

<script>
export default {
  props: ['buttons', 'formItem'],
  methods: {
    // ボタン押下
    btnClick: function (action, url, backUrl, msg) {
      if (action === 'post') {
        this.funcHttpPost(url, this.formItem)
      } else if (action === 'clear') {
        this.funcClear()
      } else if (action === 'back') {
        this.$router.push(backUrl)
      } else if (action === 'popup') {
        this.$confirm(msg, '確認', {
          confirmButtonText: '確認',
          cancelButtonText: 'キャンセル',
          type: 'info '
        }).then(() => {
          this.funcHttpPost(url, this.formItem)
        }).catch(() => {
          this.$message({
            type: 'info',
            message: 'キャンセルしました。'
          })
        })
      } else {
        console.log('action null ok!')
      }
    }
  }
}
</script>

<style scoped>
.button-style {
  width: 80px;
}
</style>
