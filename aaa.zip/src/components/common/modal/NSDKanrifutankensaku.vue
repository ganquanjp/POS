<template>
  <transition name="modal">
    <div class="modal-mask">
      <div class="modal-wrapper">
        <div class="modal-container">
          <div class="close-btn-style">
            <el-button type="text" @click="$emit('close')" size="mini"><i class="close icon"></i></el-button>
          </div>
          <div>
            <el-row>
              <el-col>
                <nsd-content-title v-bind:titlename="titlename" v-bind:message="message"></nsd-content-title>
              </el-col>
            </el-row>
            <el-row>
              <el-col>
                <nsd-search-input></nsd-search-input>
              </el-col>
            </el-row>
            <el-row>
              <el-col>
                <nsd-button-bar v-bind:buttons="buttonName" v-bind:clicks="btnClick"></nsd-button-bar>
              </el-col>
            </el-row>
            <el-row>
              <el-col>
                <div>
                  <div style="position: relative; padding-top: 10px;">
                   <span style="font-size: 12px;">10件</span>
                    <div style="position: absolute; top: 5px; right: 0px;">
                      <el-pagination
                        @size-change="handleSizeChange"
                        @current-change="handleCurrentChange"
                        :current-page.sync="currentPage1"
                        :page-size="50"
                        small
                        layout="prev, pager, next"
                        prev-text="前へ"
                        next-text="次へ"
                        :total="150">
                      </el-pagination>
                    </div>
                  </div>
                  <el-table style= "padding: -50px;" :data="this.$store.state.tableData" border height=235>
                    <el-table-column 
                      prop="rowNo" 
                      sortable label="NO." 
                      width="70px">
                    </el-table-column>
                    <el-table-column 
                      prop="kanrikasyocd" 
                      sortable 
                      label="管理箇所コード" 
                      min-width="95px">
                        <template slot-scope="scope">
                          <el-button type="text" @click="$emit('close')">{{scope.row.kanrikasyocd}}</el-button>
                        </template>
                    </el-table-column >
                    <el-table-column
                      prop="kanrikasyo"
                      sortable
                      label="管理箇所名称"
                      min-width="90px">
                    </el-table-column >
                    <el-table-column
                      prop="kkikanF"
                      sortable
                      label="管理箇所適用期間（FROM）"
                      min-width="160px">
                    </el-table-column>
                    <el-table-column
                      prop="kkikanT"
                      sortable
                      label="管理箇所適用期間（TO）"
                      min-width="140px">
                    </el-table-column>
                    <el-table-column
                      prop="futankasyocd" 
                      sortable
                      label="負担箇所コード"
                      min-width="95px">
                        <template slot-scope="scope">
                          <el-button type="text" @click="$emit('close')">{{scope.row.futankasyocd}}</el-button>
                        </template>
                    </el-table-column>
                    <el-table-column
                      prop="futankasyo"
                      sortable
                      label="負担箇所名称"
                      min-width="90px">
                    </el-table-column>
                    <el-table-column
                      prop="fkikanF"
                      sortable
                      label="負担箇所適用期間（FROM）"
                      min-width="160px">
                    </el-table-column>
                    <el-table-column
                      prop="fkikanT"
                      sortable
                      label="負担箇所適用期間（TO）"
                      min-width="140px">
                    </el-table-column>
                  </el-table>
                </div>
              </el-col>
            </el-row>
          </div>
        </div>
      </div>
    </div>
  </transition>
</template>

<script>
import NsdContentTitle from '@/components/common/NSDContentTitle.vue'
import NSDSearchInput from '@/components/common/modal/kanrifutankensaku/NSDSearchInput.vue'

export default {
  components: {
    'nsd-content-title': NsdContentTitle,
    'nsd-search-input': NSDSearchInput
  },
  methods: {
    headerClassName ({row, rowIndex}) {
      return 'class-header'
    },
    handleSizeChange (val) {
      console.log(`每页 ${val} 条`)
    },
    handleCurrentChange (val) {
      console.log(`当前页: ${val}`)
    },
    btnClick: function (item) {
      alert(item + 'ボタンをクリックします。')
    }
  },
  data () {
    return {
      message: '　',
      currentPage1: 5
    }
  },
  computed: {
    titlename: function () {
      return '【管理箇所・負担箇所紐付】検索'
    }
  }
}
</script>

<style scoped>
.el-table .class-header {
  color: black;
  font-size: 12px;
  width: 100%;
}
.modal-mask {
  position: fixed;
  z-index: 9998;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background-color: rgba(0, 0, 0, .5);
  display: table;
  transition: opacity .3s ease;
}
.modal-wrapper {
  display: table-cell;
  vertical-align: middle;
}
.modal-container {
  position: relative;
  width: 1170px;
  height: 595px;
  margin: 0 auto;
  margin-top: 10px;
  padding: 10px 15px;
  background-color: #fff;
  border-radius: 2px;
  box-shadow: 0 2px 8px rgba(0, 0, 0, .33);
  transition: all .3s ease;
}
.modal-leave-active .modal-container {
  -webkit-transform: scale(1.1);
  transform: scale(1.1);
}
.close-btn-style {
  position: absolute;
  right: 0px;
  top: 0px;
  padding: 0px;
}
</style>
