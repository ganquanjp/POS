<template>
  <div class="page-style">
    <el-row>
      <el-col>
        <nsd-content-title v-bind:titlename="titlename" v-bind:message="message"></nsd-content-title>
      </el-col>
    </el-row>
    <el-row>
      <el-col>
        <nsd-move-button-bar></nsd-move-button-bar>
      </el-col>
    </el-row>
    <el-row>
      <el-col>
        <nsd-exe-button-bar></nsd-exe-button-bar>
      </el-col>
    </el-row>
    <el-row>
      <el-col>
        <nsd-search-input></nsd-search-input>
      </el-col>
    </el-row>
    <el-row>
      <el-col>
        <nsd-table-bar></nsd-table-bar>
      </el-col>
    </el-row>
    <el-row>
      <el-col>
        <nsd-exe-button-bar></nsd-exe-button-bar>
      </el-col>
    </el-row>
  </div>
</template>

<script>
import NsdContentTitle from '@/components/common/NSDContentTitle.vue'
import NSDMoveButtonBar from '@/components/syutoku/kensaku/NSDMoveButtonBar.vue'
import NSDExeButtonBar from '@/components/syutoku/kensaku/NSDExeButtonBar.vue'
import NSDSearchInput from '@/components/syutoku/kensaku/NSDSearchInput.vue'
import NSDTable from '@/components/syutoku/kensaku/NSDTable.vue'

export default {
  components: {
    'nsd-content-title': NsdContentTitle,
    'nsd-move-button-bar': NSDMoveButtonBar,
    'nsd-exe-button-bar': NSDExeButtonBar,
    'nsd-search-input': NSDSearchInput,
    'nsd-table-bar': NSDTable

  },
  data () {
    return {
      message: '検索キーを入力してください。'
    }
  },
  computed: {
    titlename: function () {
      if (this.$route.params.id === 't-search') {
        return '【精算書登録】検索'
      } else if (this.$route.params.id === 's-search') {
        return '【取得】検索'
      } else {
        return '未実装画面'
      }
    }
  }
}
</script>

<style scoped>
.page-style {
  margin-left: 15px;
}
</style>
