<template>
  <div class="page-style">
    <el-row class="row-class">
      <el-col class="lab-class">　経理否認理由</el-col>
      <el-col style= "width: 303px;">
        <el-input v-model="input1" size="mini" :disabled="true" />
      </el-col>
    </el-row>
  </div>
</template>

<script>
export default {
  data () {
    return {
      input1: '○○に誤りがあります。'
    }
  }
}
</script>

<style scoped>
.page-style {
  font-size: 12px;
  width: 476px;
  height: 100%;
  margin-left:10px;
  line-height:30px;
  border: 1px solid;
  padding-top: 1px;
}
.row-class {
  height: 30px;
  margin-bottom: 1px;
  margin-left: 1px;
  margin-right: 1px;
}
.lab-class {
  width: 170px;
  background-color: #77cad8;
  line-height: 30px;
  margin-right: 1px;
}
</style>
