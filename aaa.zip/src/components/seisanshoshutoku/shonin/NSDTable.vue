<template>
  <div style= "padding-left: 10px; padding-right: 10px;">
    <div style="position: relative;">
     <span style="font-size: 12px;">10件</span>
      <div style="position: absolute; top: -3px; right: 0px;">
        <el-pagination
          @size-change="handleSizeChange"
          @current-change="handleCurrentChange"
          :current-page.sync="currentPage1"
          :page-size="50"
          small
          layout="prev, pager, next"
          prev-text="前へ"
          next-text="次へ"
          :total="150">
        </el-pagination>
      </div>
    </div>
    <el-table style= "padding: -50px;" :data="this.$store.state.tableData" border height=235>
      <el-table-column
        sortable
        prop="rowNo"
        label="NO."
        width="70px">
      </el-table-column>
      <el-table-column
        sortable
        prop="seisanShoNo"
        label="精算書番号"
        width="150px">
        <template slot-scope="scope">
          <el-button type="text" size="medium" @click="move(scope.row.rowNo)">{{scope.row.seisanShoNo}}</el-button>
        </template>
      </el-table-column >
      <el-table-column
        sortable
        prop="soshikiRenRyakuNm"
        label="精算箇所"
        >
      </el-table-column>
      <el-table-column
        sortable
        prop="siyoStartYmd"
        label="使用開始年月日"
        width="120px">
      </el-table-column>
      <el-table-column
        sortable
        prop="shutokuKagakuGokei"
        label="取得価額合計"
        width="150px"
        header-align=left
        align= right>
      </el-table-column>
      <el-table-column
        sortable
        prop="shoninJotai"
        label="承認状態"
        min-width="100px">
      </el-table-column>
      <el-table-column
        sortable
        prop="kenmeiCd"
        label="工事件名コード"
        width="120px">
      </el-table-column>
      <el-table-column
        sortable
        prop="kenmeiNm"
        label="工事件名"
        >
      </el-table-column>
    </el-table>
  </div>
</template>
<script scoped>
  export default {
    created: function () {
      this.$store.state.tableData = ''
    },
    methods: {
      move: function (rowNo) {
        this.funcHttpPost('/seisanshoShonin-selectBySeisanShoNo', this.$store.state.currentPageData[rowNo - 1], 'nsdstkshoninshokai')
      },
      headerClassName ({row, rowIndex}) {
        return 'class-header'
      },
      handleSizeChange (val) {
        console.log(`每页 ${val} 条`)
      },
      handleCurrentChange (val) {
        console.log(`当前页: ${val}`)
      }
    }
  }
</script>
<style scoped>
</style>
