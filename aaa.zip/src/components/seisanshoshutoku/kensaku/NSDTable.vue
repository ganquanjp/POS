<template>
  <div style= "padding-left: 10px; padding-right: 10px;">
    <div style="position: relative;">
     <span style="font-size: 12px;">10件</span>
      <div style="position: absolute; top: -3px; right: 0px;">
        <el-pagination
          @size-change="handleSizeChange"
          @current-change="handleCurrentChange"
          :current-page.sync="this.$store.state.currentPage"
          :page-size="50"
          small
          layout="prev, pager, next"
          prev-text="前へ"
          next-text="次へ"
          :total="150">
        </el-pagination>
      </div>
    </div>
    <el-table style= "padding: -50px;" :data="this.$store.state.tableData" border height=235>
      <el-table-column
        sortable
        prop="rowNo"
        label="NO."
        width="60px">
      </el-table-column>
      <el-table-column
        sortable
        prop="seisanShoId"
        label="精算書番号"
        width="120px">
      </el-table-column >
      <el-table-column
        sortable
        prop="soshikiNm"
        label="精算箇所"
        width="100px">
      </el-table-column>
      <el-table-column
        sortable
        prop="siyoStartYMDFrom"
        label="使用開始年月日"
        width="120px">
      </el-table-column>
      <el-table-column
        sortable
        prop="torokushaName"
        label="登録者氏名"
        width="100px">
      </el-table-column>
      <el-table-column
        sortable
        label="固定資産番号"
        width="105px">
          <template slot-scope="scope">
            <el-button type="text" @click="move(scope.row.rowNo)">{{scope.row.koteiShisanNo}}</el-button>
          </template>
      </el-table-column>
      <el-table-column
        sortable
        prop="koteiShisanName"
        label="固定資産名称"
        width="225px">
      </el-table-column>
      <el-table-column
        sortable
        prop="shutokuYMDFrom"
        label="取得年月日"
        width="100px">
      </el-table-column>
      <el-table-column
        sortable
        prop="settiBashoName"
        label="設置場所名称"
        width="120px">
      </el-table-column>
      <el-table-column
        sortable
        prop="kenmeiCd"
        label="工事件名コード"
        width="120px">
      </el-table-column>
      <el-table-column
        sortable
        prop="kenmeiNm"
        label="工事件名"
        width="100px">
      </el-table-column>
      <el-table-column
        sortable
        prop="kanriSoshikiCd"
        label="工事担当箇所"
        width="120px">
      </el-table-column>
      <el-table-column
        sortable
        prop="kojiTantoUserNm"
        label="工事担当者"
        width="100px">
      </el-table-column>
    </el-table>
  </div>
</template>
<script scoped>
  export default {
    data () {
      return {
        formItem: {
          seisanShoId: '',
          koteiShisanId: ''
        }
      }
    },
    methods: {
      move: function (row) {
        this.formItem.seisanShoId = this.$store.state.tableData[row - 1].seisanShoId
        this.formItem.koteiShisanId = this.$store.state.tableData[row - 1].koteiShisanId
        this.funcHttpPost('/seisanshoShutoku-selectByKey', this.formItem, 'nsdstkshokai')
      },
      handleSizeChange (val) {
        console.log(`${val} 件/ページ`)
      },
      handleCurrentChange (val) {
        console.log(`${val}ページ目`)
      }
    }
  }
</script>
<style scoped>
</style>
