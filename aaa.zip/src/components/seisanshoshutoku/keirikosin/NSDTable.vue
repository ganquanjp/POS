<template>
  <div style= "padding-left: 10px; padding-top: 10px;">
    <div style="position: relative;">
     <span style="font-size: 12px;">10件</span>
      <div style="position: absolute; top: -3px; right: 0px;">
        <el-pagination
          @size-change="handleSizeChange"
          @current-change="handleCurrentChange"
          :current-page.sync="currentPage1"
          :page-size="50"
          small
          layout="prev, pager, next"
          prev-text="前へ"
          next-text="次へ"
          :total="150">
        </el-pagination>
      </div>
    </div>
    <el-table
      :data="tableData"
      border
      :header-row-class-name="headerClassName">
      <el-table-column 
        prop="kouban"
        label="NO."
        width="48px">
      </el-table-column>
      <el-table-column
        type="selection"
        width= "35px"
        align=center>
      </el-table-column>
      <el-table-column
        prop="kojikenmeino"
        label="工事件名コード"
        width="110px">
      </el-table-column>
      <el-table-column
        prop="kojikenmei"
        label="工事件名"
        width="90px">
      </el-table-column>
      <el-table-column
        prop="seisankasho"
        label="精算箇所"
        width="200px">
      </el-table-column>
      <el-table-column
        prop="seisanshono"
        label="精算書番号"
        width="140px">
      </el-table-column>
      <el-table-column
        prop="shorino"
        label="処理No"
        width="70px">
      </el-table-column>
      <el-table-column
        prop="syutokukagakugokei"
        label="取得価額合計"
        width="100px"
        header-align=left
        align=right>
      </el-table-column>
      <el-table-column
        :render-header="renderHeader"
        width="150px">
          <template slot-scope="scope">
            <el-select v-model="scope.row.shoninjyotai" size="mini" style="width: 142px;">
              <el-option
                v-for="item in options"
                :key="item.value"
                :label="item.label"
                :value="item.value">
              </el-option>
            </el-select>
          </template>
      </el-table-column >
      <el-table-column
        label="経理否認理由"
        min-width="100px">
          <template slot-scope="scope">
            <el-input v-model="scope.row.keirihininriyu" size="mini"></el-input>
          </template>
      </el-table-column>
    </el-table>
  </div>
</template>
<script scoped>
  export default {
    methods: {
      headerClassName ({row, rowIndex}) {
        return 'class-header'
      },
      handleSizeChange (val) {
        console.log(`每页 ${val} 条`)
      },
      handleCurrentChange (val) {
        console.log(`当前页: ${val}`)
      },
      renderHeader (createElement, { column }) {
        return createElement(
          'el-lab',
          [
            '承認状態',
            createElement('span', {style: 'color: red;'}, '　　(必須)')
          ]
        )
      }
    },
    data () {
      return {
        options: [{value: '1', label: '未承認'}, {value: '2', label: '承認済'}, {value: '3', label: '経理承認済'}, {value: '4', label: '経理否認'}],
        currentPage1: 1,
        tableData: [{
          kouban: '1',
          kousin: '01110002',
          kojikenmeino: '01110002',
          kojikenmei: '工事件名Ｂ',
          seisankasho: '事業推進本部 情報システム部',
          seisanshono: '000000000000014',
          shorino: '728',
          syutokukagakugokei: '12,000円',
          shoninjyotai: '1',
          keirihininriyu: ''
        }, {
          kouban: '2',
          kojikenmeino: '01110002',
          kojikenmei: '工事件名Ｆ',
          seisankasho: '事業推進本部 情報システム部',
          seisanshono: '000000000000015',
          shorino: '742',
          siyoukaisiymd: '2012-04-30',
          syutokukagakugokei: '24,000円',
          shoninjyotai: '2',
          keirihininriyu: ''
        }, {
          kouban: '3',
          kojikenmeino: '01110002',
          kojikenmei: '工事件名Ｆ',
          seisankasho: '事業推進本部 情報システム部',
          seisanshono: '000000000000015',
          shorino: '742',
          siyoukaisiymd: '2012-04-30',
          syutokukagakugokei: '24,000円',
          shoninjyotai: '3',
          keirihininriyu: ''
        }, {
          kouban: '4',
          kojikenmeino: '01110002',
          kojikenmei: '工事件名Ｆ',
          seisankasho: '事業推進本部 情報システム部',
          seisanshono: '000000000000015',
          shorino: '742',
          siyoukaisiymd: '2012-04-30',
          syutokukagakugokei: '24,000円',
          shoninjyotai: '1',
          keirihininriyu: ''
        }, {
          kouban: '5',
          kojikenmeino: '01110002',
          kojikenmei: '工事件名Ｆ',
          seisankasho: '事業推進本部 情報システム部',
          seisanshono: '000000000000015',
          shorino: '742',
          siyoukaisiymd: '2012-04-30',
          syutokukagakugokei: '24,000円',
          shoninjyotai: '1',
          keirihininriyu: ''
        }, {
          kouban: '6',
          kojikenmeino: '01110002',
          kojikenmei: '工事件名Ｆ',
          seisankasho: '事業推進本部 情報システム部',
          seisanshono: '000000000000015',
          shorino: '742',
          siyoukaisiymd: '2012-04-30',
          syutokukagakugokei: '24,000円',
          shoninjyotai: '2',
          keirihininriyu: ''
        }, {
          kouban: '7',
          kojikenmeino: '01110002',
          kojikenmei: '工事件名Ｆ',
          seisankasho: '事業推進本部 情報システム部',
          seisanshono: '000000000000015',
          shorino: '742',
          siyoukaisiymd: '2012-04-30',
          syutokukagakugokei: '24,000円',
          shoninjyotai: '2',
          keirihininriyu: ''
        }, {
          kouban: '8',
          kojikenmeino: '01110002',
          kojikenmei: '工事件名Ｆ',
          seisankasho: '事業推進本部 情報システム部',
          seisanshono: '000000000000015',
          shorino: '742',
          siyoukaisiymd: '2012-04-30',
          syutokukagakugokei: '24,000円',
          shoninjyotai: '3',
          keirihininriyu: ''
        }, {
          kouban: '9',
          kojikenmeino: '01110002',
          kojikenmei: '工事件名Ｆ',
          seisankasho: '事業推進本部 情報システム部',
          seisanshono: '000000000000015',
          shorino: '742',
          siyoukaisiymd: '2012-04-30',
          syutokukagakugokei: '24,000円',
          shoninjyotai: '3',
          keirihininriyu: ''
        }, {
          kouban: '10',
          kojikenmeino: '01110002',
          kojikenmei: '工事件名Ｆ',
          seisankasho: '事業推進本部 情報システム部',
          seisanshono: '000000000000015',
          shorino: '742',
          siyoukaisiymd: '2012-04-30',
          syutokukagakugokei: '24,000円',
          shoninjyotai: '2',
          keirihininriyu: ''
        }]
      }
    }
  }
</script>
<style scoped>
</style>
