<template>
  <div>
    <div class="page-style">
      <el-row class="row-class">
        <el-col class="lab-class">　精算書番号</el-col>
        <el-col style= "width: 160px;">
          <el-input v-model="formItem.seisanShoNo" size="mini"></el-input>
        </el-col>
      </el-row>
      <el-row class="row-class">
        <el-col class="lab-class">　使用開始年月日</el-col>
        <el-col style= "width: 140px;">
          <el-date-picker
            v-model="formItem.siyoStartYmdFrom"
            size="mini"
            style="width: 140px;"
            type="date">
          </el-date-picker>
        </el-col>
        <el-col :span="1"style="line-height: 25px; margin-left: 5px; margin-right: -5px;">－</el-col>
        <el-col style= "width: 140px;">
          <el-date-picker
            v-model="formItem.siyoStartYmdTo"
            size="mini"
            style="width: 140px;"
            type="date">
          </el-date-picker>
        </el-col>
      </el-row>
      <el-row class="row-class">
        <el-col class="lab-class">　承認状態</el-col>
        <el-col style= "width: 160px;">
          <el-select v-model="formItem.shoninSattus" size="mini">
            <el-option
              v-for="item in item1"
              :key="item.value1"
              :label="item.label1"
              :value="item.value1">
           </el-option>
         </el-select>
        </el-col>
      </el-row>
      <el-row class="row-class">
        <el-col class="lab-class">　工事件名</el-col>
        <el-col style= "width: 240px;">
          <el-input v-model="formItem.kenmeiNm" size="mini"></el-input>
        </el-col>
      </el-row>
    </div>
    <el-row>
      <el-col>
        <nsd-button-bar v-bind:buttons="buttonName" v-bind:formItem="formItem"></nsd-button-bar>
      </el-col>
    </el-row>
  </div>
</template>

<script>
import NSDButtonBar from '@/components/common/NSDButtonBar.vue'

export default {
  components: {
    'nsd-button-bar': NSDButtonBar
  },
  data () {
    return {
      buttonName: [
        {name: '検　索', primary: true, show: true, action: 'post', url: '/seisanshoShutokuKeiri-selectByWhere'},
        {name: 'リ　セット', primary: true, show: true, action: 'clear', url: ''},
        {name: '更　新', primary: true, show: true, action: 'back', backUrl: 'nsdstkkeirikosin'}
      ],
      item1: [
      {value1: '', label1: ''},
      {value1: '01', label1: '承認済(経理提出) '},
      {value1: '02', label1: '経理審査済'},
      {value1: '20', label1: '経理審査否認'}
      ],
      formItem: {
        seisanShoNo: '',
        siyoStartYmdFrom: '',
        siyoStartYmdTo: '',
        shoninSattus: '',
        kenmeiNm: ''
      }
    }
  }
}
</script>

<style scoped>
.page-style {
  font-size: 12px;
  width: 473px;
  height: 100%;
  margin-left:10px;
  line-height:30px;
  border: 1px solid;
  padding-top: 1px;
  padding-right: 1px;
}
.row-class {
  height: 30px;
  margin-bottom: 1px;
  margin-left: 1px;
  margin-right: 1px;
}
.lab-class {
  width: 170px;
  background-color: #77cad8;
  line-height: 30px;
  margin-right: 1px;
}
</style>
