<template>
  <div style= "padding-left: 10px; padding-right: 10px;">
    <div style="position: relative;">
     <span style="font-size: 12px;">10件</span>
      <div style="position: absolute; top: -3px; right: 0px;">
        <el-pagination
          @size-change="handleSizeChange"
          @current-change="handleCurrentChange"
          :current-page.sync="currentPage1"
          :page-size="50"
          small
          layout="prev, pager, next"
          prev-text="前へ"
          next-text="次へ"
          :total="150">
        </el-pagination>
      </div>
    </div>
    <el-table style= "padding: -50px;" :data="this.$store.state.tableData" border height=235>
      <el-table-column
        sortable
        prop="rowNo"
        label="NO."
        min-width="48px">
      </el-table-column>
      <el-table-column
        sortable
        prop="seisanShoNo"
        label="精算書番号"
        min-width="140px">
      </el-table-column>
      <el-table-column
        sortable
        prop="soshikiRenRyakuNm"
        label="精算箇所"
        min-width="180px">
      </el-table-column>
      <el-table-column
        sortable
        prop="hansu"
        label="処理No"
        min-width="80px">
      </el-table-column>
      <el-table-column
        sortable
        prop="siyoStartYmd"
        label="使用開始年月日"
        min-width="110px">
      </el-table-column>
      <el-table-column
        sortable
        prop="shutokuKagakuGokei"
        label="取得価額合計"
        min-width="120px">
      </el-table-column>
      <el-table-column
        sortable
        prop="shoninJotai"
        label="承認状態"
        min-width="120px">
      </el-table-column >
      <el-table-column
        sortable
        prop="kenmeiCd"
        label="工事件名コード"
        min-width="120px">
      </el-table-column>
      <el-table-column
        sortable
        prop="kenmeiNm"
        label="工事件名"
        min-width="90px">
      </el-table-column>
    </el-table>
  </div>
</template>
<script scoped>
  export default {
    methods: {
      headerClassName ({row, rowIndex}) {
        return 'class-header'
      },
      handleSizeChange (val) {
        console.log(`每页 ${val} 条`)
      },
      handleCurrentChange (val) {
        console.log(`当前页: ${val}`)
      }
    },
    data () {
      return {
        currentPage1: 1
      }
    }
  }
</script>
<style scoped>
</style>
