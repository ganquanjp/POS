<template>
  <div>
    <el-row>
      <el-col>
        <nsd-content-title v-bind:titlename="titlename" v-bind:message="message"></nsd-content-title>
      </el-col>
    </el-row>
    <el-row>
      <el-col>
        <nsd-table-bar></nsd-table-bar>
      </el-col>
    </el-row>
  </div>
</template>

<script>
import NsdContentTitle from '@/components/common/NSDContentTitle.vue'
import NSDTable from '@/components/seisanshoshutoku/keirikosin/NSDTable.vue'

export default {
  components: {
    'nsd-content-title': NsdContentTitle,
    'nsd-table-bar': NSDTable

  },
  created: function () {
    this.$store.state.message = this.message
  },
  data () {
    return {
      titlename: '【取得経理審査/連携】更新',
      message: ''
    }
  }
}
</script>

<style scoped>
</style>
