<template>
  <div class="page-style">
    <el-row>
      <el-col>
        <nsd-content-title v-bind:titlename="titlename" v-bind:message="message"></nsd-content-title>
      </el-col>
    </el-row>
    <el-row>
      <el-col>
        <nsd-move-button-bar></nsd-move-button-bar>
      </el-col>
    </el-row>
    <el-row>
      <el-col>
        <nsd-exe-button-bar></nsd-exe-button-bar>
      </el-col>
    </el-row>
    <el-row>
      <el-col>
        <nsd-lable></nsd-lable>
      </el-col>
    </el-row>
  </div>
</template>

<script>
import NsdContentTitle from '@/components/common/NSDContentTitle.vue'
import NSDMoveButtonBar from '@/components/koteishisandaityo/sakusei/NSDMoveButtonBar.vue'
import NSDExeButtonBar from '@/components/koteishisandaityo/sakusei/NSDExeButtonBar.vue'
import NSDLable from '@/components/koteishisandaityo/sakusei/NSDLable.vue'

export default {
  components: {
    'nsd-content-title': NsdContentTitle,
    'nsd-move-button-bar': NSDMoveButtonBar,
    'nsd-exe-button-bar': NSDExeButtonBar,
    'nsd-lable': NSDLable
  },
  data () {
    return {
      message: '再作成ボタンを押下してください。'
    }
  },
  computed: {
    titlename: function () {
      return '【固定資産台帳出力】作成指示'
    }
  }
}
</script>

<style scoped>
.page-style {
  margin-left: 15px;
}
</style>
