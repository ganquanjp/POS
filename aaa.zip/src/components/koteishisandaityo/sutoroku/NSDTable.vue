<template>
  <el-table
    class="table-style"
    :data="tableData"
    resizable=false
    border
    :header-row-class-name="tableHeaderClassName"
    :row-class-name="tableRowClassName">
    <el-table-column
      prop="date1"
      label="No."
      width= "50px"
      header-align=center>
    </el-table-column>
    <el-table-column
      type="selection"
      width= "70px"
      header-align=center>
    </el-table-column>
    <el-table-column header-align=center label="出力日時">
      <el-table-column
        prop="date3"
        label="日付"
        width= "120px"
        header-align=center>
      </el-table-column>
      <el-table-column
        prop="date4"
        label="時刻"
        width= "120px"
        header-align=center>
      </el-table-column>
    </el-table-column>
    <el-table-column
      prop="date5"
      label="区分"
      width= "100px"
      header-align=center>
    </el-table-column>
    <el-table-column
      prop="date6"
      label="作成者"
      width= "200px"
      header-align=center>
    </el-table-column>
  </el-table>
</template>

<script>
export default {
  data () {
    return {
      tableData: [{
        date1: '1',
        date2: true,
        date3: '2017-12-25',
        date4: '15:40:00',
        date5: '作成指示',
        date6: 'AA A太郎'
      }, {
        date1: '2',
        date2: false,
        date3: '2017-11-25',
        date4: '03:00:00',
        date5: '夜間作成',
        date6: ''
      }]
    }
  },
  methods: {
    btnClick: function () {
      alert('ダウンロード')
    },
    tableHeaderClassName ({row, rowIndex}) {
      return 'tab-header'
    },
    tableRowClassName ({row, rowIndex}) {
      return 'tab-row'
    }
  }
}
</script>

<style>
.el-table .tab-header {
  color: #000000;
}
.el-table .tab-row {
  text-align: center;
}
.table-style {
  font-size: 12px;
  width: 661px;
  margin-left: 10px;
}
</style>
