<template>
  <div>
    <el-row>
      <el-col  style="width:300px">
        <el-button 
          v-for="(btn, key) in buttons" 
          v-if="btn.show" 
          class="button-style" 
          size="mini" 
          v-bind:type="btn.primary ? 'primary' : '' "
          v-bind:key="key"
          @click.native="btnClick(btn.goto)">
          {{ btn.name }}
        </el-button>
      </el-col>
    </el-row>
  </div>
</template>

<script>
export default {
  data () {
    return {
      buttons: [
        { name: '作成指示', primary: true, show: true, goto: 'sakusei' },
        { name: '出力', primary: false, show: true }
      ]
    }
  },
  methods: {
    btnClick: function (item) {
      if (item === 'sakusei') {
        this.$router.push({name: 'nsddaityosakusei'})
      }
    }
  }
}
</script>

<style scoped>
.button-style {
  margin-bottom: 10px;
  margin-left: 10px;
}
</style>
