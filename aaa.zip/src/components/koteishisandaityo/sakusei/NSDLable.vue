<template>
  <div class="div-style">
   <el-row style="height: 80px">
     <el-lab>現在の最新版・固定資産台帳は、</el-lab>
   </el-row>
   <el-row style="height: 80px; margin-left: 30px;">
     <el-lab style="color: red;">{{lable}}</el-lab>
   </el-row>
   <el-row style="height: 80px;">
     <el-lab>に作成されています。</el-lab>
   </el-row>
  </div>
</template>

<script>
export default {
  data () {
    return {
      lable: 'YYYY - MM - DD / HH : mm : ss'
    }
  }
}
</script>

<style>
.div-style {
  font-size: 12px;
  width: 661px;
  margin-left: 10px;
  text-align: left;
}
</style>
