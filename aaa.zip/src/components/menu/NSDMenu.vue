<template>
  <div class="page-style">
    <el-row>
      <el-col>
        <nsd-content-title v-bind:titlename="titlename" v-bind:message="message"></nsd-content-title>
      </el-col>
    </el-row>
  </div>
</template>

<script>
import NsdContentTitle from '@/components/common/NSDContentTitle.vue'

export default {
  components: {
    'nsd-content-title': NsdContentTitle
  },
  data () {
    return {
      message: '各機能を選択してください。'
    }
  },
  computed: {
    titlename: function () {
      return 'メニュー'
    }
  }
}
</script>

<style scoped>
.page-style {
  width: 100%;
}
</style>
