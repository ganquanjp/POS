<template>
  <el-container>
    <el-header height="70px"><nsd-header></nsd-header></el-header>
    <el-container>
      <nsd-nav></nsd-nav>
      <nsd-content></nsd-content>
    </el-container>
  </el-container>
</template>

<script>
import NSDHeader from '@/components/NSDHeader.vue'
import NSDNav from '@/components/NSDNav.vue'
import NSDContent from '@/components/NSDContent.vue'

export default {
  components: {
    'nsd-header': NSDHeader,
    'nsd-nav': NSDNav,
    'nsd-content': NSDContent
  }
}

pushHistory()

window.addEventListener('popstate', function (e) {
  if (confirm('ブラウザの戻るボタンを押下したら、セッションを切断します。')) {
    alert('セッションを切断しました。')
  } else {
    pushHistory()
  }
}, false)

function pushHistory () {
  var state = {
    title: 'title',
    url: '#'
  }
  window.history.pushState(state, 'title', '#')
}
</script>

<style scoped>
  .el-header, .el-footer {
    background-color: #B3C0D1;
    color: #333;
    text-align: center;
    line-height: 0px;
    padding: 2px;
  }

</style>