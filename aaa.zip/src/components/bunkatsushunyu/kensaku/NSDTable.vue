<template>
  <div style= "padding-left: 10px; padding-right: 10px; width: 951px;">
    <div style="position: relative;">
     <span style="font-size: 12px;">10件</span>
      <div style="position: absolute; top: -3px; right: 0px;">
        <el-pagination
          @size-change="handleSizeChange"
          @current-change="handleCurrentChange"
          :page-size="50"
          small
          layout="prev, pager, next"
          prev-text="前へ"
          next-text="次へ"
          :total="150">
        </el-pagination>
      </div>
    </div>
    <el-table style= "padding: -50px;" :data="this.$store.state.tableData" border height=235>
      <el-table-column
        sortable
        prop="kouban"
        label="NO."
        width="70px"
        header-align=center>
      </el-table-column>
      <el-table-column
        sortable
        prop="koujikodo"
        label="工事件名コード"
        width="120px"
        header-align=center>
      </el-table-column>
      <el-table-column
        sortable
        prop="kojiKenmei"
        label="工事件名"
        width="120px"
        header-align=center>
      </el-table-column>
      <el-table-column
        sortable
        prop="seisankasyo"
        label="精算箇所"
        width="130px"
        header-align=center>
      </el-table-column>
      <el-table-column
        sortable
        prop="seisanshono"
        label="精算書番号"
        width="150px"
        header-align=center>
      </el-table-column >
      <el-table-column
        sortable
        prop="sabisukaisiymd"
        label="サービス開始年月日"
        width="130px"
        header-align=center>
      </el-table-column>
      <el-table-column
        sortable
        prop="shoninjyotai"
        label="承認状態"
        width="80px"
        header-align=center>
      </el-table-column>
      <el-table-column
        sortable
        prop="keirihininriyu"
        label="経理審査否認理由"
        width="150px"
        header-align=center>
      </el-table-column>
    </el-table>
  </div>
</template>
<script scoped>
  export default {
    created: function () {
      this.$store.state.tableData = ''
    },
    methods: {
      handleSizeChange (val) {
        console.log(`${val} 件/ページ`)
      },
      handleCurrentChange (val) {
        console.log(`${val}ページ目`)
      }
    }
  }
</script>
<style scoped>
</style>