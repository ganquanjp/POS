<template>
  <div style= "padding-left: 10px; padding-right: 10px; width: 1039px;" >
    <div style="position: relative;">
     <span style="font-size: 12px;">10件</span>
    </div>
    <div ref="divTable">
      <el-table
        :data="tableData"
        border>
        <el-table-column 
          prop="kouban"
          label="NO."
          width="48px">
        </el-table-column>
        <el-table-column
          type="selection"
          width="60px"
          align=center>
        </el-table-column>
        <el-table-column
          prop="koujikodo"
          label="工事件名コード"
          width="110px">
        </el-table-column>
        <el-table-column
          prop="koujikenme"
          label="工事件名"
          width="150px">
        </el-table-column>
        <el-table-column
          label="精算書番号"
          width="150px">
          <template slot-scope="scope">
            <el-button type="text" @click="textBtn">{{scope.row.seisansyono}}</el-button>
          </template>
        </el-table-column >
        <el-table-column
          prop="siyokaisiymd"
          label="サービス開始年月日"
          width="140px">
          <template slot-scope="scope">
            <el-date-picker
              v-model="scope.row.siyokaisiymd"
              type="date"
              style="width: 100%;"
              size="mini">
            </el-date-picker>
          </template>
        </el-table-column>
        <el-table-column
          width="130px"
          :render-header="renderHeader">
            <template slot-scope="scope">
              <el-select v-model="scope.row.value" size="mini">
                <el-option
                  v-for="item in item"
                  :key="item.value"
                  :label="item.label"
                  :value="item.value">
                </el-option>
            </el-select>
          </template>
        </el-table-column>
        <el-table-column
          label="経理審査否認理由"
          min-width="250px">
          <template slot-scope="scope">
            <el-input v-model="scope.row.koteisisanmeisyo" size="mini" />
          </template>
        </el-table-column>
      </el-table>
    </div>
    <div ref="divScroll" class="scroll-box">
      <div style="width: 750px;">
        <el-table
          :data="tableData1"
          border>
          <el-table-column 
            prop="kouban"
            label="NO."
            width="48px">
          </el-table-column>
          <el-table-column
            label="固定資産番号"
            width="110px">
            <template slot-scope="scope">
              <el-button type="text" @click="">{{scope.row.koteisisanno}}</el-button>
            </template>
          </el-table-column>
          <el-table-column
            prop="koteisisanname"
            label="固定資産名称"
            width="200px">
          </el-table-column>
          <el-table-column
            prop="torihikisakiname"
            label="取引先名称"
            width="150px">
          </el-table-column >
          <el-table-column
            prop="syutokuymd"
            label="取得年月日"
            width="140px">
          </el-table-column>
          <el-table-column
            prop="syutokukakaku"
            label="取得価格"
            min-width="100px"
            header-align=left
            align=right>
          </el-table-column>
        </el-table>
        <div style="margin-top: 10px; border: 1px solid; padding-top: 1px; width: 404px;">
          <el-row class="row-class">
            <el-col class="lab-class">　種類</el-col>
            <el-col style= "width: 200px">
              <el-input v-model="input1" size="mini" :disabled="true" />
            </el-col>
          </el-row>
          <el-row class="row-class">
            <el-col class="lab-class">　構造</el-col>
            <el-col style= "width: 200px">
              <el-input v-model="input2" size="mini" :disabled="true" />
            </el-col>
          </el-row>
          <el-row class="row-class">
            <el-col class="lab-class">　資産単位</el-col>
            <el-col style= "width: 200px">
              <el-input v-model="input3" size="mini" :disabled="true" />
            </el-col>
          </el-row>
          <el-row class="row-class">
            <el-col class="lab-class">　科目１</el-col>
            <el-col style= "width: 200px">
              <el-input v-model="input4" size="mini" :disabled="true" />
            </el-col>
          </el-row>
          <el-row class="row-class">
            <el-col class="lab-class">　科目２</el-col>
            <el-col style= "width: 200px">
              <el-input v-model="input5" size="mini" :disabled="true" />
            </el-col>
          </el-row>
          <el-row class="row-class">
            <el-col class="lab-class">　科目３</el-col>
            <el-col style= "width: 200px">
              <el-input v-model="input6" size="mini" :disabled="true" />
            </el-col>
          </el-row>
        </div>
        <div style="margin-top: 10px; border: 1px solid; padding-top: 1px; width: 404px;">
          <el-row class="row-class">
            <el-col class="lab-class">　備忘価額_税</el-col>
            <el-col style= "width: 200px">
              <el-input v-model="input1" size="mini" :disabled="true" />
            </el-col>
          </el-row>
          <el-row class="row-class">
            <el-col class="lab-class">　償却可能限度額_税</el-col>
            <el-col style= "width: 200px">
              <el-input v-model="input2" size="mini" :disabled="true" />
            </el-col>
          </el-row>
          <el-row class="row-class">
            <el-col class="lab-class">　償却方法_税</el-col>
            <el-col style= "width: 200px">
              <el-input v-model="input3" size="mini" :disabled="true" />
            </el-col>
          </el-row>
          <el-row class="row-class">
            <el-col class="lab-class">　残存率_税</el-col>
            <el-col style= "width: 200px">
              <el-input v-model="input4" size="mini" :disabled="true" />
            </el-col>
          </el-row>
          <el-row class="row-class">
            <el-col class="lab-class">　耐用月数_税</el-col>
            <el-col style= "width: 200px">
              <el-input v-model="input5" size="mini" :disabled="true" />
            </el-col>
          </el-row>
        </div>
        <div style="margin-top: 10px; border: 1px solid; padding-top: 1px; width: 404px;">
          <el-row class="row-class">
            <el-col class="lab-class">　備忘価額_法</el-col>
            <el-col style= "width: 200px">
              <el-input v-model="input1" size="mini" :disabled="true" />
            </el-col>
          </el-row>
          <el-row class="row-class">
            <el-col class="lab-class">　償却可能限度額_法</el-col>
            <el-col style= "width: 200px">
              <el-input v-model="input2" size="mini" :disabled="true" />
            </el-col>
          </el-row>
          <el-row class="row-class">
            <el-col class="lab-class">　償却方法_法</el-col>
            <el-col style= "width: 200px">
              <el-input v-model="input3" size="mini" :disabled="true" />
            </el-col>
          </el-row>
          <el-row class="row-class">
            <el-col class="lab-class">　残存率_法</el-col>
            <el-col style= "width: 200px">
              <el-input v-model="input4" size="mini" :disabled="true" />
            </el-col>
          </el-row>
          <el-row class="row-class">
            <el-col class="lab-class">　耐用月数_法</el-col>
            <el-col style= "width: 200px">
              <el-input v-model="input5" size="mini" :disabled="true" />
            </el-col>
          </el-row>
        </div>
      </div>
    </div>
  </div>
</template>
<script scoped>
  export default {
    methods: {
      textBtn: function () {
        this.$refs.divScroll.offsetHeight = 459 - this.$refs.divTable.offsetHeight + 'px'
        alert('this.$refs.divScroll.offsetHeight')
      },
      renderHeader (createElement, { column }) {
        return createElement(
          'el-lab',
          [
            '承認状態',
            createElement('span', {style: 'color: red;'}, '　　(必須)')
          ]
        )
      }
    },
    data () {
      return {
        currentPage: 1,
        item: [{value: '1', label: '経理未承認'}, {value: '2', label: '経理承認済'}, {value: '3', label: '経理否認'}],
        tableData: [{
          kouban: '1',
          koujikodo: '0C028001',
          koujikenme: '工事件名Ａ1',
          seisankasyo: 'ＡＡ本部 A部',
          seisansyono: '000000000000012',
          siyokaisiymd: '2011-04-01',
          koteisisanmeisyo: '固定資産名称ＡＡＡＡ',
          value: '1'
        }, {
          kouban: '2',
          koujikodo: '0C028002',
          koujikenme: '工事件名Ａ2',
          seisankasyo: 'ＢＢ本部 B部',
          seisansyono: '000000000000012',
          siyokaisiymd: '2011-04-01',
          tourokusyasimei: 'AA AA',
          koteisisanno: '300000000067',
          koteisisanmeisyo: '固定資産名称ＡＡＡＡ',
          syutokuymd: '2011-03-01',
          address: 'ＣＣ１',
          value: '2'
        }, {
          kouban: '3',
          koujikodo: '0C028003',
          koujikenme: '工事件名Ａ',
          seisankasyo: 'CC本部 C部',
          seisansyono: '000000000000012',
          siyokaisiymd: '2011-04-01',
          tourokusyasimei: 'AA AA',
          koteisisanno: '300000000072',
          koteisisanmeisyo: '固定資産名称ＡＡＡＡ',
          syutokuymd: '2011-03-01',
          address: 'ＣＣ１',
          value: '3'
        }, {
          kouban: '4',
          koujikodo: '0C028002',
          koujikenme: '工事件名Ａ',
          seisankasyo: 'CC本部 C部',
          seisansyono: '000000000000012',
          siyokaisiymd: '2011-04-01',
          tourokusyasimei: 'AA AA',
          koteisisanno: '300000000072',
          koteisisanmeisyo: '固定資産名称ＡＡＡＡ',
          syutokuymd: '2011-03-01',
          address: 'ＣＣ１'
        }, {
          kouban: '5',
          koujikodo: '0C028002',
          koujikenme: '工事件名Ａ',
          seisankasyo: 'CC本部 C部',
          seisansyono: '000000000000012',
          siyokaisiymd: '2011-04-01',
          tourokusyasimei: 'AA AA',
          koteisisanno: '300000000072',
          koteisisanmeisyo: '固定資産名称ＡＡＡＡ',
          syutokuymd: '2011-03-01',
          address: 'ＣＣ１'
        }, {
          kouban: '6',
          koujikodo: '0C028002',
          koujikenme: '工事件名Ａ',
          seisankasyo: 'CC本部 C部',
          seisansyono: '000000000000012',
          siyokaisiymd: '2011-04-01',
          tourokusyasimei: 'AA AA',
          koteisisanno: '300000000072',
          koteisisanmeisyo: '固定資産名称ＡＡＡＡ',
          syutokuymd: '2011-03-01',
          address: 'ＣＣ１'
        }, {
          kouban: '7',
          koujikodo: '0C028002',
          koujikenme: '工事件名Ａ',
          seisankasyo: 'CC本部 C部',
          seisansyono: '000000000000012',
          siyokaisiymd: '2011-04-01',
          tourokusyasimei: 'AA AA',
          koteisisanno: '300000000072',
          koteisisanmeisyo: '固定資産名称ＡＡＡＡ',
          syutokuymd: '2011-03-01',
          address: 'ＣＣ１'
        }, {
          kouban: '8',
          koujikodo: '0C028002',
          koujikenme: '工事件名Ａ',
          seisankasyo: 'CC本部 C部',
          seisansyono: '000000000000012',
          siyokaisiymd: '2011-04-01',
          tourokusyasimei: 'AA AA',
          koteisisanno: '300000000072',
          koteisisanmeisyo: '固定資産名称ＡＡＡＡ',
          syutokuymd: '2011-03-01',
          address: 'ＣＣ１'
        }, {
          kouban: '9',
          koujikodo: '0C028002',
          koujikenme: '工事件名Ａ',
          seisankasyo: 'CC本部 C部',
          seisansyono: '000000000000012',
          siyokaisiymd: '2011-04-01',
          tourokusyasimei: 'AA AA',
          koteisisanno: '300000000072',
          koteisisanmeisyo: '固定資産名称ＡＡＡＡ',
          syutokuymd: '2011-03-01',
          address: 'ＣＣ１'
        }, {
          kouban: '10',
          koujikodo: '0C028002',
          koujikenme: '工事件名Ａ',
          seisankasyo: 'CC本部 C部',
          seisansyono: '000000000000012',
          siyokaisiymd: '2011-04-01',
          tourokusyasimei: 'AA AA',
          koteisisanno: '300000000072',
          koteisisanmeisyo: '固定資産名称ＡＡＡＡ',
          syutokuymd: '2011-03-01',
          address: 'ＣＣ１'
        }],
        tableData1: [{
          kouban: '1',
          koteisisanno: '300000000011',
          koteisisanname: '固定資産Ａ',
          torihikisakiname: '取引先Ｂ',
          syutokuymd: '2011-04-01',
          syutokukakaku: '90'
        }, {
          kouban: '2',
          koteisisanno: '300000000012',
          koteisisanname: '固定資産Ｂ',
          torihikisakiname: '取引先Ｂ',
          syutokuymd: '2011-04-03',
          syutokukakaku: '190'
        }, {
          kouban: '3',
          koteisisanno: '300000000013',
          koteisisanname: '固定資産Ｂ',
          torihikisakiname: '取引先Ｂ',
          syutokuymd: '2011-04-13',
          syutokukakaku: '120'
        }, {
          kouban: '4',
          koteisisanno: '300000000013',
          koteisisanname: '固定資産Ｂ',
          torihikisakiname: '取引先Ｂ',
          syutokuymd: '2011-04-13',
          syutokukakaku: '120'
        }, {
          kouban: '5',
          koteisisanno: '300000000013',
          koteisisanname: '固定資産Ｂ',
          torihikisakiname: '取引先Ｂ',
          syutokuymd: '2011-04-13',
          syutokukakaku: '120'
        }, {
          kouban: '6',
          koteisisanno: '300000000013',
          koteisisanname: '固定資産Ｂ',
          torihikisakiname: '取引先Ｂ',
          syutokuymd: '2011-04-13',
          syutokukakaku: '120'
        }, {
          kouban: '7',
          koteisisanno: '300000000013',
          koteisisanname: '固定資産Ｂ',
          torihikisakiname: '取引先Ｂ',
          syutokuymd: '2011-04-13',
          syutokukakaku: '120'
        }, {
          kouban: '8',
          koteisisanno: '300000000013',
          koteisisanname: '固定資産Ｂ',
          torihikisakiname: '取引先Ｂ',
          syutokuymd: '2011-04-13',
          syutokukakaku: '120'
        }, {
          kouban: '9',
          koteisisanno: '300000000013',
          koteisisanname: '固定資産Ｂ',
          torihikisakiname: '取引先Ｂ',
          syutokuymd: '2011-04-13',
          syutokukakaku: '120'
        }, {
          kouban: '10',
          koteisisanno: '300000000013',
          koteisisanname: '固定資産Ｂ',
          torihikisakiname: '取引先Ｂ',
          syutokuymd: '2011-04-13',
          syutokukakaku: '120'
        }]
      }
    }
  }
</script>

<style scoped>
.scroll-box {
  height: 90px;
  overflow-y: auto;
  margin-top: 10px; 
}
.row-class {
  height: 30px;
  margin-bottom: 1px;
  margin-left: 1px;
  margin-right: 1px;
}
.lab-class {
  line-height: 30px;
  width: 200px;
  background-color: #77cad8;
  margin-right: 1px;
}
</style>