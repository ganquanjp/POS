<template>
  <div style= "padding: 10px 10px 0px 10px; width: 721px;">
    <div style="position: relative;">
     <span style="font-size: 12px;">10件</span>
      <div style="position: absolute; top: -3px; right: 0px;">
        <el-pagination
          @size-change="handleSizeChange"
          @current-change="handleCurrentChange"
          :current-page.sync="currentPage1"
          :page-size="50"
          small
          layout="prev, pager, next"
          prev-text="前へ"
          next-text="次へ"
          :total="150">
        </el-pagination>
      </div>
    </div>
    <el-table
      :data="tableData"
      border
      :header-row-class-name="headerClassName">
      <el-table-column 
        prop="kouban"
        sortable
        label="NO."
        width="80px">
      </el-table-column>
      <el-table-column
        prop="lable1"
        sortable
        label="添付フェイル"
        width="340px">
      </el-table-column >
      <el-table-column
        prop="lable2"
        sortable
        label="サイズ"
        width="100px">
      </el-table-column>
      <el-table-column
        prop="lable3"
        sortable
        label="ステータス"
        width="100px">
      </el-table-column>
      <el-table-column
        prop="lable4"
        sortable
        label="取込日"
        width="100px">
      </el-table-column>
    </el-table>
  </div>
</template>
<script scoped>
  export default {
    methods: {
      move: function () {
        this.$router.push({name: 'nsdsesanshokai'})
      },
      headerClassName ({row, rowIndex}) {
        return 'class-header'
      },
      handleSizeChange (val) {
        console.log(`每页 ${val} 条`)
      },
      handleCurrentChange (val) {
        console.log(`当前页: ${val}`)
      }
    },
    data () {
      return {
        currentPage1: 5,
        tableData: [{
          kouban: '1',
          lable1: '20171201-1_kenmei.csv',
          lable2: '107 byte',
          lable3: '結果OK',
          lable4: '2011/10/12'
        }, {
          kouban: '2',
          lable1: '20171201-1_kenmei.csv',
          lable2: '107 byte',
          lable3: '結果OK',
          lable4: '2011/10/12'
        }, {
          kouban: '3',
          lable1: '20171201-1_kenmei.csv',
          lable2: '107 byte',
          lable3: '結果OK',
          lable4: '2011/10/12'
        }, {
          kouban: '4',
          lable1: '20171201-1_kenmei.csv',
          lable2: '107 byte',
          lable3: '結果OK',
          lable4: '2011/10/12'
        }, {
          kouban: '5',
          lable1: '20171201-1_kenmei.csv',
          lable2: '107 byte',
          lable3: '結果OK',
          lable4: '2011/10/12'
        }, {
          kouban: '6',
          lable1: '20171201-1_kenmei.csv',
          lable2: '107 byte',
          lable3: '結果OK',
          lable4: '2011/10/12'
        }, {
          kouban: '7',
          lable1: '20171201-1_kenmei.csv',
          lable2: '107 byte',
          lable3: '結果OK',
          lable4: '2011/10/12'
        }, {
          kouban: '8',
          lable1: '20171201-1_kenmei.csv',
          lable2: '107 byte',
          lable3: '結果OK',
          lable4: '2011/10/12'
        }, {
          kouban: '9',
          lable1: '20171201-1_kenmei.csv',
          lable2: '107 byte',
          lable3: '結果OK',
          lable4: '2011/10/12'
        }, {
          kouban: '10',
          lable1: '20171201-1_kenmei.csv',
          lable2: '107 byte',
          lable3: '結果OK',
          lable4: '2011/10/12'
        }]
      }
    }
  }
</script>
<style scoped>
</style>
