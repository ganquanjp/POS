<template>
  <div style= "padding-left: 10px; padding-right: 10px;">
    <div style="position: relative;">
     <span style="font-size: 12px;">10件</span>
      <div style="position: absolute; top: -3px; right: 0px;">
        <el-pagination
          @size-change="handleSizeChange"
          @current-change="handleCurrentChange"
          :current-page.sync="currentPage1"
          :page-size="50"
          small
          layout="prev, pager, next"
          prev-text="前へ"
          next-text="次へ"
          :total="150">
        </el-pagination>
      </div>
    </div>
    <el-table
      :data="tableData"
      height=270
      border
      :header-row-class-name="headerClassName">
      <el-table-column 
        prop="kouban"
        sortable
        label="NO."
        width="80px">
      </el-table-column>
      <el-table-column
        prop="kojikenmeicd"
        sortable
        label="工事件名コード"
        width="140px">
      </el-table-column >
      <el-table-column
        prop="kojikenmei"
        sortable
        label="工事件名"
        width="100px">
      </el-table-column>
      <el-table-column
        prop="tekiyokaisibi"
        sortable
        label="適用開始日"
        width="100px">
      </el-table-column>
      <el-table-column
        prop="tekiyosyuryobi"
        sortable
        label="適用終了日"
        width="100px">
      </el-table-column>
      <el-table-column
        prop="seisankasyo"
        sortable
        label="精算箇所"
        width="100px">
      </el-table-column>
      <el-table-column
        prop="sesanshobango"
        sortable
        label="精算書番号"
        width="140px">
         <template slot-scope="scope">
          <el-button type="text" @click="move">{{scope.row.sesanshobango}}</el-button>
         </template>
      </el-table-column>
      <el-table-column
        prop="siyokaisiymd"
        sortable
        label="使用開始年月日"
        width="140px">
      </el-table-column>
      <el-table-column
        prop="yoyakusu"
        sortable
        label="予約数"
        width="80px">
      </el-table-column>
      <el-table-column
        prop="tourokusyasimei"
        sortable
        label="登録者氏名"
        width="140px">
      </el-table-column>
      <el-table-column
        prop="kenmeistatus"
        sortable
        label="件名ステータス"
        width="140px">
      </el-table-column>
      <el-table-column
        prop="seisansyostatus"
        sortable
        label="精算書ステータス"
        width="140px">
      </el-table-column>
    </el-table>
  </div>
</template>
<script scoped>
  export default {
    methods: {
      move: function () {
        this.$router.push({name: 'nsdssstrkshokai'})
      },
      headerClassName ({row, rowIndex}) {
        return 'class-header'
      },
      handleSizeChange (val) {
        console.log(`每页 ${val} 条`)
      },
      handleCurrentChange (val) {
        console.log(`当前页: ${val}`)
      }
    },
    data () {
      return {
        currentPage1: 5,
        tableData: [{
          kouban: '01',
          kojikenmeicd: '1234567890ABCDE',
          kojikenmei: 'ＡＢＣＤＥ',
          tekiyokaisibi: '2011-10-12',
          tekiyosyuryobi: '2011-10-12',
          seisankasyo: 'ＡＢＣＤＥ',
          sesanshobango: '1234567890ABCDE',
          siyokaisiymd: '2011-10-12',
          yoyakusu: '3',
          tourokusyasimei: 'ああああ　太郎',
          kenmeistatus: '未連携',
          seisansyostatus: '登録中'
        }, {
          kouban: '02',
          kojikenmeicd: '1234567890ABCDE',
          kojikenmei: 'ＡＢＣＤＥ',
          tekiyokaisibi: '2011-10-12',
          tekiyosyuryobi: '2011-10-12',
          seisankasyo: 'ＡＢＣＤＥ',
          sesanshobango: '1234567890ABCDE',
          siyokaisiymd: '2011-10-12',
          yoyakusu: '3',
          tourokusyasimei: 'ああああ　太郎',
          kenmeistatus: '未連携',
          seisansyostatus: '登録中'
        }, {
          kouban: '03',
          kojikenmeicd: '1234567890ABCDE',
          kojikenmei: 'ＡＢＣＤＥ',
          tekiyokaisibi: '2011-10-12',
          tekiyosyuryobi: '2011-10-12',
          seisankasyo: 'ＡＢＣＤＥ',
          sesanshobango: '1234567890ABCDE',
          siyokaisiymd: '2011-10-12',
          yoyakusu: '3',
          tourokusyasimei: 'ああああ　太郎',
          kenmeistatus: '未連携',
          seisansyostatus: '登録中'
        }, {
          kouban: '04',
          kojikenmeicd: '1234567890ABCDE',
          kojikenmei: 'ＡＢＣＤＥ',
          tekiyokaisibi: '2011-10-12',
          tekiyosyuryobi: '2011-10-12',
          seisankasyo: 'ＡＢＣＤＥ',
          sesanshobango: '1234567890ABCDE',
          siyokaisiymd: '2011-10-12',
          yoyakusu: '3',
          tourokusyasimei: 'ああああ　太郎',
          kenmeistatus: '未連携',
          seisansyostatus: '登録中'
        }, {
          kouban: '05',
          kojikenmeicd: '1234567890ABCDE',
          kojikenmei: 'ＡＢＣＤＥ',
          tekiyokaisibi: '2011-10-12',
          tekiyosyuryobi: '2011-10-12',
          seisankasyo: 'ＡＢＣＤＥ',
          sesanshobango: '1234567890ABCDE',
          siyokaisiymd: '2011-10-12',
          yoyakusu: '3',
          tourokusyasimei: 'ああああ　太郎',
          kenmeistatus: '未連携',
          seisansyostatus: '登録中'
        }, {
          kouban: '06',
          kojikenmeicd: '1234567890ABCDE',
          kojikenmei: 'ＡＢＣＤＥ',
          tekiyokaisibi: '2011-10-12',
          tekiyosyuryobi: '2011-10-12',
          seisankasyo: 'ＡＢＣＤＥ',
          sesanshobango: '1234567890ABCDE',
          siyokaisiymd: '2011-10-12',
          yoyakusu: '3',
          tourokusyasimei: 'ああああ　太郎',
          kenmeistatus: '未連携',
          seisansyostatus: '登録中'
        }, {
          kouban: '07',
          kojikenmeicd: '1234567890ABCDE',
          kojikenmei: 'ＡＢＣＤＥ',
          tekiyokaisibi: '2011-10-12',
          tekiyosyuryobi: '2011-10-12',
          seisankasyo: 'ＡＢＣＤＥ',
          sesanshobango: '1234567890ABCDE',
          siyokaisiymd: '2011-10-12',
          yoyakusu: '3',
          tourokusyasimei: 'ああああ　太郎',
          kenmeistatus: '未連携',
          seisansyostatus: '登録中'
        }, {
          kouban: '08',
          kojikenmeicd: '1234567890ABCDE',
          kojikenmei: 'ＡＢＣＤＥ',
          tekiyokaisibi: '2011-10-12',
          tekiyosyuryobi: '2011-10-12',
          seisankasyo: 'ＡＢＣＤＥ',
          sesanshobango: '1234567890ABCDE',
          siyokaisiymd: '2011-10-12',
          yoyakusu: '3',
          tourokusyasimei: 'ああああ　太郎',
          kenmeistatus: '未連携',
          seisansyostatus: '登録中'
        }, {
          kouban: '09',
          kojikenmeicd: '1234567890ABCDE',
          kojikenmei: 'ＡＢＣＤＥ',
          tekiyokaisibi: '2011-10-12',
          tekiyosyuryobi: '2011-10-12',
          seisankasyo: 'ＡＢＣＤＥ',
          sesanshobango: '1234567890ABCDE',
          siyokaisiymd: '2011-10-12',
          yoyakusu: '3',
          tourokusyasimei: 'ああああ　太郎',
          kenmeistatus: '未連携',
          seisansyostatus: '登録中'
        }, {
          kouban: '10',
          kojikenmeicd: '1234567890ABCDE',
          kojikenmei: 'ＡＢＣＤＥ',
          tekiyokaisibi: '2011-10-12',
          tekiyosyuryobi: '2011-10-12',
          seisankasyo: 'ＡＢＣＤＥ',
          sesanshobango: '1234567890ABCDE',
          siyokaisiymd: '2011-10-12',
          yoyakusu: '3',
          tourokusyasimei: 'ああああ　太郎',
          kenmeistatus: '未連携',
          seisansyostatus: '登録中'
        }]
      }
    }
  }
</script>
<style scoped>
</style>
