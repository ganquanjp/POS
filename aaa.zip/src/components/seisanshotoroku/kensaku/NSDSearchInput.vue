<template>
  <div>
    <div class="page-style">
      <el-row class="row-class">
        <el-col class= "lab-class">　精算書番号</el-col>
        <el-col style= "width: 145px;">
          <el-input v-model="formItem.seisanShoNo" size="mini"></el-input>
        </el-col>
      </el-row>
      <el-row class="row-class">
        <el-col class= "lab-class">　精算箇所</el-col>
        <el-col style= "width: 300px;">
          <el-input v-model="formItem.soshikiNm" size="mini"></el-input>
        </el-col>
      </el-row>
      <el-row class="row-class">
        <el-col class= "lab-class">　使用開始年月</el-col>
        <el-col style= "width: 140px;">
          <el-date-picker
            v-model="formItem.siyoStartYMDFrom"
            size="mini"
            style="width: 140px;"
            type="date">
          </el-date-picker>
        </el-col>
        <el-col :span="1"style="line-height: 25px; margin-left: 5px; margin-right: -5px;">－</el-col>
        <el-col style= "width: 140px;">
          <el-date-picker
            v-model="formItem.siyoStartYMDTo"
            size="mini"
            style="width: 140px;"
            type="date">
          </el-date-picker>
        </el-col>
      </el-row>
      <el-row class="row-class">
        <el-col class= "lab-class">　登録者氏名</el-col>
        <el-col style= "width: 300px;">
          <el-input v-model="formItem.torokushaName" size="mini"></el-input>
        </el-col>
      </el-row>
      <el-row class="row-class">
        <el-col class= "lab-class">　工事件名</el-col>
        <el-col style= "width: 300px;">
          <el-input v-model="formItem.kenmeiNm" size="mini"></el-input>
        </el-col>
      </el-row>
      <el-row class="row-class">
        <el-col class= "lab-class">　適用期間</el-col>
        <el-col style= "width: 140px;">
          <el-date-picker
            v-model="formItem.tekiyoStartYmd"
            size="mini"
            style="width: 140px;"
            type="date">
          </el-date-picker>
        </el-col>
        <el-col :span="1"style="line-height: 25px; margin-left: 5px; margin-right: -5px;">－</el-col>
        <el-col style= "width: 140px;">
          <el-date-picker
            v-model="formItem.tekiyoEndYmd"
            size="mini"
            style="width: 140px;"
            type="date">
          </el-date-picker>
        </el-col>
      </el-row>
     </div>
    <el-row>
      <el-col>
        <nsd-button-bar v-bind:buttons="buttonName" v-bind:formItem="formItem"></nsd-button-bar>
      </el-col>
    </el-row>
  </div>
</template>

<script>
import NSDButtonBar from '@/components/common/NSDButtonBar.vue'

export default {
  components: {
    'nsd-button-bar': NSDButtonBar
  },
  data () {
    return {
      buttonName: [
        {name: '検　索', primary: true, show: true, action: 'post', url: '/seisanshoToroku-selectByWhere'},
        {name: 'ク　リ　ア', primary: true, show: true, action: 'clear', url: ''}
      ],
      formItem: {
        seisanShoNo: '',
        soshikiCd: '',
        soshikiNm: '',
        siyoStartYmdFrom: '',
        siyoStartYmdTo: '',
        torokushaName: '',
        kenmeiCd: '',
        kenmeiNm: '',
        tekiyoStartYmd: '',
        tekiyoEndYmd: ''
      }
    }
  }
}
</script>

<style scoped>
.page-style {
  font-size: 12px;
  width: 473px;
  height: 100%;
  margin-left:10px;
  border: 1px solid;
  padding-top: 1px;
  padding-right: 1px;
}
.row-class {
  height: 30px;
  margin-bottom: 1px;
  margin-left: 1px;
  margin-right: 1px;
}
.lab-class {
  width: 170px;
  background-color: #77cad8;
  line-height: 30px;
  margin-right: 1px;
}
.checkbox-class {
  width: 295px;
  line-height: 30px;
  margin-left: 1px;
}
</style>
