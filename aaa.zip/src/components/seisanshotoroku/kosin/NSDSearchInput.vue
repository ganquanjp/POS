<template>
  <div class="page-style">
    <el-row class="row-class">
      <el-col class= "lab-class">　工事件名コード<el-span class="span-class">（必須）</el-span></el-col>
      <el-col style= "width: 345px;">
        <el-input v-model="input1" size="mini"></el-input>
      </el-col>
    </el-row>
    <el-row class="row-class">
      <el-col class= "lab-class">　工事件名名称<el-span class="span-class">（必須）</el-span></el-col>
      <el-col style= "width: 345px;">
        <el-input v-model="input2" size="mini"></el-input>
      </el-col>
    </el-row>
    <el-row class="row-class">
      <el-col class= "lab-class">　適用開始日<el-span class="span-class">（必須）</el-span></el-col>
      <el-col style= "width: 145px;">
        <el-input v-model="input3" size="mini"></el-input>
      </el-col>
    </el-row>
    <el-row class="row-class">
      <el-col class= "lab-class">　適用終了日<el-span class="span-class">（必須）</el-span></el-col>
      <el-col style= "width: 145px;">
        <el-input v-model="input4" size="mini"></el-input>
      </el-col>
    </el-row>
    <el-row class="row-class">
      <el-col class= "lab-class">　連携対象</el-col>
      <el-col class= "checkbox-class">
        <el-checkbox v-model="checked1" size="mini">連携対象外</el-checkbox>
        <el-checkbox v-model="checked2" size="mini">未連携</el-checkbox>
        <el-checkbox v-model="checked3" size="mini">連携済</el-checkbox>
      </el-col>
    </el-row>
    <el-row class="row-class">
      <el-col class= "lab-class">　精算書番号<el-span class="span-class">（必須）</el-span></el-col>
      <el-col style= "width: 345px;">
        <el-input v-model="input2" size="mini"></el-input>
      </el-col>
    </el-row>
    <el-row class="row-class">
      <el-col class= "lab-class">　精算箇所<el-span class="span-class">（必須）</el-span></el-col>
      <el-col style= "width: 345px;">
        <el-input v-model="input6" size="mini"><el-button slot="append" style="position: absolute; top: 20px; left: 10px; padding-top: 5px;" size="mini" @click="showModal = true">参照</el-button></el-input>
      </el-col>
    </el-row>
    <el-row class="row-class">
      <el-col class= "lab-class">　使用開始年月日<el-span class="span-class">（必須）</el-span></el-col>
      <el-col style= "width: 145px;">
        <el-input v-model="input7" size="mini"></el-input>
      </el-col>
    </el-row>
    <el-row class="row-class">
      <el-col class= "lab-class">　登録者氏名<el-span class="span-class">（必須）</el-span></el-col>
      <el-col style= "width: 145px;">
        <el-input v-model="input8" size="mini"></el-input>
      </el-col>
    </el-row>
    <el-row class="row-class">
      <el-col class= "lab-class">　摘要</el-col>
      <el-col style= "width: 245px;">
        <el-input v-model="input9" size="mini"></el-input>
      </el-col>
    </el-row>
    <el-row class="row-class">
      <el-col class= "lab-class">　予約数<el-span class="span-class">（必須）</el-span></el-col>
      <el-col style= "width: 145px; ">
        <input class="nsd-input-class"></input>
      </el-col>
    </el-row>
    <el-row class="row-class">
      <el-col class= "lab-class">　追加予約数<el-span class="span-class">（必須）</el-span></el-col>
      <el-col style= "width: 145px; ">
        <input class="nsd-input-class"></input>
      </el-col>
    </el-row>
  </div>
</template>

<script>
export default {
  data () {
    return {
      checked1: false,
      checked2: false,
      checked3: true,
      input1: '',
      input2: '',
      input3: '',
      input4: '',
      input5: '',
      input6: '',
      input7: '',
      input8: '',
      input9: '',
      input10: ''
    }
  },
  methods: {
    querySearchAsync (queryString, cb) {
      var bumen = this.bumen
      var results = queryString ? bumen.filter(this.createStateFilter(queryString)) : bumen
      clearTimeout(this.timeout)
      this.timeout = setTimeout(() => {
        cb(results)
      }, 200 * Math.random())
    },
    createStateFilter (queryString) {
      return (state) => {
        return (state.value.toLowerCase().indexOf(queryString.toLowerCase()) === 0)
      }
    },
    handleSelect (item) {
      console.log(item)
    }
  },
  mounted () {
    this.bumen = this.loadAll()
  }
}
</script>

<style scoped>
.page-style {
  font-size: 12px;
  width: 518px;
  height: 100%;
  margin-left:10px;
  border: 1px solid;
  padding-top: 1px;
  padding-right: 1px;
}
.row-class {
  height: 30px;
  margin-bottom: 1px;
  margin-left: 1px;
  margin-right: 1px;
}
.lab-class {
  width: 170px;
  background-color: #77cad8;
  line-height: 30px;
  margin-right: 1px;
}
.checkbox-class {
  width: 300px;
  line-height: 30px;
  margin-left: 5px;
}
.span-class {
 color: red;
 float: right;
}
</style>
