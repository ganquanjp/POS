<template>
  <div>
    <div class="page-style">
      <el-row class= "row-class">
        <el-col class= "lab-class">　精算箇所<span class="span-class">（必須）</span></el-col>
        <el-col style= "width: 345px;">
          <el-autocomplete 
            v-model="formItem.seisanSoshikiNm" 
            :fetch-suggestions="querySearchAsync1"
            @select="handleSelect1"
            id="search_text" 
            size="mini" 
            >
          </el-autocomplete>
        </el-col>
      </el-row>
      <el-row class= "row-class">
        <el-col class= "lab-class">　使用開始年月日<span class="span-class">（必須）</span></el-col>
        <el-col style= "width: 145px;">
          <el-date-picker
            v-model="formItem.siyoStartYmd"
            size="mini"
            style= "width: 140px;"
            type="date">
          </el-date-picker>
        </el-col>
      </el-row>
      <el-row class= "row-class">
        <el-col class= "lab-class">　登録者氏名<span class="span-class">（必須）</span></el-col>
        <el-col style= "width: 145px;">
          <el-input v-model="formItem.seisanEntryUserId" size="mini"></el-input>
        </el-col>
      </el-row>
      <el-row class= "row-class">
        <el-col class= "lab-class">　摘要</el-col>
        <el-col style= "width: 245px;">
          <el-input v-model="formItem.tekiyo" size="mini"></el-input>
        </el-col>
      </el-row>
      <el-row class= "row-class">
        <el-col class= "lab-class">　予約数<span class="span-class">（必須）</span></el-col>
        <el-col style= "width: 145px; ">
          <el-input v-model="formItem.yoyakusu" size="mini"></el-input>
        </el-col>
      </el-row>
      <el-row class= "row-class">
        <el-col class= "lab-class">　工事件名コード<span class="span-class">（必須）</span></el-col>
        <el-col style= "width: 345px;">
          <el-autocomplete 
            v-model="formItem.kenmeiCd" 
            :fetch-suggestions="querySearchAsync2"
            @select="handleSelect2"
            id="search_text" 
            size="mini" 
            >
          </el-autocomplete>
        </el-col>
      </el-row>
      <el-row class= "row-class">
        <el-col class= "lab-class">　工事件名<span class="span-class">（必須）</span></el-col>
        <el-col style= "width: 345px;">
          <el-autocomplete 
            v-model="formItem.kenmeiNm" 
            :fetch-suggestions="querySearchAsync3"
            @select="handleSelect3"
            id="search_text" 
            size="mini" 
            >
          </el-autocomplete>
        </el-col>
      </el-row>
      <el-row class= "row-class">
        <el-col class= "lab-class">　適用開始日<span class="span-class">（必須）</span></el-col>
        <el-col style= "width: 260px;">
          <el-date-picker
            v-model="formItem.tekiyoStartYmd"
            size="mini"
            style= "width: 140px;"
            type="date">
          </el-date-picker>
        </el-col>
      </el-row>
      <el-row class= "row-class">
        <el-col class= "lab-class">　適用終了日<span class="span-class">（必須）</span></el-col>
        <el-col style= "width: 145px;">
          <el-date-picker
            v-model="formItem.tekiyoEndYmd"
            size="mini"
            style= "width: 140px;"
            type="date">
          </el-date-picker>
        </el-col>
      </el-row>
    </div>
    <el-row>
      <el-col>
        <nsd-button-bar v-bind:buttons="buttonName" v-bind:formItem="formItem"></nsd-button-bar>
      </el-col>
    </el-row>
  </div>
</template>

<script scoped>
import NSDButtonBar from '@/components/common/NSDButtonBar.vue'

export default {
  components: {
    'nsd-button-bar': NSDButtonBar
  },
  data () {
    return {
      buttonName: [
        {name: '登　録', primary: true, show: true, action: 'post', url: '/seisanshoToroku-insertSeisansho'},
        {name: 'ク　リ　ア', primary: true, show: true, action: 'clear', url: ''}
      ],
      formItem: {
        seisanSoshikiCd: '',
        seisanSoshikiNm: '',
        siyoStartYmd: '',
        seisanEntryUserId: '',
        tekiyo: '',
        yoyakusu: '',
        kenmeiCd: '',
        kenmeiNm: '',
        tekiyoStartYmd: '',
        tekiyoEndYmd: ''
      }
    }
  },
  methods: {
    loadSeisanKasho () {
      var items = ['soshikiCd', 'soshikiNm']
      return this.funcGetDropDownValue('/seisanshoToroku-selectSoshikiMaster', items)
    },
    loadKojiCD () {
      var items = ['kenmeiCd', 'kenmeiNm', 'tekiyoStartYmd', 'tekiyoEndYmd']
      return this.funcGetDropDownValue('/seisanshoToroku-selectKenmeiMaster', items)
    },
    loadKojiNM () {
      var items = ['kenmeiNm', 'kenmeiCd', 'tekiyoStartYmd', 'tekiyoEndYmd']
      return this.funcGetDropDownValue('/seisanshoToroku-selectKenmeiMaster', items)
    },
    querySearchAsync1 (queryString, cb) {
      var seisanKasho = this.seisanKasho
      var results = queryString ? seisanKasho.filter(this.createStateFilter(queryString)) : seisanKasho
      clearTimeout(this.timeout)
      this.timeout = setTimeout(() => {
        cb(results)
      }, 200 * Math.random())
    },
    querySearchAsync2 (queryString, cb) {
      var kojiCode = this.kojiCode
      var results = queryString ? kojiCode.filter(this.createStateFilter(queryString)) : kojiCode
      clearTimeout(this.timeout)
      this.timeout = setTimeout(() => {
        cb(results)
      }, 200 * Math.random())
    },
    querySearchAsync3 (queryString, cb) {
      var kojiName = this.kojiName
      var results = queryString ? kojiName.filter(this.createStateFilter(queryString)) : kojiName
      clearTimeout(this.timeout)
      this.timeout = setTimeout(() => {
        cb(results)
      }, 200 * Math.random())
    },
    createStateFilter (queryString) {
      return (state) => {
        return (state.value.toLowerCase().indexOf(queryString.toLowerCase()) === 0)
      }
    },
    handleSelect1 (item) {
      console.log(item)
      this.formItem.seisanSoshikiCd = item.seisanSoshikiCd
    },
    handleSelect2 (item) {
      console.log(item)
      this.formItem.kenmeiCd = item.value
      this.formItem.kenmeiNm = item.kenmeiNm
      this.formItem.tekiyoStartYmd = item.tekiyoStartYmd
      this.formItem.tekiyoEndYmd = item.tekiyoEndYmd
    },
    handleSelect3 (item) {
      console.log(item)
      this.formItem.kenmeiNm = item.value
      this.formItem.kenmeiCd = item.kenmeiCd
      this.formItem.tekiyoStartYmd = item.tekiyoStartYmd
      this.formItem.tekiyoEndYmd = item.tekiyoEndYmd
    }
  },
  mounted () {
    this.seisanKasho = this.loadSeisanKasho()
    this.kojiCode = this.loadKojiCD()
    this.kojiName = this.loadKojiNM()
  }
}
</script>

<style scoped>
.page-style {
  font-size: 12px;
  width: 518px;
  height: 100%;
  margin-left:10px;
  border: 1px solid;
  padding-top: 1px;
  padding-right: 1px;
}
.row-class {
  height: 30px;
  margin-bottom: 1px;
  margin-left: 1px;
  margin-right: 1px;
}
.lab-class {
  width: 170px;
  background-color: #77cad8;
  line-height: 30px;
  margin-right: 1px;
}
.checkbox-class {
  width: 300px;
  line-height: 30px;
  margin-left: 5px;
}
.span-class {
 color: red;
 float: right;
}
</style>
