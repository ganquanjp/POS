<template>
  <div>
    <el-row>
      <el-col>
        <nsd-content-title v-bind:titlename="titlename" v-bind:message="message"></nsd-content-title>
      </el-col>
    </el-row>
    <el-row>
      <el-col>
        <nsd-search-input></nsd-search-input>
      </el-col>
    </el-row>
    <el-row>
      <el-col>
        <nsd-button-bar v-bind:buttons="buttonName" v-bind:clicks="btnClick"></nsd-button-bar>
      </el-col>
    </el-row>
  </div>
</template>

<script>
import NsdContentTitle from '@/components/common/NSDContentTitle.vue'
import NSDButtonBar from '@/components/common/NSDButtonBar.vue'
import NSDSearchInput from '@/components/seisanshotoroku/shokai/NSDSearchInput.vue'

export default {
  components: {
    'nsd-content-title': NsdContentTitle,
    'nsd-button-bar': NSDButtonBar,
    'nsd-search-input': NSDSearchInput

  },
  data () {
    return {
      message: '　',
      buttonName: [
        {name: '削　除', primary: true, show: true, onClick: '削除'},
        {name: '修　正', primary: true, show: true, onClick: 'update'},
        {name: '戻　る', primary: true, show: true, onClick: '戻る'}
      ]
    }
  },
  computed: {
    titlename: function () {
      return '【精算書登録】照会'
    }
  },
  methods: {
    btnClick: function (item) {
      if (item === 'update') {
        this.$router.push({name: 'nsdssstrkkosin'})
      } else {
        alert(item + 'ボタンをクリックします。')
      }
    }
  }
}
</script>

<style scoped>

</style>
