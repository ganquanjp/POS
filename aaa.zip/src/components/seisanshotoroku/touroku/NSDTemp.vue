<template>
  <div class="page-style">
    <el-row>
      <el-col span="4">精算書番号</el-col>
      <el-col span="8">
        <el-input v-model="input" size="mini" placeholder="精算書番号を入力ください"></el-input>
      </el-col>
    </el-row>
    <el-row>
      <el-col span="4">固定資産番号</el-col>
      <el-col span="8">
        <el-input v-model="input" size="mini" placeholder="固定資産番号を入力ください"></el-input>
      </el-col>
    </el-row>
    <el-row>
      <el-col span="4">取得年月</el-col>
      <el-col span="8">
        <el-date-picker
          v-model="date1"
          size="mini"
          type="daterange"
          range-separator="～"
          start-placeholder="開始日付を選択してください"
          end-placeholder="終了日付を選択してください">
        </el-date-picker>
      </el-col>
    </el-row>
    <el-row>
      <el-col span="4">使用開始年月</el-col>
      <el-col span="8">
        <el-date-picker
          v-model="date2"
          size="mini"
          type="daterange"
          range-separator="～"
          start-placeholder="開始日付を選択してください"
          end-placeholder="終了日付を選択してください">
        </el-date-picker>
      </el-col>
    </el-row>
    <el-row>
      <el-col span="4">工事件名</el-col>
      <el-col span="8">
        <el-input v-model="input" size="mini" placeholder="工事件名を入力ください"></el-input>
      </el-col>
    </el-row>
    <el-row>
      <el-col span="4">設置場所名称</el-col>
      <el-col span="8">
        <el-input v-model="input" size="mini" placeholder="設置場所名称を入力ください"></el-input>
      </el-col>
    </el-row>
    <!--
    <table>
      <tr>
        <td bgcolor="#dcdcdc">精算書番号</td>
        <td ><el-input v-model="input" placeholder="精算書番号を入力ください"></el-input></td>
      </tr>
      <tr>
        <td bgcolor="#dcdcdc">固定資産番号</td>
        <td ><el-input v-model="input" placeholder="固定資産番号を入力ください"></el-input></td>
      </tr>
      <tr>
        <td bgcolor="#dcdcdc">取得年月</td>
        <td  colspan= 2><el-date-picker v-model="date" type="date" placeholder="日付を選択してください">"></el-date-picker></td>
        <td >～</td>
        <td colspan= 2><el-date-picker v-model="date" type="date" placeholder="日付を選択してください">"></el-date-picker></td>
      </tr>
      <tr>
        <td bgcolor="#dcdcdc">使用開始年月</td>
        <td  colspan= 2><el-date-picker v-model="date" type="date" placeholder="日付を選択してください">"></el-date-picker></td>
        <td >～</td>
        <td colspan= 2><el-date-picker v-model="date" type="date" placeholder="日付を選択してください">"></el-date-picker></td>

      </tr>
      <tr>
        <td bgcolor="#dcdcdc">工事件名</td>
        <td ><el-input v-model="input" placeholder="工事件名を入力ください"></el-input></td>
      </tr>
      <tr>
        <td bgcolor="#dcdcdc">設置場所名称</td>
        <td ><el-input v-model="input" placeholder="設置場所名称を入力ください"></el-input></td>
      </tr>
    </table>
    -->
  </div>
</template>

<script>
export default {
  data () {
    return {
      date1: '',
      date2: ''
    }
  }
}
</script>

<style scoped>
.page-style {
  font-size: 12px;
  margin-left:10px;
  line-height:30px;
}
</style>
