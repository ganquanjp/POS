import Vue from 'vue'
import Router from 'vue-router'
import nsdlayouts from '@/components/NSDLayouts.vue'
import nsdcontent from '@/components/NSDContent.vue'
import nsdssstrkkensaku from '@/components/seisanshotoroku/NSDSsstrkKensaku.vue'
import nsdssstrkshokai from '@/components/seisanshotoroku/NSDSsstrkShokai.vue'
import nsdssstrksinki from '@/components/seisanshotoroku/NSDSsstrkSinki.vue'
import nsdssstrkkosin from '@/components/seisanshotoroku/NSDSsstrkKosin.vue'
import nsdssstrkrkkkichiran from '@/components/seisanshotoroku/NSDSsstrkRkkkIchiran.vue'
import nsdstkmain from '@/components/seisanshoshutoku/NSDStkMain.vue'
import nsdstkshinki from '@/components/seisanshoshutoku/NSDStkShinki.vue'
import nsdstkshokai from '@/components/seisanshoshutoku/NSDStkShokai.vue'
import nsdstkshusei from '@/components/seisanshoshutoku/NSDStkShusei.vue'
import nsdtest from '@/components/seisanshotoroku/touroku/NSDTest.vue'
import nsdlogininput from '@/components/NSDLogInInput.vue'
import nsdmenu from '@/components/menu/NSDMenu.vue'
import nsdktssdtsakusei from '@/components/koteishisandaityo/NSDKtssdtSakusei.vue'
import nsdktssdtsuturoku from '@/components/koteishisandaityo/NSDKtssdtSuturoku.vue'
import nsdbktsnkensaku from '@/components/bunkatsushunyu/NSDBktsnKensaku.vue'
import nsdbktsnkosin from '@/components/bunkatsushunyu/NSDBktsnKosin.vue'
import nsdstkshonin from '@/components/seisanshoshutoku/NSDStkShonin.vue'
import nsdstkshoninshokai from '@/components/seisanshoshutoku/NSDStkShoninshokai.vue'
import nsdstkshoninkosin from '@/components/seisanshoshutoku/NSDStkShoninkosin.vue'
import nsdstkkeirisinsa from '@/components/seisanshoshutoku/NSDStkKeirisinsa.vue'
import nsdstkkeirikosin from '@/components/seisanshoshutoku/NSDStkKeirikosin.vue'
import nsdsssjkknaiyokensaku from '@/components/seisanshojokyaku/NSDSssjkkNaiyokensaku.vue'
import nsdsssjkknaiyoshokai from '@/components/seisanshojokyaku/NSDSssjkkNaiyoshokai.vue'
import nsdsssjkknaiyokosin from '@/components/seisanshojokyaku/NSDSssjkkNaiyokosin.vue'
import nsdsssjkkkensaku from '@/components/seisanshojokyaku/NSDSssjkkKensaku.vue'
import nsdsssjkkshokai from '@/components/seisanshojokyaku/NSDSssjkkShokai.vue'
import nsdsssjkksinki from '@/components/seisanshojokyaku/NSDSssjkkSinki.vue'
import nsdsssjkkkosin from '@/components/seisanshojokyaku/NSDSssjkkKosin.vue'
import nsdkrftkskensaku from '@/components/kanrifutankasho/NSDKrftksKensaku.vue'
import nsdkrftkskosin from '@/components/kanrifutankasho/NSDKrftksKosin.vue'
import nsdkrftkssinki from '@/components/kanrifutankasho/NSDKrftksSinki.vue'
import nsdsssjkkseisankensaku from '@/components/seisanshojokyaku/NSDSssjkkSeisankensaku.vue'
import nsdsssjkkseisanshokai from '@/components/seisanshojokyaku/NSDSssjkkSeisanshokai.vue'
import nsdsssjkkseisankosin from '@/components/seisanshojokyaku/NSDSssjkkSeisankosin.vue'
import nsdnsssjkkshoninkensku from '@/components/seisanshojokyaku/NSDSssjkkShoninkensku.vue'
import nsdnsssjkkshoninshokai from '@/components/seisanshojokyaku/NSDSssjkkShoninshokai.vue'
import nsdnsssjkkshoninkosin from '@/components/seisanshojokyaku/NSDSssjkkShoninkosin.vue'
import nsdsssjkkkeirikosin from '@/components/seisanshojokyaku/NSDSssjkkKeirikosin.vue'
import nsdsssjkkkeirikensaku from '@/components/seisanshojokyaku/NSDSssjkkKeirikensaku.vue'

Vue.use(Router)

export default new Router({

  routes: [
    {
      path: '/',
      name: 'nsdlogininput',
      component: nsdlogininput
    }, {
      path: '/',
      name: 'nsdlayouts',
      component: nsdlayouts,
      children: [{
        path: '/nsdcontent',
        component: nsdcontent,
        children: [{
          path: '/nsdcontent/nsdssstrkkensaku/:id',
          component: nsdssstrkkensaku,
          name: 'nsdssstrkkensaku'
        }, {
          path: '/nsdcontent/seisanshotoroku/nsdssstrkshokai',
          component: nsdssstrkshokai,
          name: 'nsdssstrkshokai'
        }, {
          path: '/nsdcontent/seisanshotoroku/renkeikekaichiran',
          component: nsdssstrkrkkkichiran,
          name: 'nsdssstrkrkkkichiran'
        }, {
          path: '/nsdcontent/seisanshotoroku/nsdssstrksinki',
          component: nsdssstrksinki,
          name: 'nsdssstrksinki'
        }, {
          path: '/nsdcontent/seisanshotoroku/nsdssstrkkosin',
          component: nsdssstrkkosin,
          name: 'nsdssstrkkosin'
        }, {
          path: '/nsdcontent/seisanshotoroku/touroku/nsdtest',
          component: nsdtest,
          name: 'test'
        }, {
          path: '/nsdcontent/seisanshoshutoku/nsdstkmain',
          component: nsdstkmain,
          name: 'nsdstkmain'
        }, {
          path: '/nsdcontent/seisanshoshutoku/nsdstkshinki',
          component: nsdstkshinki,
          name: 'nsdstkshinki'
        }, {
          path: '/nsdcontent/seisanshoshutoku/nsdstkshokai',
          component: nsdstkshokai,
          name: 'nsdstkshokai'
        }, {
          path: '/nsdcontent/seisanshoshutoku/nsdstkshusei',
          component: nsdstkshusei,
          name: 'nsdstkshusei'
        }, {
          path: '/nsdcontent/daityo/nsdktssdtsakusei',
          component: nsdktssdtsakusei,
          name: 'nsdktssdtsakusei'
        }, {
          path: '/nsdcontent/daityo/nsdktssdtsuturoku',
          component: nsdktssdtsuturoku,
          name: 'nsdktssdtsuturoku'
        }, {
          path: '/nsdcontent/bunkatsushunyu/nsdbktsnkensaku',
          component: nsdbktsnkensaku,
          name: 'nsdbktsnkensaku'
        }, {
          path: '/nsdcontent/bunkatsushunyu/nsdbktsnkosin',
          component: nsdbktsnkosin,
          name: 'nsdbktsnkosin'
        }, {
          path: '/nsdcontent/seisanshoshutoku/nsdstkshonin',
          component: nsdstkshonin,
          name: 'nsdstkshonin'
        }, {
          path: '/nsdcontent/seisanshoshutoku/nsdstkshoninshokai',
          component: nsdstkshoninshokai,
          name: 'nsdstkshoninshokai'
        }, {
          path: '/nsdcontent/seisanshoshutoku/nsdstkshoninkosin',
          component: nsdstkshoninkosin,
          name: 'nsdstkshoninkosin'
        }, {
          path: '/nsdcontent/seisanshoshutoku/nsdstkkeirisinsa',
          component: nsdstkkeirisinsa,
          name: 'nsdstkkeirisinsa'
        }, {
          path: '/nsdcontent/seisanshoshutoku/nsdstkkeirikosin',
          component: nsdstkkeirikosin,
          name: 'nsdstkkeirikosin'
        }, {
          path: '/nsdcontent/seisanshojokyaku/nsdsssjkknaiyokensaku',
          component: nsdsssjkknaiyokensaku,
          name: 'nsdsssjkknaiyokensaku'
        }, {
          path: '/nsdcontent/seisanshojokyaku/nsdsssjkknaiyoshokai',
          component: nsdsssjkknaiyoshokai,
          name: 'nsdsssjkknaiyoshokai'
        }, {
          path: '/nsdcontent/seisanshojokyaku/nsdsssjkknaiyokosin',
          component: nsdsssjkknaiyokosin,
          name: 'nsdsssjkknaiyokosin'
        }, {
          path: '/nsdcontent/seisanshojokyaku/nsdsssjkkkensaku',
          component: nsdsssjkkkensaku,
          name: 'nsdsssjkkkensaku'
        }, {
          path: '/nsdcontent/seisanshojokyaku/nsdsssjkkshokai',
          component: nsdsssjkkshokai,
          name: 'nsdsssjkkshokai'
        }, {
          path: '/nsdcontent/seisanshojokyaku/nsdsssjkksinki',
          component: nsdsssjkksinki,
          name: 'nsdsssjkksinki'
        }, {
          path: '/nsdcontent/seisanshojokyaku/nsdsssjkkkosin',
          component: nsdsssjkkkosin,
          name: 'nsdsssjkkkosin'
        }, {
          path: '/nsdcontent/menu/nsdmenu',
          component: nsdmenu,
          name: 'nsdmenu'
        }, {
          path: '/nsdcontent/kanrifutankasho/nsdkrftkskensaku',
          component: nsdkrftkskensaku,
          name: 'nsdkrftkskensaku'
        }, {
          path: '/nsdcontent/kanrifutankasho/nsdkrftkskosin',
          component: nsdkrftkskosin,
          name: 'nsdkrftkskosin'
        }, {
          path: '/nsdcontent/kanrifutankasho/nsdkrftkssinki',
          component: nsdkrftkssinki,
          name: 'nsdkrftkssinki'
        }, {
          path: '/nsdcontent/seisanshojokyaku/nsdsssjkkseisankensaku',
          component: nsdsssjkkseisankensaku,
          name: 'nsdsssjkkseisankensaku'
        }, {
          path: '/nsdcontent/seisanshojokyaku/nsdsssjkkseisanshokai',
          component: nsdsssjkkseisanshokai,
          name: 'nsdsssjkkseisanshokai'
        }, {
          path: '/nsdcontent/seisanshojokyaku/nsdsssjkkseisankosin',
          component: nsdsssjkkseisankosin,
          name: 'nsdsssjkkseisankosin'
        }, {
          path: '/nsdcontent/seisanshojokyaku/nsdnsssjkkshoninkensku',
          component: nsdnsssjkkshoninkensku,
          name: 'nsdnsssjkkshoninkensku'
        }, {
          path: '/nsdcontent/seisanshojokyaku/nsdnsssjkkshoninshokai',
          component: nsdnsssjkkshoninshokai,
          name: 'nsdnsssjkkshoninshokai'
        }, {
          path: '/nsdcontent/seisanshojokyaku/nsdnsssjkkshoninkosin',
          component: nsdnsssjkkshoninkosin,
          name: 'nsdnsssjkkshoninkosin'
        }, {
          path: '/nsdcontent/seisanshojokyaku/nsdsssjkkkeirikosin',
          component: nsdsssjkkkeirikosin,
          name: 'nsdsssjkkkeirikosin'
        }, {
          path: '/nsdcontent/seisanshojokyaku/nsdsssjkkkeirikensaku',
          component: nsdsssjkkkeirikensaku,
          name: 'nsdsssjkkkeirikensaku'
        }]
      }]
    }
  ]

/*
  routes: [
    {
      path: '/',
      name: 'nsdlayouts',
      component: nsdlayouts,
      children: [{
        path: '/nsdcontent',
        component: nsdcontent,
        children: [{
          path: '/nsdcontent/seisanshotoroku/touroku/nsdssstrkkensaku',
          component: nsdssstrkkensaku
        }, {
          path: '/nsdcontent/seisanshotoroku/touroku/nsdtest',
          component: nsdtest
        }]
      }]
    }
  ]
*/
})
