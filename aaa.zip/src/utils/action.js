import qs from 'qs'

export default{
  install (Vue, options) {
    Vue.prototype.$baseURL = '/nkss-web'
    Vue.prototype.headers = {'Content-Type': 'application/x-www-form-urlencoded'}

    Vue.prototype.funcHttpPost = function (url, requestData, moveUrl) {
      url = this.$baseURL + url
      var _store = this.$store
      var _router = this.$router
      var _alert = this.$alert
      this.$http.post(url, qs.stringify(requestData), this.headers)
      .then(function (response) {
        if (typeof (response.data.msg) === 'undefined' || response.data.msg === '') {
          _store.state.message = ''
          _store.state.tableData = response.data.dataList
          if (response.data.dataList.length > 0) {
            _store.state.currentPageData = response.data.dataList.slice(0, 10)
          }
          if (moveUrl !== undefined) {
            _router.push(moveUrl)
          }
        } else {
          _store.state.message = response.data.msg
        }
      })
      .catch(function (error) {
        funcHttpError(_store, _alert)
        console.log(error)
      })
    }

    Vue.prototype.funcHttpGet = function (url) {
      url = this.$baseURL + url
      var _store = this.$store
      var _alert = this.$alert
      this.$http.get(url)
      .then(function (response) {
        _store.state.tableData = response.data.dataList
        _store.state.message = response.data.msg
        _store.state.currentPageData = response.data.dataList.slice(0, 10)
      })
      .catch(function (error) {
        funcHttpError(_store, _alert)
        console.log(error)
      })
    }

    Vue.prototype.funcClear = function () {
      this.$store.state.tableData = []
      this.$store.state.currentPageData = []
      this.$store.state.message = ''
    }

    Vue.prototype.funcGetDropDownValue = function (url, itemNames) {
      url = this.$baseURL + url
      var _store = this.$store
      var _alert = this.$alert
      var resultArray = []
      this.$http.get(url).then(function (response) {
        response.data.dataList.forEach(function (row, index, array) {
          var obj = {}
          obj['value'] = row[itemNames[0]]
          for (var item in itemNames) {
            if (item > 0) {
              obj[itemNames[item]] = row[itemNames[item]]
            }
          }
          resultArray[index] = obj
        })
      })
      .catch(function (error) {
        funcHttpError(_store, _alert)
        console.log(error)
      })
      return resultArray
    }

    function funcHttpError (_store, _alert) {
      _store.state.message = 'サーバーメンテナンス中......'
      _alert(_store.state.message, 'エラー', {
        confirmButtonText: '確定',
        callback: action => {
          /* 動作なし */
        }
      })
    }
  }
}
