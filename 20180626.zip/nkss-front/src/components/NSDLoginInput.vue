<template>
  <div>
    <div class="div-style-1">
      <div class="div-style-2"><p>固 定 資 産 登 録 シ ス テ ム</p></div>
    </div>
    <div style="padding-left: 15px;margin-top: 5px;">
      <!--<span style="font-size: 26px;">ログイン</span>-->
    </div>
    <div>
      <nsd-content-title v-bind:titlename="titlename" v-bind:message="this.$store.state.message"></nsd-content-title>
    </div>
    <div class="div-style-3">
      <el-form :model="loginForm" status-icon ref="loginForm" width="100px" label-width="100px" label-position="left" class="class-loginForm">
        <el-form-item label="ユーザーID" prop="userId" :rules="[{ required: true, message: '必須入力項目'}]">
          <el-input type="text" style= "width: 240px;" v-model="loginForm.userId"></el-input>
        </el-form-item>
        <el-form-item label="パスワード" prop="password" :rules="[{ required: true, message: '必須入力項目'}]">
          <el-input type="password" style= "width: 240px;" v-model="loginForm.password"></el-input>
        </el-form-item>
        <el-form-item style="padding-left: 170px;">
          <el-button size="mini" @click="login('loginForm')"  type="primary">ログイン</el-button>
        </el-form-item>
      </el-form>
    </div>
  </div>
</template>

<script>
import NsdContentTitle from '@/components/common/NSDContentTitle.vue'

export default {
  components: {
    'nsd-content-title': NsdContentTitle
  },
  data () {
    return {
      titlename: 'ログイン',
      loginForm: {
        userId: '',
        password: ''
      }
    }
  },
  methods: {
    login: function (formName) {
      this.$store.state.message = {}
      this.$refs[formName].validate((valid) => {
        if (valid) {
          this.funcHttpPost('/system-userlogin', this.loginForm, 'nsdmenu')
        } else {
          return false
        }
      })
    }
  }
}
</script>

<style scoped>
.div-style-1 {
  background-color: #B3C0D1;
  color: #333;
  text-align: center;
  line-height: 0px;
  padding: 2px;
  height: 70px;
}
.div-style-2 {
  sition: relative;
  border-style:groove;
  color:white;
  text-align:center;
  margin:0px;
  height:65px;
  font-size:30px;
}
.div-style-3 {
  padding-top: 100px;
  text-align: center;
}
.info-style {
  vertical-align: middle;
  color : red;
  font-size: 12px;
  width:100%;
}
.class-loginForm {
  display: inline-block;
}
</style>

