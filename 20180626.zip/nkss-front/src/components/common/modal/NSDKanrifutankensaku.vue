<template>
  <transition name="modal">
    <div class="modal-mask">
      <div class="modal-wrapper">
        <div class="modal-container">
          <div class="close-btn-style">
            <el-button type="text" @click="this.close" size="mini"><i class="close icon"></i></el-button>
          </div>
          <div>
            <el-row>
              <el-col>
                <nsd-content-title v-bind:titlename="titlename" v-bind:message="this.$store.state.message"></nsd-content-title>
              </el-col>
            </el-row>
            <div class="page-style">
              <el-row class="row-class">
                <el-col class="lab-class">　管理箇所（コード／名称）</el-col>
                <el-col style= "width: 160px;">
                  <el-input v-model="formItem.kanrikasyocd" size="mini" placeholder=""></el-input>
                </el-col>
                <el-col :span="1">　／</el-col>
                <el-col style= "width: 164px; margin-left:-1px;">
                  <el-input v-model="formItem.kanrikasyo" size="mini" placeholder=""></el-input>
                </el-col>
              </el-row>
              <el-row class="row-class">
                <el-col class="lab-class">　負担箇所（コード／名称）</el-col>
                <el-col style= "width: 160px;">
                  <el-input v-model="formItem.futankasyocd" size="mini" placeholder=""></el-input>
                </el-col>
                <el-col :span="1">　／</el-col>
                <el-col style= "width: 164px; margin-left:-1px;">
                  <el-input v-model="formItem.futankasyo" size="mini" placeholder=""></el-input>
                </el-col>
              </el-row>
              <el-row class="row-class">
                <el-col class="lab-class">　使用開始年月日</el-col>
                <el-col style= "width: 160px;">
                  <el-date-picker
                    v-model="formItem.kaisiymd"
                    size="mini"
                    style="width: 160px;"
                    type="date"
                    value-format="yyyy-MM-dd">
                  </el-date-picker>
                </el-col>
              </el-row>
            </div>
            <el-row >
              <el-col>
                <nsd-button-bar v-bind:buttons="buttonName" v-bind:formItem="formItem"></nsd-button-bar>
              </el-col>
            </el-row>
            <el-row v-if="this.tableData.length > 0">
              <el-col>
                <div>
                  <div style="position: relative;">
                   <span style="font-size: 12px;">{{this.tableData.length}}件</span>
                    <div style="position: absolute; top: -5px; right: 0px;">
                      <el-pagination
                        background
                        @size-change="handleSizeChange"
                        @current-change="handleCurrentChange"
                        :current-page.sync="pageData.currentPage"
                        :page-sizes="this.pageData.pageSizeArr"
                        :page-size="this.pageData.pageSizeAct"
                        small
                        layout="prev, pager, next"
                        prev-text="前へ"
                        next-text="次へ"
                        :total="this.tableData.length">
                      </el-pagination>
                    </div>
                  </div>
                  <el-table style= "padding: -50px;" :data="this.tableData.current" border max-height=335 @sort-change="handleSortChange">
                    <el-table-column 
                      prop="rowNo" 
                      label="NO." 
                      width="70px">
                    </el-table-column>
                    <el-table-column 
                      prop="kanrikasyocd" 
                      sortable 
                      label="管理箇所コード" 
                      min-width="95px">
                        <template slot-scope="scope">
                          <el-button type="text" @click="move(scope.row)">{{scope.row.kanrikasyocd}}</el-button>
                        </template>
                    </el-table-column >
                    <el-table-column
                      prop="kanrikasyo"
                      label="管理箇所名称"
                      min-width="90px">
                    </el-table-column >
                    <el-table-column
                      prop="kkikanF"
                      sortable
                      label="管理箇所適用期間（FROM）"
                      min-width="160px">
                    </el-table-column>
                    <el-table-column
                      prop="kkikanT"
                      sortable
                      label="管理箇所適用期間（TO）"
                      min-width="140px">
                    </el-table-column>
                    <el-table-column
                      prop="futankasyocd" 
                      sortable
                      label="負担箇所コード"
                      min-width="95px">
                    </el-table-column>
                    <el-table-column
                      prop="futankasyo"
                      label="負担箇所名称"
                      min-width="90px">
                    </el-table-column>
                    <el-table-column
                      prop="fkikanF"
                      sortable
                      label="負担箇所適用期間（FROM）"
                      min-width="160px">
                    </el-table-column>
                    <el-table-column
                      prop="fkikanT"
                      sortable
                      label="負担箇所適用期間（TO）"
                      min-width="140px">
                    </el-table-column>
                  </el-table>
                </div>
              </el-col>
            </el-row>
          </div>
        </div>
      </div>
    </div>
  </transition>
</template>

<script>
import NsdContentTitle from '@/components/common/NSDContentTitle.vue'
import NSDButtonBar from '@/components/common/NSDButtonBar.vue'

export default {
  components: {
    'nsd-content-title': NsdContentTitle,
    'nsd-button-bar': NSDButtonBar
  },
  created: function () {
    this.$store.state.message.msgLevel = ''
    this.$store.state.message.content = this.$CONST_.msgContent.SEARCH
  },
  data () {
    return {
      titlename: '【管理箇所・負担箇所】検索',
      buttonName: [
        {name: this.$CONST_.buttonName.SEARCH, primary: true, show: true, action: 'httpPost', url: '/sansho-kanrifutanks', callBack: this.searchCallBack},
        {name: this.$CONST_.buttonName.RESET, primary: true, show: true, action: 'reset', url: ''},
        {name: this.$CONST_.buttonName.BACK, primary: true, show: true, action: 'close', url: '', callBack: this.close}
      ],
      formItem: {
        kanrikasyocd: '',
        kanrikasyo: '',
        futankasyocd: '',
        futankasyo: '',
        kaisiymd: ''
      },
      pageData: {
        total: 0,
        pageNum: 0,
        pageSizeArr: this.$CONST_.tableConst.PAGE_SIZES,
        pageSizeAct: this.$CONST_.tableConst.PAGE_SIZE,
        currentPage: 1,
        visible: false
      },
      tableData: []
    }
  },
  methods: {
    move: function (rowData) {
      let para = Object.assign({}, rowData)
      this.$emit('backData', para)
      this.close()
    },
    handleSizeChange (index) {
      this.pageData.pageSizeAct = index
      this.initTableList(1)
    },
    handleCurrentChange (index) {
      this.initTableList(index)
    },
    initTableList (index) {
      this._initPageData(index)
      this.getPageData()
      let container = this.$el.querySelector('.el-table__body-wrapper')
      if (container !== null) {
        container.scrollTop = 0
      }
    },
    _initPageData (index) {
      this.pageData.pageNum = (index - 1) * this.pageData.pageSizeAct
      this.pageData.currentPage = index
    },
    getPageData () {
      this.tableData.current = this.tableData.slice(this.pageData.pageSizeAct * (this.pageData.currentPage - 1), this.pageData.pageSizeAct * this.pageData.currentPage)
    },
    // ヘッダーにてソートボタンを押すとソート変更する
    handleSortChange ({ column, prop, order }) {
      this.funcSortChange(column, prop, order, this.$store)
      // ページデータ再設定
      this.getPageData()
    },
    searchCallBack (val) {
      if (typeof (val) !== 'undefined') {
        this.tableData = val
      } else {
        this.tableData = []
      }
      this.pageData.currentPage = 1
      this.getPageData()
    },
    close () {
      this.funcInitMessage(this.$store)
      this.$emit('close')
    }
  }
}
</script>

<style scoped>
.el-table .class-header {
  color: black;
  font-size: 12px;
  width: 100%;
}
.modal-mask {
  position: fixed;
  z-index: 1;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background-color: rgba(0, 0, 0, .5);
  display: table;
  transition: opacity .3s ease;
}
.modal-wrapper {
  display: table-cell;
  vertical-align: middle;
}
.modal-container {
  position: relative;
  width: 1170px;
  height: 595px;
  margin: 0 auto;
  margin-top: 10px;
  padding: 10px 15px;
  background-color: #fff;
  border-radius: 2px;
  box-shadow: 0 2px 8px rgba(0, 0, 0, .33);
  transition: all .3s ease;
}
.modal-leave-active .modal-container {
  -webkit-transform: scale(1.1);
  transform: scale(1.1);
}
.close-btn-style {
  position: absolute;
  right: 0px;
  top: 0px;
  padding: 0px;
}
.page-style {
  font-size: 12px;
  width: 520px;
  height: 100%;
  line-height:30px;
  border: 1px solid;
  padding-top: 1px;
  padding-right: 1px;
}
.row-class {
  height: 30px;
  margin-bottom: 1px;
  margin-left: 1px;
  margin-right: 1px;
}
.lab-class {
  width: 170px;
  background-color: #77cad8;
  line-height: 30px;
  margin-right: 1px;
}
</style>
