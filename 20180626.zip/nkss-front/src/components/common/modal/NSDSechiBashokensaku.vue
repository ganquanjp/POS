<template>
  <transition name="modal">
    <div class="modal-mask">
      <div class="modal-wrapper">
        <div class="modal-container">
          <div class="close-btn-style">
            <el-button type="text" @click="this.close" size="mini"><i class="close icon"></i></el-button>
          </div>
          <div>
            <el-row>
              <el-col>
                <nsd-content-title v-bind:titlename="titlename" v-bind:message="this.$store.state.message"></nsd-content-title>
              </el-col>
            </el-row>
            <div class="scroll-box">
              <div class="page-style">
                <el-row class="row-class">
                  <el-col class="lab-class">　場所コード</el-col>
                  <el-col style= "width: 350px;">
                    <el-input v-model="formItem.sechiBashoCd" size="mini"></el-input>
                  </el-col>
                </el-row>
                <el-row class="row-class">
                  <el-col class="lab-class">　場所名称</el-col>
                  <el-col style= "width: 350px;">
                    <el-input v-model="formItem.sechiBashoNm" size="mini"></el-input>
                  </el-col>
                </el-row>
              </div>
             <el-row >
               <el-col>
                 <nsd-button-bar v-bind:buttons="buttonName" v-bind:formItem="formItem"></nsd-button-bar>
               </el-col>
             </el-row>
              <el-row v-if="this.tableData.length > 0">
                <el-col>
                  <div>
                    <div style="position: relative;">
                     <span style="font-size: 12px;">{{this.tableData.length}}件</span>
                      <div style="position: absolute; top: -5px; right: 0px;">
                        <el-pagination
                          background
                          @size-change="handleSizeChange"
                          @current-change="handleCurrentChange"
                          :current-page.sync="pageData.currentPage"
                          :page-sizes="this.pageData.pageSizeArr"
                          :page-size="this.pageData.pageSizeAct"
                          small
                          layout="prev, pager, next"
                          prev-text="前へ"
                          next-text="次へ"
                          :total="this.tableData.length">
                        </el-pagination>
                      </div>
                    </div>
                    <el-table style= "padding: -50px;" :data="this.tableData.current" border max-height=297 @sort-change="handleSortChange">
                      <el-table-column 
                        prop="rowNo"
                        label="NO."
                        min-width="75px">
                      </el-table-column>
                      <el-table-column
                         prop="sechiBashoCd"
                         sortable
                         label="場所コード"
                         min-width="250px">
                           <template slot-scope="scope">
                             <el-button type="text" size="medium" @click="move(scope.row)">{{scope.row.sechiBashoCd}}</el-button>
                           </template>
                      </el-table-column >
                      <el-table-column
                         prop="sechiBashoNm"
                         label="場所名称"
                         min-width="555px">
                      </el-table-column>
                    </el-table>
                  </div>
                </el-col>
              </el-row>
            </div>
          </div>
        </div>
      </div>
    </div>
  </transition>
</template>

<script scoped>
import NsdContentTitle from '@/components/common/NSDContentTitle.vue'
import NSDButtonBar from '@/components/common/NSDButtonBar.vue'

export default {
  components: {
    'nsd-content-title': NsdContentTitle,
    'nsd-button-bar': NSDButtonBar
  },
  created: function () {
    this.$store.state.message.msgLevel = ''
    this.$store.state.message.content = this.$CONST_.msgContent.SEARCH
  },
  data () {
    return {
      titlename: '【設置場所】検索',
      buttonName: [
        {name: this.$CONST_.buttonName.SEARCH, primary: true, show: true, action: 'httpPost', url: '/sansho-sechibasho', callBack: this.searchCallBack},
        {name: this.$CONST_.buttonName.RESET, primary: true, show: true, action: 'reset', url: ''},
        {name: this.$CONST_.buttonName.BACK, primary: true, show: true, action: 'close', url: '', callBack: this.close}
      ],
      formItem: {
        sechiBashoCd: '',
        sechiBashoNm: ''
      },
      pageData: {
        total: 0,
        pageNum: 0,
        pageSizeArr: this.$CONST_.tableConst.PAGE_SIZES,
        pageSizeAct: this.$CONST_.tableConst.PAGE_SIZE,
        currentPage: 1,
        visible: false
      },
      tableData: []
    }
  },
  methods: {
    move: function (rowData) {
      let para = Object.assign({}, rowData)
      this.$emit('backData', para)
      this.close()
    },
    handleSizeChange (index) {
      this.pageData.pageSizeAct = index
      this.initTableList(1)
    },
    handleCurrentChange (index) {
      this.initTableList(index)
    },
    initTableList (index) {
      this._initPageData(index)
      this.getPageData()
      let container = this.$el.querySelector('.el-table__body-wrapper')
      if (container !== null) {
        container.scrollTop = 0
      }
    },
    _initPageData (index) {
      this.pageData.pageNum = (index - 1) * this.pageData.pageSizeAct
      this.pageData.currentPage = index
    },
    getPageData () {
      this.tableData.current = this.tableData.slice(this.pageData.pageSizeAct * (this.pageData.currentPage - 1), this.pageData.pageSizeAct * this.pageData.currentPage)
    },
    // ヘッダーにてソートボタンを押すとソート変更する
    handleSortChange ({ column, prop, order }) {
      this.funcSortChange(column, prop, order, this.$store)
      // ページデータ再設定
      this.getPageData()
    },
    searchCallBack (val) {
      if (typeof (val) !== 'undefined') {
        this.tableData = val
      } else {
        this.tableData = []
      }
      this.pageData.currentPage = 1
      this.getPageData()
    },
    close () {
      this.funcInitMessage(this.$store)
      this.$emit('close')
    }
  }
}
</script>

<style scoped>
.modal-mask {
  position: fixed;
  z-index: 1;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background-color: rgba(0, 0, 0, .5);
  display: table;
  transition: opacity .3s ease;
}
.modal-wrapper {
  display: table-cell;
  vertical-align: middle;
}
.modal-container {
  position: relative;
  width: 910px;
  height: 550px;
  margin: 0 auto;
  margin-top: 10px;
  padding: 10px 15px;
  background-color: #fff;
  border-radius: 2px;
  box-shadow: 0 2px 8px rgba(0, 0, 0, .33);
  transition: all .3s ease;
}
.modal-leave-active .modal-container {
  -webkit-transform: scale(1.1);
  transform: scale(1.1);
}
.close-btn-style {
  position: absolute;
  right: 0px;
  top: 0px;
  padding: 0px;
}
.page-style {
  font-size: 12px;
  width: 523px;
  height: 100%;
  margin-top:5px;
  line-height:30px;
  border: 1px solid;
  padding-top: 1px;
  padding-right: 1px;
}
.row-class {
  height: 30px;
  margin-bottom: 1px;
  margin-left: 1px;
  margin-right: 1px;
}
.lab-class {
  width: 170px;
  background-color: #77cad8;
  line-height: 30px;
  margin-right: 1px;
}
</style>
