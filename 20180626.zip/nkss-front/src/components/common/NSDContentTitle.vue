<template>
  <div>
    <el-row v-if="titlename!=''">
      <el-col>
        <span class="title-style">{{ titlename }}</span>
        <span v-if="seitumei!=''" class="seitumei-style">{{ seitumei }}</span><hr/>
      </el-col>
    </el-row>
    <el-row>
      <el-col>
        <div class="info-style">
          <label style="padding-left: 5px;" >
            <span style="color: red" v-if="isError===1">{{ message.content }}</span>
            <span v-else-if="isError===0">{{ message.content }}</span>
            <span v-else></span>
          </label>
          <hr/>
        </div>
      </el-col>
    </el-row>
  </div>
</template>

<script>
export default {
  props: ['titlename', 'seitumei', 'message'],
  computed: {
    isError: function () {
      if (typeof (this.message) !== 'undefined') {
        if (typeof (this.message.content) !== 'undefined') {
          if (this.message.msgLevel === 'E') {
            return 1
          } else {
            return 0
          }
        }
      }
    }
  }
}
</script>

<style scoped>
.title-style {
  font-size: 20px;
  padding-left: 5px;
}
.info-style {
  vertical-align: middle;
  font-size: 12px;
  width:100%;
}
.seitumei-style {
  font-size: 12px;
  color: red;
  white-space: pre-wrap;
  padding-left: 5px;
  display:block;
}
</style>
