<template>
  <el-menu
    default-active="1"
    :router="true"
    :unique-opened="false"
    @open="handleOpen"
    @close="handleClose"
    @select="handleSelect">
    <el-submenu v-for="(category, key) in categorys" :index="category.groupId" :key="category.groupId">
      <template slot="title">
        <span>{{ category.groupName }}</span>
      </template>
      <el-menu-item 
        v-for="(link, key) in category.usmList"
        :route="{ name: link.routerName, params: { id: link.id }}"
        :index="link.menuId"
        :key="key"
      >
        {{ link.menuLinkNm }}
      </el-menu-item>
    </el-submenu>
  </el-menu>
</template>

<script>
export default {
  methods: {
    handleOpen (key, keyPath) {
      // console.log(key, keyPath)
    },
    handleClose (key, keyPath) {
      // console.log(key, keyPath)
    },
    handleSelect (key, keyPath) {
      /*
      if (key !== this.curMenuId) {

      }
      this.setInitMessage(this.curMenuId)
      */
      this.funcClearStoreData()
      // this.curMenuId = key
      this.setInitMessage(key)
    },
    setInitMessage (menuId) {
      if (menuId === 'KSS020-G060' ||
          menuId === 'KSS030-G040' ||
          menuId === 'KSS040-G040' ||
          menuId === 'KSS070-G050'
      ) {
        this.$store.state.message.content = this.$CONST_.msgContent.INSERT
      } else if (menuId === 'KSS020-G120' ||
        menuId === 'KSS060-G030' ||
        menuId === 'KSS060-G040'
      ) {
        this.$store.state.message.content = ''
      } else if (menuId === 'KSS060-G030') {
        this.$store.state.message.content = this.$CONST_.msgContent.DAICHO
      } else {
        this.$store.state.message.content = this.$CONST_.msgContent.SEARCH
      }
    }
  },
  created () {
    this.categorys = this.$store.state.tableData
  },
  data () {
    return {
      categorys: [],
      curMenuId: ''
    }
  }
}
</script>

<style>

</style>