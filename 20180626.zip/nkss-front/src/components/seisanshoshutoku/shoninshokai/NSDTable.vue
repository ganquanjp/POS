<template>
  <div>
    <div class="div-style1" v-if="formItem.shoninStatusCd === this.$CONST_.shoninStatus.HININ">
      <el-row class="row-class">
        <el-col class="lab-class">　経理審査否認理由</el-col>
        <el-col style= "width: 237px;">
          <el-input v-model="formItem.riyu" size="mini" :disabled="true" />
        </el-col>
      </el-row>
    </div>
    <div class="div-style1">
      <el-row class="row-class">
        <el-col style= "width: 379px; background-color: #2053cc; color: white;">　取得情報</el-col>
      </el-row>
      <el-row class="row-class">
        <el-col class="lab-class">　精算書番号</el-col>
        <el-col style= "width: 237px;">
          <el-input v-model="formItem.seisanShoNo" size="mini" :disabled="true" />
        </el-col>
      </el-row>
      <el-row class="row-class">
        <el-col class="lab-class">　処理No</el-col>
        <el-col style= "width: 237px;">
          <input v-model="formItem.hansu" size="mini" class="nsd-input-class" disabled="disabled" style="cursor: default;" />
        </el-col>
      </el-row>
      <el-row class="row-class">
        <el-col class="lab-class">　使用開始年月日</el-col>
        <el-col style= "width: 237px;">
          <el-input v-model="formItem.siyoStartYmd" size="mini" :disabled="true" />
        </el-col>
      </el-row>
      <el-row class="row-class">
        <el-col class="lab-class">　取得価額合計</el-col>
          <el-col class="input-group" style= "width: 237px">
            <vue-numeric currency="\" separator="," v-model="formItem.shutokuKagakuGoke" size="mini" class="nsd-input-class label-input-class" disabled="disabled" style="cursor: default;" ></vue-numeric>
          </el-col>
      </el-row>
      <el-row class="row-class">
        <el-col class="lab-class">　承認状態</el-col>
        <el-col style= "width: 237px;">
          <el-input v-model="formItem.shoninStatusNm" size="mini" :disabled="true" />
        </el-col>
      </el-row>
      <el-row class="row-class">
        <el-col class="lab-class">　工事件名</el-col>
        <el-col style= "width: 237px;">
          <el-input v-model="formItem.kenmeiNm" size="mini" :disabled="true" />
        </el-col>
      </el-row>
    </div>
    <div style="position: relative; margin-left: 10px;">
     <span style="font-size: 12px;">{{this.$store.state.tableData.shutokuSisanLst.length}}件</span>
      <div style="position: absolute; top: -10px; right: 0px;">
        <el-pagination
          background
          @size-change="handleSizeChange"
          @current-change="handleCurrentChange"
          :current-page.sync="pageData.currentPage"
          :page-sizes="pageData.pageSizeArr"
          :page-size="pageData.pageSizeAct"
          layout="prev, pager, next"
          prev-text="前へ"
          next-text="次へ"
          :total="this.$store.state.tableData.shutokuSisanLst.length">
        </el-pagination>
      </div>
    </div>
    <div style="margin-left: 10px;">
      <el-table
        :data="this.$store.state.currentPageData"
        max-height=235
        border>
        <el-table-column
          prop="rowNo"
          label="NO."
          min-width="70px">
        </el-table-column>
        <el-table-column
          prop="koteiShisanNo"
          label="固定資産番号"
          min-width="120px">
        </el-table-column>
        <el-table-column
          prop="koteiShisanNm"
          label="固定資産名称"
          min-width="250px">
        </el-table-column>
        <el-table-column
          prop="shutokuYmd"
          label="取得年月日"
          min-width="120px">
        </el-table-column>
        <el-table-column
          prop="shutokuKagaku"
          label="取得価額"
          header-align=left
          align=right
          :formatter="commaFormatter"
          min-width="120px">
        </el-table-column >
      </el-table>
    </div>
    <el-row>
      <el-col>
        <nsd-button-bar v-bind:buttons="buttonName" v-bind:formItem="formItem"></nsd-button-bar>
      </el-col>
    </el-row>
  </div>
</template>

<script>
import NSDButtonBar from '@/components/common/NSDButtonBar.vue'
export default {
  components: {
    'nsd-button-bar': NSDButtonBar
  },
  created: function () {
    this.formItem = this.$store.state.tableData
    if (this.formItem.shoninStatusCd === this.$CONST_.shoninStatus.TOROKU) {
      this.buttonName[1].disabled = false
    } else if (this.formItem.shoninStatusCd === this.$CONST_.shoninStatus.SHONIN) {
      this.buttonName[1].disabled = false
    } else if (this.formItem.shoninStatusCd === null) {
      this.buttonName[1].disabled = false
    } else {
      this.buttonName[1].disabled = true
    }
    this.getPageData()
  },
  methods: {
    handleSizeChange (index) {
      this.pageData.pageSizeAct = index
      this.initTableList(1)
    },
    handleCurrentChange (index) {
      this.initTableList(index)
    },
    initTableList (index) {
      this._initPageData(index)
      this.getPageData()
      let container = this.$el.querySelector('.el-table__body-wrapper')
      if (container !== null) {
        container.scrollTop = 0
      }
    },
    _initPageData (index) {
      this.pageData.pageNum = (index - 1) * this.pageData.pageSizeAct
      this.pageData.currentPage = index
    },
    getPageData () {
      this.$store.state.currentPageData = this.$store.state.tableData.shutokuSisanLst.slice(this.pageData.pageSizeAct * (this.pageData.currentPage - 1), this.pageData.pageSizeAct * this.pageData.currentPage)
    },
    printCallBack (val) {
      var url = ''
      for (var i = 0; i < val.length; i++) {
        url = this.$baseURL + this.$CONST_.urlPath.OUTPUT_PDF + val[i] + '.pdf'
        window.open(url)
      }
    }
  },
  data () {
    return {
      buttonName: [
        {name: this.$CONST_.buttonName.PRINT, primary: true, show: true, action: 'insert', url: '/seisanshoshutokuShoninkosin-printing', callBack: this.printCallBack, msg: '印刷しますか？'},
        {name: this.$CONST_.buttonName.UPDATE, primary: true, show: true, action: 'back', url: '', backUrl: 'nsdstkshoninkosin', msg: ''},
        {name: this.$CONST_.buttonName.BACK, primary: true, show: true, action: 'back', url: '', backUrl: 'nsdstkshonin', msg: ''}
      ],
      formItem: '',
      pageData: {
        total: 0,
        pageNum: 0,
        pageSizeArr: this.$CONST_.tableConst.PAGE_SIZES,
        pageSizeAct: this.$CONST_.tableConst.PAGE_SIZE,
        currentPage: 1,
        visible: false
      }
    }
  }
}
</script>
<style scoped>
.div-style1 {
  font-size: 12px;
  width: 381px;
  height: 100%;
  margin-bottom: 10px;
  margin-left: 10px;
  line-height:30px;
  border: 1px solid;
  padding-top: 1px;
}
.div-style2 {
  font-size: 12px;
  width: 476px;
  height: 100%;
  margin-bottom: 10px;
  margin-left: 10px;
  line-height:30px;
  border: 1px solid;
  padding-top: 1px;
}
.row-class {
  height: 30px;
  margin-bottom: 1px;
  margin-left: 1px;
  margin-right: 1px;
}
.lab-class {
  line-height: 30px;
  width: 140px;
  background-color: #77cad8;
  margin-right: 1px;
}
</style>
