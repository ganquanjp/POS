<template>
  <div>
    <div class="scroll-box">
      <div class="page-style">
        <el-row class="row-class">
          <el-col style= "width: 100%; background-color: #2053cc; color: #FFFFFF; line-height: 30px;">　基本情報</el-col>
        </el-row>
        <el-row class="row-class">
          <el-col class="lab-class">　固定資産番号<span class="span-class">（必須）</span></el-col>
          <el-col style= "width: 170px; padding-top: -5px;">
            <el-input v-model="formItem.koteiShisanNo" size="mini" :disabled=true>
              <el-button slot="append" style="position: absolute; top: 20px; left: 10px;" size="mini" @click="showModalKotei = true">参照</el-button>
            </el-input>
          </el-col>
        </el-row>
        <el-row class="row-class">
          <el-col class="lab-class">　親固定資産番号<span class="span-class">（必須）</span></el-col>
          <el-col style= "width: 170px">
          <el-input v-model="formItem.komoku06" size="mini" :disabled=true>
              <el-button slot="append" style="position: absolute; top: 20px; left: 10px;" size="mini" @click="showModalKoteioya = true">参照</el-button>
            </el-input>
          </el-col>
          <el-col style= "width: 60px; background-color: #77cad8; line-height: 30px; margin: 0px 1px 0px 1px;">　枝番</el-col>
          <el-col style= "width: 100px">
            <el-input :maxlength="4" v-model="formItem.oyaKoteiShisanEda"  size="mini" />
          </el-col>
        </el-row>
        <el-row class="row-class">
          <el-col class="lab-class">　取得年月日<span class="span-class">（必須）</span></el-col>
          <el-col style= "width: 260px">
            <el-tooltip effect="light" placement="right-start">
              <div slot="content">「取得年月日」は「使用開始年月日」以前の日付を登録してください。</div>
              <el-date-picker
                v-model="formItem.shutokuYmd"
                size="mini"
                style= "width: 140px;"
                type="date"
                value-format="yyyy-MM-dd">
              </el-date-picker>
            </el-tooltip>
          </el-col>
        </el-row>
        <el-row class="row-class">
          <el-col class="lab-class">　固定資産名称<span class="span-class">（必須）</span></el-col>
          <el-col style= "width: 333px">
            <el-input :maxlength="20" v-model="formItem.koteiShisanNm"  size="mini" />
          </el-col>
        </el-row>
        <el-row class="row-class">
          <el-col class="lab-class">　種類<span class="span-class">（必須）</span></el-col>
          <el-col style= "width: 333px">
            <el-tooltip effect="light" placement="right-start">
              <div slot="content">自社所有建物の場合は、「建物（自社ビル）」または「建物付属（自社ビル）」を選択する。<br/>
                                  ただし建物付属設備のうち、DCの動力源となる電気設備、発・変電設備、蓄電池設備、<br/>
                                  中央監視制御装置、電話交換機、広告設備等は「建物附属」を選択する。<br/>
                                  K工事（リース）に係る設備、消耗品等は「リース投資（XXX）」として処理する。</div>
              <el-select v-model="formItem.shuruiCd" size="mini" style="width: 200px;" @change="shuruiChange">
                <el-option
                  v-for="item in this.optionsShurui"
                  :key="item.aw1ShuCod"
                  :label="item.aw1ShuKnj"
                  :value="item.aw1ShuCod">
                </el-option>
              </el-select>
            </el-tooltip>
          </el-col>
        </el-row>
        <el-row class="row-class">
          <el-col class="lab-class">　構造</el-col>
          <el-col style= "width: 333px">
            <el-select v-model="formItem.kouzouCd" size="mini" style="width: 200px;" @change="kouzouChange">
              <el-option
                v-for="item in this.optionsKouzou"
                :key="item.aw2KouCod"
                :label="item.aw2KouKnj"
                :value="item.aw2KouCod">
              </el-option>
            </el-select>
          </el-col>
        </el-row>
        <el-row class="row-class">
          <el-col class="lab-class">　資産単位</el-col>
          <el-col style= "width: 333px">
            <el-select v-model="formItem.shisanTaniCd" size="mini" style="width: 200px;" @change="shisanTaniChange">
              <el-option
                v-for="item in this.optionsShisanTani"
                :key="item.aw3SaiCod"
                :label="item.aw3SaiKnj"
                :value="item.aw3SaiCod">
              </el-option>
            </el-select>
          </el-col>
        </el-row>
        <el-row class="row-class">
          <el-col class="lab-class">　科目１</el-col>
          <el-col style= "width: 333px">
           <el-tooltip effect="light" placement="right-start">
            <div slot="content">「リース投資資産」と通常の固定資産は、別々の工事精算書で登録してください。</div>
            <el-select v-model="formItem.kamokuCd1" size="mini" style="width: 200px;" @change="kamokuCd1Change">
              <el-option
                v-for="item in this.optionsKamoku1"
                :key="item.aw4Shu4Cod"
                :label="item.aw4Shu4Knj"
                :value="item.aw4Shu4Cod">
              </el-option>
            </el-select>
           </el-tooltip>
          </el-col>
        </el-row>
        <el-row class="row-class">
          <el-col class="lab-class">　科目２</el-col>
          <el-col style= "width: 333px">
            <el-tooltip effect="light" placement="right-start">
              <div slot="content">DC設備＝DC内の資産<br/>
                                  業務設備＝本社の資産</div>
              <el-select v-model="formItem.kamokuCd2" size="mini" style="width: 200px;" @change="kamokuCd2Change">
                <el-option
                  v-for="item in this.optionsKamoku2"
                  :key="item.aw5Shu5Cod"
                  :label="item.aw5Shu5Knj"
                  :value="item.aw5Shu5Cod">
                </el-option>
              </el-select>
            </el-tooltip>
          </el-col>
        </el-row>
        <el-row class="row-class">
          <el-col class="lab-class">　科目３</el-col>
          <el-col style= "width: 333px">
            <el-tooltip effect="light" placement="right-start">
              <div slot="content">初期費用＝K工事（一括個別収入）<br/>
                                  一般＝T工事、K工事（標準・リース）</div>
              <el-select v-model="formItem.kamokuCd3" size="mini" style="width: 200px;" @change="kamokuCd3Change">
                <el-option
                  v-for="item in this.optionsKamoku3"
                  :key="item.aw6Shu6Cod"
                  :label="item.aw6Shu6Knj"
                  :value="item.aw6Shu6Cod">
                </el-option>
              </el-select>
            </el-tooltip>
          </el-col>
        </el-row>
        <el-row class="row-class">
          <el-col class="lab-class" v-if=this.ztaiyoYmFlg>　耐用月数<span class="span-class">（必須）</span></el-col>
          <el-col class="lab-class" v-if=!this.ztaiyoYmFlg>　耐用年数<span class="span-class">（必須）</span></el-col>
          <el-col style= "width: 140px; text-align: right" >
            <vue-numeric v-model="formItem.taiyoNensuZei" size="mini" class="nsd-input-date-class" v-bind:max="999" :disabled=!this.ztaiyoYmFlg></vue-numeric>
          </el-col>
        </el-row>
      </div>
      <div class="page-style" style="margin-top: 10px;">
        <el-row class="row-class">
          <el-col style= "width: 100%; background-color: #2053cc; color: #FFFFFF; line-height: 30px;">　取得情報</el-col>
        </el-row>
        <el-row class="row-class">
          <el-col class="lab-class">　取引先名称<span class="span-class" v-if=this.torihikiFlg>（必須）</span></el-col>
          <el-col style= "width: 333px; padding-top: -5px;">
            <el-input v-model="formItem.torihikiSakiNm" size="mini" v-bind:disabled=this.torihikiBtnFlg>
              <el-button slot="append" style="position: absolute; top: 20px; left: 10px;" size="mini" v-bind:disabled=this.torihikiBtnFlg @click="showModalTrhks = true">参照</el-button>
            </el-input>
          </el-col>
        </el-row>
        <el-row class="row-class">
          <el-col class="lab-class">　製造会社名称</el-col>
          <el-col style= "width: 333px; padding-top: -5px;">
            <el-input :maxlength="20" v-model="formItem.seizoKaishaNm" size="mini" />
          </el-col>
        </el-row>
        <el-row class="row-class">
          <el-col class="lab-class">　製品名称</el-col>
          <el-col style= "width: 200px">
            <el-input :maxlength="10" v-model="formItem.seihinNm"  size="mini" />
          </el-col>
        </el-row>
        <el-row class="row-class">
          <el-col class="lab-class">　型番</el-col>
          <el-col style= "width: 200px">
            <el-input :maxlength="10" v-model="formItem.kataban"  size="mini" />
          </el-col>
        </el-row>
        <el-row class="row-class">
          <el-col class="lab-class">　物品数量<span class="span-class">（必須）</span></el-col>
          <el-col style= "width: 200px">
            <vue-numeric v-model="formItem.suryo" size="mini" class="nsd-input-date-class" v-bind:precision="2" @blur="inputSuryo"></vue-numeric>
          </el-col>
        </el-row>
        <el-row class="row-class">
          <el-col class="lab-class">　単位<span class="span-class">（必須）</span></el-col>
          <el-col style= "width: 200px">
            <el-select v-model="formItem.taniCd" size="mini" style="width: 200px;">
              <el-option
                v-for="item in this.optionsTani"
                :key="item.awfTaniCod"
                :label="item.awfTaniKnj"
                :value="item.awfTaniCod">
              </el-option>
            </el-select>
          </el-col>
        </el-row>
        <el-row class="row-class">
          <el-col class="lab-class">　物品<span class="span-class">（必須）</span></el-col>
          <el-col class="input-group" style= "width: 200px">
            <vue-numeric currency="\" separator="," v-model="formItem.buppinGaku" size="mini" class="nsd-input-class" @blur="inputBuppinGaku"></vue-numeric>
            </input>
          </el-col>
        </el-row>
        <el-row class="row-class">
          <el-col class="lab-class">　工費<span class="span-class">（必須）</span></el-col>
          <el-col class="input-group" style= "width: 200px">
            <vue-numeric currency="\" separator="," v-model="formItem.kouhiGaku" size="mini" class="nsd-input-class" @blur="inputKouhiGaku"></vue-numeric>
            </input>
          </el-col>
        </el-row>
        <el-row class="row-class">
          <el-col class="lab-class">　総係費</el-col>
          <el-col class="input-group" style= "width: 200px">
            <vue-numeric currency="\" separator="," v-model="formItem.souKeihiGaku" size="mini" class="nsd-input-class" @blur="inputSouKeihiGaku"></vue-numeric>
            </input>
          </el-col>
        </el-row>
      </div>
      <div class="page-style" style="margin-top: 10px;">
        <el-row class="row-class">
          <el-col style= "width: 100%; background-color: #2053cc; color: #FFFFFF; line-height: 30px;">　管理情報</el-col>
        </el-row>
        <el-row class="row-class">
          <el-col class="lab-class">　管理箇所名称<span class="span-class">（必須）</span></el-col>
          <el-col style= "width: 333px; padding-top: -5px;">
            <el-tooltip effect="light" placement="right-start">
              <div slot="content">DC＝資産の管理部門名＋センター名<br/>
                                  本社＝資産の管理部門名＋一括</div>
              <el-input v-model="formItem.kanriSoshikiNm" size="mini" :disabled=true>
                <el-button slot="append" style="position: absolute; top: 20px; left: 10px;" size="mini" @click="showModalKanri = true">参照</el-button>
              </el-input>
            </el-tooltip>
          </el-col>
        </el-row>
        <el-row class="row-class">
          <el-col class="lab-class">　負担箇所<span class="span-class">（必須）</span></el-col>
          <el-col style= "width: 333px; padding-top: -5px;">
          <el-input :disabled="true" v-model="formItem.futanSoshikiNm" size="mini"></el-input>
          </el-col>
        </el-row>
        <el-row class="row-class">
          <el-col class="lab-class">　設置場所名称<span class="span-class">（必須）</span></el-col>
          <el-col style= "width: 200px">
            <el-input v-model="formItem.sechiBashoNm" size="mini" :disabled=true>
              <el-button slot="append" style="position: absolute; top: 20px; left: 10px;" size="mini" @click="showModalSechi = true">参照</el-button>
            </el-input>
          </el-col>
        </el-row>
        <el-row class="row-class">
          <el-col class="lab-class">　取得事由<span class="span-class">（必須）</span></el-col>
          <el-col style= "width: 333px">
            <el-select v-model="formItem.shutokuRiyuCd" size="mini" style="width: 200px;">
              <el-option
                v-for="item in this.optionsShutokuRiyu"
                :key="item.awkKmksbtCod"
                :label="item.awkMeishoKnj"
                :value="item.awkKmksbtCod">
              </el-option>
            </el-select>
          </el-col>
        </el-row>
      </div>
      <div class="page-style" style="margin-top: 10px;">
        <el-row class="row-class">
          <el-col style= "width: 100%; background-color: #2053cc; color: #FFFFFF; line-height: 30px;">　任意情報</el-col>
        </el-row>
        <el-row class="row-class">
          <el-col class="lab-class">　摘要１</el-col>
          <el-col style= "width: 333px; padding-top: -5px;">
            <el-input :maxlength="30" v-model="formItem.tekiyo1" size="mini" />
          </el-col>
        </el-row>
        <el-row class="row-class">
          <el-col class="lab-class">　摘要２</el-col>
          <el-col style= "width: 333px; padding-top: -5px;">
            <el-input :maxlength="20" v-model="formItem.tekiyo2" size="mini" />
          </el-col>
        </el-row>
        <el-row class="row-class">
          <el-col class="lab-class">　摘要３</el-col>
          <el-col style= "width: 333px">
            <el-input :maxlength="5" v-model="formItem.tekiyo3"  size="mini" />
          </el-col>
        </el-row>
        <el-row class="row-class">
          <el-col class="lab-class">　摘要４</el-col>
          <el-col style= "width: 333px">
            <el-input :maxlength="5" v-model="formItem.tekiyo4"  size="mini" />
          </el-col>
        </el-row>
        <el-row class="row-class">
          <el-col class="lab-class">　摘要５</el-col>
          <el-col style= "width: 333px">
            <el-input :maxlength="5" v-model="formItem.tekiyo5"  size="mini" />
          </el-col>
        </el-row>
        <el-row class="row-class">
          <el-col class="lab-class">　工事担当箇所</el-col>
          <el-col style= "width: 333px">
            <el-input :maxlength="6" v-model="formItem.kojiTantoSoshikiCd"  size="mini" />
          </el-col>
        </el-row>
        <el-row class="row-class">
          <el-col class="lab-class">　工事担当者</el-col>
          <el-col style= "width: 333px">
            <el-input :maxlength="10" v-model="formItem.kojiTantoUserNm"  size="mini" />
          </el-col>
        </el-row>
      </div>
    </div>
    <el-row>
      <el-col>
        <nsd-button-bar v-bind:buttons="buttonName" v-bind:formItem="formItem"></nsd-button-bar>
      </el-col>
    </el-row>
    <modal-kotei v-if="showModalKotei" @close="showModalKotei = false" @backData="backDataKotei" v-bind:hanteFlg="this.hanteFlg"></modal-kotei>
    <modal-koteioya v-if="showModalKoteioya" @close="showModalKoteioya = false" @backData="backDataKoteiOya"></modal-koteioya>
    <modal-trhks v-if="showModalTrhks" @close="showModalTrhks = false" @backData="backDataTrhks"></modal-trhks>
    <modal-kanri v-if="showModalKanri" @close="showModalKanri = false" @backData="backDataKanri"></modal-kanri>
    <modal-sechi v-if="showModalSechi" @close="showModalSechi = false" @backData="backDataSechi"></modal-sechi>
  </div>
</template>

<script>
import NSDButtonBar from '@/components/common/NSDButtonBar.vue'
import NSDKanrifutankensaku from '@/components/common/modal/NSDKanrifutankensaku'
import NSDKoteisisankensaku from '@/components/common/modal/NSDKoteisisankensaku'
import NSDSechiBashokensaku from '@/components/common/modal/NSDSechiBashokensaku'
import NSDTorihikiSakikensaku from '@/components/common/modal/NSDTorihikiSakikensaku'

export default {
  components: {
    'nsd-button-bar': NSDButtonBar,
    'modal-kotei': NSDKoteisisankensaku,
    'modal-koteioya': NSDKoteisisankensaku,
    'modal-kanri': NSDKanrifutankensaku,
    'modal-sechi': NSDSechiBashokensaku,
    'modal-trhks': NSDTorihikiSakikensaku
  },
  created: function () {
    this.init()
    this.leaseControl()
    this.initFormItem = JSON.parse(JSON.stringify(this.formItem))
  },
  methods: {
    init () {
      this.funcHttpPostComm('/comm-getShuNmLst', '', this.getShuNmLstCallBack)
      this.funcHttpPostComm('/comm-getTaniLst', '', this.getTaniLstCallBack)
      this.funcHttpPostComm('/comm-getMeiShouLst', {awkKomokSbt: '103'}, this.getMeiShouLstCallBack)
    },
    getTaniLstCallBack (val) {
      this.optionsTani = val
    },
    getMeiShouLstCallBack (val) {
      this.optionsShutokuRiyu = val
    },
    getShuNmLstCallBack (val) {
      this.optionsShurui = val
    },
    shuruiChange (val) {
      this.formItem.kouzouCd = ''
      this.formItem.shisanTaniCd = ''
      this.formItem.kamokuCd1 = ''
      this.formItem.kamokuCd2 = ''
      this.formItem.kamokuCd3 = ''
      this.optionsKouzou = []
      this.optionsShisanTani = []
      this.optionsKamoku1 = []
      this.optionsKamoku2 = []
      this.optionsKamoku3 = []
      var param = {shuCod: val}
      this.funcHttpPostComm('/comm-getKouNmLst', param, this.getKouNmLstCallBack)
    },
    getKouNmLstCallBack (val) {
      this.optionsKouzou = val
      this.leaseControl(this.formItem.shuruiCd)
      this.getTaiyoNensu(this.formItem.shuruiCd)
    },
    kouzouChange (val) {
      this.formItem.shisanTaniCd = ''
      this.formItem.kamokuCd1 = ''
      this.formItem.kamokuCd2 = ''
      this.formItem.kamokuCd3 = ''
      this.optionsShisanTani = []
      this.optionsKamoku1 = []
      this.optionsKamoku2 = []
      this.optionsKamoku3 = []
      var param = {shuCod: this.formItem.shuruiCd, kouzou: val}
      this.funcHttpPostComm('/comm-getSaiNmLst', param, this.getSaiNmLstCallBack)
    },
    getSaiNmLstCallBack (val) {
      this.optionsShisanTani = val
      this.getTaiyoNensu(this.formItem.shuruiCd, this.formItem.kouzouCd)
    },
    shisanTaniChange (val) {
      this.formItem.kamokuCd1 = ''
      this.formItem.kamokuCd2 = ''
      this.formItem.kamokuCd3 = ''
      this.optionsKamoku1 = []
      this.optionsKamoku2 = []
      this.optionsKamoku3 = []
      var param = {shuCod: this.formItem.shuruiCd, kouzou: this.formItem.kouzouCd, shisanTani: val}
      this.funcHttpPostComm('/comm-getShu4NmLst', param, this.getShu4NmLstCallBack)
    },
    getShu4NmLstCallBack (val) {
      this.optionsKamoku1 = val
      this.getTaiyoNensu(this.formItem.shuruiCd, this.formItem.kouzouCd, this.formItem.shisanTaniCd)
    },
    kamokuCd1Change (val) {
      this.formItem.kamokuCd2 = ''
      this.formItem.kamokuCd3 = ''
      this.optionsKamoku2 = []
      this.optionsKamoku3 = []
      var param = {shuCod: this.formItem.shuruiCd, kouzou: this.formItem.kouzouCd, shisanTani: this.formItem.shisanTaniCd, kamoku1: val}
      this.funcHttpPostComm('/comm-getShu5NmLst', param, this.getShu5NmLstCallBack)
    },
    getShu5NmLstCallBack (val) {
      this.optionsKamoku2 = val
      this.leaseControl(this.formItem.shuruiCd, val)
      this.getTaiyoNensu(this.formItem.shuruiCd, this.formItem.kouzouCd, this.formItem.shisanTaniCd, this.formItem.kamokuCd1)
    },
    kamokuCd2Change (val) {
      this.formItem.kamokuCd3 = ''
      this.optionsKamoku3 = []
      var param = {
        shuCod: this.formItem.shuruiCd,
        kouzou: this.formItem.kouzouCd,
        shisanTani: this.formItem.shisanTaniCd,
        kamoku1: this.formItem.kamokuCd1,
        kamoku2: val
      }
      this.funcHttpPostComm('/comm-getShu6NmLst', param, this.getShu6NmLstCallBack)
    },
    getShu6NmLstCallBack (val) {
      this.optionsKamoku3 = val
      this.getTaiyoNensu(this.formItem.shuruiCd, this.formItem.kouzouCd, this.formItem.shisanTaniCd, this.formItem.kamokuCd1, this.formItem.kamokuCd2)
    },
    kamokuCd3Change (val) {
      this.leaseControl(this.formItem.shuruiCd, this.formItem.kamokuCd1, val)
      this.getTaiyoNensu(this.formItem.shuruiCd, this.formItem.kouzouCd, this.formItem.shisanTaniCd, this.formItem.kamokuCd1, this.formItem.kamokuCd2, this.formItem.kamokuCd3)
    },
    backDataKotei (val) {
      this.formItem.seisanShoId = val['seisanShoId']
      this.formItem.koteiShisanNo = val['koteiNo']
      if (this.formItem.komoku06 === '' || this.formItem.komoku06 === undefined) {
        this.formItem.komoku06 = val['koteiNo']
      }
      this.formItem.koteiShisanId = val['koteiCod']
      this.formItem.useYmd = val['useYmd']
      this.formItem.shutokuYmd = val['getYmd']
      this.formItem.tekiyoStartYmd = val['tekiyoStartYmd']
      this.formItem.tekiyoEndYmd = val['tekiyoEndYmd']
    },
    backDataKoteiOya (val) {
      this.formItem.komoku06 = val['koteiNo']
    },
    backDataTrhks (val) {
      this.formItem.torihikiSakiCd = val['abbTorihkCod']
      this.formItem.torihikiSakiNm = val['abbTorihkKnj']
      this.formItem.torihikiSakiTekiyoYmdF = val['abbTekiyfYmd']
      this.formItem.torihikiSakiTekiyoYmdT = val['abbTekiytYmd']
    },
    backDataKanri (val) {
      this.formItem.kanriSoshikiCd = val['kanrikasyocd']
      this.formItem.kanriSoshikiNm = val['kanrikasyo']
      this.formItem.kanriSoshikiF = val['kkikanF']
      this.formItem.kanriSoshikiT = val['kkikanT']
      this.formItem.futanSoshikiCd = val['futankasyocd']
      this.formItem.futanSoshikiNm = val['futankasyo']
      this.formItem.futanSoshikiF = val['fkikanF']
      this.formItem.futanSoshikiT = val['fkikanT']
    },
    backDataSechi (val) {
      this.formItem.sechiBashoCd = val['sechiBashoCd']
      this.formItem.sechiBashoNm = val['sechiBashoNm']
    },
    leaseControl (shuCd, shu4Cd, shu6Cd) {
      if (shuCd === '12' || shuCd === '42' || shuCd === '43' || shuCd === '51' || shuCd === '61' || shu4Cd === '305') {
        this.ztaiyoYmFlg = true
        this.torihikiFlg = true
        this.torihikiBtnFlg = false
      } else {
        this.ztaiyoYmFlg = false
        if (shu6Cd === '99') {
          this.torihikiFlg = true
          this.torihikiBtnFlg = false
        } else {
          this.torihikiFlg = false
          this.torihikiBtnFlg = true
          this.formItem.torihikiSakiCd = ''
          this.formItem.torihikiSakiNm = ''
        }
      }
    },
    succesCallBack (val) {
      this.formItem = {}
      this.formItem = JSON.parse(JSON.stringify(this.initFormItem))
      this.leaseControl(this.formItem.shuruiCd)
    },
    getTaiyoNensu (pShuCod = '', pKouCod = '', pSaiCod = '', pShu4Cod = '', pShu5Cod = '', pShu6Cod = '') {
      var param = {shuCod: pShuCod, kouCod: pKouCod, saiCod: pSaiCod, shu4Cod: pShu4Cod, shu5Cod: pShu5Cod, shu6Cod: pShu6Cod}
      this.funcHttpPostComm('/comm-getShuKouSaiInfo', param, this.getTaiyoNensuCallBack)
    },
    getTaiyoNensuCallBack (val) {
      if (val !== undefined) {
        this.formItem.taiyoNensuZei = val.zeitaiYs
      }
    },
    inputSuryo () {
      if (this.formItem.suryo > 999999999999.99) {
        this.formItem.suryo = 0
      }
    },
    inputBuppinGaku () {
      if (this.formItem.buppinGaku > 9999999999999) {
        this.formItem.buppinGaku = 0
      }
    },
    inputKouhiGaku () {
      if (this.formItem.kouhiGaku > 9999999999999) {
        this.formItem.kouhiGaku = 0
      }
    },
    inputSouKeihiGaku () {
      if (this.formItem.souKeihiGaku > 9999999999999) {
        this.formItem.souKeihiGaku = 0
      }
    }
  },
  data () {
    return {
      showModalKotei: false,
      showModalKoteioya: false,
      showModalKanri: false,
      showModalSechi: false,
      showModalTrhks: false,
      buttonName: [
        {name: this.$CONST_.buttonName.INSERT, primary: true, show: true, action: 'insert', url: '/seisanshoShutoku-insert', callBack: this.succesCallBack, msg: '登録しますか？'},
        {name: this.$CONST_.buttonName.RESET, primary: true, show: true, action: 'reset', url: '', msg: 'リセットしますか？'}
      ],
      hanteFlg: '1',
      optionsShurui: [],
      optionsKouzou: [],
      optionsShisanTani: [],
      optionsKamoku1: [],
      optionsKamoku2: [],
      optionsKamoku3: [],
      optionsTani: [],
      optionsShutokuRiyu: [],
      sechiBashoList: [],
      ztaiyoYmFlg: true,
      torihikiFlg: true,
      torihikiBtnFlg: false,
      formItem: {
        koteiShisanNo: '',
        oyaKoteiShisanEda: '',
        shutokuYmd: '',
        koteiShisanNm: '',
        shuruiCd: '',
        kouzouCd: '',
        shisanTaniCd: '',
        kamokuCd1: '',
        kamokuCd2: '',
        kamokuCd3: '',
        taiyoNensuZei: '',
        torihikiSakiCd: '',
        torihikiSakiNm: '',
        seizoKaishaNm: '',
        seihinNm: '',
        kataban: '',
        suryo: '0.00',
        taniCd: '',
        buppinGaku: '0',
        kouhiGaku: '0',
        souKeihiGaku: '0',
        kanriSoshikiCd: '',
        kanriSoshikiNm: '',
        futanSoshikiCd: '',
        futanSoshikiNm: '',
        sechiBashoCd: '',
        sechiBashoNm: '',
        shutokuRiyuCd: '1',
        tekiyo1: '',
        tekiyo2: '',
        tekiyo3: '',
        tekiyo4: '',
        tekiyo5: '',
        kojiTantoUserNm: '',
        kojiTantoSoshikiCd: '',
        komoku06: ''
      },
      initFormItem: {}
    }
  }
}
</script>

<style scoped>
.page-style {
  font-size: 12px;
  margin-left:10px;
  width: 476px;
  border: 1px solid;
  padding-top: 1px;
}
.row-class {
  height: 30px;
  margin-bottom: 1px;
  margin-left: 1px;
  margin-right: 1px;
}
.lab-class {
  line-height: 30px;
  width: 140px;
  background-color: #77cad8;
  margin-right: 1px;
}
.scroll-box {
  height: 525px;
  overflow-y: auto;
}
.input-group {
  line-height: normal;
  display: inline-table;
  width: 100%;
  border-collapse: separate;
}
.label-input-class {
  border-top-right-radius: 0;
  border-bottom-right-radius: 0;
}
.span-class {
 color: red;
 float: right;
}
.nsd-input-date-class {
 text-align: right;
}

</style>
