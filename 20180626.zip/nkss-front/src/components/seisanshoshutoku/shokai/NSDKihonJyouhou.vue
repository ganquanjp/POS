<template>
  <div>
    <div class="scroll-box">
      <div class="page-style">
        <el-row class="row-class">
          <el-col style= "width: 100%; background-color: #2053cc; color: #FFFFFF; line-height: 30px;">　基本情報</el-col>
        </el-row>
        <el-row class="row-class">
          <el-col class="lab-class">　工事件名</el-col>
          <el-col style= "width: 333px; padding-top: -5px;">
            <el-input v-model="formItem.kenmeiNm" size="mini" :disabled="true" />
          </el-col>
        </el-row>
        <el-row class="row-class">
          <el-col class="lab-class">　使用開始年月日</el-col>
          <el-col style= "width: 333px; padding-top: -5px;">
            <el-input v-model="formItem.siyoStartYmd" size="mini" :disabled="true" />
          </el-col>
        </el-row>
        <el-row class="row-class">
          <el-col class="lab-class">　固定資産番号</el-col>
          <el-col style= "width: 333px; padding-top: -5px;">
            <el-input v-model="formItem.koteiShisanNo" size="mini" :disabled="true" />
          </el-col>
        </el-row>
        <el-row class="row-class">
          <el-col class="lab-class">　親固定資産番号</el-col>
          <el-col style= "width: 150px">
            <el-input v-model="formItem.komoku06" size="mini" :disabled="true" />
          </el-col>
          <el-col style= "width: 80px; background-color: #77cad8; line-height: 30px; margin: 0px 1px 0px 1px;">　枝番</el-col>
          <el-col style= "width: 100px">
            <el-input v-model="formItem.oyaKoteiShisanEda" size="mini" :disabled="true" />
          </el-col>
        </el-row>
        <el-row class="row-class">
          <el-col class="lab-class">　取得年月日</el-col>
          <el-col style= "width: 333px">
            <vueDateFormat v-model="formItem.shutokuYmd" size="mini" class="nsd-input-date-class" disabled="disabled" :format="dateFormat" :time="formItem.shutokuYmd" :type="dateType" :autoUpdate="false"></vueDateFormat>
          </el-col>
        </el-row>
        <el-row class="row-class">
          <el-col class="lab-class">　固定資産名称</el-col>
          <el-col style= "width: 333px">
            <el-input v-model="formItem.koteiShisanNm" size="mini" :disabled="true"/>
          </el-col>
        </el-row>
        <el-row class="row-class">
          <el-col class="lab-class">　種類</el-col>
          <el-col style= "width: 333px">
            <el-input v-model="formItem.shuKnj" size="mini" :disabled="true" />
          </el-col>
        </el-row>
        <el-row class="row-class">
          <el-col class="lab-class">　構造</el-col>
          <el-col style= "width: 333px">
            <el-input v-model="formItem.kouKnj" size="mini" :disabled="true" />
          </el-col>
        </el-row>
        <el-row class="row-class">
          <el-col class="lab-class">　資産単位</el-col>
          <el-col style= "width: 333px">
            <el-input v-model="formItem.saiKnj" size="mini" :disabled="true" />
          </el-col>
        </el-row>
        <el-row class="row-class">
          <el-col class="lab-class">　科目１</el-col>
          <el-col style= "width: 333px">
            <el-input v-model="formItem.shu4Knj" size="mini" :disabled="true" />
          </el-col>
        </el-row>
        <el-row class="row-class">
          <el-col class="lab-class">　科目２</el-col>
          <el-col style= "width: 333px">
            <el-input v-model="formItem.shu5Knj" size="mini" :disabled="true" />
          </el-col>
        </el-row>
        <el-row class="row-class">
          <el-col class="lab-class">　科目３</el-col>
          <el-col style= "width: 333px">
            <el-input v-model="formItem.shu6Knj" size="mini" :disabled="true" />
          </el-col>
        </el-row>
        <el-row class="row-class">
          <el-col class="lab-class" v-if="this.$store.state.tableData[0].shuruiCd === '12' || this.$store.state.tableData[0].shuruiCd === '42' || this.$store.state.tableData[0].shuruiCd === '43' || this.$store.state.tableData[0].shuruiCd === '51' || this.$store.state.tableData[0].shuruiCd === '61' || this.$store.state.tableData[0].shuruiCdkamokuCd1 === '305'">　耐用月数</el-col>
          <el-col class="lab-class" v-if="!(this.$store.state.tableData[0].shuruiCd === '12' || this.$store.state.tableData[0].shuruiCd === '42' || this.$store.state.tableData[0].shuruiCd === '43' || this.$store.state.tableData[0].shuruiCd === '51' || this.$store.state.tableData[0].shuruiCd === '61' || this.$store.state.tableData[0].shuruiCdkamokuCd1 === '305')">　耐用年数</el-col>
          <el-col style= "width: 333px">
            <vue-numeric v-model="formItem.taiyoNensuZei" size="mini" class="nsd-input-class" disabled="disabled"></vue-numeric>
          </el-col>
        </el-row>
      </div>
      <div class="page-style" style="margin-top: 10px;">
        <el-row class="row-class">
          <el-col style= "width: 100%; background-color: #2053cc; color: #FFFFFF; line-height: 30px;">　取得情報</el-col>
        </el-row>
        <el-row class="row-class">
          <el-col class="lab-class">　取引先名称</el-col>
          <el-col style= "width: 333px; padding-top: -5px;">
            <el-input v-model="formItem.torihikiSakiNm" size="mini" :disabled="true" />
          </el-col>
        </el-row>
        <el-row class="row-class">
          <el-col class="lab-class">　製造会社名称</el-col>
          <el-col style= "width: 333px; padding-top: -5px;">
            <el-input v-model="formItem.seizoKaishaNm" size="mini" :disabled="true" />
          </el-col>
        </el-row>
        <el-row class="row-class">
          <el-col class="lab-class">　製品名称</el-col>
          <el-col style= "width: 333px; padding-top: -5px;">
            <el-input v-model="formItem.seihinNm" size="mini" :disabled="true" />
          </el-col>
        </el-row>
        <el-row class="row-class">
          <el-col class="lab-class">　型番</el-col>
          <el-col style= "width: 333px">
            <el-input v-model="formItem.kataban" size="mini" :disabled="true" />
          </el-col>
        </el-row>
        <el-row class="row-class">
          <el-col class="lab-class">　物品数量</el-col>
          <el-col style= "width: 333px">
            <vue-numeric v-model="formItem.suryo" size="mini" class="nsd-input-class" disabled="disabled" v-bind:precision="2" ></vue-numeric>
          </el-col>
        </el-row>
        <el-row class="row-class">
          <el-col class="lab-class">　単位</el-col>
          <el-col style= "width: 333px">
            <el-input v-model="formItem.taniNm" size="mini" :disabled="true" />
          </el-col>
        </el-row>
        <el-row class="row-class">
          <el-col class="lab-class">　物品</el-col>
          <el-col class="input-group" style= "width: 333px">
            <vue-numeric currency="\" separator="," v-model="formItem.buppinGaku" size="mini" class="nsd-input-class" disabled="disabled"></vue-numeric>
            </input>
          </el-col>
        </el-row>
        <el-row class="row-class">
          <el-col class="lab-class">　工費</el-col>
          <el-col class="input-group" style= "width: 333px">
            <vue-numeric currency="\" separator="," v-model="formItem.kouhiGaku" size="mini" class="nsd-input-class" disabled="disabled"></vue-numeric>
            </input>
          </el-col>
        </el-row>
        <el-row class="row-class">
          <el-col class="lab-class">　総係費</el-col>
          <el-col class="input-group" style= "width: 333px">
            <vue-numeric currency="\" separator="," v-model="formItem.souKeihiGaku" size="mini" class="nsd-input-class" disabled="disabled"></vue-numeric>
            </input>
          </el-col>
        </el-row>
        <el-row class="row-class">
          <el-col class="lab-class">　取得価額</el-col>
          <el-col class="input-group" style= "width: 333px">
            <vue-numeric currency="\" separator="," v-model="formItem.shutokuGaku" size="mini" class="nsd-input-class" disabled="disabled"></vue-numeric>
            </input>
          </el-col>
        </el-row>
      </div>
      <div class="page-style" style="margin-top: 10px;">
        <el-row class="row-class">
          <el-col style= "width: 100%; background-color: #2053cc; color: #FFFFFF; line-height: 30px;">　管理情報</el-col>
        </el-row>
        <el-row class="row-class">
          <el-col class="lab-class">　管理箇所名称</el-col>
          <el-col style= "width: 333px; padding-top: -5px;">
            <el-input v-model="formItem.kanriSoshikiNm" size="mini" :disabled="true" />
          </el-col>
        </el-row>
        <el-row class="row-class">
          <el-col class="lab-class">　負担箇所</el-col>
          <el-col style= "width: 333px; padding-top: -5px;">
            <el-input v-model="formItem.futanSoshikiNm" size="mini" :disabled="true" />
          </el-col>
        </el-row>
        <el-row class="row-class">
          <el-col class="lab-class">　設置場所名称</el-col>
          <el-col style= "width: 333px">
            <el-input v-model="formItem.sechiBashoNm" size="mini" :disabled="true" />
          </el-col>
        </el-row>
        <el-row class="row-class">
          <el-col class="lab-class">　取得事由</el-col>
          <el-col style= "width: 333px">
            <el-input v-model="formItem.shutokuRiyuNm" size="mini" :disabled="true" />
          </el-col>
        </el-row>
      </div>
      <div class="page-style" style="margin-top: 10px;">
        <el-row class="row-class">
          <el-col style= "width: 100%; background-color: #2053cc; color: #FFFFFF; line-height: 30px;">　任意情報</el-col>
        </el-row>
        <el-row class="row-class">
          <el-col class="lab-class">　摘要１</el-col>
          <el-col style= "width: 333px; padding-top: -5px;">
            <el-input v-model="formItem.tekiyo1" size="mini" :disabled="true" />
          </el-col>
        </el-row>
        <el-row class="row-class">
          <el-col class="lab-class">　摘要２</el-col>
          <el-col style= "width: 333px; padding-top: -5px;">
            <el-input v-model="formItem.tekiyo2" size="mini" :disabled="true" />
          </el-col>
        </el-row>
        <el-row class="row-class">
          <el-col class="lab-class">　摘要３</el-col>
          <el-col style= "width: 333px">
            <el-input v-model="formItem.tekiyo3" size="mini" :disabled="true" />
          </el-col>
        </el-row>
        <el-row class="row-class">
          <el-col class="lab-class">　摘要４</el-col>
          <el-col style= "width: 333px">
            <el-input v-model="formItem.tekiyo4" size="mini" :disabled="true" />
          </el-col>
        </el-row>
        <el-row class="row-class">
          <el-col class="lab-class">　摘要５</el-col>
          <el-col style= "width: 333px">
            <el-input v-model="formItem.tekiyo5" size="mini" :disabled="true" />
          </el-col>
        </el-row>
        <el-row class="row-class">
          <el-col class="lab-class">　工事担当箇所</el-col>
          <el-col style= "width: 333px">
            <el-input v-model="formItem.kojiTantoSoshikiCd" size="mini" :disabled="true" />
          </el-col>
        </el-row>
        <el-row class="row-class">
          <el-col class="lab-class">　工事担当者</el-col>
          <el-col style= "width: 333px">
            <el-input v-model="formItem.kojiTantoUserNm" size="mini" :disabled="true" />
          </el-col>
        </el-row>
      </div>
    </div>
    <el-row>
      <el-col>
        <nsd-button-bar v-bind:buttons="buttonName" v-bind:formItem="formItem"></nsd-button-bar>
      </el-col>
    </el-row>
  </div>
</template>

<script>
import NSDButtonBar from '@/components/common/NSDButtonBar.vue'

export default {
  components: {
    'nsd-button-bar': NSDButtonBar
  },
  created () {
    this.formItem = this.$store.state.tableData[0]
    if (this.formItem.shoninStatus === this.$CONST_.shoninStatus.TOROKU || this.formItem.shoninStatus === this.$CONST_.shoninStatus.HININ) {
      this.buttonName[0].disabled = false
      this.buttonName[1].disabled = false
    } else {
      this.buttonName[0].disabled = true
      this.buttonName[1].disabled = true
    }
  },
  data () {
    return {
      dateFormat: 'yyyy-MM-dd',
      dateType: 'fmt',
      buttonName: [
        {name: this.$CONST_.buttonName.DELETE, primary: true, show: true, action: 'popup', url: '/seisanshoShutoku-delByPyKey', backUrl: 'nsdstkmain', msg: '削除しますか？'},
        {name: this.$CONST_.buttonName.MODIFY, primary: true, show: true, action: 'back', backUrl: 'nsdstkshusei'},
        {name: this.$CONST_.buttonName.BACK, primary: true, show: true, action: 'back', url: '', backUrl: 'nsdstkmain'}
      ]
    }
  }
}
</script>

<style scoped>
.page-style {
  font-size: 12px;
  margin-left:10px;
  width: 476px;
  border: 1px solid;
  padding-top: 1px;
}
.row-class {
  height: 30px;
  margin-bottom: 1px;
  margin-left: 1px;
  margin-right: 1px;
}
.lab-class {
  line-height: 30px;
  width: 140px;
  background-color: #77cad8;
  margin-right: 1px;
}
.scroll-box {
  height: 450px;
  overflow-y: auto;
}
.input-group {
  line-height: normal;
  display: inline-table;
  width: 100%;
  border-collapse: separate;
}
.label-input-class {
  border-top-right-radius: 0;
  border-bottom-right-radius: 0;
}
</style>
