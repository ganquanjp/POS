<template>
  <div>
    <el-row>
      <el-col>
        <nsd-content-title v-bind:titlename="titlename" v-bind:message="this.$store.state.message"></nsd-content-title>
      </el-col>
    </el-row>
    <el-row>
      <el-col>
        <nsd-table></nsd-table>
      </el-col>
    </el-row>
  </div>
</template>

<script>
import NsdContentTitle from '@/components/common/NSDContentTitle.vue'
import NSDTable from '@/components/seisanshoshutoku/shoninkosin/NSDUpdateInput.vue'

export default {
  components: {
    'nsd-content-title': NsdContentTitle,
    'nsd-table': NSDTable
  },
  data () {
    return {
      message: '　'
    }
  },
  created () {
    this.$store.state.message.content = this.$CONST_.msgContent.UPDATE
  },
  computed: {
    titlename: function () {
      return '【取得承認】更新'
    }
  },
  methods: {
    btnClick: function (item) {
      alert(item + 'ボタンをクリックします。')
    }
  }
}
</script>

<style scoped>
</style>
