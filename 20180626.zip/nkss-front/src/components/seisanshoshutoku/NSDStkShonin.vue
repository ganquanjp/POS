<template>
  <div class="page-style">
    <el-row>
      <el-col>
        <nsd-content-title v-bind:titlename="titlename" v-bind:message="this.$store.state.message"></nsd-content-title>
      </el-col>
    </el-row>
    <el-row>
      <el-col>
        <nsd-search-input></nsd-search-input>
      </el-col>
    </el-row>
    <el-row v-if="this.$store.state.tableData.length > 0">
      <el-col>
        <nsd-table></nsd-table>
      </el-col>
    </el-row>
  </div>
</template>

<script>
import NsdContentTitle from '@/components/common/NSDContentTitle.vue'
import NSDSearchInput from '@/components/seisanshoshutoku/shonin/NSDSearchInput.vue'
import NSDTable from '@/components/seisanshoshutoku/shonin/NSDTable.vue'

export default {
  components: {
    'nsd-content-title': NsdContentTitle,
    'nsd-search-input': NSDSearchInput,
    'nsd-table': NSDTable
  },
  data () {
    return {
      titlename: '【取得承認】検索'
    }
  },
  methods: {
    btnClick: function (item) {
      alert(item + 'ボタンをクリックします。')
    }
  }
}
</script>

<style scoped>
</style>
