<template>
  <div>
    <el-row>
      <el-col>
        <nsd-content-title v-bind:titlename="titlename" v-bind:seitumei="seitumei" v-bind:message="this.$store.state.message"></nsd-content-title>
      </el-col>
    </el-row>
    <el-row>
      <el-col>
        <nsd-add-input></nsd-add-input>
      </el-col>
    </el-row>
  </div>
</template>

<script>
import NsdContentTitle from '@/components/common/NSDContentTitle.vue'
import NSDAddInput from '@/components/seisanshotoroku/sinki/NSDAddInput.vue'

export default {
  components: {
    'nsd-content-title': NsdContentTitle,
    'nsd-add-input': NSDAddInput
  },
  data () {
    return {
      titlename: '【精算書登録】新規登録',
      seitumei: '\n「適用開始日」および「適用終了日」はデフォルトのままにしてください。\n なお、「適用開始日」は設備の「取得年月日」および「使用開始年月日」以前である必要があります。'
    }
  }
}
</script>

<style scoped>

</style>
