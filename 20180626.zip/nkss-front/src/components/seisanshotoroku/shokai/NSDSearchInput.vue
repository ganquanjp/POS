<template>
  <div>
    <div class="page-style">
      <el-row class="row-class">
        <el-col class= "lab-class">　精算書番号</el-col>
        <el-col style= "width: 600px;">
          <el-input v-model="formItem.seisanShoNo" size="mini" :disabled="true"></el-input>
        </el-col>
      </el-row>
      <el-row class="row-class">
        <el-col class= "lab-class">　精算箇所</el-col>
        <el-col style= "width: 600px;">
          <el-input v-model="formItem.soshikiRenNm" size="mini" :disabled="true"></el-input>
        </el-col>
      </el-row>
      <el-row class="row-class">
        <el-col class= "lab-class">　使用開始年月日</el-col>
        <el-col style= "width: 600px;">
          <el-input v-model="formItem.siyoStartYmd" size="mini" :disabled="true"></el-input>
        </el-col>
      </el-row>
      <el-row class="row-class">
        <el-col class= "lab-class">　登録者氏名</el-col>
        <el-col style= "width: 600px;">
          <el-input v-model="formItem.torokushaName" size="mini" :disabled="true"></el-input>
        </el-col>
      </el-row>
      <el-row class="row-class">
        <el-col class= "lab-class">　摘要</el-col>
        <el-col style= "width: 600px;">
          <el-input v-model="formItem.tekiyo" size="mini" :disabled="true"></el-input>
        </el-col>
      </el-row>
      <el-row class="row-class">
        <el-col class= "lab-class">　予約数</el-col>
        <el-col style= "width: 600px; ">
          <input v-model="formItem.yoyakusu" size="mini" class="nsd-input-class" disabled="disabled" style="cursor: default;" />
        </el-col>
      </el-row>
      <el-row class="row-class">
        <el-col class= "lab-class">　工事件名コード</el-col>
        <el-col style= "width: 600px;">
          <el-input v-model="formItem.kenmeiCd" size="mini" :disabled="true"></el-input>
        </el-col>
      </el-row>
      <el-row class="row-class">
        <el-col class= "lab-class">　工事件名</el-col>
        <el-col style= "width: 600px;">
          <el-input v-model="formItem.kenmeiNm" size="mini" :disabled="true"></el-input>
        </el-col>
      </el-row>
      <el-row class="row-class">
        <el-col class= "lab-class">　適用開始日</el-col>
        <el-col style= "width: 600px;">
          <el-input v-model="formItem.tekiyoStartYmd" size="mini" :disabled="true"></el-input>
        </el-col>
      </el-row>
      <el-row class="row-class">
        <el-col class= "lab-class">　適用終了日</el-col>
        <el-col style= "width: 600px;">
          <el-input v-model="formItem.tekiyoEndYmd" size="mini" :disabled="true"></el-input>
        </el-col>
      </el-row>
      <el-row class="row-class">
        <el-col class= "lab-class">　連携対象</el-col>
        <el-col style= "width: 600px;">
          <el-input v-model="formItem.renkeiStatusKnj" size="mini" :disabled="true"></el-input>
        </el-col>
      </el-row>
    </div>
    <el-row>
      <el-col>
        <nsd-button-bar v-bind:buttons="buttonName" v-bind:formItem="formItem"></nsd-button-bar>
      </el-col>
    </el-row>
  </div>
</template>

<script>
import NSDButtonBar from '@/components/common/NSDButtonBar.vue'

export default {
  components: {
    'nsd-button-bar': NSDButtonBar
  },
  created: function () {
    this.formItem = this.$store.state.tableData[0]
    this.buttonName[0].disabled = this.formItem.delDisabled
    this.buttonName[1].disabled = this.formItem.updDisabled
  },
  data () {
    return {
      buttonName: [
        {name: this.$CONST_.buttonName.DELETE, primary: true, show: true, action: 'popup', url: '/seisanshoToroku-delete', backUrl: 'nsdssstrkkensaku', msg: '削除しますか？'},
        {name: this.$CONST_.buttonName.MODIFY, primary: true, show: true, action: 'back', backUrl: 'nsdssstrkkosin'},
        {name: this.$CONST_.buttonName.BACK, primary: true, show: true, action: 'back', backUrl: 'nsdssstrkkensaku'}
      ],
      formItem: {
        seisanShoNo: '',
        soshikiRenNm: '',
        siyoStartYmd: '',
        torokushaName: '',
        tekiyo: '',
        yoyakusu: '',
        tsuikaYoyakusu: '',
        kenmeiCd: '',
        kenmeiNm: '',
        tekiyoStartYmd: '',
        tekiyoEndYmd: '',
        renkeiStatus: '',
        renkeiStatusKnj: ''
      }
    }
  }
}
</script>

<style scoped>
.page-style {
  font-size: 12px;
  width: 775px;
  height: 100%;
  margin-left:10px;
  border: 1px solid;
  padding-top: 1px;
  padding-right: 1px;
}
.row-class {
  height: 30px;
  margin-bottom: 1px;
  margin-left: 1px;
  margin-right: 1px;
}
.lab-class {
  width: 170px;
  background-color: #77cad8;
  line-height: 30px;
  margin-right: 1px;
}
</style>
