<template>
  <div>
    <div class="page-style">
      <el-row class="row-class">
        <el-col class= "lab-class">　精算書番号</el-col>
        <el-col style= "width: 345px;">
          <el-input v-model="formItem.seisanShoNo" size="mini" :disabled="true"></el-input>
        </el-col>
      </el-row>
      <el-row class="row-class">
        <el-col class= "lab-class">　精算箇所<span class="span-class">（必須）</span></el-col>
        <el-col style= "width: 600px;">
          <el-autocomplete 
            style= "width: 600px;"
            v-model="formItem.soshikiRenNm" 
            :fetch-suggestions="querySearchAsyncSoshikiRenNm"
            id="search_text" 
            size="mini" 
            @blur="inputSoshikiRenNm"
            >
          </el-autocomplete>
        </el-col>
      </el-row>
      <el-row class="row-class">
        <el-col class= "lab-class">　使用開始年月日<span class="span-class">（必須）</span></el-col>
        <el-col style= "width: 145px;">
          <el-tooltip effect="light" placement="right-start">
            <div slot="content">K工事（一括個別収入）＝お客様検収日<br/>
                                T工事・K工事（標準）＝工事竣工日<br/>
                                K工事（リース）＝契約開始日</div>
            <el-date-picker
              v-model="formItem.siyoStartYmd"
              @blur="inputSiyoStartYmd"
              @change="changeSiyoStartYmd"
              size="mini"
              value-format="yyyy-MM-dd">
              style= "width: 140px;"
              type="date">
            </el-date-picker>
          </el-tooltip>
        </el-col>
      </el-row>
      <el-row class="row-class">
        <el-col class= "lab-class">　登録者氏名<span class="span-class">（必須）</span></el-col>
        <el-col style= "width: 345px;">
          <el-autocomplete 
            v-model="formItem.torokushaName" 
            :fetch-suggestions="querySearchAsyncTorokushaName"
            id="search_text" 
            size="mini" 
            @blur="inputTorokushaName">
          </el-autocomplete>
        </el-col>
      </el-row>
      <el-row class="row-class">
        <el-col class= "lab-class">　摘要</el-col>
        <el-col style= "width: 345px;">
          <el-input :maxlength="30" v-model="formItem.tekiyo" size="mini"></el-input>
        </el-col>
      </el-row>
      <el-row class="row-class">
        <el-col class= "lab-class">　予約数</el-col>
        <el-col style= "width: 145px; ">
          <input v-model="formItem.yoyakusu" class="nsd-input-class" :disabled="true"></input>
        </el-col>
      </el-row>
      <el-row class="row-class">
        <el-col class= "lab-class">　追加予約数</el-col>
        <el-col style= "width: 145px; ">
          <vue-numeric v-model="formItem.tsuikaYoyakusu" size="mini" class="nsd-input-class" :maxlength="3"></vue-numeric>
        </el-col>
      </el-row>
      <el-row class="row-class">
        <el-col class= "lab-class">　工事件名コード<span class="span-class">（必須）</span></el-col>
        <el-col style= "width: 345px;">
          <el-tooltip effect="light" placement="right-start">
            <div slot="content">決裁書起案番号または需要箇所契約番号</div>
            <el-autocomplete 
              v-model="formItem.kenmeiCd" 
              :fetch-suggestions="querySearchAsyncKenmeiCd"
              @select="handleSelectKenmeiCd"
              id="search_text" 
              size="mini"
              >
            </el-autocomplete>
          </el-tooltip>
        </el-col>
      </el-row>
      <el-row class="row-class">
        <el-col class= "lab-class">　工事件名<span class="span-class">（必須）</span></el-col>
        <el-col style= "width: 300px;">
          <el-autocomplete 
            v-model="formItem.kenmeiNm" 
            :fetch-suggestions="querySearchAsyncKenmeiNm"
            @select="handleSelectKenmeiNm"
            id="search_text" 
            size="mini" 
            style= "width: 300px;"
            >
          </el-autocomplete>
        </el-col>
      </el-row>
      <el-row class="row-class">
        <el-col class= "lab-class">　適用開始日<span class="span-class">（必須）</span></el-col>
        <el-col style= "width: 145px;">
          <el-date-picker
            v-model="formItem.tekiyoStartYmd"
            size="mini"
            value-format="yyyy-MM-dd">
            style= "width: 140px;"
            type="date">
          </el-date-picker>
        </el-col>
      </el-row>
      <el-row class="row-class">
        <el-col class= "lab-class">　適用終了日<span class="span-class">（必須）</span></el-col>
        <el-col style= "width: 145px;">
          <el-date-picker
            v-model="formItem.tekiyoEndYmd"
            size="mini"
            value-format="yyyy-MM-dd">
            style= "width: 140px;"
            type="date">
          </el-date-picker>
        </el-col>
      </el-row>
    </div>
    <el-row>
      <el-col>
        <nsd-button-bar v-bind:buttons="buttonName" v-bind:formItem="formItem" @resetInit="resetInit"></nsd-button-bar>
      </el-col>
    </el-row>
  </div>
</template>

<script>
import moment from 'moment'
import NSDButtonBar from '@/components/common/NSDButtonBar.vue'

export default {
  components: {
    'nsd-button-bar': NSDButtonBar
  },
  created: function () {
    this.resetInitData = JSON.parse(JSON.stringify(this.$store.state.tableData[0]))
    this.resetInitData.tsuikaYoyakusu = 0
    this.formItem = JSON.parse(JSON.stringify(this.$store.state.tableData[0]))
    this.formItem.tsuikaYoyakusu = 0
  },
  data () {
    return {
      buttonName: [
        {name: this.$CONST_.buttonName.MODIFY, primary: true, show: true, action: 'insert', url: '/seisanshoToroku-modifySeisansho', callBack: this.updCallBack, msg: '更新しますか？'},
        {name: this.$CONST_.buttonName.RESET, primary: true, show: true, action: 'resetInit', url: '', msg: 'リセットしますか？'},
        {name: this.$CONST_.buttonName.BACK, primary: true, show: true, action: 'back', backUrl: 'nsdssstrkshokai'}
      ],
      formItem: {},
      resetInitData: {}
    }
  },
  methods: {
    resetInit () {
      this.formItem = {}
      this.formItem = JSON.parse(JSON.stringify(this.resetInitData))
    },
    loadSeisanKasho () {
      var items = ['soshikiRenNm', 'soshikiCd']
      return this.funcGetDropDownValue('/autocomplete-selectSoshikiMaster', items)
    },
    loadKojiInfo () {
      this.kojiCode = this.loadKojiCd()
      this.kojiName = this.loadKojiNm()
    },
    loadKojiCd () {
      var items = ['kenmeiCd', 'kenmeiNm', 'tekiyoStartYmd', 'tekiyoEndYmd']
      var url = '/autocomplete-selectKenmeiMaster'
      if (this.formItem.siyoStartYmd !== undefined && this.formItem.siyoStartYmd !== '' && this.formItem.siyoStartYmd !== null) {
        url = url + '?siyoStartYmd=' + this.formItem.siyoStartYmd
      }
      return this.funcGetDropDownValue(url, items)
    },
    loadKojiNm () {
      var items = ['kenmeiNm', 'kenmeiCd', 'tekiyoStartYmd', 'tekiyoEndYmd']
      var url = '/autocomplete-selectKenmeiMaster'
      if (this.formItem.siyoStartYmd !== undefined && this.formItem.siyoStartYmd !== '' && this.formItem.siyoStartYmd !== null) {
        url = url + '?siyoStartYmd=' + this.formItem.siyoStartYmd
      }
      return this.funcGetDropDownValue(url, items)
    },
    loadTorokushaName () {
      var items = ['seiMei', 'userId', 'sei', 'mei', 'nyushaYmd']
      return this.funcGetDropDownValue('/autocomplete-selectUserMaster', items)
    },
    querySearchAsyncSoshikiRenNm (queryString, cb) {
      var seisanKasho = this.seisanKasho
      var results = queryString ? seisanKasho.filter(this.createStateFilter(queryString)) : seisanKasho
      clearTimeout(this.timeout)
      this.timeout = setTimeout(() => {
        cb(results)
      }, 200 * Math.random())
    },
    querySearchAsyncTorokushaName (queryString, cb) {
      var torokushaName = this.torokushaName
      console.log(torokushaName)
      var results = queryString ? torokushaName.filter(this.createStateFilter(queryString)) : torokushaName
      clearTimeout(this.timeout)
      this.timeout = setTimeout(() => {
        cb(results)
      }, 200 * Math.random())
    },
    querySearchAsyncKenmeiCd (queryString, cb) {
      var kojiCode = this.kojiCode
      var results = queryString ? kojiCode.filter(this.createStateFilter(queryString)) : kojiCode
      clearTimeout(this.timeout)
      this.timeout = setTimeout(() => {
        cb(results)
      }, 200 * Math.random())
    },
    querySearchAsyncKenmeiNm (queryString, cb) {
      var kojiName = this.kojiName
      var results = queryString ? kojiName.filter(this.createStateFilter(queryString)) : kojiName
      clearTimeout(this.timeout)
      this.timeout = setTimeout(() => {
        cb(results)
      }, 200 * Math.random())
    },
    createStateFilter (queryString) {
      console.log(queryString)
      return (state) => {
        return (state.value.toLowerCase().indexOf(queryString.toLowerCase()) >= 0)
      }
    },
    handleSelectKenmeiCd (item) {
      this.formItem.kenmeiCd = item.value
      this.formItem.kenmeiNm = item.kenmeiNm
      this.formItem.tekiyoStartYmd = moment(item.tekiyoStartYmd).format('YYYY-MM-DD')
      this.formItem.tekiyoEndYmd = moment(item.tekiyoEndYmd).format('YYYY-MM-DD')
    },
    handleSelectKenmeiNm (item) {
      this.formItem.kenmeiNm = item.value
      this.formItem.kenmeiCd = item.kenmeiCd
      this.formItem.tekiyoStartYmd = moment(item.tekiyoStartYmd).format('YYYY-MM-DD')
      this.formItem.tekiyoEndYmd = moment(item.tekiyoEndYmd).format('YYYY-MM-DD')
    },
    handleSelectTorokushaName (item) {
      this.formItem.seisanEntryUserId = item.userId
      this.formItem.nyushaYmd = moment(item.nyushaYmd).format('YYYY-MM-DD')
    },
    inputSoshikiRenNm (item) {
      if (item.srcElement.value === '') {
        this.formItem.soshikiRenNm = ''
      }
    },
    inputTorokushaName (item) {
      if (item.srcElement.value === '') {
        this.formItem.torokushaName = ''
      }
    },
    inputSiyoStartYmd (item) {
      if (item.userInput !== null && item.userInput !== '') {
        this.formItem.siyoStartYmd = item.userInput
        if (!this.IsDate(this.formItem.siyoStartYmd)) {
          item.userInput = ''
          this.formItem.siyoStartYmd = item.userInput
        }
      }
      this.loadKojiInfo()
    },
    changeSiyoStartYmd (value) {
      if (value === null) {
        this.loadKojiInfo()
      }
    },
    inputTekiyoStartYmd (item) {
      if (item.userInput !== null && item.userInput !== '') {
        this.formItem.tekiyoStartYmd = item.userInput
        if (!this.IsDate(this.formItem.tekiyoStartYmd)) {
          item.userInput = ''
          this.formItem.tekiyoStartYmd = item.userInput
        }
      }
    },
    inputTekiyoEndYmd (item) {
      if (item.userInput !== null && item.userInput !== '') {
        this.formItem.tekiyoEndYmd = item.userInput
        if (!this.IsDate(this.formItem.tekiyoEndYmd)) {
          item.userInput = ''
          this.formItem.tekiyoEndYmd = item.userInput
        }
      }
    },
    updCallBack (val) {
      this.funcClearData()
      this.$router.push({name: 'nsdssstrkkensaku'})
    }
  },
  mounted () {
    this.seisanKasho = this.loadSeisanKasho()
    this.torokushaName = this.loadTorokushaName()
    this.loadKojiInfo()
  }
}
</script>

<style scoped>
.page-style {
  font-size: 12px;
  width: 775px;
  height: 100%;
  margin-left:10px;
  border: 1px solid;
  padding-top: 1px;
  padding-right: 1px;
}
.row-class {
  height: 30px;
  margin-bottom: 1px;
  margin-left: 1px;
  margin-right: 1px;
}
.lab-class {
  width: 170px;
  background-color: #77cad8;
  line-height: 30px;
  margin-right: 1px;
}
.checkbox-class {
  width: 300px;
  line-height: 30px;
  margin-left: 5px;
}
.span-class {
 color: red;
 float: right;
}
</style>
