<template>
  <div>
    <el-row>
      <el-col>
        <nsd-content-title v-bind:titlename="titlename" v-bind:message="this.$store.state.message"></nsd-content-title>
      </el-col>
    </el-row>
    <el-row>
      <el-col>
        <nsd-search-input></nsd-search-input>
      </el-col>
    </el-row>
  </div>
</template>

<script>
import NsdContentTitle from '@/components/common/NSDContentTitle.vue'
import NSDSearchInput from '@/components/seisanshotoroku/kosin/NSDSearchInput.vue'

export default {
  components: {
    'nsd-content-title': NsdContentTitle,
    'nsd-search-input': NSDSearchInput

  },
  data () {
    return {
      titlename: '【精算書登録】修正',
      message: ''
    }
  }
}
</script>

<style scoped>

</style>
