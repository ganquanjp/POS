<template>
  <div>
    <el-row>
      <el-col>
        <nsd-content-title v-bind:titlename="titlename" v-bind:message="this.$store.state.message"></nsd-content-title>
      </el-col>
    </el-row>
    <el-row>
      <el-col>
        <nsd-search-input></nsd-search-input>
      </el-col>
    </el-row>
    <el-row v-if="this.$store.state.tableData.length > 0">
      <el-col>
        <nsd-table></nsd-table>
      </el-col>
    </el-row>
  </div>
</template>

<script>
import NsdContentTitle from '@/components/common/NSDContentTitle.vue'
import NSDSearchInput from '@/components/seisanshojokyaku/shoninkensaku/NSDSearchInput.vue'
import NSDTable from '@/components/seisanshojokyaku/shoninkensaku/NSDTable.vue'

export default {
  components: {
    'nsd-content-title': NsdContentTitle,
    'nsd-search-input': NSDSearchInput,
    'nsd-table': NSDTable

  },
  data () {
    return {
      titlename: '【除却承認】検索'
    }
  }
}
</script>

<style scoped>
</style>

