<template>
  <div>
    <div class="page-style">
        <el-row class="row-class">
          <el-col class="lab-class">　精算書番号</el-col>
          <el-col style= "width: 640px;">
            <el-input v-model="formItem.jokyakuSeisanShoNo" size="mini" :disabled="true"></el-input>
          </el-col>
        </el-row>
        <el-row class="row-class">
          <el-col class="lab-class">　精算箇所</el-col>
          <el-col style= "width: 640px;">
            <el-input v-model="formItem.soshikiRenNm" size="mini" :disabled="true""></el-input>
          </el-col>
        </el-row>
        <el-row class="row-class">
          <el-col class="lab-class">　除却予定年月日</el-col>
          <el-col style= "width: 640px;">
            <el-input v-model="formItem.jokyakuYoteYmd" size="mini" :disabled="true"></el-input>
          </el-col>
        </el-row>
        <el-row class="row-class">
          <el-col class="lab-class">　摘要</el-col>
          <el-col style= "width: 640px;">
            <el-input v-model="formItem.tekiyo" size="mini" :disabled="true"></el-input>
          </el-col>
        </el-row>
        <el-row class="row-class">
          <el-col class="lab-class">　工事件名</el-col>
          <el-col style= "width: 640px;">
            <el-input v-model="formItem.kenmeiNm" size="mini" :disabled="true""></el-input>
          </el-col>
        </el-row>
    </div>
    <div style="height: 25px;">
      <div style="position: absolute; top: 165px; left: 10px;">
        <span style="font-size: 12px;">{{this.$store.state.tableData.koteiSisanLst.length}}件</span>
      </div>
      <div style="position: absolute; top: 155px; right: 0px;">
        <el-pagination
          background
          @size-change="handleSizeChange"
          @current-change="handleCurrentChange"
          :current-page.sync="pageData.currentPage"
          :page-sizes="pageData.pageSizeArr"
          :page-size="pageData.pageSizeAct"
          layout="prev, pager, next"
          prev-text="前へ"
          next-text="次へ"
          :total="this.$store.state.tableData.koteiSisanLst.length">
        </el-pagination>
      </div>
    </div>
    <div ref="divScroll" class="scroll-box">
      <div>
        <el-table
          :data="this.$store.state.currentPageData"
          border>
          <el-table-column 
            prop="rowNo"
            label="NO."
            min-width="48px">
          </el-table-column>
          <el-table-column
            label="固定資産番号"
            min-width="110px">
            <template slot-scope="scope">
              <el-button type="text" size="medium" @click="move(scope.row)">{{scope.row.koteiNo}}</el-button>
            </template>
          </el-table-column>
          <el-table-column
            prop="koteiKnj"
            label="固定資産名称"
            min-width="200px">
          </el-table-column>
          <el-table-column
            prop="getkgkYen"
            label="元_取得価額"
            header-align=left
            align=right
            :formatter="commaFormatter"
            min-width="150px">
          </el-table-column >
          <el-table-column
            prop="jokyakuGaku"
            label="除_取得価額"
            header-align=left
            align=right
            :formatter="commaFormatter"
            min-width="140px">
          </el-table-column>
          <el-table-column
            prop="jokyakuShubetsuNm"
            label="除却種別コード"
            min-width="100px">
          </el-table-column>
        </el-table>
        <div style="margin-top: 10px; border: 1px solid; padding-top: 1px; width: 532px; font-size: 12px;" v-if="display">
          <el-row class="row-class">
            <el-col class="lab-class">　固定資産番号</el-col>
            <el-col style= "width: 328px">
              <el-input v-model="koteiItem.koteiNo" size="mini" :disabled="true" />
            </el-col>
          </el-row>
          <el-row class="row-class">
            <el-col class="lab-class">　固定資産名称</el-col>
            <el-col style= "width: 328px">
              <el-input v-model="koteiItem.koteiKnj" size="mini" :disabled="true" />
            </el-col>
          </el-row>
          <el-row class="row-class">
            <el-col class="lab-class">　取得年月日</el-col>
            <el-col style= "width: 328px">
              <el-input v-model="koteiItem.getYmd" size="mini" :disabled="true" />
            </el-col>
          </el-row>
          <el-row class="row-class">
            <el-col class="lab-class">　元_数量</el-col>
            <el-col style= "width: 100px">
              <vue-numeric v-model="koteiItem.meiSu" size="mini" class="nsd-input-class" disabled="disabled" v-bind:precision="2" ></vue-numeric>
            </el-col>            
            <el-col style="width: 50px; line-height: 30px; background-color: #77cad8; margin-right: 1px; margin-left: 1px;">　単位</el-col>
            <el-col style= "width: 175px">
              <el-input v-model="koteiItem.taniKnj" size="mini" :disabled="true" />
            </el-col>
          </el-row>
          <el-row class="row-class">
            <el-col class="lab-class">　元_取得価額</el-col>
            <el-col class="input-group" style= "width: 328px">
              <vue-numeric currency="\" separator="," v-model="koteiItem.getkgkYen" size="mini" class="nsd-input-class" disabled="disabled"></vue-numeric>
            </el-col>
          </el-row>
          <el-row class="row-class">
            <el-col class="lab-class">　除却区分</el-col>
            <el-col style= "width: 328px">
              <el-input v-model="koteiItem.jokyakuKbnNm" size="mini" :disabled="true" />
            </el-col>
          </el-row>
          <el-row class="row-class">
            <el-col class="lab-class">　除却種別コード</el-col>
            <el-col style= "width: 328px">
              <el-input v-model="koteiItem.jokyakuShubetsuNm" size="mini" :disabled="true" />
            </el-col>
          </el-row>
          <el-row class="row-class">
            <el-col class="lab-class">　除_数量</el-col>
            <el-col style= "width: 100px">
              <vue-numeric v-model="koteiItem.jokyakuSuryo" size="mini" class="nsd-input-class" disabled="disabled" v-bind:precision="2" ></vue-numeric>
            </el-col>            
            <el-col style="width: 50px; line-height: 30px; background-color: #77cad8; margin-right: 1px; margin-left: 1px;">　単位</el-col>
            <el-col style= "width: 175px">
              <el-input v-model="koteiItem.taniKnj" size="mini" :disabled="true" />
            </el-col>
          </el-row>
          <el-row class="row-class">
            <el-col class="lab-class">　除_取得価額</el-col>
            <el-col class="input-group" style= "width: 328px">
              <vue-numeric currency="\" separator="," v-model="koteiItem.jokyakuGaku" size="mini" class="nsd-input-class" disabled="disabled"></vue-numeric>
            </el-col>
          </el-row>
        </div>
      </div>
    </div>
    <el-row>
      <el-col>
        <nsd-button-bar v-bind:buttons="buttonName" v-bind:formItem="formItem"></nsd-button-bar>
      </el-col>
    </el-row>
  </div>
</template>

<script scoped>
import NSDButtonBar from '@/components/common/NSDButtonBar.vue'

export default {
  components: {
    'nsd-button-bar': NSDButtonBar
  },
  created: function () {
    this.formItem = this.$store.state.tableData
    if (this.formItem.shoninStatus === this.$CONST_.shoninStatus.RENKEI) {
      this.buttonName[0].disabled = true
      this.buttonName[1].disabled = true
    } else {
      this.buttonName[0].disabled = false
      this.buttonName[1].disabled = false
    }
    this.getPageData()
  },
  methods: {
    move: function (rowData) {
      this.koteiItem = rowData
      this.display = true
    },
    handleSizeChange (index) {
      this.pageData.pageSizeAct = index
      this.initTableList(1)
    },
    handleCurrentChange (index) {
      this.initTableList(index)
    },
    initTableList (index) {
      this._initPageData(index)
      this.getPageData()
      let container = this.$el.querySelector('.el-table__body-wrapper')
      if (container !== null) {
        container.scrollTop = 0
      }
    },
    _initPageData (index) {
      this.pageData.pageNum = (index - 1) * this.pageData.pageSizeAct
      this.pageData.currentPage = index
    },
    getPageData () {
      this.$store.state.currentPageData = this.$store.state.tableData.koteiSisanLst.slice(this.pageData.pageSizeAct * (this.pageData.currentPage - 1), this.pageData.pageSizeAct * this.pageData.currentPage)
    },
    printCallBack (val) {
      var url = ''
      for (var i = 0; i < val.length; i++) {
        url = this.$baseURL + this.$CONST_.urlPath.OUTPUT_PDF + val[i] + '.pdf'
        window.open(url)
      }
    }
  },
  data () {
    return {
      display: false,
      buttonName: [
        {name: this.$CONST_.buttonName.PRINT, primary: true, show: true, action: 'insert', url: '/seisanshoJokyakuNaiyo-printing', callBack: this.printCallBack, msg: '経理に提出する際は除却精算通告で除却年月日を入力の上、除却承認画面より印刷してください。印刷しますか？'},
        {name: this.$CONST_.buttonName.UPDATE, primary: true, show: true, action: 'back', url: '', backUrl: 'NSDSssjkkNaiyokosin', msg: ''},
        {name: this.$CONST_.buttonName.BACK, primary: true, show: true, action: 'back', url: '', backUrl: 'nsdsssjkknaiyokensaku', msg: ''}
      ],
      formItem: '',
      koteiItem: '',
      pageData: {
        total: 0,
        pageNum: 0,
        pageSizeArr: this.$CONST_.tableConst.PAGE_SIZES,
        pageSizeAct: this.$CONST_.tableConst.PAGE_SIZE,
        currentPage: 1,
        visible: false
      }
    }
  }
}
</script>

<style scoped>
.page-style {
  font-size: 12px;
  width: 843px;
  height: 100%;
  line-height:30px;
  border: 1px solid;
  padding-top: 1px;
  margin-left: 10px;
}
.scroll-box {
  max-height: 340px;
  overflow-y: auto;
  margin-left: 10px;
}
.row-class {
  height: 30px;
  margin-bottom: 1px;
  margin-left: 1px;
  margin-right: 1px;
}
.lab-class {
  line-height: 30px;
  width: 200px;
  background-color: #77cad8;
  margin-right: 1px;
}
.input-group {
  line-height: normal;
  display: inline-table;
  width: 200px;
  border-collapse: separate;
}
</style>