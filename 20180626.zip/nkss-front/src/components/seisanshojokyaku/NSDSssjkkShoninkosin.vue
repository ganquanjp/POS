<template>
  <div>
    <el-row>
      <el-col>
        <nsd-content-title v-bind:titlename="titlename" v-bind:message="this.$store.state.message"></nsd-content-title>
      </el-col>
    </el-row>
    <el-row>
      <el-col>
        <nsd-update-input></nsd-update-input>
      </el-col>
    </el-row>
  </div>
</template>

<script>
import NsdContentTitle from '@/components/common/NSDContentTitle.vue'
import NSDUpdateInput from '@/components/seisanshojokyaku/shoninkosin/NSDUpdateInput.vue'

export default {
  components: {
    'nsd-content-title': NsdContentTitle,
    'nsd-update-input': NSDUpdateInput

  },
  created () {
    this.$store.state.message.content = this.$CONST_.msgContent.UPDATE
  },
  data () {
    return {
      titlename: '【除却承認】更新'
    }
  }
}
</script>

<style scoped>
</style>
