<template>
  <div>
    <div class="page-style">
        <el-row class="row-class">
          <el-col class="lab-class">　精算書番号</el-col>
          <el-col style= "width: 640px;">
            <el-input v-model="resetInitData.jokyakuSeisanShoNo" size="mini" :disabled="true"></el-input>
          </el-col>
        </el-row>
        <el-row class="row-class">
          <el-col class="lab-class">　精算箇所</el-col>
          <el-col style= "width: 640px;">
            <el-input v-model="resetInitData.soshikiRenNm" size="mini" :disabled="true""></el-input>
          </el-col>
        </el-row>
        <el-row class="row-class">
          <el-col class="lab-class">　除却予定年月日</el-col>
          <el-col style= "width: 640px;">
            <el-input v-model="resetInitData.jokyakuYoteYmd" size="mini" :disabled="true"></el-input>
          </el-col>
        </el-row>
        <el-row class="row-class">
          <el-col class="lab-class">　摘要</el-col>
          <el-col style= "width: 640px;">
            <el-input v-model="resetInitData.tekiyo" size="mini" :disabled="true"></el-input>
          </el-col>
        </el-row>
        <el-row class="row-class">
          <el-col class="lab-class">　工事件名</el-col>
          <el-col style= "width: 640px;">
            <el-input v-model="resetInitData.kenmeiNm" size="mini" :disabled="true""></el-input>
          </el-col>
        </el-row>
    </div>
    <div style="height: 25px;">
      <div style="position: absolute; top: 165px; left: 10px;">
        <span style="font-size: 12px;">{{this.resetInitData.koteiSisanLst.length}}件</span>
      </div>
      <div style="position: absolute; top: 155px; right: 0px;">
        <el-pagination
          background
          @size-change="handleSizeChange"
          @current-change="handleCurrentChange"
          :current-page.sync="pageData.currentPage"
          :page-sizes="pageData.pageSizeArr"
          :page-size="pageData.pageSizeAct"
          layout="prev, pager, next"
          prev-text="前へ"
          next-text="次へ"
          :total="this.resetInitData.koteiSisanLst.length">
        </el-pagination>
      </div>
    </div>
    <div ref="divScroll" class="scroll-box">
      <div>
        <el-table
          :data="this.formItem.koteiSisanLst"
          border>
          <el-table-column 
            prop="rowNo"
            label="NO."
            min-width="48px">
          </el-table-column>
          <el-table-column
            label="固定資産番号"
            min-width="110px">
            <template slot-scope="scope">
              <el-button type="text" size="medium" @click="move(scope.row)">{{scope.row.koteiNo}}</el-button>
            </template>
          </el-table-column>
          <el-table-column
            prop="koteiKnj"
            label="固定資産名称"
            min-width="200px">
          </el-table-column>
          <el-table-column
            prop="getkgkYen"
            label="元_取得価額"
            header-align=left
            align=right
            :formatter="commaFormatter"
            min-width="150px">
          </el-table-column >
          <el-table-column
            prop="jokyakuGaku"
            label="除_取得価額"
            header-align=left
            align=right
            :formatter="commaFormatter"
            min-width="140px">
          </el-table-column>
          <el-table-column
            prop="jokyakuShubetsuNm"
            label="除却種別コード"
            min-width="100px">
          </el-table-column>
        </el-table>
        <div style="margin-top: 10px; border: 1px solid; padding-top: 1px; width: 532px; font-size: 12px;" v-if="display">
          <el-row class="row-class">
            <el-col class="lab-class">　固定資産番号</el-col>
            <el-col style= "width: 328px">
              <el-input v-model="koteiItem.koteiNo" size="mini" :disabled="true" />
            </el-col>
          </el-row>
          <el-row class="row-class">
            <el-col class="lab-class">　固定資産名称</el-col>
            <el-col style= "width: 328px">
              <el-input v-model="koteiItem.koteiKnj" size="mini" :disabled="true" />
            </el-col>
          </el-row>
          <el-row class="row-class">
            <el-col class="lab-class">　取得年月日</el-col>
            <el-col style= "width: 328px">
              <el-input v-model="koteiItem.getYmd" size="mini" :disabled="true" />
            </el-col>
          </el-row>
          <el-row class="row-class">
            <el-col class="lab-class">　元_数量</el-col>
            <el-col style= "width: 100px">
              <vue-numeric v-model="koteiItem.meiSu" size="mini" class="nsd-input-class" disabled="disabled" v-bind:precision="2" ></vue-numeric>
            </el-col>            
            <el-col style="width: 50px; line-height: 30px; background-color: #77cad8; margin-right: 1px; margin-left: 1px;">　単位</el-col>
            <el-col style= "width: 175px">
              <el-input v-model="koteiItem.taniKnj" size="mini" :disabled="true" />
            </el-col>
          </el-row>
          <el-row class="row-class">
            <el-col class="lab-class">　元_取得価額</el-col>
            <el-col style= "width: 328px">
              <vue-numeric currency="\" separator="," v-model="koteiItem.getkgkYen" size="mini" class="nsd-input-class" disabled="disabled"></vue-numeric>
            </el-col>
          </el-row>
          <el-row class="row-class">
            <el-col class="lab-class">　除却区分<span class="span-class">（必須）</span></el-col>
            <el-col style= "width: 328px">
              <el-select v-model="koteiItem.jokyakuKbn" size="mini" style= "width: 328px"  @change="jokyakuKbnChange">
                <el-option
                   v-for="item in this.jokyakuKbnLst"
                   :key="item.cd1"
                   :label="item.cdKnj"
                   :value="item.cd1">
                </el-option>
              </el-select>
            </el-col>
          </el-row>
          <el-row class="row-class">
            <el-col class="lab-class">　除却種別コード<span class="span-class">（必須）</span></el-col>
            <el-col style= "width: 328px">
              <el-select v-model="koteiItem.jokyakuShubetsuCd" size="mini"style= "width: 328px"  @change="jokyakuSbtChange">
                <el-option
                   v-for="item in this.jokyakuSbtLst"
                   :key="item.cd1"
                   :label="item.cdKnj"
                   :value="item.cd1">
                </el-option>
              </el-select>
            </el-col>
          </el-row>
          <el-row class="row-class">
            <el-col class="lab-class">　除_数量<span class="span-class">（必須）</span></el-col>
            <el-col style= "width: 100px">
              <vue-numeric v-model="koteiItem.jokyakuSuryo" size="mini" class="nsd-input-class" v-bind:precision="2" :disabled=this.btnDisabled></vue-numeric>
            </el-col>            
            <el-col style="width: 50px; line-height: 30px; background-color: #77cad8; margin-right: 1px; margin-left: 1px;">　単位</el-col>
            <el-col style= "width: 48px">
              <el-input v-model="koteiItem.taniKnj" size="mini" :disabled="true" />
            </el-col>
            <el-col style= "width: 48px">
              <el-button type="primary" size="mini" style="margin-left: 1px;" v-bind:disabled=this.btnDisabled @click="btnClick(koteiItem)">取得価格数量按分</el-button>
            </el-col>
          </el-row>
          <el-row class="row-class">
            <el-col class="lab-class">　除_取得価額<span class="span-class">（必須）</span></el-col>
            <el-col style= "width: 328px">
              <vue-numeric currency="\" separator="," v-model="koteiItem.jokyakuGaku" size="mini" class="nsd-input-class" :disabled=this.btnDisabled></vue-numeric>
            </el-col>
          </el-row>
        </div>
      </div>
    </div>
    <el-row>
      <el-col>
        <nsd-button-bar v-bind:buttons="buttonName" v-bind:formItem="formItem" @resetInit="resetInit"></nsd-button-bar>
      </el-col>
    </el-row>
  </div>
</template>

<script scoped>
import NSDButtonBar from '@/components/common/NSDButtonBar.vue'

export default {
  components: {
    'nsd-button-bar': NSDButtonBar
  },
  created: function () {
    this.resetInitData = JSON.parse(JSON.stringify(this.$store.state.tableData))
    this.formItem.koteiSisanLst = JSON.parse(JSON.stringify(this.$store.state.tableData.koteiSisanLst))
    this.funcHttpPostComm('/comm-getCodeShubetsuList', {cdShubetsu: 'CD0006'}, this.JokyakuKbnCallBack)
    this.funcHttpPostComm('/comm-getCodeShubetsuList', {cdShubetsu: 'CD0008'}, this.JokyakuSbtCallBack)
  },
  methods: {
    move: function (rowData) {
      this.koteiItem = rowData
      if (this.koteiItem.jokyakuKbn === '0') {
        this.btnDisabled = true
      } else {
        this.btnDisabled = false
      }
      this.display = true
    },
    resetInit () {
      this.formItem = {}
      this.formItem.koteiSisanLst = JSON.parse(JSON.stringify(this.resetInitData.koteiSisanLst))
      this.display = false
    },
    JokyakuKbnCallBack (val) {
      this.jokyakuKbnLst = val
    },
    JokyakuSbtCallBack (val) {
      this.jokyakuSbtLst = val
      // this.jokyakuSbtLst.unshift({cd1: '', cdKnj: ''})
    },
    handleSizeChange (index) {
      this.pageData.pageSizeAct = index
      this.initTableList(1)
    },
    handleCurrentChange (index) {
      this.initTableList(index)
    },
    initTableList (index) {
      this._initPageData(index)
      this.getPageData()
    },
    _initPageData (index) {
      this.pageData.pageNum = (index - 1) * this.pageData.pageSizeAct
      this.pageData.currentPage = index
    },
    getPageData () {
      this.$store.state.currentPageData = this.$store.state.tableData.koteiSisanLst.slice(this.pageData.pageSizeAct * (this.pageData.currentPage - 1), this.pageData.pageSizeAct * this.pageData.currentPage)
    },
    jokyakuKbnChange (val) {
      if (val === '0') {
        this.koteiItem.jokyakuSuryo = this.koteiItem.meiSu
        this.koteiItem.jokyakuGaku = this.koteiItem.getkgkYen
        this.btnDisabled = true
      } else {
        this.koteiItem.jokyakuSuryo = '0'
        this.koteiItem.jokyakuGaku = '0'
        this.btnDisabled = false
      }
      for (var item in this.jokyakuKbnLst) {
        if (val === this.jokyakuKbnLst[item].cd1) {
          this.koteiItem.jokyakuKbnNm = this.jokyakuKbnLst[item].cdKnj
        }
      }
    },
    jokyakuSbtChange (val) {
      for (var item in this.jokyakuSbtLst) {
        if (val === this.jokyakuSbtLst[item].cd1) {
          this.koteiItem.jokyakuShubetsuNm = this.jokyakuSbtLst[item].cdKnj
        }
      }
    },
    btnClick (val) {
      val.jokyakuGaku = Math.round(parseFloat(val.getkgkYen) * (parseFloat(val.jokyakuSuryo) / parseFloat(val.meiSu)))
    },
    updCallBack (val) {
      this.funcClearData()
      this.$router.push({name: 'nsdsssjkknaiyokensaku'})
    }
  },
  data () {
    return {
      display: false,
      btnDisabled: false,
      buttonName: [
        {name: this.$CONST_.buttonName.UPDATE, primary: true, show: true, action: 'insert', url: '/seisanshoJokyakuNaiyo-updateInfo', callBack: this.updCallBack, msg: '更新しますか？'},
        {name: this.$CONST_.buttonName.RESET, primary: true, show: true, action: 'resetInit', url: '', msg: 'リセットしますか？'},
        {name: this.$CONST_.buttonName.BACK, primary: true, show: true, action: 'back', url: '', backUrl: 'nsdsssjkknaiyoshokai', msg: ''}
      ],
      jokyakuKbnLst: [],
      jokyakuSbtLst: [],
      formItem: [],
      koteiItem: '',
      resetInitData: {},
      pageData: {
        total: 0,
        pageNum: 0,
        pageSizeArr: this.$CONST_.tableConst.PAGE_SIZES,
        pageSizeAct: this.$CONST_.tableConst.PAGE_SIZE,
        currentPage: 1,
        visible: false
      }
    }
  }
}
</script>

<style scoped>
.page-style {
  font-size: 12px;
  width: 843px;
  height: 100%;
  line-height:30px;
  border: 1px solid;
  padding-top: 1px;
  margin-left: 10px;
}
.scroll-box {
  max-height: 340px;
  overflow-y: auto;
  margin-left: 10px;
}
.row-class {
  height: 30px;
  margin-bottom: 1px;
  margin-left: 1px;
  margin-right: 1px;
}
.lab-class {
  line-height: 30px;
  width: 200px;
  background-color: #77cad8;
  margin-right: 1px;
}
.span-class {
 color: red;
 float: right;
}
</style>