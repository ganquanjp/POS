<template>
  <div>
    <div style= "padding-left: 10px; padding-right: 10px;">
      <div class="page-style">
        <el-row class="row-class">
          <el-col class="lab-class">　精算書番号</el-col>
          <el-col style= "width: 640px;">
            <el-input v-model="formItem.jokyakuSeisanShoNo" size="mini" :disabled="true"></el-input>
          </el-col>
        </el-row>
        <el-row class="row-class">
          <el-col class="lab-class">　精算箇所</el-col>
          <el-col style= "width: 640px;">
            <el-input v-model="formItem.soshikiRenNm" size="mini" :disabled="true""></el-input>
          </el-col>
        </el-row>
        <el-row class="row-class">
          <el-col class="lab-class">　除却予定年月</el-col>
          <el-col style= "width: 640px;">
            <el-input v-model="formItem.jokyakuYoteYmd" size="mini" :disabled="true"></el-input>
          </el-col>
        </el-row>
        <el-row class="row-class">
          <el-col class="lab-class">　登録者氏名</el-col>
          <el-col style= "width: 640px;">
            <el-input v-model="formItem.seiMei" size="mini" :disabled="true"></el-input>
          </el-col>
        </el-row>
        <el-row class="row-class">
          <el-col class="lab-class">　摘要</el-col>
          <el-col style= "width: 640px;">
            <el-input v-model="formItem.tekiyo" size="mini" :disabled="true"></el-input>
          </el-col>
        </el-row>
        <el-row class="row-class">
          <el-col class="lab-class">　工事件名</el-col>
          <el-col style= "width: 640px;">
            <el-input v-model="formItem.kenmeiNm" size="mini" :disabled="true""></el-input>
          </el-col>
        </el-row>
      </div>
      <div style="height: 10px"></div>
      <div style="height: 25px">
       <span style="font-size: 12px;">{{this.$store.state.tableData.koteiSisanLst.length}}件</span>
        <div style="position: absolute; top: 195px; right: 0px;">
          <el-pagination
            background
            @size-change="handleSizeChange"
            @current-change="handleCurrentChange"
            :current-page.sync="pageData.currentPage"
            :page-sizes="pageData.pageSizeArr"
            :page-size="pageData.pageSizeAct"
            layout="prev, pager, next"
            prev-text="前へ"
            next-text="次へ"
            :total="this.$store.state.tableData.koteiSisanLst.length">
          </el-pagination>
        </div>
      </div>
      <el-table
        :data="this.$store.state.currentPageData"
        max-height=260
        border>
        <el-table-column 
          prop="rowNo"
          label="NO."
          min-width="50px">
        </el-table-column>
        <el-table-column
          prop="koteiNo"
          label="固定資産番号"
          min-width="120px">
        </el-table-column >
        <el-table-column
          prop="koteiKnj"
          label="固定資産名称"
          min-width="120px">
        </el-table-column>
        <el-table-column
          prop="getYmd"
          label="取得年月日"
          min-width="100px">
        </el-table-column>
        <el-table-column
          prop="useYmd"
          label="使用開始年月日"
          min-width="100px">
        </el-table-column>
        <el-table-column
          prop="koteioyaNo"
          label="親固定資産番号"
          min-width="120px">
        </el-table-column>
        <el-table-column
          prop="edaBan"
          label="枝番"
          min-width="60px">
        </el-table-column>
        <el-table-column
          prop="koshiKbn"
          label="子資産残"
          min-width="80px">
        </el-table-column>
      </el-table>
    </div>
    <el-row>
      <el-col>
        <nsd-button-bar v-bind:buttons="buttonName" v-bind:formItem="formItem"></nsd-button-bar>
      </el-col>
    </el-row>
  </div>
</template>

<script>
import NSDButtonBar from '@/components/common/NSDButtonBar.vue'

export default {
  components: {
    'nsd-button-bar': NSDButtonBar
  },
  created: function () {
    this.formItem = this.$store.state.tableData
    if (this.formItem.jokyakuYmd === null) {
      this.buttonName[0].disabled = false
      this.buttonName[1].disabled = false
    } else {
      if (this.formItem.shoninStatus === '20') {
        this.buttonName[0].disabled = false
        this.buttonName[1].disabled = false
      } else {
        this.buttonName[0].disabled = true
        this.buttonName[1].disabled = true
      }
    }
    this.getPageData()
  },
  methods: {
    handleSizeChange (index) {
      this.pageData.pageSizeAct = index
      this.initTableList(1)
    },
    handleCurrentChange (index) {
      this.initTableList(index)
    },
    initTableList (index) {
      this._initPageData(index)
      this.getPageData()
      let container = this.$el.querySelector('.el-table__body-wrapper')
      if (container !== null) {
        container.scrollTop = 0
      }
    },
    _initPageData (index) {
      this.pageData.pageNum = (index - 1) * this.pageData.pageSizeAct
      this.pageData.currentPage = index
    },
    getPageData () {
      this.$store.state.currentPageData = this.$store.state.tableData.koteiSisanLst.slice(this.pageData.pageSizeAct * (this.pageData.currentPage - 1), this.pageData.pageSizeAct * this.pageData.currentPage)
    }
  },
  data () {
    return {
      buttonName: [
        {name: this.$CONST_.buttonName.DELETE, primary: true, show: true, action: 'popup', url: '/seisanshoJokyaku-delByPyKey', backUrl: 'nsdsssjkkkensaku', msg: '削除しますか？'},
        {name: this.$CONST_.buttonName.UPDATE, primary: true, show: true, action: 'back', url: '', backUrl: 'NSDSssjkkKosin', msg: ''},
        {name: this.$CONST_.buttonName.BACK, primary: true, show: true, action: 'back', url: '', backUrl: 'nsdsssjkkkensaku', msg: ''}
      ],
      formItem: '',
      tableData: [],
      pageData: {
        total: 0,
        pageNum: 0,
        pageSizeArr: this.$CONST_.tableConst.PAGE_SIZES,
        pageSizeAct: this.$CONST_.tableConst.PAGE_SIZE,
        currentPage: 1,
        visible: false
      }
    }
  }
}
</script>

<style scoped>
.page-style {
  font-size: 12px;
  width: 783px;
  height: 100%;
  line-height:30px;
  border: 1px solid;
  padding-top: 1px;
  padding-right: 1px;
}
.row-class {
  height: 30px;
  margin-bottom: 1px;
  margin-left: 1px;
  margin-right: 1px;
}
.lab-class {
  line-height: 30px;
  width: 140px;
  background-color: #77cad8;
  margin-right: 1px;
}
</style>
