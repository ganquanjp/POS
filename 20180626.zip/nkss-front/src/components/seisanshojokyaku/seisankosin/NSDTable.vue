<template>
  <div>
    <div class="page-style">
        <el-row class="row-class">
          <el-col class="lab-class">　精算書番号</el-col>
          <el-col style= "width: 640px;">
            <el-input v-model="formItem.jokyakuSeisanShoNo" size="mini" :disabled="true"></el-input>
          </el-col>
        </el-row>
        <el-row class="row-class">
          <el-col class="lab-class">　精算箇所</el-col>
          <el-col style= "width: 640px;">
            <el-input v-model="formItem.soshikiRenNm" size="mini" :disabled="true""></el-input>
          </el-col>
        </el-row>
        <el-row class="row-class">
          <el-col class="lab-class">　除却年月日</el-col>
          <el-col style= "width: 140px;">
            <el-date-picker
              tabindex="3"
              v-model="formItem.jokyakuYmd"
              size="mini"
              style="width: 140px;"
              type="date"
              :editable="true"
              value-format="yyyy-MM-dd"
              @blur="inputJokyakuYmd"
              >
            </el-date-picker>
          </el-col>
        </el-row>
        <el-row class="row-class">
          <el-col class="lab-class">　摘要</el-col>
          <el-col style= "width: 640px;">
            <el-input v-model="formItem.tekiyo" size="mini" :disabled="true"></el-input>
          </el-col>
        </el-row>
        <el-row class="row-class">
          <el-col class="lab-class">　工事件名</el-col>
          <el-col style= "width: 640px;">
            <el-input v-model="formItem.kenmeiNm" size="mini" :disabled="true""></el-input>
          </el-col>
        </el-row>
    </div>
    <div style="height: 25px;">
      <div style="position: absolute; top: 165px; left: 10px;">
        <span style="font-size: 12px;">{{this.formItem.koteiSisanLst.length}}件</span>
      </div>
      <div style="position: absolute; top: 155px; right: 0px;">
        <el-pagination
          background
          @size-change="handleSizeChange"
          @current-change="handleCurrentChange"
          :current-page.sync="pageData.currentPage"
          :page-sizes="pageData.pageSizeArr"
          :page-size="pageData.pageSizeAct"
          layout="prev, pager, next"
          prev-text="前へ"
          next-text="次へ"
          :total="this.formItem.koteiSisanLst.length">
        </el-pagination>
      </div>
    </div>
    <div ref="divScroll" class="scroll-box">
      <div>
        <el-table
          :data="this.formItem.koteiSisanLst"
          border>
          <el-table-column 
            prop="rowNo"
            label="NO."
            min-width="48px">
          </el-table-column>
          <el-table-column
            label="固定資産番号"
            min-width="110px">
            <template slot-scope="scope">
              <el-button type="text" size="medium" @click="move(scope.row)">{{scope.row.koteiNo}}</el-button>
            </template>
          </el-table-column>
          <el-table-column
            prop="koteiKnj"
            label="固定資産名称"
            min-width="200px">
          </el-table-column>
          <el-table-column
            prop="getkgkYen"
            label="元_取得価額"
            header-align=left
            align=right
            :formatter="commaFormatter"
            min-width="150px">
          </el-table-column >
          <el-table-column
            prop="jokyakuGaku"
            label="除_取得価額"
            header-align=left
            align=right
            :formatter="commaFormatter"
            min-width="140px">
          </el-table-column>
          <el-table-column
            prop="jokyakuShubetsuNm"
            label="除却種別コード"
            min-width="100px">
          </el-table-column>
        </el-table>
        <div style="margin-top: 10px; border: 1px solid; padding-top: 1px; width: 404px; font-size: 12px;" v-if="display">
          <el-row class="row-class">
            <el-col class="lab-class">　固定資産番号</el-col>
            <el-col style= "width: 200px">
              <el-input v-model="koteiItem.koteiNo" size="mini" :disabled="true" />
            </el-col>
          </el-row>
          <el-row class="row-class">
            <el-col class="lab-class">　固定資産名称</el-col>
            <el-col style= "width: 200px">
              <el-input v-model="koteiItem.koteiKnj" size="mini" :disabled="true" />
            </el-col>
          </el-row>
          <el-row class="row-class">
            <el-col class="lab-class">　取得年月日</el-col>
            <el-col style= "width: 200px">
              <el-input v-model="koteiItem.getYmd" size="mini" :disabled="true" />
            </el-col>
          </el-row>
          <el-row class="row-class">
            <el-col class="lab-class">　元_数量</el-col>
            <el-col style= "width: 100px">
              <vue-numeric v-model="koteiItem.meiSu" size="mini" class="nsd-input-class" disabled="disabled" v-bind:precision="2" ></vue-numeric>
            </el-col>            
            <el-col style="width: 50px; line-height: 30px; background-color: #77cad8; margin-right: 1px; margin-left: 1px;">　単位</el-col>
            <el-col style= "width: 48px">
              <el-input v-model="koteiItem.taniKnj" size="mini" :disabled="true" />
            </el-col>
          </el-row>
          <el-row class="row-class">
            <el-col class="lab-class">　元_取得価額</el-col>
            <el-col style= "width: 200px">
              <vue-numeric currency="\" separator="," v-model="koteiItem.getkgkYen" size="mini" class="nsd-input-class" disabled="disabled"></vue-numeric>
            </el-col>
          </el-row>
          <el-row class="row-class">
            <el-col class="lab-class">　除却区分</el-col>
            <el-col style= "width: 200px;">
              <el-input v-model="koteiItem.jokyakuKbnNm" size="mini" :disabled="true" />
            </el-col>
          </el-row>
          <el-row class="row-class">
            <el-col class="lab-class">　除却種別コード</el-col>
            <el-col style= "width: 200px">
              <el-input v-model="koteiItem.jokyakuShubetsuNm" size="mini" :disabled="true" />
            </el-col>
          </el-row>
          <el-row class="row-class">
            <el-col class="lab-class">　除_数量</el-col>
            <el-col style= "width: 100px">
              <vue-numeric v-model="koteiItem.jokyakuSuryo" size="mini" class="nsd-input-class" v-bind:precision="2" disabled="disabled"></vue-numeric>
            </el-col>            
            <el-col style="width: 50px; line-height: 30px; background-color: #77cad8; margin-right: 1px; margin-left: 1px;">　単位</el-col>
            <el-col style= "width: 48px">
              <el-input v-model="koteiItem.taniKnj" size="mini" :disabled="true" />
            </el-col>
          </el-row>
          <el-row class="row-class">
            <el-col class="lab-class">　除_取得価額</el-col>
            <el-col style= "width: 200px">
              <vue-numeric currency="\" separator="," v-model="koteiItem.jokyakuGaku" size="mini" class="nsd-input-class" disabled="disabled"></vue-numeric>
            </el-col>
          </el-row>
        </div>
      </div>
    </div>
    <el-row>
      <el-col>
        <nsd-button-bar v-bind:buttons="buttonName" v-bind:formItem="formItem" @resetInit="resetInit"></nsd-button-bar>
      </el-col>
    </el-row>
  </div>
</template>

<script scoped>
import NSDButtonBar from '@/components/common/NSDButtonBar.vue'

export default {
  components: {
    'nsd-button-bar': NSDButtonBar
  },
  created: function () {
    this.resetInitData = JSON.parse(JSON.stringify(this.$store.state.tableData))
    this.formItem = JSON.parse(JSON.stringify(this.$store.state.tableData))
  },
  methods: {
    move: function (rowData) {
      this.koteiItem = rowData
      this.display = true
    },
    resetInit () {
      this.formItem = {}
      this.formItem = JSON.parse(JSON.stringify(this.resetInitData))
      this.display = false
    },
    handleSizeChange (index) {
      this.pageData.pageSizeAct = index
      this.initTableList(1)
    },
    handleCurrentChange (index) {
      this.initTableList(index)
    },
    initTableList (index) {
      this._initPageData(index)
      this.getPageData()
    },
    _initPageData (index) {
      this.pageData.pageNum = (index - 1) * this.pageData.pageSizeAct
      this.pageData.currentPage = index
    },
    getPageData () {
      this.$store.state.currentPageData = this.$store.state.tableData.koteiSisanLst.slice(this.pageData.pageSizeAct * (this.pageData.currentPage - 1), this.pageData.pageSizeAct * this.pageData.currentPage)
    },
    updCallBack (val) {
      this.funcClearData()
      this.$router.push({name: 'nsdsssjkkseisankensaku'})
    },
    inputJokyakuYmd (item) {
      if (item.userInput !== null && item.userInput !== '') {
        this.formItem.jokyakuYmd = item.userInput
        if (!this.IsDate(this.formItem.jokyakuYmd)) {
          item.userInput = this.resetInitData.jokyakuYmd
          this.formItem.jokyakuYmd = item.userInput
        }
      }

      // 選択
      if ((item.userInput === null)) {
      }
      // 手入力
      if (item.userInput === '') {
        item.userInput = this.resetInitData.jokyakuYmd
        this.formItem.jokyakuYmd = item.userInput
      }
    }
  },
  data () {
    return {
      display: false,
      buttonName: [
        {name: this.$CONST_.buttonName.UPDATE, primary: true, show: true, action: 'insert', url: '/seisanshoJokyakuSeisan-updateInfo', callBack: this.updCallBack, msg: '更新しますか？'},
        {name: this.$CONST_.buttonName.RESET, primary: true, show: true, action: 'resetInit', url: '', msg: 'リセットしますか？'},
        {name: this.$CONST_.buttonName.BACK, primary: true, show: true, action: 'back', url: '', backUrl: 'nsdsssjkkseisanshokai', msg: ''}
      ],
      formItem: {},
      koteiItem: '',
      resetInitData: {},
      pageData: {
        total: 0,
        pageNum: 0,
        pageSizeArr: this.$CONST_.tableConst.PAGE_SIZES,
        pageSizeAct: this.$CONST_.tableConst.PAGE_SIZE,
        currentPage: 1
      }
    }
  }
}
</script>

<style scoped>
.page-style {
  font-size: 12px;
  width: 843px;
  height: 100%;
  line-height:30px;
  border: 1px solid;
  padding-top: 1px;
  margin-left: 10px;
}
.scroll-box {
  max-height: 340px;
  overflow-y: auto;
  margin-left: 10px;
}
.row-class {
  height: 30px;
  margin-bottom: 1px;
  margin-left: 1px;
  margin-right: 1px;
}
.lab-class {
  line-height: 30px;
  width: 200px;
  background-color: #77cad8;
  margin-right: 1px;
}
</style>