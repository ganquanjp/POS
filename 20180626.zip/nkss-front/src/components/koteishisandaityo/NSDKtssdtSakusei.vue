<template>
  <div>
    <el-row>
      <el-col>
        <nsd-content-title v-bind:titlename="titlename" v-bind:message="this.$store.state.message"></nsd-content-title>
      </el-col>
    </el-row>
    <div class="body-style">
      <el-row style="height: 80px">
        <span>現在の最新版・固定資産台帳は、</span>
      </el-row>
      <el-row style="height: 80px; margin-left: 30px;">
        <span style="color: red;">{{this.$store.state.tableData[0]}}</span>
      </el-row>
      <el-row style="height: 80px;">
        <span>に作成されています。</span>
      </el-row>
    </div>
    <el-row>
      <el-col>
        <nsd-button-bar v-bind:buttons="buttonName"></nsd-button-bar>
      </el-col>
    </el-row>
  </div>
</template>

<script>
import NsdContentTitle from '@/components/common/NSDContentTitle.vue'
import NSDButtonBar from '@/components/common/NSDButtonBar.vue'

export default {
  components: {
    'nsd-content-title': NsdContentTitle,
    'nsd-button-bar': NSDButtonBar
  },
  created: function () {
    this.funcHttpPost('/koteshisanDaityo-selectSakuseiTimestamp', '')
  },
  data () {
    return {
      titlename: '【固定資産台帳出力】作成指示',
      buttonName: [
        {name: this.$CONST_.buttonName.REDO, primary: true, show: true, action: 'post', url: '/koteshisanDaityo-selectByWhere'}
      ]
    }
  }
}
</script>

<style scoped>
.body-style {
  font-size: 12px;
  margin-left: 40px;
  text-align: left;
}
</style>
