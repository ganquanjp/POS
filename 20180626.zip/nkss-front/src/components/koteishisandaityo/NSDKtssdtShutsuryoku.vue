<template>
  <div>
    <el-row>
      <el-col>
        <nsd-content-title v-bind:titlename="titlename" v-bind:message="this.$store.state.message"></nsd-content-title>
      </el-col>
    </el-row>
    <el-row v-if="this.$store.state.tableData.length > 0">
      <el-col>
        <div style= "padding-left: 10px; padding-right: 10px; width: 850px;">
          <div style="position: relative;">
           <span style="font-size: 12px;">{{this.$store.state.tableData.length}}件</span>
            <div style="position: absolute; top: -3px; right: 0px;">
              <el-pagination
                background
                @size-change="handleSizeChange"
                @current-change="handleCurrentChange"
                :page-sizes="this.pageData.pageSizeArr"
                :page-size="this.pageData.pageSizeAct"
                small
                layout="prev, pager, next"
                prev-text="前へ"
                next-text="次へ"
                :total="this.$store.state.tableData.length">
              </el-pagination>
            </div>
          </div>
          <el-table style= "padding: -50px;" :data="this.$store.state.currentPageData" border max-height=520>
            <el-table-column
              prop="rowNo"
              label="No."
              min-width="50px"
              header-align=center>
            </el-table-column>
            <el-table-column
              label="固定資産台帳ファイル"
              min-width="300px"
              header-align=center>
              <template slot-scope="scope">
                <!--<span v-html="download_link(scope.row.daichoNm)"></span>-->
                <el-button type="text" size="medium" @click="download(scope.row.daichoNm, scope.row.sakuseiDate)">{{scope.row.daichoNm}}</el-button>
              </template>
            </el-table-column>
            <el-table-column header-align=center label="出力日時">
              <el-table-column
                prop="sakuseiDate"
                label="日付"
                min-width="120px"
                header-align=center>
              </el-table-column>
              <el-table-column
                prop="sakuseiTime"
                label="時刻"
                min-width="120px"
                header-align=center
                class-name="isNotLastCell">
              </el-table-column>
            </el-table-column>
            <el-table-column
              prop="sakuseiKbnNm"
              label="区分"
              min-width="120px"
              header-align=center>
            </el-table-column>
            <el-table-column
              prop="sakuseiUserNm"
              label="作成者"
              min-width="100px"
              header-align=center>
            </el-table-column>
          </el-table>
        </div>
      </el-col>
    </el-row>
  </div>
</template>

<script>
import NsdContentTitle from '@/components/common/NSDContentTitle.vue'

export default {
  components: {
    'nsd-content-title': NsdContentTitle
  },
  created: function () {
    this.funcHttpPost('/koteshisanDaityo-getKoteishisanDaityoFileInfo')
    if (this.$store.state.tableData.length > 0) {
      this.getPageData()
    }
  },
  data () {
    return {
      titlename: '【固定資産台帳出力】出力',
      pageData: {
        total: 0,
        pageNum: 0,
        pageSizeArr: this.$CONST_.tableConst.PAGE_SIZES,
        pageSizeAct: this.$CONST_.tableConst.PAGE_SIZE,
        visible: false
      }
    }
  },
  computed: {
  },
  methods: {
    download: function (filename, sakuseiDate) {
      var _store = this.$store
      var url = this.$CONST_.urlPath.OUTPUT_EXCEL + sakuseiDate.replace(/[-]*/g, '') + '/' + filename
      this.funcInitMessage(_store)
      this.funcHttpGet(url, 'filedownload')
      /*
      this.$confirm('選択した固定資産台帳ファイルをダウンロード？', '確認', {
        confirmButtonText: 'OK',
        cancelButtonText: 'キャンセル',
        type: 'info',
        showClose: false
      }).then(() => {
        this.funcInitMessage(_store)
        this.funcHttpGet(url, 'filedownload')
      }).catch(() => {
      })
      */
    },
    download_link: function (filename) {
      return '<a href="' + this.$CONST_.urlPath.OUTPUT_EXCEL + filename + '">' + filename + '</a>'
    },
    handleSizeChange (index) {
      this.pageData.pageSizeAct = index
      this.initTableList(1)
    },
    handleCurrentChange (index) {
      this.initTableList(index)
    },
    initTableList (index) {
      this._initPageData(index)
      this.getPageData()
    },
    _initPageData (index) {
      this.pageData.pageNum = (index - 1) * this.pageData.pageSizeAct
      this.$store.state.currentPage = index
    },
    getPageData () {
      this.$store.state.currentPageData = this.$store.state.tableData.slice(this.pageData.pageSizeAct * (this.$store.state.currentPage - 1), this.pageData.pageSizeAct * this.$store.state.currentPage)
    }
  }
}
</script>

<style>
  .el-table--border .has-gutter td:nth-last-of-type(2), .el-table--border .has-gutter th:nth-last-of-type(2).isNotLastCell {
    border-right: 1px solid #ebeef5;
  }
</style>
