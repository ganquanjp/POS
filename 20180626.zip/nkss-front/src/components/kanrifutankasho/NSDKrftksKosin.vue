<template>
  <div>
    <el-row>
      <el-col>
        <nsd-content-title v-bind:titlename="titlename" v-bind:message="this.$store.state.message"></nsd-content-title>
      </el-col>
    </el-row>
    <el-row>
      <el-col>
        <div style="padding: 0px 10px 0px 10px;">
          <div style="position: relative;">
            <span style="font-size: 12px;">{{ this.formItem.kanriFutanLst.length }}件</span>
          </div>
          <el-table
            :data="this.formItem.kanriFutanLst"
            border
            :header-row-class-name="headerClassName"
            max-height="487">
            <el-table-column 
              prop="rowNo"
              label="NO."
              width="50px">
            </el-table-column>
            <el-table-column
              width="55px"
              header-align=center
              :render-header="renderHeader6">
              <template slot-scope="scope">
                <el-checkbox v-model="scope.row.upd" style="top: 20%; left: 35%;" size="mini" />
              </template>
            </el-table-column>
            <el-table-column
              width="55px"
              header-align=center
              :render-header="renderHeader7">
              <template slot-scope="scope">
                <el-checkbox v-model="scope.row.del" style="top: 20%; left: 35%;" size="mini" />
              </template>
            </el-table-column>
            <el-table-column :render-header="renderHeader1">
              <el-table-column
                min-width="220px"
                label="名称">
                <template slot-scope="scope">
                  <el-autocomplete v-model="scope.row.kanriSoshikiKnj"
                  :value="scope.row.kanriSoshikiCd"
                  :fetch-suggestions="querySearchAsyncKSoshikiKnj"
                  @select="handleSelectKSoshikiKnj(scope.row, $event)"
                  style="width: 100%;"
                  size="mini" 
                  >
                  </el-autocomplete>
                </template>
              </el-table-column>
              <el-table-column 
                prop="kanriTekiyoStartYmd"
                width="110px"
                :render-header="renderHeaderYmdFrom"
                :formatter="dateFormat">
              </el-table-column>
              <el-table-column 
                prop="kanriTekiyoEndYmd"
                width="110px"
                :render-header="renderHeaderYmdTo"
                :formatter="dateFormat">
              </el-table-column>
            </el-table-column>
            <el-table-column :render-header="renderHeader2">
              <el-table-column
                min-width="220px"
                label="名称">>
                <template slot-scope="scope">
                  <el-autocomplete v-model="scope.row.futanSoshikiKnj"
                  :value="scope.row.futanSoshikiCd"
                  :fetch-suggestions="querySearchAsyncFSoshikiKnj"
                  @select="handleSelectFSoshikiKnj(scope.row, $event)"
                  style="width: 100%;"
                  size="mini" 
                  >
                  </el-autocomplete>
                </template>
              </el-table-column>
              <el-table-column
                prop="futanTekiyoStartYmd"
                width="110px"
                :render-header="renderHeaderYmdFrom"
                :formatter="dateFormat">
              </el-table-column>
              <el-table-column
                prop="futanTekiyoEndYmd"
                width="110px"
                :render-header="renderHeaderYmdTo"
                :formatter="dateFormat">
              </el-table-column>
            </el-table-column>
          </el-table>
        </div>
      </el-col>
    </el-row>
    <el-row>
      <el-col>
        <nsd-button-bar v-bind:buttons="buttonName" v-bind:formItem="formItem" @resetInit="resetInit"></nsd-button-bar>
      </el-col>
    </el-row>
  </div>
</template>

<script>
import NsdContentTitle from '@/components/common/NSDContentTitle.vue'
import NSDButtonBar from '@/components/common/NSDButtonBar.vue'
import moment from 'moment'

export default {
  components: {
    'nsd-content-title': NsdContentTitle,
    'nsd-button-bar': NSDButtonBar
  },
  created () {
    this.$store.state.message.content = this.$CONST_.msgContent.UPDATE
    this.init()

    this.formItem.kanriSoshikiCd = this.formItem.kanriSoshikiCd
    this.formItem.kanriSoshikiKnj = this.formItem.kanriSoshikiKnj
    this.formItem.futanSoshikiCd = this.formItem.futanSoshikiCd
    this.formItem.futanSoshikiKnj = this.formItem.futanSoshikiKnj
  },
  mounted () {
    this.kanriSoshikiKnj = this.loadKSoshikiKnj()
    this.futanSoshikiKnj = this.loadFSoshikiKnj()
  },
  methods: {
    resetInit () {
      this.formItem = {}
      this.init()
    },
    init () {
      this.resetInitData = JSON.parse(JSON.stringify(this.$store.state.tableData))
      for (var i = 0; i < this.resetInitData.length; i++) {
        this.resetInitData[i].upd = false
        this.resetInitData[i].del = false
        this.resetInitData[i].kanriTekiyoStartYmd = moment(this.resetInitData[i].kanriTekiyoStartYmd).format('YYYY-MM-DD')
        this.resetInitData[i].kanriTekiyoEndYmd = moment(this.resetInitData[i].kanriTekiyoEndYmd).format('YYYY-MM-DD')
        this.resetInitData[i].futanTekiyoStartYmd = moment(this.resetInitData[i].futanTekiyoStartYmd).format('YYYY-MM-DD')
        this.resetInitData[i].futanTekiyoEndYmd = moment(this.resetInitData[i].futanTekiyoEndYmd).format('YYYY-MM-DD')
      }
      this.formItem.kanriFutanLst = JSON.parse(JSON.stringify(this.resetInitData))
      this.formItem.kanriFutanInitLst = JSON.parse(JSON.stringify(this.resetInitData))
      this.formItem.dataLen = this.formItem.kanriFutanLst.length
    },
    renderHeader1 (createElement, { column }) {
      return createElement(
        'label',
        [
          '管理箇所',
          createElement('span', {style: 'color: red;'}, '　(必須)')
        ]
      )
    },
    renderHeader2 (createElement, { column }) {
      return createElement(
        'label',
        [
          '負担箇所',
          createElement('span', {style: 'color: red;'}, '　(必須)')
        ]
      )
    },
    headerClassName ({row, rowIndex}) {
      return 'class-header'
    },
    renderHeader6 (createElement, { column }) {
      return createElement(
        'el-checkbox', {on: { change: this.updHandleHeader }, attrs: {value: this.updChkAll}}, [createElement('span', {style: 'font-size: 11px; color: black; font-weight: bold;'}, '更新')]
      )
    },
    renderHeader7 (createElement, { column }) {
      return createElement(
        'el-checkbox', {on: { change: this.delHandleHeader }, attrs: {value: this.delChkAll}}, [createElement('span', {style: 'font-size: 11px; color: black; font-weight: bold;'}, '削除')]
      )
    },
    renderHeaderYmdFrom (createElement, { column }) {
      return createElement(
        'label', '適用期間(FROM)'
      )
    },
    renderHeaderYmdTo (createElement, { column }) {
      return createElement(
        'label', '適用期間(TO)'
      )
    },
    renderHeaderCheckbox (createElement, { column }) {
      return createElement(
        'el-checkbox'
      )
    },
    dateFormat (row, column) {
      if (row[column.property] !== '') {
        return moment(row[column.property]).format('YYYY-MM-DD')
      }
    },
    handleSelectKSoshikiKnj (row, item) {
      row.kanriSoshikiKnj = item.value
      row.kanriSoshikiCd = item.ab9SoshikCod
      row.kanriTekiyoStartYmd = moment(item.ab9TekiyfYmd).format('YYYY-MM-DD')
      row.kanriTekiyoEndYmd = moment(item.ab9TekiytYmd).format('YYYY-MM-DD')
      if (this.resetInitData[row.rowNo - 1].kanriSoshikiCd.trim() === row.kanriSoshikiCd.trim() &&
        this.resetInitData[row.rowNo - 1].futanSoshikiCd.trim() === row.futanSoshikiCd.trim()) {
        row.upd = false
      } else {
        row.upd = true
      }
    },
    loadKSoshikiKnj () {
      var items = ['ab9SoshikKnj', 'ab9SoshikCod', 'ab9TekiyfYmd', 'ab9TekiytYmd']
      return this.funcGetDropDownValue('/autocomplete-selectSoshikTeisuMaster', items)
    },
    querySearchAsyncKSoshikiKnj (queryString, cb) {
      var kanriSoshikiKnj = this.kanriSoshikiKnj
      var results = queryString ? kanriSoshikiKnj.filter(this.createStateFilter(queryString)) : kanriSoshikiKnj
      clearTimeout(this.timeout)
      this.timeout = setTimeout(() => {
        cb(results)
      }, 200 * Math.random())
    },
    handleSelectFSoshikiKnj (row, item) {
      row.futanSoshikiKnj = item.value
      row.futanSoshikiCd = item.ab9SoshikCod
      row.futanTekiyoStartYmd = moment(item.ab9TekiyfYmd).format('YYYY-MM-DD')
      row.futanTekiyoEndYmd = moment(item.ab9TekiytYmd).format('YYYY-MM-DD')
      if (this.resetInitData[row.rowNo - 1].kanriSoshikiCd.trim() === row.kanriSoshikiCd.trim() &&
        this.resetInitData[row.rowNo - 1].futanSoshikiCd.trim() === row.futanSoshikiCd.trim()) {
        row.upd = false
      } else {
        row.upd = true
      }
    },
    loadFSoshikiKnj () {
      var items = ['ab9SoshikKnj', 'ab9SoshikCod', 'ab9TekiyfYmd', 'ab9TekiytYmd']
      return this.funcGetDropDownValue('/autocomplete-selectSoshikTeisuMaster', items)
    },
    querySearchAsyncFSoshikiKnj (queryString, cb) {
      var futanSoshikiKnj = this.futanSoshikiKnj
      var results = queryString ? futanSoshikiKnj.filter(this.createStateFilter(queryString)) : futanSoshikiKnj
      clearTimeout(this.timeout)
      this.timeout = setTimeout(() => {
        cb(results)
      }, 200 * Math.random())
    },
    createStateFilter (queryString) {
      return (state) => {
        return (state.value.toLowerCase().indexOf(queryString.toLowerCase()) >= 0)
      }
    },
    updHandleHeader (checked) {
      this.updChkAll = checked
      var itemLst = JSON.parse(JSON.stringify(this.formItem.kanriFutanLst))
      var itemInitLst = JSON.parse(JSON.stringify(this.formItem.kanriFutanInitLst))
      var dataLen = this.formItem.kanriFutanLst.length
      var kanriSoshikiCd = this.formItem.kanriSoshikiCd
      var kanriSoshikiKnj = this.formItem.kanriSoshikiKnj
      var futanSoshikiCd = this.formItem.futanSoshikiCd
      var futanSoshikiKnj = this.formItem.futanSoshikiKnj
      this.formItem = {}
      for (var i = 0; i < itemLst.length; i++) {
        if (checked) {
          itemLst[i].upd = true
        } else {
          itemLst[i].upd = false
        }
      }
      this.formItem.kanriFutanLst = itemLst
      this.formItem.kanriFutanInitLst = itemInitLst
      this.formItem.dataLen = dataLen
      this.formItem.kanriSoshikiCd = kanriSoshikiCd
      this.formItem.kanriSoshikiKnj = kanriSoshikiKnj
      this.formItem.futanSoshikiCd = futanSoshikiCd
      this.formItem.futanSoshikiKnj = futanSoshikiKnj
    },
    delHandleHeader (checked) {
      this.delChkAll = checked
      var itemLst = JSON.parse(JSON.stringify(this.formItem.kanriFutanLst))
      var itemInitLst = JSON.parse(JSON.stringify(this.formItem.kanriFutanInitLst))
      var dataLen = this.formItem.kanriFutanLst.length
      var kanriSoshikiCd = this.formItem.kanriSoshikiCd
      var kanriSoshikiKnj = this.formItem.kanriSoshikiKnj
      var futanSoshikiCd = this.formItem.futanSoshikiCd
      var futanSoshikiKnj = this.formItem.futanSoshikiKnj
      this.formItem = {}
      for (var i = 0; i < itemLst.length; i++) {
        if (checked) {
          itemLst[i].del = true
        } else {
          itemLst[i].del = false
        }
      }
      this.formItem.kanriFutanLst = itemLst
      this.formItem.kanriFutanInitLst = itemInitLst
      this.formItem.dataLen = dataLen
      this.formItem.kanriSoshikiCd = kanriSoshikiCd
      this.formItem.kanriSoshikiKnj = kanriSoshikiKnj
      this.formItem.futanSoshikiCd = futanSoshikiCd
      this.formItem.futanSoshikiKnj = futanSoshikiKnj
    },
    updCallBack (val) {
      this.funcClearData()
      this.$router.push({name: 'nsdkrftkskensaku'})
    }
  },
  data () {
    return {
      titlename: '【管理箇所／負担箇所紐付】更新',
      buttonName: [
        {name: this.$CONST_.buttonName.UPDATE, primary: true, show: true, action: 'insert', url: '/kanriFutanhimodzuki-updateInfo', callBack: this.updCallBack, msg: '更新しますか？'},
        {name: this.$CONST_.buttonName.RESET, primary: true, show: true, action: 'resetInit', url: '', msg: 'リセットしますか？'},
        {name: this.$CONST_.buttonName.BACK, primary: true, show: true, action: 'back', backUrl: 'nsdkrftkskensaku'}
      ],
      resetInitData: [],
      showModal: false,
      formItem: {
        kanriSoshikiCd: '',
        kanriSoshikiKnj: '',
        futanSoshikiCd: '',
        futanSoshikiKnj: '',
        updateDate: ''
      },
      pageData: {
        total: 0,
        pageNum: 0,
        pageSizeArr: this.$CONST_.tableConst.PAGE_SIZES,
        pageSizeAct: this.$CONST_.tableConst.PAGE_SIZE,
        visible: false
      }
    }
  }
}
</script>

<style scoped>
.page-style {
  font-size: 12px;
  width: 745px;
  height: 100%;
  line-height:30px;
  border: 1px solid;
  padding-top: 1px;
  padding-right: 1px;
}
.row-class {
  height: 30px;
  margin-bottom: 1px;
  margin-left: 1px;
  margin-right: 1px;
}
.lab-class {
  line-height: 30px;
  width: 140px;
  background-color: #77cad8;
  margin-right: 1px;
}
.span-class {
 color: red;
 float: right;
}
</style>
