<template>
  <div>
    <el-row>
      <el-col>
        <nsd-content-title v-bind:titlename="titlename" v-bind:message="this.$store.state.message"></nsd-content-title>
      </el-col>
    </el-row>
    <div class="scroll-box">
    <div class="page-style">
      <el-row class="row-class">
        <el-col class="lab-class">　会計整理年月<span class="span-class">（必須）</span></el-col>
        <el-col style= "width: 130px;">
          <el-select v-model="formItem.kaikeiSeiriYm" size="mini" >
            <el-option
              v-for="item in this.kaikeiSeiriYmList"
              :key="item.sa1KaikeiYm"
              :label="item.sa1KaikeiYm"
              :value="item.sa1KaikeiYm">
           </el-option>
         </el-select>
        </el-col>
      </el-row>
      <el-row class="row-class">
        <el-col class="lab-class">　パワー経理の発行組織<span class="span-class">（必須）</span></el-col>
        <el-col style= "width: 200px;">
          <el-autocomplete
            style= "width: 200px;"
            v-model="formItem.hakouSoshikiNm" 
            :fetch-suggestions="querySearchAsynchakouSoshikiNm"
            @select="handleSelecthakouSoshikiNm"
            id="search_text" 
            size="mini" 
            >
          </el-autocomplete>
        </el-col>
      </el-row>
    </div>
      <el-row>
        <el-col>
          <div style= "padding-left: 10px; padding-top: 10px;">
            <div style="position: relative;">
              <span style="font-size: 12px;">{{this.formItem.seisanShoList.length}}件</span>
            </div>
            <el-table
              :data="this.formItem.seisanShoList"
              max-height=425
              border>
              <el-table-column prop="rowNo" label="No." min-width="40px"></el-table-column>
              <el-table-column header-align=center :render-header="renderHeaderChkBox" min-width="55px" align=center>
                <template slot-scope="scope">
                  <el-checkbox v-model="scope.row.upd" size="mini" />
                </template>
              </el-table-column>
              <el-table-column prop="seisanShoNo" label="精算書番号" min-width="120px">
                <template slot-scope="scope">
                  <el-button type="text" size="medium" @click="showKoteiShisanInfoLst(scope.row.bsKtInfoLst)">{{scope.row.seisanShoNo}}</el-button>
                </template>
              </el-table-column>
              <el-table-column prop="soshikiRenNm" label="精算箇所" min-width="250px"></el-table-column>
              <el-table-column prop="hansu" label="処理No" min-width="50px" align=right header-align=left></el-table-column>
              <el-table-column prop="serviceKaisiYmd" :render-header="renderServiceYmd" width="140px">
                <template slot-scope="scope">
                  <el-date-picker 
                    v-model="scope.row.serviceStartYmd"
                    @blur="inputServiceStartYmd"
                    type="date" 
                    style="width: 100%;" 
                    size="mini"
                    value-format="yyyy-MM-dd">
                  </el-date-picker>
                </template>
              </el-table-column>
              <el-table-column prop="keiyakuBeginDate" :render-header="renderKeiyakuBeginDate" min-width="140px">
                <template slot-scope="scope">
                  <el-date-picker 
                    v-model="scope.row.keiyakuStartYmd" 
                    @blur="inputKeiyakuBeginDate"
                    type="date" 
                    style="width: 100%;" 
                    size="mini"
                    value-format="yyyy-MM-dd">
                  </el-date-picker>
                </template>
              </el-table-column>
              <el-table-column prop="keiyakuEndDate" :render-header="renderKeiyakuEndDate" min-width="140px">
                <template slot-scope="scope">
                  <el-date-picker 
                    v-model="scope.row.keiyakuEndYmd" 
                    @blur="inputKeiyakuEndDate"
                    type="date" 
                    style="width: 100%;" 
                    size="mini"
                    value-format="yyyy-MM-dd">
                  </el-date-picker>
                </template>
              </el-table-column>
              <el-table-column :render-header="renderShoninStatus" min-width="150px">
                <template slot-scope="scope">
                  <el-select v-model="scope.row.shoninStatus" size="mini" style="width: 100%;">
                    <el-option v-for="item in shoninStatusList" :key="item.cd1" :label="item.cdKnj" :value="item.cd1">
                    </el-option>
                  </el-select>
                </template>
              </el-table-column >
              <el-table-column label="経理否認理由" min-width="150px">
                <template slot-scope="scope">
                  <el-input v-model="scope.row.riyu" size="mini" style="width: 100%;"></el-input>
                </template>
              </el-table-column>
              <el-table-column prop="kenmeiCd" label="工事件名コード" min-width="100px"></el-table-column>
              <el-table-column prop="kmouwkKnj" label="工事件名" min-width="150px"></el-table-column>
            </el-table>
          </div>
        </el-col>
      </el-row>
      <div v-if="this.showKoteiInfoLstFlg">
        <el-row>
          <el-col>
            <div style= "padding-left: 10px; padding-top: 30px;">
              <div style="position: relative;">
                <span style="font-size: 12px;">{{this.koteiShisanInfoLst.length}}件</span>
                <div style="position: absolute; top: -3px; right: 0px;">
                  <el-pagination
                    background
                    @size-change="handleSizeChangeKotei"
                    @current-change="handleCurrentChangeKotei"
                    :current-page.sync="pageData.currentPageKotei" 
                    :page-sizes="pageData.pageSizeArrKotei"
                    :page-size="pageData.pageSizeActKotei"
                    small
                    layout="prev, pager, next"
                    prev-text="前へ"
                    next-text="次へ"
                    :total="this.koteiShisanInfoLst.length">
                  </el-pagination>
                </div>
              </div>
              <el-table
                :data="this.bsKtInfoLstCurrent"
                max-height=156
                border>
                <el-table-column prop="rowNo" label="No." min-width="48px"></el-table-column>
                <el-table-column prop="koteiShisanNo" label="固定資産番号" min-width="140px">
                  <template slot-scope="scope">
                    <el-button type="text" size="medium" @click="showKoteiShisanInfo(scope.row)">{{scope.row.koteiShisanNo}}</el-button>
                  </template>
                </el-table-column>
                <el-table-column prop="koteiShisanNm" label="固定資産名称" min-width="200px"></el-table-column>
                <el-table-column prop="torihkKnj" label="取引先名称" min-width="200px"></el-table-column>
                <el-table-column prop="shutokuYmd" label="取得年月日" min-width="140px"></el-table-column>
                <el-table-column prop="shutokuKagaku" label="取得価額" min-width="110px"></el-table-column>
              </el-table>
            </div>
          </el-col>
        </el-row>
      </div>
      <div class="kotei-detail-style" v-if="this.showKoteiInfoFlg">
        <el-col :span="8">
          <el-row class="row-class">
            <el-col class="lab-class">　種類</el-col>
            <el-col style= "width: 200px">
              <el-input v-model="koteiShisanInfo.shuKnj" size="mini" :disabled="true" />
            </el-col>
          </el-row>
          <el-row class="row-class">
            <el-col class="lab-class">　構造</el-col>
            <el-col style= "width: 200px">
              <el-input v-model="koteiShisanInfo.kouKnj" size="mini" :disabled="true" />
            </el-col>
          </el-row>
          <el-row class="row-class">
            <el-col class="lab-class">　資産単位</el-col>
            <el-col style= "width: 200px">
              <el-input v-model="koteiShisanInfo.saiKnj" size="mini" :disabled="true" />
            </el-col>
          </el-row>
          <el-row class="row-class">
            <el-col class="lab-class">　科目１</el-col>
            <el-col style= "width: 200px">
              <el-input v-model="koteiShisanInfo.shu4Knj" size="mini" :disabled="true" />
            </el-col>
          </el-row>
          <el-row class="row-class">
            <el-col class="lab-class">　科目２</el-col>
            <el-col style= "width: 200px">
              <el-input v-model="koteiShisanInfo.shu5Knj" size="mini" :disabled="true" />
            </el-col>
          </el-row>
          <el-row class="row-class">
            <el-col class="lab-class">　科目３</el-col>
            <el-col style= "width: 200px">
              <el-input v-model="koteiShisanInfo.shu6Knj" size="mini" :disabled="true" />
            </el-col>
          </el-row>
        </el-col>
        <el-col :span="8">
          <el-row class="row-class">
            <el-col class="lab-class">　備忘価額_税</el-col>
            <el-col style= "width: 200px">
              <el-input v-model="koteiShisanInfo.biboKagakuZei" size="mini" :disabled="true" />
            </el-col>
          </el-row>
          <el-row class="row-class">
            <el-col class="lab-class">　償却可能限度額_税</el-col>
            <el-col style= "width: 200px">
              <el-input v-model="koteiShisanInfo.shokyakuGendoZei" size="mini" :disabled="true" />
            </el-col>
          </el-row>
          <el-row class="row-class">
            <el-col class="lab-class">　償却方法_税</el-col>
            <el-col style= "width: 200px">
              <el-input v-model="koteiShisanInfo.syokyakuHohoZei" size="mini" :disabled="true" />
            </el-col>
          </el-row>
          <el-row class="row-class">
            <el-col class="lab-class">　残存率_税</el-col>
            <el-col style= "width: 200px">
              <el-input v-model="koteiShisanInfo.zanzonRitsuZei" size="mini" :disabled="true" />
            </el-col>
          </el-row>
          <el-row class="row-class">
            <el-col class="lab-class">　耐用月数_税</el-col>
            <el-col style= "width: 200px">
              <el-input v-model="koteiShisanInfo.taiyoNensuZei" size="mini" :disabled="true" />
            </el-col>
          </el-row>
        </el-col>
        <el-col :span="8">
          <el-row class="row-class">
            <el-col class="lab-class">　備忘価額_商</el-col>
            <el-col style= "width: 200px">
              <el-input v-model="koteiShisanInfo.biboKagakuSho" size="mini" :disabled="true" />
            </el-col>
          </el-row>
          <el-row class="row-class">
            <el-col class="lab-class">　償却可能限度額_商</el-col>
            <el-col style= "width: 200px">
              <el-input v-model="koteiShisanInfo.shokyakuGendoSho" size="mini" :disabled="true" />
            </el-col>
          </el-row>
          <el-row class="row-class">
            <el-col class="lab-class">　償却方法_商</el-col>
            <el-col style= "width: 200px">
              <el-input v-model="koteiShisanInfo.syokyakuHohoSho" size="mini" :disabled="true" />
            </el-col>
          </el-row>
          <el-row class="row-class">
            <el-col class="lab-class">　残存率_商</el-col>
            <el-col style= "width: 200px">
              <el-input v-model="koteiShisanInfo.zanzonRitsuSho" size="mini" :disabled="true" />
            </el-col>
          </el-row>
          <el-row class="row-class">
            <el-col class="lab-class">　耐用月数_商</el-col>
            <el-col style= "width: 200px">
              <el-input v-model="koteiShisanInfo.taiyoNensuSho" size="mini" :disabled="true" />
            </el-col>
          </el-row>
        </el-col>
      </div>
    </div>
    <el-row>
      <el-col>
        <nsd-button-bar v-bind:buttons="buttonName" v-bind:formItem="formItem" @resetInit="resetInit"></nsd-button-bar>
      </el-col>
    </el-row>
  </div>
</template>

<script>
import NsdContentTitle from '@/components/common/NSDContentTitle.vue'
import NSDButtonBar from '@/components/common/NSDButtonBar.vue'

export default {
  components: {
    'nsd-content-title': NsdContentTitle,
    'nsd-button-bar': NSDButtonBar
  },
  created () {
    this.$store.state.message.content = this.$CONST_.msgContent.RENKEI
    this.formItem.seisanShoList = JSON.parse(JSON.stringify(this.$store.state.tableData))
    this.loadShoninStatus()
    this.initShow()
    this.resetInitData = JSON.parse(JSON.stringify(this.formItem))
  },
  mounted () {
    this.hakouSoshikiNm = this.loadHakouSoshikiNM()
  },
  data () {
    return {
      titlename: '【分割収入経理審査／連係】更新',
      buttonName: [
        {name: this.$CONST_.buttonName.UPDATE, primary: true, show: true, action: 'insert', url: '/bunkatsuSyunyu-update', callBack: this.updCallBack, msg: '更新しますか？'},
        {name: this.$CONST_.buttonName.RESET, primary: true, show: true, action: 'resetInit', url: '', msg: 'リセットしますか？'},
        {name: this.$CONST_.buttonName.BACK, primary: true, show: true, action: 'back', backUrl: 'nsdbktsnkensaku'}
      ],
      shoninStatusList: [],
      koteiShisanInfoLst: [],
      bsKtInfoLstCurrent: [],
      koteiShisanInfo: '',
      formItem: {
        hakouSoshikiNm: '',
        kaikeiSeiriYm: ''
      },
      kensu: 0,
      resetInitData: {},
      showKoteiInfoLstFlg: false,
      showKoteiInfoFlg: false,
      multipleSelection: [],
      kaikeiSeiriYmList: [],
      updChkAll: false,
      pageData: {
        totalKotei: 0,
        pageNumKotei: 0,
        pageSizeArrKotei: this.$CONST_.tableConst.PAGE_SIZES,
        pageSizeActKotei: this.$CONST_.tableConst.PAGE_SIZE,
        currentPageKotei: 1
      }
    }
  },
  methods: {
    initShow () {
      this.funcHttpPostComm('/comm-getHakouSoshiki', {soshikCod: '1000'}, this.initHakouSoshikiCallBack)
      this.funcHttpPostComm('/autocomplete-selectKaikeiYmMaster', '', this.initKaikeiYmCallBack)
      this.funcHttpPostComm('/bunkatsuSyunyu-initUpdInfo', {seisanShoIdLst: this.formItem.seisanShoList}, this.initUpdInfoCallBack)
      this.setCheck()
    },
    initUpdInfoCallBack (val) {
      for (var i = 0; i < val.length; i++) {
        if (this.formItem.seisanShoList[i].seisanShoId.trim() === val[i].seisanshoid) {
          this.formItem.seisanShoList[i].serviceStartYmd = val[i].servicestartymd
          this.formItem.seisanShoList[i].keiyakuStartYmd = val[i].keiyakustartymd
          this.formItem.seisanShoList[i].keiyakuEndYmd = val[i].keiyakuendymd
        }
      }
    },
    initHakouSoshikiCallBack (val) {
      if (val.length > 0) {
        this.formItem.hakouSoshikiNm = val[0].ab9SoshikKnj
        this.formItem.hakouSoshikiCd = val[0].ab9SoshikCod
        this.formItem.TekiyfYmd = val[0].ab9TekiyfYmd
        this.formItem.TekiytYmd = val[0].ab9TekiytYmd
      }
    },
    initKaikeiYmCallBack (val) {
      this.kaikeiSeiriYmList = val
      if (val.length > 0) {
        this.formItem.kaikeiSeiriYm = val[val.length - 1].sa1KaikeiYm
      }
    },
    loadHakouSoshikiNM () {
      var items = ['ab9SoshikKnj', 'ab9SoshikCod', 'ab9TekiyfYmd', 'ab9TekiytYmd']
      return this.funcGetDropDownValue('/autocomplete-selectSoshikTeisuMaster', items)
    },
    handleSelecthakouSoshikiNm (item) {
      this.formItem.hakouSoshikiNm = item.value
      this.formItem.hakouSoshikiCd = item.ab9SoshikCod
      this.formItem.TekiyfYmd = item.ab9TekiyfYmd
      this.formItem.TekiytYmd = item.ab9TekiytYmd
    },
    querySearchAsynchakouSoshikiNm (queryString, cb) {
      var hakouSoshikiNm = this.hakouSoshikiNm
      var results = queryString ? hakouSoshikiNm.filter(this.createStateFilter(queryString)) : hakouSoshikiNm
      clearTimeout(this.timeout)
      this.timeout = setTimeout(() => {
        cb(results)
      }, 200 * Math.random())
    },
    createStateFilter (queryString) {
      return (state) => {
        return (state.value.toLowerCase().indexOf(queryString.toLowerCase()) >= 0)
      }
    },
    showKoteiShisanInfoLst: function (rowData) {
      console.log(rowData)
      this.koteiShisanInfoLst = rowData
      this.getPageDataKotei(this.koteiShisanInfoLst)
      this.showKoteiInfoLstFlg = true
      this.showKoteiInfoFlg = false
    },
    showKoteiShisanInfo: function (rowData) {
      this.koteiShisanInfo = rowData
      this.showKoteiInfoFlg = true
    },
    renderServiceYmd (createElement, { column }) {
      return createElement(
        'label',
        [
          'サービス開始年月日',
          createElement(
            'span', {style: 'color: red;'}, '(必須)')
        ]
      )
    },
    renderKeiyakuBeginDate (createElement, { column }) {
      return createElement(
        'label',
        [
          '契約期間(自)',
          createElement(
            'span', {style: 'color: red;'}, '(必須)')
        ]
      )
    },
    renderKeiyakuEndDate (createElement, { column }) {
      return createElement(
        'label',
        [
          '契約期間(至)',
          createElement(
            'span', {style: 'color: red;'}, '(必須)')
        ]
      )
    },
    renderShoninStatus (createElement, { column }) {
      return createElement(
        'label',
        [
          '承認状態',
          createElement(
            'span', {style: 'color: red;'}, '(必須)')
        ]
      )
    },
    renderHeaderChkBox (createElement, { column }) {
      return createElement(
        'el-checkbox', {on: { change: this.updHandleHeader }, attrs: {value: this.updChkAll}}, [createElement('span', {style: 'font-size: 11px; color: black; font-weight: bold;'}, '更新')]
      )
    },
    loadShoninStatus () {
      var searchWhere = {
        cdShubetsu: this.$CONST_.cdShubetsu.SHONIN_STATUS,
        cd1Arr: [
          this.$CONST_.shoninStatus.SHONIN,
          this.$CONST_.shoninStatus.RENKEI,
          this.$CONST_.shoninStatus.HININ
        ]
      }
      this.funcHttpPostComm('/comm-getCodeShubetsuList', searchWhere, this.loadShoninStatusCallBack)
    },
    loadShoninStatusCallBack (val) {
      this.shoninStatusList = val
    },
    handleSizeChangeKotei (index) {
      this.pageData.pageSizeActKotei = index
      this.initTableList(1)
    },
    handleCurrentChangeKotei (index) {
      this.initTableList(index)
    },
    initTableListKotei (index) {
      this._initPageData(index)
      this.getPageData()
    },
    _initPageDataKotei (index) {
      this.pageData.pageNumKotei = (index - 1) * this.pageData.pageSizeActKotei
      this.pageData.currentPageKotei = index
    },
    getPageDataKotei (itemLst) {
      this.bsKtInfoLstCurrent = itemLst.slice(this.pageData.pageSizeActKotei * (this.pageData.currentPageKotei - 1), this.pageData.pageSizeActKotei * this.pageData.currentPageKotei)
    },
    updHandleHeader (checked) {
      this.updChkAll = checked
      var itemData = JSON.parse(JSON.stringify(this.formItem))
      this.formItem = {}
      for (var i = 0; i < itemData.seisanShoList.length; i++) {
        if (checked) {
          itemData.seisanShoList[i].upd = true
        } else {
          itemData.seisanShoList[i].upd = false
        }
      }
      this.formItem = itemData
    },
    resetInit () {
      this.formItem = JSON.parse(JSON.stringify(this.resetInitData))
      this.initShow()
      this.updChkAll = false
      this.showKoteiInfoLstFlg = false
      this.showKoteiInfoFlg = false
      this.setCheck()
    },
    setCheck () {
      var inititemLst = JSON.parse(JSON.stringify(this.formItem.seisanShoList))
      this.kensu = inititemLst.length
      this.formItem.seisanShoList = []
      for (var i = 0; i < inititemLst.length; i++) {
        inititemLst[i].upd = false
        this.formItem.seisanShoList.push(inititemLst[i])
      }
    },
    updCallBack (val) {
      this.funcClearData()
      this.$router.push({name: 'nsdbktsnkensaku'})
    },
    inputServiceStartYmd (item) {
      if (item.userInput !== null && item.userInput !== '') {
        this.formItem.serviceStartYmd = item.userInput
        if (!this.IsDate(this.formItem.serviceStartYmd)) {
          item.userInput = ''
          this.formItem.serviceStartYmd = item.userInput
        }
      }
    },
    inputKeiyakuBeginDate (item) {
      if (item.userInput !== null && item.userInput !== '') {
        this.formItem.keiyakuBeginDate = item.userInput
        if (!this.IsDate(this.formItem.keiyakuBeginDate)) {
          item.userInput = ''
          this.formItem.keiyakuBeginDate = item.userInput
        }
      }
    },
    inputKeiyakuEndDate (item) {
      if (item.userInput !== null && item.userInput !== '') {
        this.formItem.keiyakuEndDate = item.userInput
        if (!this.IsDate(this.formItem.keiyakuEndDate)) {
          item.userInput = ''
          this.formItem.keiyakuEndDate = item.userInput
        }
      }
    }
  }
}
</script>

<style scoped>
.kotei-detail-style {
  font-size: 12px;
  height: 100%;
  margin-left:10px;
  border: 0px solid;
  padding-top: 30px;
  padding-right: 1px;
}
.page-style {
  font-size: 12px;
  width: 373px;
  height: 100%;
  line-height:30px;
  border: 1px solid;
  padding-top: 1px;
  margin-left: 10px;
}
.row-class {
  height: 30px;
  margin-bottom: 1px;
  margin-left: 1px;
  margin-right: 1px;
}
.lab-class {
  width: 170px;
  background-color: #77cad8;
  line-height: 30px;
  margin-right: 1px;
}
.span-class {
 color: red;
 float: right;
}
.scroll-box {
  max-height: 508px;
  overflow-y: auto;
}
</style>
