<template>
  <el-container>
    <el-aside id="elaside" width=200px><nsd-nav></nsd-nav></el-aside>
    <el-main><nsd-content></nsd-content></el-main>
  </el-container>
</template>

<script>
import NSDNav from '@/components/NSDNav.vue'
import NSDContent from '@/components/NSDContent.vue'

export default {
  components: {
    'nsd-nav': NSDNav,
    'nsd-content': NSDContent
  },
  mounted () {
    var height = window.innerHeight - 16
    height = height + 'px'
    document.getElementById('elaside').style.height = height
  }
}

pushHistory()

window.addEventListener('popstate', function (e) {
  if (confirm('ブラウザの戻るボタンを押下したら、セッションを切断します。')) {
    alert('セッションを切断しました。')
  } else {
    pushHistory()
  }
}, false)

function pushHistory () {
  var state = {
    title: 'title',
    url: '#'
  }
  window.history.pushState(state, 'title', '#')
}
</script>

<style>
.el-aside {
  border-right: 1px groove;
}
</style>