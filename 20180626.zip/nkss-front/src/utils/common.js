﻿export default{
  install (Vue, options) {
    Vue.prototype.commaFormatter = function (row, column, cellValue) {
      var delimiter = '.'
      var en = '\\'
      if (cellValue === '') {
        return cellValue
      }
      var numString = cellValue.toString()
      var targetNum
      function isDecimal () { // 整数か小数かをわけわけ。
        if (numString.indexOf(delimiter) > -1) {
          return true
        } else {
          return false
        }
      }
      if (isDecimal()) { // 小数だったら、前と後ろを分けておく。
        targetNum = numString.split(delimiter)
      } else { // 整数だったらそのまま。
        targetNum = numString
      }
      if (targetNum instanceof Array) { // わけわけされてたら、前を置換して、小数点付けて後ろをまるっと付け足し。
        return en + (targetNum[0].replace(/(\d)(?=(\d{3})+$)/g, '$1,') + delimiter + targetNum[1])
      } else { // わけわけされてなかったら、そのまま置換。
        return en + targetNum.replace(/(\d)(?=(\d{3})+$)/g, '$1,')
      }
    }

    // ヘッダーにてソートボタンを押すとソート変更する
    Vue.prototype.funcSortChange = function (column, prop, order, _store) {
       // 状態保存
      _store.state.sortItem.column = column
      _store.state.sortItem.prop = prop
      _store.state.sortItem.order = order
      _store.state.tableData.sort(function (a, b) {
        var avar = a[prop]
        var bvar = b[prop]
        if (avar === null) {
          avar = ''
        }
        if (bvar === null) {
          bvar = ''
        }
        // 数値にする
        if (avar !== undefined && bvar !== undefined && typeof (avar) !== 'number' && typeof (bvar) !== 'number' && (avar.replace(/^\s+|\s+$/g, '')).length !== (bvar.replace(/^\s+|\s+$/g, '')).length) {
          if (avar.replace(/^\s+|\s+$/g, '') === '') {
            avar = 0
          } else {
            avar = parseFloat(avar)
          }
          if (bvar.replace(/^\s+|\s+$/g, '') === '') {
            bvar = 0
          } else {
            bvar = parseFloat(bvar)
          }
        }
        if (order === 'ascending') {
          if (avar > bvar) return 1
          if (avar < bvar) return -1
          return 0
        }
        if (order === 'descending') {
          if (avar > bvar) return -1
          if (avar < bvar) return 1
          return 0
        }
        if (order === null) {
          if (a.rowNo > b.rowNo) return 1
          if (a.rowNo < b.rowNo) return -1
          return 0
        }
      })
    }

    // ヘッダーにてソートボタンを押すとソート変更する
    Vue.prototype.popfuncSortChange = function (column, prop, order, _data) {
      _data.sort(function (a, b) {
        var avar = a[prop]
        var bvar = b[prop]
        if (avar === null) {
          avar = ''
        }
        if (bvar === null) {
          bvar = ''
        }
        // 数値にする
        if (avar !== undefined && bvar !== undefined && typeof (avar) !== 'number' && typeof (bvar) !== 'number' && (avar.replace(/^\s+|\s+$/g, '')).length !== (bvar.replace(/^\s+|\s+$/g, '')).length) {
          if (avar.replace(/^\s+|\s+$/g, '') === '') {
            avar = 0
          } else {
            avar = parseFloat(avar)
          }
          if (bvar.replace(/^\s+|\s+$/g, '') === '') {
            bvar = 0
          } else {
            bvar = parseFloat(bvar)
          }
        }
        if (order === 'ascending') {
          if (avar > bvar) return 1
          if (avar < bvar) return -1
          return 0
        }
        if (order === 'descending') {
          if (avar > bvar) return -1
          if (avar < bvar) return 1
          return 0
        }
        if (order === null) {
          if (a.rowNo > b.rowNo) return 1
          if (a.rowNo < b.rowNo) return -1
          return 0
        }
      })
    }

    Vue.prototype.IsDate = function (datestring) {
      var reg = /^(\d{4})-(\d{2})-(\d{2})$/
      var str = datestring
      if (str === '') return true
      if (!reg.test(str) && RegExp.$2 <= 12 && RegExp.$3 <= 31) {
        return false
      }
      return true
    }
  }
}
