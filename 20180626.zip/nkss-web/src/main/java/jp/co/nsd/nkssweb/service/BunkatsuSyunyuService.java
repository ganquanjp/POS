package jp.co.nsd.nkssweb.service;

import java.util.List;
import java.util.Map;

import jp.co.nsd.nkssweb.dao.BunkatsuSyunyu;
import jp.co.nsd.nkssweb.dao.Kss004;
import jp.co.nsd.nkssweb.dao.Kss008;

public interface BunkatsuSyunyuService {

	/**
	 * 分割情報取得
	 *
	 * @param selectCondition
	 * @return
	 */
	List<BunkatsuSyunyu> getBunkatsuInfo(BunkatsuSyunyu selectCondition);

	/**
	 * 分割情報更新画面初期化
	 *
	 * @param seisanShoId
	 * @return
	 */
	List<Map<String, Object>> initUpdInfo(List<String> seisanShoIdLst);


	/**
	 * 分割情報更新処理
	 *
	 * @param insertKss008Lst
	 * @param updateKss008Lst
	 * @param Kss008Lst
	 * @param kss004Lst
	 * @return
	 * @throws Exception
	 */
	int update(List<Kss008> insertKss008Lst, List<Kss008> updateKss008Lst, List<Kss008> Kss008Lst, List<Kss004> kss004Lst, Map<String, Object> renkeiInfoMap) throws Exception;
}
