package jp.co.nsd.nkssweb.dao;

import java.util.Date;

public class Kss016 extends Kss016Key {
    private Integer cdHyojJun;

    private String cdShubetsuNm;

    private String cdKnj;

    private String cdRyaku;

    private Date entryDate;

    private String entryUserId;

    private Date updateDate;

    private String updateUserId;

    public Integer getCdHyojJun() {
        return cdHyojJun;
    }

    public void setCdHyojJun(Integer cdHyojJun) {
        this.cdHyojJun = cdHyojJun;
    }

    public String getCdShubetsuNm() {
        return cdShubetsuNm;
    }

    public void setCdShubetsuNm(String cdShubetsuNm) {
        this.cdShubetsuNm = cdShubetsuNm == null ? null : cdShubetsuNm.trim();
    }

    public String getCdKnj() {
        return cdKnj;
    }

    public void setCdKnj(String cdKnj) {
        this.cdKnj = cdKnj == null ? null : cdKnj.trim();
    }

    public String getCdRyaku() {
        return cdRyaku;
    }

    public void setCdRyaku(String cdRyaku) {
        this.cdRyaku = cdRyaku == null ? null : cdRyaku.trim();
    }

    public Date getEntryDate() {
        return entryDate;
    }

    public void setEntryDate(Date entryDate) {
        this.entryDate = entryDate;
    }

    public String getEntryUserId() {
        return entryUserId;
    }

    public void setEntryUserId(String entryUserId) {
        this.entryUserId = entryUserId == null ? null : entryUserId.trim();
    }

    public Date getUpdateDate() {
        return updateDate;
    }

    public void setUpdateDate(Date updateDate) {
        this.updateDate = updateDate;
    }

    public String getUpdateUserId() {
        return updateUserId;
    }

    public void setUpdateUserId(String updateUserId) {
        this.updateUserId = updateUserId == null ? null : updateUserId.trim();
    }
}