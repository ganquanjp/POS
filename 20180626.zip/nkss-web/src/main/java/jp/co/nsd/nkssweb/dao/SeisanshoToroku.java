package jp.co.nsd.nkssweb.dao;

public class SeisanshoToroku {

	private int rowNo;
	private String seisanShoId;
	private String koteiShisanId;
	private String seisanShoNo;
	private String soshikiRenNm;
	private String siyoStartYmd;
	private String siyoStartYmdFrom;
	private String siyoStartYmdTo;
	private String tekiyo;
	private String yoyakusu;
	private String tsuikaYoyakusu;
	private String torokushaName;
	private String kenmeiCd;
	private String kenmeiId;
	private String kenmeimstCd;
	private String kenmeiNm;
	private String tekiyoStartYmd;
	private String tekiyoEndYmd;
	private String renkeiStatus;
	private String renkeiStatusKnj;
	private String shoninStatus;
	private String updateDate02;
	private String updateDate04;
	private boolean updDisabled;
	private boolean delDisabled;

	public int getRowNo() {
		return rowNo;
	}

	public void setRowNo(int rowNo) {
		this.rowNo = rowNo;
	}

	public String getSeisanShoId() {
		return seisanShoId;
	}

	public void setSeisanShoId(String seisanShoId) {
		this.seisanShoId = seisanShoId;
	}

	public String getKoteiShisanId() {
		return koteiShisanId;
	}

	public void setKoteiShisanId(String koteiShisanId) {
		this.koteiShisanId = koteiShisanId;
	}

	public String getSeisanShoNo() {
		return seisanShoNo;
	}

	public void setSeisanShoNo(String seisanShoNo) {
		this.seisanShoNo = seisanShoNo;
	}

	public String getSoshikiRenNm() {
		return soshikiRenNm;
	}

	public void setSoshikiRenNm(String soshikiRenNm) {
		this.soshikiRenNm = soshikiRenNm;
	}

	public String getSiyoStartYmd() {
		return siyoStartYmd;
	}

	public void setSiyoStartYmd(String siyoStartYmd) {
		this.siyoStartYmd = siyoStartYmd;
	}

	public String getSiyoStartYmdFrom() {
		return siyoStartYmdFrom;
	}

	public void setSiyoStartYmdFrom(String siyoStartYmdFrom) {
		this.siyoStartYmdFrom = siyoStartYmdFrom;
	}

	public String getSiyoStartYmdTo() {
		return siyoStartYmdTo;
	}

	public void setSiyoStartYmdTo(String siyoStartYmdTo) {
		this.siyoStartYmdTo = siyoStartYmdTo;
	}

	public String getTekiyo() {
		return tekiyo;
	}

	public void setTekiyo(String tekiyo) {
		this.tekiyo = tekiyo;
	}

	public String getYoyakusu() {
		return yoyakusu;
	}

	public void setYoyakusu(String yoyakusu) {
		this.yoyakusu = yoyakusu;
	}

	public String getTsuikaYoyakusu() {
		return tsuikaYoyakusu;
	}

	public void setTsuikaYoyakusu(String tsuikaYoyakusu) {
		this.tsuikaYoyakusu = tsuikaYoyakusu;
	}

	public String getTorokushaName() {
		return torokushaName;
	}

	public void setTorokushaName(String torokushaName) {
		this.torokushaName = torokushaName;
	}

	public String getKenmeiCd() {
		return kenmeiCd;
	}

	public void setKenmeiCd(String kenmeiCd) {
		this.kenmeiCd = kenmeiCd;
	}

	public String getKenmeiId() {
		return kenmeiId;
	}

	public void setKenmeiId(String kenmeiId) {
		this.kenmeiId = kenmeiId;
	}

	public String getKenmeimstCd() {
		return kenmeimstCd;
	}

	public void setKenmeimstCd(String kenmeimstCd) {
		this.kenmeimstCd = kenmeimstCd;
	}

	public String getKenmeiNm() {
		return kenmeiNm;
	}

	public void setKenmeiNm(String kenmeiNm) {
		this.kenmeiNm = kenmeiNm;
	}

	public String getTekiyoStartYmd() {
		return tekiyoStartYmd;
	}

	public void setTekiyoStartYmd(String tekiyoStartYmd) {
		this.tekiyoStartYmd = tekiyoStartYmd;
	}

	public String getTekiyoEndYmd() {
		return tekiyoEndYmd;
	}

	public void setTekiyoEndYmd(String tekiyoEndYmd) {
		this.tekiyoEndYmd = tekiyoEndYmd;
	}

	public String getRenkeiStatus() {
		return renkeiStatus;
	}

	public void setRenkeiStatus(String renkeiStatus) {
		this.renkeiStatus = renkeiStatus;
	}

	public String getRenkeiStatusKnj() {
		return renkeiStatusKnj;
	}

	public void setRenkeiStatusKnj(String renkeiStatusKnj) {
		this.renkeiStatusKnj = renkeiStatusKnj;
	}

	public String getShoninStatus() {
		return shoninStatus;
	}

	public void setShoninStatus(String shoninStatus) {
		this.shoninStatus = shoninStatus;
	}

	public String getUpdateDate02() {
		return updateDate02;
	}

	public void setUpdateDate02(String updateDate02) {
		this.updateDate02 = updateDate02;
	}

	public String getUpdateDate04() {
		return updateDate04;
	}

	public void setUpdateDate04(String updateDate04) {
		this.updateDate04 = updateDate04;
	}

	public boolean isUpdDisabled() {
		return updDisabled;
	}

	public void setUpdDisabled(boolean updDisabled) {
		this.updDisabled = updDisabled;
	}

	public boolean isDelDisabled() {
		return delDisabled;
	}

	public void setDelDisabled(boolean delDisabled) {
		this.delDisabled = delDisabled;
	}

}