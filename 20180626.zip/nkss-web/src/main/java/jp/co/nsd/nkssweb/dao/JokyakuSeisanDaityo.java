package jp.co.nsd.nkssweb.dao;

import java.math.BigDecimal;

/**
 * 資産台帳別内訳（除却）
 *
 * @version 1.00
 */
public class JokyakuSeisanDaityo {
	// 資産台帳別内訳（除却）情報
	// 固定資産
	private String koteiShisan;
	// 取得年月日
	private String shutokuYmd;
	// 使用開始年月日
	private String siyoStartYmd;
	// 管理箇所
	private String kanriSoshiki;
	// 設置場所
	private String sechiBasho;
	// 種類・構造・資産単位・科目1・科目2・科目3（種構資１２３）
	private String shubetsuCode;
	// 取引先
	private String torihikiSaki;
	// 摘要１
	private String tekiyo1;
	// 摘要２
	private String tekiyo2;
	// 摘要３
	private String tekiyo3;
	// 摘要４
	private String tekiyo4;
	// 摘要５
	private String tekiyo5;
	// 子資産残
	private String koshiZan;
	// 除却元数量(単位)
	private String motoSuryoTani;
	// 除却元取得原価
	private BigDecimal motoRwggetkgksyen;
	// 除却数量(単位)
	private String suryoTani;
	// 除却取得原価
	private BigDecimal rwggetkgksYen;
	// 除却後数量(単位)
	private String aftSuryoTani;
	// 除却後取得原価
	private BigDecimal aftRwggetkgksYen;
	// 除却原価(物品)
	private BigDecimal buppinGaku;
	// 除却簿価(工費)
	private BigDecimal kouhiGaku;
	// 除却簿価(合計)
	private BigDecimal bokaSum;
	// 除却損
	private BigDecimal ksJksonYen;
	public String getKoteiShisan() {
		return koteiShisan;
	}
	public void setKoteiShisan(String koteiShisan) {
		this.koteiShisan = koteiShisan;
	}
	/**
	 * @return shutokuYmd
	 */
	public String getShutokuYmd() {
		return shutokuYmd;
	}
	/**
	 * @param shutokuYmd セットする shutokuYmd
	 */
	public void setShutokuYmd(String shutokuYmd) {
		this.shutokuYmd = shutokuYmd;
	}
	/**
	 * @return siyoStartYmd
	 */
	public String getSiyoStartYmd() {
		return siyoStartYmd;
	}
	/**
	 * @param siyoStartYmd セットする siyoStartYmd
	 */
	public void setSiyoStartYmd(String siyoStartYmd) {
		this.siyoStartYmd = siyoStartYmd;
	}
	/**
	 * @return kanriSoshiki
	 */
	public String getKanriSoshiki() {
		return kanriSoshiki;
	}
	/**
	 * @param kanriSoshiki セットする kanriSoshiki
	 */
	public void setKanriSoshiki(String kanriSoshiki) {
		this.kanriSoshiki = kanriSoshiki;
	}
	/**
	 * @return sechiBasho
	 */
	public String getSechiBasho() {
		return sechiBasho;
	}
	/**
	 * @param sechiBasho セットする sechiBasho
	 */
	public void setSechiBasho(String sechiBasho) {
		this.sechiBasho = sechiBasho;
	}
	/**
	 * @return shubetsuCode
	 */
	public String getShubetsuCode() {
		return shubetsuCode;
	}
	/**
	 * @param shubetsuCode セットする shubetsuCode
	 */
	public void setShubetsuCode(String shubetsuCode) {
		this.shubetsuCode = shubetsuCode;
	}
	/**
	 * @return torihikiSaki
	 */
	public String getTorihikiSaki() {
		return torihikiSaki;
	}
	/**
	 * @param torihikiSaki セットする torihikiSaki
	 */
	public void setTorihikiSaki(String torihikiSaki) {
		this.torihikiSaki = torihikiSaki;
	}
	/**
	 * @return tekiyo1
	 */
	public String getTekiyo1() {
		return tekiyo1;
	}
	/**
	 * @param tekiyo1 セットする tekiyo1
	 */
	public void setTekiyo1(String tekiyo1) {
		this.tekiyo1 = tekiyo1;
	}
	/**
	 * @return tekiyo2
	 */
	public String getTekiyo2() {
		return tekiyo2;
	}
	/**
	 * @param tekiyo2 セットする tekiyo2
	 */
	public void setTekiyo2(String tekiyo2) {
		this.tekiyo2 = tekiyo2;
	}
	/**
	 * @return tekiyo3
	 */
	public String getTekiyo3() {
		return tekiyo3;
	}
	/**
	 * @param tekiyo3 セットする tekiyo3
	 */
	public void setTekiyo3(String tekiyo3) {
		this.tekiyo3 = tekiyo3;
	}
	/**
	 * @return tekiyo4
	 */
	public String getTekiyo4() {
		return tekiyo4;
	}
	/**
	 * @param tekiyo4 セットする tekiyo4
	 */
	public void setTekiyo4(String tekiyo4) {
		this.tekiyo4 = tekiyo4;
	}
	/**
	 * @return tekiyo5
	 */
	public String getTekiyo5() {
		return tekiyo5;
	}
	/**
	 * @param tekiyo5 セットする tekiyo5
	 */
	public void setTekiyo5(String tekiyo5) {
		this.tekiyo5 = tekiyo5;
	}
	/**
	 * @return koshiZan
	 */
	public String getKoshiZan() {
		return koshiZan;
	}
	/**
	 * @param koshiZan セットする koshiZan
	 */
	public void setKoshiZan(String koshiZan) {
		this.koshiZan = koshiZan;
	}
	/**
	 * @return motoSuryoTani
	 */
	public String getMotoSuryoTani() {
		return motoSuryoTani;
	}
	/**
	 * @param motoSuryoTani セットする motoSuryoTani
	 */
	public void setMotoSuryoTani(String motoSuryoTani) {
		this.motoSuryoTani = motoSuryoTani;
	}
	/**
	 * @return motoRwggetkgksyen
	 */
	public BigDecimal getMotoRwggetkgksyen() {
		return motoRwggetkgksyen;
	}
	/**
	 * @param motoRwggetkgksyen セットする motoRwggetkgksyen
	 */
	public void setMotoRwggetkgksyen(BigDecimal motoRwggetkgksyen) {
		this.motoRwggetkgksyen = motoRwggetkgksyen;
	}
	/**
	 * @return suryoTani
	 */
	public String getSuryoTani() {
		return suryoTani;
	}
	/**
	 * @param suryoTani セットする suryoTani
	 */
	public void setSuryoTani(String suryoTani) {
		this.suryoTani = suryoTani;
	}
	/**
	 * @return rwggetkgksYen
	 */
	public BigDecimal getRwggetkgksYen() {
		return rwggetkgksYen;
	}
	/**
	 * @param rwggetkgksYen セットする rwggetkgksYen
	 */
	public void setRwggetkgksYen(BigDecimal rwggetkgksYen) {
		this.rwggetkgksYen = rwggetkgksYen;
	}
	/**
	 * @return aftSuryoTani
	 */
	public String getAftSuryoTani() {
		return aftSuryoTani;
	}
	/**
	 * @param aftSuryoTani セットする aftSuryoTani
	 */
	public void setAftSuryoTani(String aftSuryoTani) {
		this.aftSuryoTani = aftSuryoTani;
	}
	/**
	 * @return aftRwggetkgksYen
	 */
	public BigDecimal getAftRwggetkgksYen() {
		return aftRwggetkgksYen;
	}
	/**
	 * @param aftRwggetkgksYen セットする aftRwggetkgksYen
	 */
	public void setAftRwggetkgksYen(BigDecimal aftRwggetkgksYen) {
		this.aftRwggetkgksYen = aftRwggetkgksYen;
	}
	/**
	 * @return buppinGaku
	 */
	public BigDecimal getBuppinGaku() {
		return buppinGaku;
	}
	/**
	 * @param buppinGaku セットする buppinGaku
	 */
	public void setBuppinGaku(BigDecimal buppinGaku) {
		this.buppinGaku = buppinGaku;
	}
	/**
	 * @return kouhiGaku
	 */
	public BigDecimal getKouhiGaku() {
		return kouhiGaku;
	}
	/**
	 * @param kouhiGaku セットする kouhiGaku
	 */
	public void setKouhiGaku(BigDecimal kouhiGaku) {
		this.kouhiGaku = kouhiGaku;
	}
	/**
	 * @return bokaSum
	 */
	public BigDecimal getBokaSum() {
		return bokaSum;
	}
	/**
	 * @param bokaSum セットする bokaSum
	 */
	public void setBokaSum(BigDecimal bokaSum) {
		this.bokaSum = bokaSum;
	}
	/**
	 * @return ksJksonYen
	 */
	public BigDecimal getKsJksonYen() {
		return ksJksonYen;
	}
	/**
	 * @param ksJksonYen セットする ksJksonYen
	 */
	public void setKsJksonYen(BigDecimal ksJksonYen) {
		this.ksJksonYen = ksJksonYen;
	}



}