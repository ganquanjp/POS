/***********************************************************************
*
*業務名: 工事精算システム
*機能名: 候補内容(共通処理)
*
*機能概要: 入力中の内容を部分一致にて検索し、
*          候補を入力フォーム下部に表示のデータを取得する
*
*JavaＶｅｒ：J2SE1.8.0準拠
*
*更新履歴: Ver.1.00 2018/03/13　NSD　新規作成
***********************************************************************/
package jp.co.nsd.nkssweb.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import jp.co.nsd.nkssweb.dao.Aads01;
import jp.co.nsd.nkssweb.dao.Abda09;
import jp.co.nsd.nkssweb.dao.Kss002;
import jp.co.nsd.nkssweb.dao.Kss011;
import jp.co.nsd.nkssweb.dao.Kss013;
import jp.co.nsd.nkssweb.dao.mapper.AutocompleteMapper;
import jp.co.nsd.nkssweb.service.AutocompleteService;

@Service
public class AutocompleteServiceImpl implements AutocompleteService {

	@Autowired
	private AutocompleteMapper autocompleteMapper;

	/**
	 * 件名情報取得
	 *
	 * @version 1.00
	 */
	@Override
	public List<Kss002> getKenmeiMaster(String siyoStartYmd) {

		return autocompleteMapper.selectAllKss002(siyoStartYmd);
	}

	/**
	 * 組織情報全件取得
	 *
	 * @version 1.00
	 */
	@Override
	public List<Kss011> getSoshikiMaster() {

		return autocompleteMapper.selectAllKss011();
	}

	/**
	 * ユーザ情報全件取得
	 *
	 * @version 1.00
	 */
	@Override
	public List<Kss013> getUserMaster() {

		List<Kss013> kss013Lst = autocompleteMapper.selectAllKss013();

		for (int i = 0; i < kss013Lst.size(); i++) {
			Kss013 kss013 = kss013Lst.get(i);
			//登録者氏名
			kss013.setSeiMei(kss013.getSei().concat(kss013.getMei()));
		}

		return kss013Lst;
	}

	/**
	 * 組織定数の組織名称を取得
	 *
	 * @version 1.00
	 */
	@Override
	public List<Abda09> getSoshikTeisuMaster() {

		return autocompleteMapper.selectAllAbda09();
	}

	/**
	 * 会計整理年月を取得
	 *
	 * @version 1.00
	 */
	@Override
	public List<Aads01> getKaikeiYmMaster() {
		return autocompleteMapper.selectAllAads01();
	}

}
