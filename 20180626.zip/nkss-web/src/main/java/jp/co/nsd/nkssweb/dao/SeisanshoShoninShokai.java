package jp.co.nsd.nkssweb.dao;

import java.math.BigDecimal;
import java.util.List;

public class SeisanshoShoninShokai {

	// 行番
	private int rowNo;

	// 経理審査否認理由
	private String riyu;

	// 精算書番号
	private String SeisanShoNo;

	// 処理No
	private BigDecimal hansu;

	// 使用開始年月日
	private String siyoStartYmd;

	// 取得価額合計
	private String shutokuKagakuGoke;

	// 承認ステータスコード
	private String shoninStatusCd;

	// 承認ステータス名
	private String shoninStatusNm;

	// 工事件名
	private String kenmeiNm;

	// 精算書ＩＤ
	private String seisanShoId;

	// 固定資産ＩＤ
	private String koteiShisanId;

	// 固定資産番号
	private String koteiShisanNo;

	// 固定資産名称
	private String koteiShisanNm;

	// 取得年月日
	private String shutokuYmd;

	// 取得価額
	private String shutokuKagaku;

	// 取得資産明細情報
	private List<SeisanshoShoninshutokuSisan> shutokuSisanLst;

	// 固定資産の混在カウント
	private int kouCnt;

	// 固定資産のリースフラグ
	private String leaseFlg;

	//固定資産の取引先・耐用年数混在カウント
	private int toriTaiCnt;

	// 更新年月日
	private String updateDate;

	public int getRowNo() {
		return rowNo;
	}

	public void setRowNo(int rowNo) {
		this.rowNo = rowNo;
	}

	public String getRiyu() {
		return riyu;
	}

	public void setRiyu(String riyu) {
		this.riyu = riyu;
	}

	public String getSeisanShoNo() {
		return SeisanShoNo;
	}

	public void setSeisanShoNo(String seisanShoNo) {
		SeisanShoNo = seisanShoNo;
	}

	public BigDecimal getHansu() {
		return hansu;
	}

	public void setHansu(BigDecimal hansu) {
		this.hansu = hansu;
	}

	public String getSiyoStartYmd() {
		return siyoStartYmd;
	}

	public void setSiyoStartYmd(String siyoStartYmd) {
		this.siyoStartYmd = siyoStartYmd;
	}

	public String getShutokuKagakuGoke() {
		return shutokuKagakuGoke;
	}

	public void setShutokuKagakuGoke(String shutokuKagakuGoke) {
		this.shutokuKagakuGoke = shutokuKagakuGoke;
	}

	public String getShoninStatusCd() {
		return shoninStatusCd;
	}

	public void setShoninStatusCd(String shoninStatusCd) {
		this.shoninStatusCd = shoninStatusCd;
	}

	public String getShoninStatusNm() {
		return shoninStatusNm;
	}

	public void setShoninStatusNm(String shoninStatusNm) {
		this.shoninStatusNm = shoninStatusNm;
	}

	public String getKenmeiNm() {
		return kenmeiNm;
	}

	public void setKenmeiNm(String kenmeiNm) {
		this.kenmeiNm = kenmeiNm;
	}

	public String getSeisanShoId() {
		return seisanShoId;
	}

	public void setSeisanShoId(String seisanShoId) {
		this.seisanShoId = seisanShoId;
	}

	public String getKoteiShisanId() {
		return koteiShisanId;
	}

	public void setKoteiShisanId(String koteiShisanId) {
		this.koteiShisanId = koteiShisanId;
	}

	public String getKoteiShisanNo() {
		return koteiShisanNo;
	}

	public void setKoteiShisanNo(String koteiShisanNo) {
		this.koteiShisanNo = koteiShisanNo;
	}

	public String getKoteiShisanNm() {
		return koteiShisanNm;
	}

	public void setKoteiShisanNm(String koteiShisanNm) {
		this.koteiShisanNm = koteiShisanNm;
	}

	public String getShutokuYmd() {
		return shutokuYmd;
	}

	public void setShutokuYmd(String shutokuYmd) {
		this.shutokuYmd = shutokuYmd;
	}

	public String getShutokuKagaku() {
		return shutokuKagaku;
	}

	public void setShutokuKagaku(String shutokuKagaku) {
		this.shutokuKagaku = shutokuKagaku;
	}

	public List<SeisanshoShoninshutokuSisan> getShutokuSisanLst() {
		return shutokuSisanLst;
	}

	public void setShutokuSisanLst(List<SeisanshoShoninshutokuSisan> shutokuSisanLst) {
		this.shutokuSisanLst = shutokuSisanLst;
	}

	public int getKouCnt() {
		return kouCnt;
	}

	public void setKouCnt(int kouCnt) {
		this.kouCnt = kouCnt;
	}

	public String getLeaseFlg() {
		return leaseFlg;
	}

	public void setLeaseFlg(String leaseFlg) {
		this.leaseFlg = leaseFlg;
	}

	public int getToriTaiCnt() {
		return toriTaiCnt;
	}

	public void setToriTaiCnt(int toriTaiCnt) {
		this.toriTaiCnt = toriTaiCnt;
	}

	public String getUpdateDate() {
		return updateDate;
	}

	public void setUpdateDate(String updateDate) {
		this.updateDate = updateDate;
	}
}