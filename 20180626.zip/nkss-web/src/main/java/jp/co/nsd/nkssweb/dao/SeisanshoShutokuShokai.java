package jp.co.nsd.nkssweb.dao;

public class SeisanshoShutokuShokai {

	private int rowNo;
	private String seisanShoId;
	private String koteiShisanId;
	private String soshikiNm;
	private String sechiBashoName;
	private String kenmeiCd;
	private String kenmeiNm;
	private String tekiyoStartYmd;
	private String tekiyoEndYmd;
	private String siyoStartYmd;
	private String koteiShisanNo;
	private String oyaKoteiShisanNo;
	private String oyaKoteiShisanEda;
	private String shutokuYmd;
	private String koteiShisanNm;
	private String shuruiCd;
	private String kouzouCd;
	private String shisanTaniCd;
	private String kamokuCd1;
	private String kamokuCd2;
	private String kamokuCd3;
	private String shuKnj;
	private String kouKnj;
	private String saiKnj;
	private String shu4Knj;
	private String shu5Knj;
	private String shu6Knj;
	private String taiyoNensuZei;
	private String taiyoNensuSho;
	private String torihikiSakiCd;
	private String torihikiSakiNm;
	private String komoku06;
	public String getTorihikiSakiTekiyoYmdF() {
		return torihikiSakiTekiyoYmdF;
	}
	public void setTorihikiSakiTekiyoYmdF(String torihikiSakiTekiyoYmdF) {
		this.torihikiSakiTekiyoYmdF = torihikiSakiTekiyoYmdF;
	}
	public String getTorihikiSakiTekiyoYmdT() {
		return torihikiSakiTekiyoYmdT;
	}
	public void setTorihikiSakiTekiyoYmdT(String torihikiSakiTekiyoYmdT) {
		this.torihikiSakiTekiyoYmdT = torihikiSakiTekiyoYmdT;
	}
	private String torihikiSakiTekiyoYmdF;
	private String torihikiSakiTekiyoYmdT;
	private String seizoKaishaNm;
	private String seihinNm;
	private String kataban;
	private String suryo;
	private String taniCd;
	private String taniNm;
	private String buppinGaku;
	private String kouhiGaku;
	private String souKeihiGaku;
	private String shutokuGaku;
	private String kanriSoshikiCd;
	private String kanriSoshikiNm;
	private String kanriSoshikiF;
	private String kanriSoshikiT;
	private String futanSoshikiCd;
	private String futanSoshikiNm;
	private String futanSoshikiF;
	private String futanSoshikiT;
	private String sechiBashoCd;
	private String sechiBashoNm;
	private String shutokuRiyuCd;
	private String shutokuRiyuNm;
	private String tekiyo1;
	private String tekiyo2;
	private String tekiyo3;
	private String tekiyo4;
	private String tekiyo5;
	private String kojiTantoUserNm;
	private String kojiTantoSoshikiCd;
	private String shoninStatus;
	private String updateDate;
	public int getRowNo() {
		return rowNo;
	}
	public void setRowNo(int rowNo) {
		this.rowNo = rowNo;
	}
	public String getSeisanShoId() {
		return seisanShoId;
	}
	public void setSeisanShoId(String seisanShoId) {
		this.seisanShoId = seisanShoId;
	}
	public String getKoteiShisanId() {
		return koteiShisanId;
	}
	public void setKoteiShisanId(String koteiShisanId) {
		this.koteiShisanId = koteiShisanId;
	}
	public String getSoshikiNm() {
		return soshikiNm;
	}
	public void setSoshikiNm(String soshikiNm) {
		this.soshikiNm = soshikiNm;
	}
	public String getSechiBashoName() {
		return sechiBashoName;
	}
	public void setSechiBashoName(String sechiBashoName) {
		this.sechiBashoName = sechiBashoName;
	}
	public String getKenmeiCd() {
		return kenmeiCd;
	}
	public void setKenmeiCd(String kenmeiCd) {
		this.kenmeiCd = kenmeiCd;
	}
	public String getKenmeiNm() {
		return kenmeiNm;
	}
	public void setKenmeiNm(String kenmeiNm) {
		this.kenmeiNm = kenmeiNm;
	}
	public String getTekiyoStartYmd() {
		return tekiyoStartYmd;
	}
	public void setTekiyoStartYmd(String tekiyoStartYmd) {
		this.tekiyoStartYmd = tekiyoStartYmd;
	}
	public String getTekiyoEndYmd() {
		return tekiyoEndYmd;
	}
	public void setTekiyoEndYmd(String tekiyoEndYmd) {
		this.tekiyoEndYmd = tekiyoEndYmd;
	}
	public String getSiyoStartYmd() {
		return siyoStartYmd;
	}
	public void setSiyoStartYmd(String siyoStartYmd) {
		this.siyoStartYmd = siyoStartYmd;
	}
	public String getKoteiShisanNo() {
		return koteiShisanNo;
	}
	public void setKoteiShisanNo(String koteiShisanNo) {
		this.koteiShisanNo = koteiShisanNo;
	}
	public String getOyaKoteiShisanNo() {
		return oyaKoteiShisanNo;
	}
	public void setOyaKoteiShisanNo(String oyaKoteiShisanNo) {
		this.oyaKoteiShisanNo = oyaKoteiShisanNo;
	}
	public String getOyaKoteiShisanEda() {
		return oyaKoteiShisanEda;
	}
	public void setOyaKoteiShisanEda(String oyaKoteiShisanEda) {
		this.oyaKoteiShisanEda = oyaKoteiShisanEda;
	}
	public String getShutokuYmd() {
		return shutokuYmd;
	}
	public void setShutokuYmd(String shutokuYmd) {
		this.shutokuYmd = shutokuYmd;
	}
	public String getKoteiShisanNm() {
		return koteiShisanNm;
	}
	public void setKoteiShisanNm(String koteiShisanNm) {
		this.koteiShisanNm = koteiShisanNm;
	}
	public String getShuruiCd() {
		return shuruiCd;
	}
	public void setShuruiCd(String shuruiCd) {
		this.shuruiCd = shuruiCd;
	}
	public String getKouzouCd() {
		return kouzouCd;
	}
	public void setKouzouCd(String kouzouCd) {
		this.kouzouCd = kouzouCd;
	}
	public String getShisanTaniCd() {
		return shisanTaniCd;
	}
	public void setShisanTaniCd(String shisanTaniCd) {
		this.shisanTaniCd = shisanTaniCd;
	}
	public String getKamokuCd1() {
		return kamokuCd1;
	}
	public void setKamokuCd1(String kamokuCd1) {
		this.kamokuCd1 = kamokuCd1;
	}
	public String getKamokuCd2() {
		return kamokuCd2;
	}
	public void setKamokuCd2(String kamokuCd2) {
		this.kamokuCd2 = kamokuCd2;
	}
	public String getKamokuCd3() {
		return kamokuCd3;
	}
	public void setKamokuCd3(String kamokuCd3) {
		this.kamokuCd3 = kamokuCd3;
	}
	public String getShuKnj() {
		return shuKnj;
	}
	public void setShuKnj(String shuKnj) {
		this.shuKnj = shuKnj;
	}
	public String getKouKnj() {
		return kouKnj;
	}
	public void setKouKnj(String kouKnj) {
		this.kouKnj = kouKnj;
	}
	public String getSaiKnj() {
		return saiKnj;
	}
	public void setSaiKnj(String saiKnj) {
		this.saiKnj = saiKnj;
	}
	public String getShu4Knj() {
		return shu4Knj;
	}
	public void setShu4Knj(String shu4Knj) {
		this.shu4Knj = shu4Knj;
	}
	public String getShu5Knj() {
		return shu5Knj;
	}
	public void setShu5Knj(String shu5Knj) {
		this.shu5Knj = shu5Knj;
	}
	public String getShu6Knj() {
		return shu6Knj;
	}
	public void setShu6Knj(String shu6Knj) {
		this.shu6Knj = shu6Knj;
	}
	public String getTaiyoNensuZei() {
		return taiyoNensuZei;
	}
	public void setTaiyoNensuZei(String taiyoNensuZei) {
		this.taiyoNensuZei = taiyoNensuZei;
	}
	public String getTaiyoNensuSho() {
		return taiyoNensuSho;
	}
	public void setTaiyoNensuSho(String taiyoNensuSho) {
		this.taiyoNensuSho = taiyoNensuSho;
	}
	public String getTorihikiSakiCd() {
		return torihikiSakiCd;
	}
	public void setTorihikiSakiCd(String torihikiSakiCd) {
		this.torihikiSakiCd = torihikiSakiCd;
	}
	public String getTorihikiSakiNm() {
		return torihikiSakiNm;
	}
	public void setTorihikiSakiNm(String torihikiSakiNm) {
		this.torihikiSakiNm = torihikiSakiNm;
	}
	public String getSeizoKaishaNm() {
		return seizoKaishaNm;
	}
	public void setSeizoKaishaNm(String seizoKaishaNm) {
		this.seizoKaishaNm = seizoKaishaNm;
	}
	public String getSeihinNm() {
		return seihinNm;
	}
	public void setSeihinNm(String seihinNm) {
		this.seihinNm = seihinNm;
	}
	public String getKataban() {
		return kataban;
	}
	public void setKataban(String kataban) {
		this.kataban = kataban;
	}
	public String getSuryo() {
		return suryo;
	}
	public void setSuryo(String suryo) {
		this.suryo = suryo;
	}
	public String getTaniCd() {
		return taniCd;
	}
	public void setTaniCd(String taniCd) {
		this.taniCd = taniCd;
	}
	public String getTaniNm() {
		return taniNm;
	}
	public void setTaniNm(String taniNm) {
		this.taniNm = taniNm;
	}
	public String getBuppinGaku() {
		return buppinGaku;
	}
	public void setBuppinGaku(String buppinGaku) {
		this.buppinGaku = buppinGaku;
	}
	public String getKouhiGaku() {
		return kouhiGaku;
	}
	public void setKouhiGaku(String kouhiGaku) {
		this.kouhiGaku = kouhiGaku;
	}
	public String getSouKeihiGaku() {
		return souKeihiGaku;
	}
	public void setSouKeihiGaku(String souKeihiGaku) {
		this.souKeihiGaku = souKeihiGaku;
	}
	public String getShutokuGaku() {
		return shutokuGaku;
	}
	public void setShutokuGaku(String shutokuGaku) {
		this.shutokuGaku = shutokuGaku;
	}
	public String getKanriSoshikiCd() {
		return kanriSoshikiCd;
	}
	public void setKanriSoshikiCd(String kanriSoshikiCd) {
		this.kanriSoshikiCd = kanriSoshikiCd;
	}
	public String getKanriSoshikiNm() {
		return kanriSoshikiNm;
	}
	public void setKanriSoshikiNm(String kanriSoshikiNm) {
		this.kanriSoshikiNm = kanriSoshikiNm;
	}
	public String getKanriSoshikiF() {
		return kanriSoshikiF;
	}
	public void setKanriSoshikiF(String kanriSoshikiF) {
		this.kanriSoshikiF = kanriSoshikiF;
	}
	public String getKanriSoshikiT() {
		return kanriSoshikiT;
	}
	public void setKanriSoshikiT(String kanriSoshikiT) {
		this.kanriSoshikiT = kanriSoshikiT;
	}
	public String getFutanSoshikiCd() {
		return futanSoshikiCd;
	}
	public void setFutanSoshikiCd(String futanSoshikiCd) {
		this.futanSoshikiCd = futanSoshikiCd;
	}
	public String getFutanSoshikiNm() {
		return futanSoshikiNm;
	}
	public void setFutanSoshikiNm(String futanSoshikiNm) {
		this.futanSoshikiNm = futanSoshikiNm;
	}
	public String getFutanSoshikiF() {
		return futanSoshikiF;
	}
	public void setFutanSoshikiF(String futanSoshikiF) {
		this.futanSoshikiF = futanSoshikiF;
	}
	public String getFutanSoshikiT() {
		return futanSoshikiT;
	}
	public void setFutanSoshikiT(String futanSoshikiT) {
		this.futanSoshikiT = futanSoshikiT;
	}
	public String getSechiBashoCd() {
		return sechiBashoCd;
	}
	public void setSechiBashoCd(String sechiBashoCd) {
		this.sechiBashoCd = sechiBashoCd;
	}
	public String getSechiBashoNm() {
		return sechiBashoNm;
	}
	public void setSechiBashoNm(String sechiBashoNm) {
		this.sechiBashoNm = sechiBashoNm;
	}
	public String getShutokuRiyuCd() {
		return shutokuRiyuCd;
	}
	public void setShutokuRiyuCd(String shutokuRiyuCd) {
		this.shutokuRiyuCd = shutokuRiyuCd;
	}
	public String getShutokuRiyuNm() {
		return shutokuRiyuNm;
	}
	public void setShutokuRiyuNm(String shutokuRiyuNm) {
		this.shutokuRiyuNm = shutokuRiyuNm;
	}
	public String getTekiyo1() {
		return tekiyo1;
	}
	public void setTekiyo1(String tekiyo1) {
		this.tekiyo1 = tekiyo1;
	}
	public String getTekiyo2() {
		return tekiyo2;
	}
	public void setTekiyo2(String tekiyo2) {
		this.tekiyo2 = tekiyo2;
	}
	public String getTekiyo3() {
		return tekiyo3;
	}
	public void setTekiyo3(String tekiyo3) {
		this.tekiyo3 = tekiyo3;
	}
	public String getTekiyo4() {
		return tekiyo4;
	}
	public void setTekiyo4(String tekiyo4) {
		this.tekiyo4 = tekiyo4;
	}
	public String getTekiyo5() {
		return tekiyo5;
	}
	public void setTekiyo5(String tekiyo5) {
		this.tekiyo5 = tekiyo5;
	}
	public String getKojiTantoUserNm() {
		return kojiTantoUserNm;
	}
	public void setKojiTantoUserNm(String kojiTantoUserNm) {
		this.kojiTantoUserNm = kojiTantoUserNm;
	}
	public String getKojiTantoSoshikiCd() {
		return kojiTantoSoshikiCd;
	}
	public void setKojiTantoSoshikiCd(String kojiTantoSoshikiCd) {
		this.kojiTantoSoshikiCd = kojiTantoSoshikiCd;
	}
	public String getShoninStatus() {
		return shoninStatus;
	}
	public void setShoninStatus(String shoninStatus) {
		this.shoninStatus = shoninStatus;
	}
	public String getUpdateDate() {
		return updateDate;
	}
	public void setUpdateDate(String updateDate) {
		this.updateDate = updateDate;
	}
	public String getKomoku06() {
		return komoku06;
	}
	public void setKomoku06(String komoku06) {
		this.komoku06 = komoku06;
	}

}