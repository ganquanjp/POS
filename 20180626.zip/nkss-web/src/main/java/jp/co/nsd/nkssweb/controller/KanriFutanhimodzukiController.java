/***********************************************************************
*
*業務名: 工事精算システム
*機能名: 除却（登録・修正・削除）(ログ出力処理)
*
*機能概要: 除却情報を処理する。
*
*JavaＶｅｒ：J2SE1.8.0準拠
*
*更新履歴: Ver.1.00 2018/03/06　NSD　新規作成
***********************************************************************/

package jp.co.nsd.nkssweb.controller;

import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.time.DateUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import jp.co.nsd.nkssweb.dao.Abda09;
import jp.co.nsd.nkssweb.dao.InputCheck;
import jp.co.nsd.nkssweb.dao.KanriFutanhimodzuki;
import jp.co.nsd.nkssweb.dao.Kss015;
import jp.co.nsd.nkssweb.dao.Kss015Key;
import jp.co.nsd.nkssweb.dao.mapper.Kss015Mapper;
import jp.co.nsd.nkssweb.service.CommService;
import jp.co.nsd.nkssweb.service.InputCheckService;
import jp.co.nsd.nkssweb.service.KanriFutanhimodzukiService;
import jp.co.nsd.nkssweb.service.SystemService;
import jp.co.nsd.nkssweb.utils.NSDCommUtils;
import jp.co.nsd.nkssweb.utils.NSDConstant;
import jp.co.nsd.nkssweb.utils.NSDDataCheck;
import jp.co.nsd.nkssweb.utils.NSDDateUtils;

/**
 * 管理箇所/負担箇所紐付（検索）処理
 *
 * @version 1.00
 */
@RestController
public class KanriFutanhimodzukiController extends BaseController {

	@Autowired
	private KanriFutanhimodzukiService kanriFutanhimodzukiService;

	@Autowired
	protected SystemService systemService;

	@Autowired
	protected InputCheckService inputCheckService;

	@Autowired
	private Kss015Mapper kss015Mapper;

	@Autowired
	private NSDDataCheck nsdDataCheck;

	@Autowired
	protected CommService commService;

	/**
	 * 管理箇所/負担箇所紐付（検索）処理
	 *
	 * @param reqMap
	 *            INPUTパラメータ
	 * @return 管理箇所/負担箇所情報データ
	 * @exception IllegalAccessException
	 * @exception InvocationTargetException
	 * @version 1.00
	 */
	@RequestMapping(value = "/kanriFutanhimodzuki-selectByWhere", method = RequestMethod.POST)
	public Map<String, Object> selectByWhere(@RequestParam Map<String, Object> reqMap) throws Exception {

		Map<String, Object> resultMap = new HashMap<String, Object>();

		KanriFutanhimodzuki kanriFutanhimodzuki = new KanriFutanhimodzuki();

		List<KanriFutanhimodzuki> kfhList = new ArrayList<>();

		// Mapの情報をBeanのプロパティにセット
		BeanUtils.populate(kanriFutanhimodzuki, reqMap);

		// サービス呼び出し
		kfhList = kanriFutanhimodzukiService.getKanriFutanInfo(kanriFutanhimodzuki);

		// 検索結果を返却Mapに設定する
		setDataToResultMap(resultMap, kfhList);

		return resultMap;
	}

	/**
	 * 管理箇所/負担箇所紐付（新規）処理
	 *
	 * @param reqMap
	 *            INPUTパラメータ
	 * @version 1.00
	 * @throws Exception
	 */
	@RequestMapping(value = "/kanriFutanhimodzuki-insertInfo", method = RequestMethod.POST)
	public Map<String, Object> insertInfo(HttpServletRequest request, @RequestParam Map<String, Object> reqMap)
			throws Exception {

		Map<String, Object> resultMap = new HashMap<String, Object>();

		// 入力チェック
		String errStr = inputCheckForInsert(reqMap);
		if (StringUtils.isNotEmpty(errStr)) {
			return setMsgToResultMap(resultMap, NSDConstant.MSGID_INPUT_ERROR, errStr);
		}

		// 画面から登録データ取得して、Kss015に設定する
		List<Kss015> kss015Lst = new ArrayList<>();
		errStr = setInsertInfo(request, reqMap, kss015Lst);
		if (StringUtils.isNotEmpty(errStr) && NSDConstant.MSGID_EXIST_INPUT.equals(errStr)) {
			return setMsgToResultMap(resultMap, NSDConstant.MSGID_EXIST_INPUT);
		} else if (StringUtils.isNotEmpty(errStr)) {
			return setMsgToResultMap(resultMap, errStr);
		}
		// サービス呼び出し
		kanriFutanhimodzukiService.insertInfo(kss015Lst);

		// 処理結果データ
		resultMap.put(NSDConstant.RESULT_DATA_NAME, NSDConstant.BLANK_STRING);

		return setMsgToResultMapNoLog(resultMap, NSDConstant.MSGID_INSERT_SUCCES);
	}

	/**
	 * 登録情報を設定する
	 *
	 * @param request
	 * @param reqMap
	 * @param kss015Lst
	 *
	 * @return kss015Lst
	 * @throws Exception
	 */
	private String setInsertInfo(HttpServletRequest request, Map<String, Object> reqMap, List<Kss015> kss015Lst)
			throws Exception {

		Date date = new Date();
		String loginUserId = getLoginUserInfo(request).getUserId();
		// MapKey
		String key;
		for (int i = 0; i < 25; i++) {

			// 管理箇所KEY
			key = "kanriFutanLst".concat("[" + i + "]").concat("[kanriSoshikiKnj]");
			// 管理箇所が空の場合
			if (StringUtils.isEmpty((String) reqMap.get(key))) {
				continue;
			}

			Kss015 kss015 = new Kss015();

			// 管理箇所コード
			key = "kanriFutanLst".concat("[" + i + "]").concat("[kanriSoshikiCd]");
			kss015.setKanriSoshikiCd((String) reqMap.get(key));

			// 管理箇所適用期間（FROM）
			key = "kanriFutanLst".concat("[" + i + "]").concat("[kanriTekiyoStartYmd]");
			kss015.setKanriTekiyoStartYmd(NSDDateUtils.parseStrToCal(reqMap.get(key).toString().trim()).getTime());

			// 管理箇所適用期間（TO）
			key = "kanriFutanLst".concat("[" + i + "]").concat("[kanriTekiyoEndYmd]");
			kss015.setKanriTekiyoEndYmd(NSDDateUtils.parseStrToCal(reqMap.get(key).toString().trim()).getTime());

			// 負担箇所コード
			key = "kanriFutanLst".concat("[" + i + "]").concat("[futanSoshikiCd]");
			kss015.setFutanSoshikiCd((String) reqMap.get(key));

			// 負担箇所適用期間（FROM）
			key = "kanriFutanLst".concat("[" + i + "]").concat("[futanTekiyoStartYmd]");
			kss015.setFutanTekiyoStartYmd(NSDDateUtils.parseStrToCal(reqMap.get(key).toString().trim()).getTime());

			// 負担箇所適用期間（TO）
			key = "kanriFutanLst".concat("[" + i + "]").concat("[futanTekiyoEndYmd]");
			kss015.setFutanTekiyoEndYmd(NSDDateUtils.parseStrToCal(reqMap.get(key).toString().trim()).getTime());

			// 登録年月日
			kss015.setEntryDate(date);

			// 登録ユーザーＩＤ
			kss015.setEntryUserId(loginUserId);

			// 更新年月日
			kss015.setUpdateDate(date);

			// 更新ユーザーＩＤ
			kss015.setUpdateUserId(loginUserId);

			if (checkInputIsExist(kss015Lst, kss015)) {
				return NSDConstant.MSGID_EXIST_INPUT;
			}
			// 除却資産明細
			kss015Lst.add(kss015);
		}
		return "";
	}

	/**
	 * 重複入力のチェック処理
	 *
	 * @param kss015Lst
	 *            INPUTパラメータ
	 * @param kss015
	 *            INPUTパラメータ
	 */
	private boolean checkInputIsExist(List<Kss015> kss015Lst, Kss015 kss015) {
		for (Kss015 kss015info : kss015Lst) {
			if (StringUtils.equals(kss015info.getKanriSoshikiCd(), kss015.getKanriSoshikiCd())
					&& kss015info.getKanriTekiyoStartYmd().compareTo(kss015.getKanriTekiyoStartYmd()) == 0
					&& StringUtils.equals(kss015info.getFutanSoshikiCd(), kss015.getFutanSoshikiCd())
					&& kss015info.getFutanTekiyoStartYmd().compareTo(kss015.getFutanTekiyoStartYmd()) == 0) {
				return true;
			}
		}
		return false;
	}

	/**
	 * 管理箇所/負担箇所紐付（更新）処理
	 *
	 * @param reqMap
	 *            INPUTパラメータ
	 * @return 除却情報データ
	 * @version 1.00
	 * @throws Exception
	 */
	@RequestMapping(value = "/kanriFutanhimodzuki-updateInfo", method = RequestMethod.POST)
	public Map<String, Object> updateInfo(HttpServletRequest request, @RequestParam Map<String, Object> reqMap)
			throws Exception {

		Map<String, Object> resultMap = new HashMap<String, Object>();

		// 入力チェック
		String errStr = inputCheckForUpdate(reqMap);
		if (StringUtils.isNotEmpty(errStr)) {
			return setMsgToResultMap(resultMap, NSDConstant.MSGID_INPUT_ERROR, errStr);
		}

		// 管理／負担箇所(更新)
		List<Kss015> kss015UpdLst = new ArrayList<Kss015>();
		// 管理／負担箇所(登録)
		List<Kss015> kss015InsLst = new ArrayList<Kss015>();
		// 管理／負担箇所(削除)
		List<Kss015> kss015DelLst = new ArrayList<Kss015>();

		// 入力したデータをチェックして、更新情報に設定する
		String err = setUpdateInfo(request, reqMap, kss015InsLst, kss015DelLst, kss015UpdLst);
		if (StringUtils.isNotEmpty(err) && NSDConstant.MSGID_EXIST_INPUT.equals(err)) {
			return setMsgToResultMapNoLog(resultMap, NSDConstant.MSGID_EXIST_INPUT);
		} else if (StringUtils.isNotEmpty(err)) {
			return setMsgToResultMapNoLog(resultMap, err);
		}
		// サービス呼び出し
		kanriFutanhimodzukiService.updateInfo(kss015InsLst, kss015DelLst, kss015UpdLst);

		// 処理結果データ
		resultMap.put(NSDConstant.RESULT_DATA_NAME, "");

		return setMsgToResultMapNoLog(resultMap, NSDConstant.MSGID_UPDATE_SUCCES);
	}

	/**
	 * 更新情報を設定する
	 *
	 * @param request
	 * @param reqMap
	 * @param kss015InsLst
	 * @param kss015DelLst
	 * @param kss015UpdLst
	 * @throws Exception
	 */
	private String setUpdateInfo(HttpServletRequest request, Map<String, Object> reqMap, List<Kss015> kss015InsLst,
			List<Kss015> kss015DelLst, List<Kss015> kss015UpdLst) throws Exception {
		Date date = new Date();
		String loginUserId = getLoginUserInfo(request).getUserId();
		// MapKey
		String key;
		// 更新チェック
		boolean updChk = false;
		// 削除チェック
		boolean delChk = false;

		Kss015 kss015InputAft = new Kss015();
		Kss015 kss015InputBef = new Kss015();
		Kss015 kss015Del = new Kss015();
		int dataLen = Integer.valueOf((String) reqMap.get("dataLen"));
		// 更新・削除処理判断
		for (int i = 0; i < dataLen; i++) {
			kss015InputAft = new Kss015();
			kss015InputBef = new Kss015();
			kss015Del = new Kss015();
			updChk = false;
			delChk = false;
			// 管理箇所KEY
			key = "kanriFutanLst".concat("[" + i + "]").concat("[kanriSoshikiKnj]");
			// 管理箇所が空の場合
			if (StringUtils.isEmpty((String) reqMap.get(key))) {
				continue;
			}

			// 管理／負担箇所情報を設定
			String keyUpd = "kanriFutanLst".concat("[" + i + "]").concat("[upd]");
			String keyDel = "kanriFutanLst".concat("[" + i + "]").concat("[del]");

			// チェックボックスの値を取得する
			if (null != reqMap.get(keyUpd)) {
				updChk = Boolean.valueOf((String) reqMap.get(keyUpd));
			}
			if (null != reqMap.get(keyDel)) {
				delChk = Boolean.valueOf((String) reqMap.get(keyDel));
			}

			if (updChk) {
				// 更新修正用
				setKss015(reqMap, kss015InputAft, kss015InputBef, i, date, loginUserId, key);

				if (!checkIsExist(kss015InputAft, kss015InputBef, kss015Del)) {

					// 排他チェック
					key = "kanriFutanLst".concat("[" + i + "]").concat("[updateDate]");
					String errId = commService.doHaita(kss015Del, (String) reqMap.get(key));
					if (!NSDConstant.BLANK_STRING.equals(errId)) {
						return errId;
					}

					// 変更前のデータを削除する
					kss015DelLst.add(kss015Del);
					// 変更後のデータを登録する
					if (checkInputIsExist(kss015InsLst, kss015InputAft)) {
						return NSDConstant.MSGID_EXIST_INPUT;
					}
					kss015InsLst.add(kss015InputAft);
				} else {
					// 画面にて何も変更しない
					kss015InputAft.setEntryDate(null);
					kss015InputAft.setEntryUserId(null);
					kss015UpdLst.add(kss015InputAft);
				}
			} else if (delChk) {
				// 削除データを用
				setKss015(reqMap, kss015InputAft, kss015InputBef, i, date, loginUserId, key);

				// 排他チェック
				key = "kanriFutanLst".concat("[" + i + "]").concat("[updateDate]");
				String errId = commService.doHaita(kss015InputBef, (String) reqMap.get(key));
				if (!NSDConstant.BLANK_STRING.equals(errId)) {
					return errId;
				}

				// データを削除する
				kss015DelLst.add(kss015InputBef);
			} else {
				// 処理なし
			}
		}
		return NSDConstant.BLANK_STRING;
	}

	/**
	 * 入力したデータを変更するかチェック
	 *
	 * @param kss015InputBef
	 * @param kss015InputAft
	 * @param kss015Del
	 * @return false : 存在する true : 存在しない
	 * @throws Exception
	 */
	private boolean checkIsExist(Kss015 kss015InputAft, Kss015 kss015InputBef, Kss015 kss015Del) {
		// 入力したデータが存在するか
		if (StringUtils.equals(kss015InputAft.getKanriSoshikiCd(), kss015InputBef.getKanriSoshikiCd())
				&& DateUtils.isSameInstant(kss015InputAft.getKanriTekiyoStartYmd(),
						kss015InputBef.getKanriTekiyoStartYmd())
				&& StringUtils.equals(kss015InputAft.getFutanSoshikiCd(), kss015InputBef.getFutanSoshikiCd())
				&& DateUtils.isSameInstant(kss015InputAft.getFutanTekiyoStartYmd(),
						kss015InputBef.getFutanTekiyoStartYmd())) {
			// 画面データを変更しないでチェックボックスをチェックするの場合、処理なし

			return true;
		} else {
			// 上記以外の場合、削除情報を設定する
			kss015Del.setKanriSoshikiCd(kss015InputBef.getKanriSoshikiCd());
			kss015Del.setKanriTekiyoStartYmd(kss015InputBef.getKanriTekiyoStartYmd());
			kss015Del.setFutanSoshikiCd(kss015InputBef.getFutanSoshikiCd());
			kss015Del.setFutanTekiyoStartYmd(kss015InputBef.getFutanTekiyoStartYmd());

			// 入力したデータ重複登録チェック
			Kss015 kss015 = kss015Mapper.selectByPrimaryKey(kss015InputAft);
			if (kss015 != null) {
				return true;
			} else {
				return false;
			}
		}
	}

	/**
	 * 入力したデータを取得する
	 *
	 * @param reqMap
	 * @param kss015InputBef
	 * @param kss015InputAft
	 * @param kss015InputBef
	 * @param i
	 * @param date
	 * @param loginUserId
	 * @param key
	 * @throws Exception
	 */
	private void setKss015(Map<String, Object> reqMap, Kss015 kss015InputAft, Kss015 kss015InputBef, int i, Date date,
			String loginUserId, String key) throws Exception {

		// 変更後の値を取得する
		// 管理箇所コード
		key = "kanriFutanLst".concat("[" + i + "]").concat("[kanriSoshikiCd]");
		kss015InputAft.setKanriSoshikiCd((String) reqMap.get(key));

		// 管理箇所適用期間（FROM）
		key = "kanriFutanLst".concat("[" + i + "]").concat("[kanriTekiyoStartYmd]");
		kss015InputAft.setKanriTekiyoStartYmd(NSDDateUtils.parseStrToCal(reqMap.get(key).toString().trim()).getTime());

		// 管理箇所適用期間（TO）
		key = "kanriFutanLst".concat("[" + i + "]").concat("[kanriTekiyoEndYmd]");
		kss015InputAft.setKanriTekiyoEndYmd(NSDDateUtils.parseStrToCal(reqMap.get(key).toString().trim()).getTime());

		// 負担箇所コード
		key = "kanriFutanLst".concat("[" + i + "]").concat("[futanSoshikiCd]");
		kss015InputAft.setFutanSoshikiCd((String) reqMap.get(key));

		// 負担箇所適用期間（FROM）
		key = "kanriFutanLst".concat("[" + i + "]").concat("[futanTekiyoStartYmd]");
		kss015InputAft.setFutanTekiyoStartYmd(NSDDateUtils.parseStrToCal(reqMap.get(key).toString().trim()).getTime());

		// 負担箇所適用期間（TO）
		key = "kanriFutanLst".concat("[" + i + "]").concat("[futanTekiyoEndYmd]");
		kss015InputAft.setFutanTekiyoEndYmd(NSDDateUtils.parseStrToCal(reqMap.get(key).toString().trim()).getTime());

		// 登録年月日
		kss015InputAft.setEntryDate(date);

		// 登録ユーザーＩＤ
		kss015InputAft.setEntryUserId(loginUserId);

		// 更新年月日
		kss015InputAft.setUpdateDate(date);

		// 更新ユーザーＩＤ
		kss015InputAft.setUpdateUserId(loginUserId);

		// 変更前の値を取得する
		// 管理箇所コード
		key = "kanriFutanInitLst".concat("[" + i + "]").concat("[kanriSoshikiCd]");
		kss015InputBef.setKanriSoshikiCd((String) reqMap.get(key));

		// 管理箇所適用期間（FROM）
		key = "kanriFutanInitLst".concat("[" + i + "]").concat("[kanriTekiyoStartYmd]");
		kss015InputBef.setKanriTekiyoStartYmd(NSDDateUtils.parseStrToCal(reqMap.get(key).toString().trim()).getTime());

		// 負担箇所コード
		key = "kanriFutanInitLst".concat("[" + i + "]").concat("[futanSoshikiCd]");
		kss015InputBef.setFutanSoshikiCd((String) reqMap.get(key));

		// 負担箇所適用期間（FROM）
		key = "kanriFutanInitLst".concat("[" + i + "]").concat("[futanTekiyoStartYmd]");
		kss015InputBef.setFutanTekiyoStartYmd(NSDDateUtils.parseStrToCal(reqMap.get(key).toString().trim()).getTime());
	}

	/**
	 * 新規登録の入力データチェック
	 *
	 * @param reqMap
	 *            INPUTパラメータ
	 * @return エラーメッセージID
	 * @version 1.00
	 */
	private String inputCheckForInsert(Map<String, Object> reqMap) {
		String errStr = NSDConstant.BLANK_STRING;
		List<InputCheck> inputCheckList = new ArrayList<InputCheck>();

		getCheckItemList(reqMap, inputCheckList, NSDConstant.ACTION_INSERT);

		// １件でも入力しないの場合
		if (inputCheckList.size() == 0) {
			errStr = NSDCommUtils.setKakoToStr(
					"管理箇所／負担箇所紐付情報：".concat(systemService.getMessage(NSDConstant.MSGID_CHECK_EMPTY).getContent()));

		} else {
			errStr = nsdDataCheck.dataCheck(inputCheckList);
		}

		return errStr;

	}

	/**
	 * 更新の入力データチェック
	 *
	 * @param reqMap
	 *            INPUTパラメータ
	 * @return エラーメッセージID
	 * @version 1.00
	 */
	private String inputCheckForUpdate(Map<String, Object> reqMap) {
		String errStr = NSDConstant.BLANK_STRING;
		List<InputCheck> inputCheckList = new ArrayList<InputCheck>();
		getCheckItemList(reqMap, inputCheckList, NSDConstant.ACTION_UPDATE);

		// １件でも選択しないの場合
		if (inputCheckList.size() == 0) {
			errStr = NSDCommUtils
					.setKakoToStr(systemService.getMessage(NSDConstant.MSGID_RECORD_NOT_SELECTED).getContent());

		} else {
			errStr = nsdDataCheck.dataCheck(inputCheckList);
		}
		return errStr;

	}

	/**
	 * 登録、更新の入力データチェック
	 *
	 * @param reqMap
	 *            INPUTパラメータ
	 * @param inputCheckList
	 * @param actionFlag
	 *            登録・更新フラグ 0:登録 1:更新
	 *
	 * @return エラーメッセージID
	 * @version 1.00
	 *
	 */
	private void getCheckItemList(Map<String, Object> reqMap, List<InputCheck> inputCheckList, int actionFlag) {

		Map<Integer, Object> args;
		Boolean isDelete = false;
		// 画面明細件数取得
		Set<String> set = countViewRecord(reqMap);

		// 画面明細部
		for (int i = 0; i < set.size(); i++) {

			isDelete = false;
			String name = NSDConstant.BLANK_STRING;

			// 更新・削除の場合
			if (NSDConstant.ACTION_UPDATE == actionFlag) {

				args = new HashMap<Integer, Object>();
				String updId = "kanriFutanLst".concat("[" + i + "]").concat("[upd]");
				String delId = "kanriFutanLst".concat("[" + i + "]").concat("[del]");
				if ((StringUtils.isEmpty((String) reqMap.get(delId))
						|| StringUtils.equals((String) reqMap.get(delId), "false"))
						&& (StringUtils.isEmpty((String) reqMap.get(updId))
								|| StringUtils.equals((String) reqMap.get(updId), "false"))) {
					continue;
				}
				if (StringUtils.equals((String) reqMap.get(delId), "true")
						&& (StringUtils.isEmpty((String) reqMap.get(updId))
								|| StringUtils.equals((String) reqMap.get(updId), "false"))) {
					isDelete = true;
				}
				name = "(行番号：".concat(String.valueOf(i + 1).concat(")："));
				args.put(NSDConstant.CHECK_ITEM.ONLYONE_SELECT.ordinal(), reqMap.get(delId));
				inputCheckList.add(setInputCheck(reqMap, updId, name, args));
			}

			String kanriSoshikiKnj = "kanriFutanLst".concat("[" + i + "]").concat("[kanriSoshikiKnj]");
			String kanriTekiyoStartYmd = "kanriFutanLst".concat("[" + i + "]").concat("[kanriTekiyoStartYmd]");
			String kanriTekiyoEndYmd = "kanriFutanLst".concat("[" + i + "]").concat("[kanriTekiyoEndYmd]");

			String futanSoshikiKnj = "kanriFutanLst".concat("[" + i + "]").concat("[futanSoshikiKnj]");
			String futanTekiyoStartYmd = "kanriFutanLst".concat("[" + i + "]").concat("[futanTekiyoStartYmd]");
			String futanTekiyoEndYmd = "kanriFutanLst".concat("[" + i + "]").concat("[futanTekiyoEndYmd]");

			if (NSDConstant.ACTION_INSERT == actionFlag
					&& StringUtils.isEmpty((String) reqMap.get(kanriSoshikiKnj))
					&& StringUtils.isEmpty((String) reqMap.get(futanSoshikiKnj))) {
				continue;
			}

			args = new HashMap<Integer, Object>();
			args.put(NSDConstant.CHECK_ITEM.EMPTY_CHECK.ordinal(), null);
			name = "管理箇所名称(行番号：".concat(String.valueOf(i + 1).concat(")："));
			inputCheckList.add(setInputCheck(reqMap, kanriSoshikiKnj, name, args));

			args = new HashMap<Integer, Object>();
			args.put(NSDConstant.CHECK_ITEM.EMPTY_CHECK.ordinal(), null);
			args.put(NSDConstant.CHECK_ITEM.DATE_FORMAT_CHECK.ordinal(), null);
			name = "管理箇所適用期間(From)(行番号：".concat(String.valueOf(i + 1).concat(")："));
			inputCheckList.add(setInputCheck(reqMap, kanriTekiyoStartYmd, name, args));

			args = new HashMap<Integer, Object>();
			args.put(NSDConstant.CHECK_ITEM.EMPTY_CHECK.ordinal(), null);
			args.put(NSDConstant.CHECK_ITEM.DATE_FORMAT_CHECK.ordinal(), null);
			name = "管理箇所適用期間(To)(行番号：".concat(String.valueOf(i + 1).concat(")："));
			inputCheckList.add(setInputCheck(reqMap, kanriTekiyoEndYmd, name, args));

			if(!isDelete){
				args = new HashMap<Integer, Object>();
				args.put(NSDConstant.CHECK_ITEM.DATE_COMPARE_CHECK.ordinal(), (String) reqMap.get(kanriTekiyoEndYmd));
				name = "管理箇所適用期間(行番号：".concat(String.valueOf(i + 1).concat(")："));
				inputCheckList.add(setInputCheck(reqMap, kanriTekiyoStartYmd, name, args));

				args = new HashMap<Integer, Object>();
				args.put(NSDConstant.CHECK_ITEM.IS_EXIST_ABDA09.ordinal(), setSelectAbda09ByWhere(reqMap, i, "kanri"));
				name = "管理箇所名称(行番号：".concat(String.valueOf(i + 1).concat(")："));
				inputCheckList.add(setInputCheck(reqMap, kanriSoshikiKnj, name, args));
			}

			args = new HashMap<Integer, Object>();
			args.put(NSDConstant.CHECK_ITEM.EMPTY_CHECK.ordinal(), null);
			name = "負担箇所名称(行番号：".concat(String.valueOf(i + 1).concat(")："));
			inputCheckList.add(setInputCheck(reqMap, futanSoshikiKnj, name, args));

			args = new HashMap<Integer, Object>();
			args.put(NSDConstant.CHECK_ITEM.EMPTY_CHECK.ordinal(), null);
			args.put(NSDConstant.CHECK_ITEM.DATE_FORMAT_CHECK.ordinal(), null);
			name = "負担箇所適用期間(From)(行番号：".concat(String.valueOf(i + 1).concat(")："));
			inputCheckList.add(setInputCheck(reqMap, futanTekiyoStartYmd, name, args));

			args = new HashMap<Integer, Object>();
			args.put(NSDConstant.CHECK_ITEM.EMPTY_CHECK.ordinal(), null);
			args.put(NSDConstant.CHECK_ITEM.DATE_FORMAT_CHECK.ordinal(), null);
			name = "負担箇所適用期間(To)(行番号：".concat(String.valueOf(i + 1).concat(")："));
			inputCheckList.add(setInputCheck(reqMap, futanTekiyoEndYmd, name, args));

			if(!isDelete){
				args = new HashMap<Integer, Object>();
				args.put(NSDConstant.CHECK_ITEM.DATE_COMPARE_CHECK.ordinal(), (String) reqMap.get(futanTekiyoEndYmd));
				name = "負担箇所適用期間(行番号：".concat(String.valueOf(i + 1).concat(")："));
				inputCheckList.add(setInputCheck(reqMap, futanTekiyoStartYmd, name, args));

				args = new HashMap<Integer, Object>();
				args.put(NSDConstant.CHECK_ITEM.IS_EXIST_ABDA09.ordinal(), setSelectAbda09ByWhere(reqMap, i, "futan"));
				name = "負担箇所名称(行番号：".concat(String.valueOf(i + 1).concat(")："));
				inputCheckList.add(setInputCheck(reqMap, kanriSoshikiKnj, name, args));

				args = new HashMap<Integer, Object>();
				args.put(NSDConstant.CHECK_ITEM.IS_EXIST_KSS015.ordinal(), setSelectKss015ByWhere(reqMap, i));
				name = "管理負担箇所(行番号：".concat(String.valueOf(i + 1).concat(")："));
				inputCheckList.add(setInputCheck(reqMap, "", name, args));
			}
		}
	}

	/**
	 * 画面明細件数取得
	 *
	 * @param reqMap
	 * @return
	 */
	private Set<String> countViewRecord(Map<String, Object> reqMap) {
		Set<String> set = new HashSet<String>();
		for (Entry<String, Object> entry : reqMap.entrySet()) {
			String[] record = entry.getKey().replace("[", ",").replace("]", "").split(",");
			if (record.length == 3) {
				set.add(record[1]);
			}
		}
		return set;
	}

	/**
	 * 組織定数検索条件を作成する
	 *
	 * @param reqMap
	 * @param idx
	 *            行番号
	 * @return
	 */
	private Kss015Key setSelectKss015ByWhere(Map<String, Object> reqMap, int idx) {

		Kss015Key kss015Key = new Kss015Key();

		String kanriSoshikiCdKey = "kanriFutanLst[" + idx + "][kanriSoshikiCd]";
		String kanriTekiyoStartYmdKey = "kanriFutanLst[" + idx + "][kanriTekiyoStartYmd]";

		String futanSoshikiCdKey = "kanriFutanLst[" + idx + "][futanSoshikiCd]";
		String futanTekiyoStartYmdKey = "kanriFutanLst[" + idx + "][futanTekiyoStartYmd]";

		// 管理箇所コード
		kss015Key.setKanriSoshikiCd(reqMap.get(kanriSoshikiCdKey).toString().trim());
		// 管理箇所適用開始年月日
		String kanriTekiyoStartYmd = (String) reqMap.get(kanriTekiyoStartYmdKey);
		if (StringUtils.isNotEmpty(kanriTekiyoStartYmd)) {
			kss015Key.setKanriTekiyoStartYmd(NSDDateUtils.parseStrToCal(kanriTekiyoStartYmd).getTime());
		}

		// 負担箇所コード
		kss015Key.setFutanSoshikiCd(reqMap.get(futanSoshikiCdKey).toString().trim());
		// 負担箇所適用開始年月日
		String futanTekiyoStartYmd = (String) reqMap.get(futanTekiyoStartYmdKey);
		if (StringUtils.isNotEmpty(futanTekiyoStartYmd)) {
			kss015Key.setFutanTekiyoStartYmd(NSDDateUtils.parseStrToCal(futanTekiyoStartYmd).getTime());
		}

		return kss015Key;
	}

	/**
	 * 組織定数検索条件を作成する
	 *
	 * @param reqMap
	 * @param idx
	 *            行番号
	 * @param soshikiName
	 *            管理: 「kanri」 負担: 「futan」
	 * @return
	 */
	private Abda09 setSelectAbda09ByWhere(Map<String, Object> reqMap, int idx, String soshikiName) {

		Abda09 abda09 = new Abda09();

		String soshikiCdKey = "kanriFutanLst[" + idx + "][" + soshikiName + "SoshikiCd]";

		String tekiyoStartYmdKey = "kanriFutanLst[" + idx + "][" + soshikiName + "TekiyoStartYmd]";

		// 画面入力した組織名
		abda09.setAb9SoshikCod((String) reqMap.get(soshikiCdKey));
		// 適用開始日
		String tekiyoStartYmd = (String) reqMap.get(tekiyoStartYmdKey);
		if (StringUtils.isNotEmpty((tekiyoStartYmd))) {
			abda09.setAb9TekiyfYmd(NSDDateUtils.parseStrToCal(tekiyoStartYmd).getTime());
		}

		return abda09;
	}

}