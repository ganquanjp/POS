/***********************************************************************
*
*業務名: 工事精算システム
*機能名: 候補内容(共通処理)
*
*機能概要: 入力中の内容を部分一致にて検索し、
*          候補を入力フォーム下部に表示のデータを取得する
*
*JavaＶｅｒ：J2SE1.8.0準拠
*
*更新履歴: Ver.1.00 2018/03/13　NSD　新規作成
***********************************************************************/
package jp.co.nsd.nkssweb.service;

import java.util.List;

import jp.co.nsd.nkssweb.dao.Aads01;
import jp.co.nsd.nkssweb.dao.Abda09;
import jp.co.nsd.nkssweb.dao.Kss002;
import jp.co.nsd.nkssweb.dao.Kss011;
import jp.co.nsd.nkssweb.dao.Kss013;

/**
 * 候補内容(共通処理)
 *
 * @version 1.00
 */
public interface AutocompleteService {

	/**
	 * ユーザ情報全件取得
	 *
	 * @version 1.00
	 */
	List<Kss013> getUserMaster();

	/**
	 * 件名マスタを取得
	 *
	 * @return
	 */
	List<Kss002> getKenmeiMaster(String siyoStartYmd);

	/**
	 * 組織マスタを取得
	 *
	 * @return
	 */
	List<Kss011> getSoshikiMaster();

	/**
	 * 組織定数の組織名称を取得
	 *
	 * @return
	 */
	List<Abda09> getSoshikTeisuMaster();

	/**
	 * 会計整理年月を取得
	 *
	 * @return
	 */
	List<Aads01> getKaikeiYmMaster();

}
