package jp.co.nsd.nkssweb.dao;

import java.util.Date;

public class Awda01 {
    private String aw1ShuCod;

    private String aw1ShuKnj;

    private Short aw1ZeizanRit;

    private Short aw1ShozanRit;

    private Short aw1ZlstzanRit;

    private Short aw1SlstzanRit;

    private String aw1KotshuCod;

    private String aw1JtssnKbn;

    private String aw1RenynFlg;

    private String aw1SisanKbn;

    private String aw1SkyKbn;

    private String aw1ShkhohCod;

    private String aw1SshkhohCod;

    private Short aw1ZeityoYs;

    private Short aw1ShotyoYs;

    private Integer aw1UpdateCnt;

    private Date aw1TorokDh;

    private String aw1TorshaCod;

    private Date aw1UpdateDh;

    private String aw1UpdshaCod;

    public String getAw1ShuCod() {
        return aw1ShuCod;
    }

    public void setAw1ShuCod(String aw1ShuCod) {
        this.aw1ShuCod = aw1ShuCod == null ? null : aw1ShuCod.trim();
    }

    public String getAw1ShuKnj() {
        return aw1ShuKnj;
    }

    public void setAw1ShuKnj(String aw1ShuKnj) {
        this.aw1ShuKnj = aw1ShuKnj == null ? null : aw1ShuKnj.trim();
    }

    public Short getAw1ZeizanRit() {
        return aw1ZeizanRit;
    }

    public void setAw1ZeizanRit(Short aw1ZeizanRit) {
        this.aw1ZeizanRit = aw1ZeizanRit;
    }

    public Short getAw1ShozanRit() {
        return aw1ShozanRit;
    }

    public void setAw1ShozanRit(Short aw1ShozanRit) {
        this.aw1ShozanRit = aw1ShozanRit;
    }

    public Short getAw1ZlstzanRit() {
        return aw1ZlstzanRit;
    }

    public void setAw1ZlstzanRit(Short aw1ZlstzanRit) {
        this.aw1ZlstzanRit = aw1ZlstzanRit;
    }

    public Short getAw1SlstzanRit() {
        return aw1SlstzanRit;
    }

    public void setAw1SlstzanRit(Short aw1SlstzanRit) {
        this.aw1SlstzanRit = aw1SlstzanRit;
    }

    public String getAw1KotshuCod() {
        return aw1KotshuCod;
    }

    public void setAw1KotshuCod(String aw1KotshuCod) {
        this.aw1KotshuCod = aw1KotshuCod == null ? null : aw1KotshuCod.trim();
    }

    public String getAw1JtssnKbn() {
        return aw1JtssnKbn;
    }

    public void setAw1JtssnKbn(String aw1JtssnKbn) {
        this.aw1JtssnKbn = aw1JtssnKbn == null ? null : aw1JtssnKbn.trim();
    }

    public String getAw1RenynFlg() {
        return aw1RenynFlg;
    }

    public void setAw1RenynFlg(String aw1RenynFlg) {
        this.aw1RenynFlg = aw1RenynFlg == null ? null : aw1RenynFlg.trim();
    }

    public String getAw1SisanKbn() {
        return aw1SisanKbn;
    }

    public void setAw1SisanKbn(String aw1SisanKbn) {
        this.aw1SisanKbn = aw1SisanKbn == null ? null : aw1SisanKbn.trim();
    }

    public String getAw1SkyKbn() {
        return aw1SkyKbn;
    }

    public void setAw1SkyKbn(String aw1SkyKbn) {
        this.aw1SkyKbn = aw1SkyKbn == null ? null : aw1SkyKbn.trim();
    }

    public String getAw1ShkhohCod() {
        return aw1ShkhohCod;
    }

    public void setAw1ShkhohCod(String aw1ShkhohCod) {
        this.aw1ShkhohCod = aw1ShkhohCod == null ? null : aw1ShkhohCod.trim();
    }

    public String getAw1SshkhohCod() {
        return aw1SshkhohCod;
    }

    public void setAw1SshkhohCod(String aw1SshkhohCod) {
        this.aw1SshkhohCod = aw1SshkhohCod == null ? null : aw1SshkhohCod.trim();
    }

    public Short getAw1ZeityoYs() {
        return aw1ZeityoYs;
    }

    public void setAw1ZeityoYs(Short aw1ZeityoYs) {
        this.aw1ZeityoYs = aw1ZeityoYs;
    }

    public Short getAw1ShotyoYs() {
        return aw1ShotyoYs;
    }

    public void setAw1ShotyoYs(Short aw1ShotyoYs) {
        this.aw1ShotyoYs = aw1ShotyoYs;
    }

    public Integer getAw1UpdateCnt() {
        return aw1UpdateCnt;
    }

    public void setAw1UpdateCnt(Integer aw1UpdateCnt) {
        this.aw1UpdateCnt = aw1UpdateCnt;
    }

    public Date getAw1TorokDh() {
        return aw1TorokDh;
    }

    public void setAw1TorokDh(Date aw1TorokDh) {
        this.aw1TorokDh = aw1TorokDh;
    }

    public String getAw1TorshaCod() {
        return aw1TorshaCod;
    }

    public void setAw1TorshaCod(String aw1TorshaCod) {
        this.aw1TorshaCod = aw1TorshaCod == null ? null : aw1TorshaCod.trim();
    }

    public Date getAw1UpdateDh() {
        return aw1UpdateDh;
    }

    public void setAw1UpdateDh(Date aw1UpdateDh) {
        this.aw1UpdateDh = aw1UpdateDh;
    }

    public String getAw1UpdshaCod() {
        return aw1UpdshaCod;
    }

    public void setAw1UpdshaCod(String aw1UpdshaCod) {
        this.aw1UpdshaCod = aw1UpdshaCod == null ? null : aw1UpdshaCod.trim();
    }
}