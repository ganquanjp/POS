package jp.co.nsd.nkssweb.dao;

import java.math.BigDecimal;

public class SeisanshoShoninPrint {

	// 版数
	private String hansu;

	// 使用開始日
	private String siyoStartYmd;

	// 工事件名コード
	private String kenmeiCd;

	// 工事件名名称
	private String kenmeiNm;

	// 精算箇所コード
	private String soshikiCd;

	// 精算箇所名称
	private String soshikiRenNm;

	// 精算書Ｎｏ.
	private String seisanShoNo;

	// 適用
	private String tekiyo;

	// 総件数
	private Long shutokuSisanCnt;

	// 総額
	private BigDecimal shutokuKagaku;

	// 種類コード
	private String shuruiCd;

	// 構造コード
	private String kouzouCd;

	// 資産単位コード
	private String shisanTaniCd;

	// 種別４コード
	private String kamokuCd1;

	// 種別５コード
	private String kamokuCd2;

	// 種別６コード
	private String kamokuCd3;

	// 取引先コード
	private String torihikiSakiCd;

	// 取引先名称
	private String torihikiSakiNm;

	// 取得価額
	private BigDecimal rwgGetkgkYen;

	// 種類名称
	private String shuKnj;

	// 構造名称
	private String kouKnj;

	// 細目名称
	private String saiKnj;

	// 種別４名称
	private String shu4Knj;

	// 種別５名称
	private String shu5Knj;

	// 種別６名称
	private String shu6Knj;

	// 件数
	private Long kenSu;

	// 固定資産番号
	private String koteiShisanNo;

	// 固定資産名所
	private String koteiShisanNm;

	// 取得年月日
	private String shutokuYmd;

	// 管理箇所コード
	private String kanriSoshikiCd;

	// 負担箇所コード
	private String futanSoshikiCd;

	// 場所コード
	private String bashoCd;

	// 数量
	private String suryo;

	// 取得価額（合計）
	private BigDecimal rwgGetkgkYenSum;

	// 適用１
	private String tekiyo1;

	// 適用２
	private String tekiyo2;

	// 適用３
	private String tekiyo3;

	// 適用４
	private String tekiyo4;

	// 適用５
	private String tekiyo5;

	// 製品名/型番/製品会社名称
	private String seihinKataSeizo;

	// 親固定資産番号
	private String oyaKoteiShisanNo;

	// 枝番
	private String edaNo;

	// 工事担当者
	private String kojiTantoUserNm;

	// 工事担当箇所
	private String kojiTantoSoshikiCd;

	// 償却区分＿税＿名称
	private String syokyakuMeishoKnjZei;

	// 償却区分＿商＿名称
	private String syokyakuMeishoKnjSho;

	// 場所名称
	private String bashoKnj;

	// 単位名称
	private String taniKnj;

	// 管理箇所名称
	private String kanriSoshikKnj;

	// 負担箇所名称
	private String futanSoshikKnj;

	// 物品
	private BigDecimal buppin;

	// 工費
	private BigDecimal kouhiGaku;

	// 総係費
	private BigDecimal souKeihiGaku;

	// 耐用年数（税）
	private String taiyoNensuZei;

	// 耐用年数（商）
	private String taiyoNensuSho;

	public String getHansu() {
		return hansu;
	}

	public void setHansu(String hansu) {
		this.hansu = hansu;
	}

	public String getSiyoStartYmd() {
		return siyoStartYmd;
	}

	public void setSiyoStartYmd(String siyoStartYmd) {
		this.siyoStartYmd = siyoStartYmd;
	}

	public String getKenmeiCd() {
		return kenmeiCd;
	}

	public void setKenmeiCd(String kenmeiCd) {
		this.kenmeiCd = kenmeiCd;
	}

	public String getKenmeiNm() {
		return kenmeiNm;
	}

	public void setKenmeiNm(String kenmeiNm) {
		this.kenmeiNm = kenmeiNm;
	}

	public String getSoshikiCd() {
		return soshikiCd;
	}

	public void setSoshikiCd(String soshikiCd) {
		this.soshikiCd = soshikiCd;
	}

	public String getSoshikiRenNm() {
		return soshikiRenNm;
	}

	public void setSoshikiRenNm(String soshikiRenNm) {
		this.soshikiRenNm = soshikiRenNm;
	}

	public String getSeisanShoNo() {
		return seisanShoNo;
	}

	public void setSeisanShoNo(String seisanShoNo) {
		this.seisanShoNo = seisanShoNo;
	}

	public String getTekiyo() {
		return tekiyo;
	}

	public void setTekiyo(String tekiyo) {
		this.tekiyo = tekiyo;
	}

	public Long getShutokuSisanCnt() {
		return shutokuSisanCnt;
	}

	public void setShutokuSisanCnt(Long shutokuSisanCnt) {
		this.shutokuSisanCnt = shutokuSisanCnt;
	}

	public BigDecimal getShutokuKagaku() {
		return shutokuKagaku;
	}

	public void setShutokuKagaku(BigDecimal shutokuKagaku) {
		this.shutokuKagaku = shutokuKagaku;
	}

	public String getShuruiCd() {
		return shuruiCd;
	}

	public void setShuruiCd(String shuruiCd) {
		this.shuruiCd = shuruiCd;
	}

	public String getKouzouCd() {
		return kouzouCd;
	}

	public void setKouzouCd(String kouzouCd) {
		this.kouzouCd = kouzouCd;
	}

	public String getShisanTaniCd() {
		return shisanTaniCd;
	}

	public void setShisanTaniCd(String shisanTaniCd) {
		this.shisanTaniCd = shisanTaniCd;
	}

	public String getKamokuCd1() {
		return kamokuCd1;
	}

	public void setKamokuCd1(String kamokuCd1) {
		this.kamokuCd1 = kamokuCd1;
	}

	public String getKamokuCd2() {
		return kamokuCd2;
	}

	public void setKamokuCd2(String kamokuCd2) {
		this.kamokuCd2 = kamokuCd2;
	}

	public String getKamokuCd3() {
		return kamokuCd3;
	}

	public void setKamokuCd3(String kamokuCd3) {
		this.kamokuCd3 = kamokuCd3;
	}

	public String getTorihikiSakiCd() {
		return torihikiSakiCd;
	}

	public void setTorihikiSakiCd(String torihikiSakiCd) {
		this.torihikiSakiCd = torihikiSakiCd;
	}

	public String getTorihikiSakiNm() {
		return torihikiSakiNm;
	}

	public void setTorihikiSakiNm(String torihikiSakiNm) {
		this.torihikiSakiNm = torihikiSakiNm;
	}

	public BigDecimal getRwgGetkgkYen() {
		return rwgGetkgkYen;
	}

	public void setRwgGetkgkYen(BigDecimal rwgGetkgkYen) {
		this.rwgGetkgkYen = rwgGetkgkYen;
	}

	public String getShuKnj() {
		return shuKnj;
	}

	public void setShuKnj(String shuKnj) {
		this.shuKnj = shuKnj;
	}

	public String getKouKnj() {
		return kouKnj;
	}

	public void setKouKnj(String kouKnj) {
		this.kouKnj = kouKnj;
	}

	public String getSaiKnj() {
		return saiKnj;
	}

	public void setSaiKnj(String saiKnj) {
		this.saiKnj = saiKnj;
	}

	public String getShu4Knj() {
		return shu4Knj;
	}

	public void setShu4Knj(String shu4Knj) {
		this.shu4Knj = shu4Knj;
	}

	public String getShu5Knj() {
		return shu5Knj;
	}

	public void setShu5Knj(String shu5Knj) {
		this.shu5Knj = shu5Knj;
	}

	public String getShu6Knj() {
		return shu6Knj;
	}

	public void setShu6Knj(String shu6Knj) {
		this.shu6Knj = shu6Knj;
	}

	public Long getKenSu() {
		return kenSu;
	}

	public void setKenSu(Long kenSu) {
		this.kenSu = kenSu;
	}

	public String getKoteiShisanNo() {
		return koteiShisanNo;
	}

	public void setKoteiShisanNo(String koteiShisanNo) {
		this.koteiShisanNo = koteiShisanNo;
	}

	public String getKoteiShisanNm() {
		return koteiShisanNm;
	}

	public void setKoteiShisanNm(String koteiShisanNm) {
		this.koteiShisanNm = koteiShisanNm;
	}

	public String getShutokuYmd() {
		return shutokuYmd;
	}

	public void setShutokuYmd(String shutokuYmd) {
		this.shutokuYmd = shutokuYmd;
	}

	public String getKanriSoshikiCd() {
		return kanriSoshikiCd;
	}

	public void setKanriSoshikiCd(String kanriSoshikiCd) {
		this.kanriSoshikiCd = kanriSoshikiCd;
	}

	public String getFutanSoshikiCd() {
		return futanSoshikiCd;
	}

	public void setFutanSoshikiCd(String futanSoshikiCd) {
		this.futanSoshikiCd = futanSoshikiCd;
	}

	public String getBashoCd() {
		return bashoCd;
	}

	public void setBashoCd(String bashoCd) {
		this.bashoCd = bashoCd;
	}

	public String getSuryo() {
		return suryo;
	}

	public void setSuryo(String suryo) {
		this.suryo = suryo;
	}

	public BigDecimal getRwgGetkgkYenSum() {
		return rwgGetkgkYenSum;
	}

	public void setRwgGetkgkYenSum(BigDecimal rwgGetkgkYenSum) {
		this.rwgGetkgkYenSum = rwgGetkgkYenSum;
	}

	public String getTekiyo1() {
		return tekiyo1;
	}

	public void setTekiyo1(String tekiyo1) {
		this.tekiyo1 = tekiyo1;
	}

	public String getTekiyo2() {
		return tekiyo2;
	}

	public void setTekiyo2(String tekiyo2) {
		this.tekiyo2 = tekiyo2;
	}

	public String getTekiyo3() {
		return tekiyo3;
	}

	public void setTekiyo3(String tekiyo3) {
		this.tekiyo3 = tekiyo3;
	}

	public String getTekiyo4() {
		return tekiyo4;
	}

	public void setTekiyo4(String tekiyo4) {
		this.tekiyo4 = tekiyo4;
	}

	public String getTekiyo5() {
		return tekiyo5;
	}

	public void setTekiyo5(String tekiyo5) {
		this.tekiyo5 = tekiyo5;
	}

	public String getSeihinKataSeizo() {
		return seihinKataSeizo;
	}

	public void setSeihinKataSeizo(String seihinKataSeizo) {
		this.seihinKataSeizo = seihinKataSeizo;
	}

	public String getOyaKoteiShisanNo() {
		return oyaKoteiShisanNo;
	}

	public void setOyaKoteiShisanNo(String oyaKoteiShisanNo) {
		this.oyaKoteiShisanNo = oyaKoteiShisanNo;
	}

	public String getEdaNo() {
		return edaNo;
	}

	public void setEdaNo(String edaNo) {
		this.edaNo = edaNo;
	}

	public String getKojiTantoUserNm() {
		return kojiTantoUserNm;
	}

	public void setKojiTantoUserNm(String kojiTantoUserNm) {
		this.kojiTantoUserNm = kojiTantoUserNm;
	}

	public String getKojiTantoSoshikiCd() {
		return kojiTantoSoshikiCd;
	}

	public void setKojiTantoSoshikiCd(String kojiTantoSoshikiCd) {
		this.kojiTantoSoshikiCd = kojiTantoSoshikiCd;
	}

	public String getSyokyakuMeishoKnjZei() {
		return syokyakuMeishoKnjZei;
	}

	public void setSyokyakuMeishoKnjZei(String syokyakuMeishoKnjZei) {
		this.syokyakuMeishoKnjZei = syokyakuMeishoKnjZei;
	}

	public String getSyokyakuMeishoKnjSho() {
		return syokyakuMeishoKnjSho;
	}

	public void setSyokyakuMeishoKnjSho(String syokyakuMeishoKnjSho) {
		this.syokyakuMeishoKnjSho = syokyakuMeishoKnjSho;
	}

	public String getBashoKnj() {
		return bashoKnj;
	}

	public void setBashoKnj(String bashoKnj) {
		this.bashoKnj = bashoKnj;
	}

	public String getTaniKnj() {
		return taniKnj;
	}

	public void setTaniKnj(String taniKnj) {
		this.taniKnj = taniKnj;
	}

	public String getKanriSoshikKnj() {
		return kanriSoshikKnj;
	}

	public void setKanriSoshikKnj(String kanriSoshikKnj) {
		this.kanriSoshikKnj = kanriSoshikKnj;
	}

	public String getFutanSoshikKnj() {
		return futanSoshikKnj;
	}

	public void setFutanSoshikKnj(String futanSoshikKnj) {
		this.futanSoshikKnj = futanSoshikKnj;
	}

	public BigDecimal getBuppin() {
		return buppin;
	}

	public void setBuppin(BigDecimal buppin) {
		this.buppin = buppin;
	}

	public BigDecimal getKouhiGaku() {
		return kouhiGaku;
	}

	public void setKouhiGaku(BigDecimal kouhiGaku) {
		this.kouhiGaku = kouhiGaku;
	}

	public BigDecimal getSouKeihiGaku() {
		return souKeihiGaku;
	}

	public void setSouKeihiGaku(BigDecimal souKeihiGaku) {
		this.souKeihiGaku = souKeihiGaku;
	}

	public String getTaiyoNensuZei() {
		return taiyoNensuZei;
	}

	public void setTaiyoNensuZei(String taiyoNensuZei) {
		this.taiyoNensuZei = taiyoNensuZei;
	}

	public String getTaiyoNensuSho() {
		return taiyoNensuSho;
	}

	public void setTaiyoNensuSho(String taiyoNensuSho) {
		this.taiyoNensuSho = taiyoNensuSho;
	}

}