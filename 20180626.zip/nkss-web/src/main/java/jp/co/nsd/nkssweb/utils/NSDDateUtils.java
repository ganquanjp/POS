package jp.co.nsd.nkssweb.utils;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.ParsePosition;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;

import org.apache.commons.lang.StringUtils;

/**
 * システム共通ユーティリティ
 *
 * @author nsdH272059
 *
 */
public class NSDDateUtils {

	/**
	 * 文字列はjava.util.Dateに変換
	 *
	 * @param time
	 * @return
	 */
	public static Date stringToDate(String time) {
		SimpleDateFormat formatter;
		int tempPos = time.indexOf("AD");
		time = time.trim();
		formatter = new SimpleDateFormat("yyyy.MM.dd G 'at' hh:mm:ss z");
		if (tempPos > -1) {
			time = time.substring(0, tempPos) + "西暦" + time.substring(tempPos + "AD".length());// china
			formatter = new SimpleDateFormat("yyyy.MM.dd G 'at' hh:mm:ss z");
		}
		tempPos = time.indexOf("-");
		if (tempPos > -1 && (time.indexOf(" ") < 0)) {
			formatter = new SimpleDateFormat("yyyyMMddHHmmssZ");
		} else if ((time.indexOf("/") > -1) && (time.indexOf(" ") > -1)) {
			formatter = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
		} else if ((time.indexOf("-") > -1) && (time.indexOf(" ") > -1)) {
			formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		} else if ((time.indexOf("/") > -1) && (time.indexOf("am") > -1) || (time.indexOf("pm") > -1)) {
			formatter = new SimpleDateFormat("yyyy-MM-dd KK:mm:ss a");
		} else if ((time.indexOf("-") > -1) && (time.indexOf("am") > -1) || (time.indexOf("pm") > -1)) {
			formatter = new SimpleDateFormat("yyyy-MM-dd KK:mm:ss a");
		}
		ParsePosition pos = new ParsePosition(0);
		java.util.Date ctime = formatter.parse(time, pos);

		return ctime;
	}

	/**
	 * 文字列はjava.util.Dateに変換
	 *
	 * @param dateStr
	 * @param dateFormatter
	 * @return
	 * @throws ParseException
	 */
	public static Date stringToDate(String dateStr, String dateFormatter) {
		SimpleDateFormat formatter;
		formatter = new SimpleDateFormat(dateFormatter);
		ParsePosition pos = new ParsePosition(0);
		java.util.Date date = formatter.parse(dateStr, pos);
		return date;
	}

	/**
	 * java.util.Dateは文字列に変換
	 *
	 * @param time
	 * @param dateFormatter
	 * @return
	 */
	public static String dateToString(Date time, String dateFormatter) {
		SimpleDateFormat formatter;
		formatter = new SimpleDateFormat(dateFormatter);
		String ctime = formatter.format(time);

		return ctime;
	}

	/**
	 * 日付の年を取得
	 *
	 * @param time
	 * @param addYear
	 * @return
	 */
	public static String dateToMM(Date time, int addYear) {
		Calendar cal = Calendar.getInstance();
		cal.setTime(time);
		cal.add(Calendar.YEAR, addYear);

		return dateToString(cal.getTime(), "yyyyMMdd").substring(4, 6);
	}

	/**
	 * 日付の月を取得
	 *
	 * @param time
	 * @param addMonth
	 * @return
	 */
	public static String dateToYYYY(Date time, int addMonth) {
		Calendar cal = Calendar.getInstance();
		cal.setTime(time);
		cal.add(Calendar.MONTH, addMonth);

		return dateToString(time, "yyyyMMdd").substring(0, 4);
	}

	/**
	 * システム時刻
	 *
	 * @return
	 */
	public static String Now() {
		return dateToString(new Date(), "yyyy-MM-dd HH:mm:ss");
	}

	/**
	 * システム時刻、フォーマット付き
	 *
	 * @param dateFormatter
	 * @return
	 */
	public static String Now(String dateFormatter) {
		return dateToString(new Date(), dateFormatter);
	}

	/**
	 * <p>
	 * [概 要] String型⇒Calendar型への変換処理
	 * </p>
	 * <p>
	 * [詳 細]
	 * </p>
	 * <p>
	 * [備 考]
	 * </p>
	 *
	 * @param str
	 *            変換前日付文字列
	 * @return Calendar型オブジェクト（変換に失敗した場合はnullを返します。）
	 */
	public static Calendar parseStrToCal(String str) {
		Calendar cal = new GregorianCalendar();
		if (str == null) {
			cal = null;
		} else {
			try {
				cal.setTime(DateFormat.getDateInstance().parse(str.replace("-", "/")));
			} catch (ParseException e) {
				cal = null;
			}
		}
		return cal;
	}

	/**
	 * ミリ秒まで時刻に変換する。
	 *
	 * @param dateTime
	 *            時刻フォーマット：yyyy-MM-dd HH:mm:ss yyyy-MM-dd HH:mm:ss. yyyy-MM-dd
	 *            HH:mm:ss.S yyyy-MM-dd HH:mm:ss.SSS
	 *
	 * @return 時刻フォーマット：yyyy-MM-dd HH:mm:ss.SSS
	 */
	public static String toMillisecondWithSSS(String dateTime) {

		String millisecond = NSDConstant.BLANK_STRING;

		switch (dateTime.indexOf(NSDConstant.STRING_DOT)) {
		case -1:
			// ミリ秒なしの場合、そのまま返却
			millisecond = dateTime.concat(NSDConstant.STRING_DOT).concat("000");
			break;
		case 19:
			// ミリ秒(３桁未満の場合、後ろに３桁まで０を補足、３桁以上の場合、切捨て)
			String ms = dateTime.substring(20);
			if (ms.length() < 3) {
				ms = NSDCommUtils.addCharForStr(ms, '0', 3);
			} else {
				ms = ms.substring(0, 3);
			}
			millisecond = dateTime.substring(0, 19).concat(NSDConstant.STRING_DOT).concat(ms);
			break;
		default:
			// それ以外の場合、そのまま返却
			millisecond = dateTime;
			break;
		}

		return millisecond;
	}

	/**
	 * ミリ秒まで時刻比較
	 *
	 * @param dateTime1
	 * @param dateTime2
	 * @return
	 */
	public static boolean compareDateByMillisecond(Date dateTime1, Date dateTime2) {

		// 「空」の判定
		switch (NSDCommUtils.compareObjectForIsEmpty(dateTime1, dateTime2)) {
		case 1:
			return true;
		case 2:
			return false;
		}

		String ms1 = converDateToMillisecond(dateTime1);
		String ms2 = converDateToMillisecond(dateTime2);
		if (ms1.equals(ms2)) {
			return true;
		}
		return false;

	}

	/**
	 * ミリ秒まで時刻比較
	 *
	 * @param dateTime1
	 * @param dateTime2
	 * @return
	 */
	public static boolean compareDateByMillisecond(String dateTime1, String dateTime2) {

		// 「空」の判定
		switch (NSDCommUtils.compareObjectForIsEmpty(dateTime1, dateTime2)) {
		case 1:
			return true;
		case 2:
			return false;
		}

		String ms1 = converDateToMillisecond(dateTime1);
		String ms2 = converDateToMillisecond(dateTime2);
		if (ms1.equals(ms2)) {
			return true;
		}

		return false;
	}

	/**
	 * ミリ秒まで時刻比較
	 *
	 * @param dateTime1
	 * @param dateTime2
	 * @return
	 */
	public static boolean compareDateByMillisecond(String dateTime1, Date dateTime2) {

		// 「空」の判定
		switch (NSDCommUtils.compareObjectForIsEmpty(dateTime1, dateTime2)) {
		case 1:
			return true;
		case 2:
			return false;
		}

		String ms1 = converDateToMillisecond(dateTime1);
		String ms2 = converDateToMillisecond(dateTime2);
		if (ms1.equals(ms2)) {
			return true;
		}

		return false;
	}

	/**
	 * ミリ秒まで時刻比較
	 *
	 * @param dateTime1
	 * @param dateTime2
	 * @return
	 */
	public static boolean compareDateByMillisecond(Date dateTime1, String dateTime2) {

		// 「空」の判定
		switch (NSDCommUtils.compareObjectForIsEmpty(dateTime1, dateTime2)) {
		case 1:
			return true;
		case 2:
			return false;
		}

		String ms1 = converDateToMillisecond(dateTime1);
		String ms2 = converDateToMillisecond(dateTime2);
		if (ms1.equals(ms2)) {
			return true;
		}
		return false;
	}

	/**
	 * 日付よりミリ秒を返却
	 *
	 * @param date
	 * @return
	 */
	public static String converDateToMillisecond(Date date) {
		String dateStr = dateToString(date, "yyyy-MM-dd HH:mm:ss.SSS");
		String dateFormat = NSDDateUtils.toMillisecondWithSSS(dateStr);
		return dateFormat;
	}

	/**
	 * 日付文字列よりミリ秒を返却
	 *
	 * @param date
	 * @return
	 */
	public static String converDateToMillisecond(String date) {
		String dateFormat = NSDDateUtils.toMillisecondWithSSS(date);
		return dateFormat;
	}

	/**
	 * 日付From-To大小比較チェック
	 *
	 * @param dateFrom
	 * @param dateTo
	 * @return
	 */
	public static int compareDate(String dateFrom, Object dateTo) {

		// 日付（From）と日付（To）存在の場合
		if (!StringUtils.isEmpty(dateFrom) && !StringUtils.isEmpty((String) dateTo)) {
			java.sql.Date dateF = java.sql.Date.valueOf(dateFrom.trim());
			java.sql.Date dateT = java.sql.Date.valueOf(((String) dateTo).trim());
			return dateF.compareTo(dateT);
		}
		return 9;
	}
}
