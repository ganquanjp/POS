/***********************************************************************
*
*業務名: 工事精算システム
*機能名: 除却（登録・修正・削除）(ログ出力処理)
*
*機能概要: 除却情報を処理する。
*
*JavaＶｅｒ：J2SE1.8.0準拠
*
*更新履歴: Ver.1.00 2018/03/06　NSD　新規作成
***********************************************************************/

package jp.co.nsd.nkssweb.controller.seisanshoshutoku;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import jp.co.nsd.nkssweb.controller.BaseController;
import jp.co.nsd.nkssweb.dao.InputCheck;
import jp.co.nsd.nkssweb.dao.Kss004;
import jp.co.nsd.nkssweb.dao.SeisanshoShonin;
import jp.co.nsd.nkssweb.dao.SeisanshoShoninShokai;
import jp.co.nsd.nkssweb.service.CommService;
import jp.co.nsd.nkssweb.service.SystemService;
import jp.co.nsd.nkssweb.service.seisanshoshutoku.SeisanshoShoninService;
import jp.co.nsd.nkssweb.utils.NSDConstant;
import jp.co.nsd.nkssweb.utils.NSDDataCheck;

/**
 * 承認（検索・照会・更新）処理
 *
 * @version 1.00
 */
@RestController
public class SeisanshoShoninController extends BaseController {

	@Autowired
	private SeisanshoShoninService seisanshoShoninService;

	@Autowired
	protected SystemService systemService;

	@Autowired
	private NSDDataCheck nsdDataCheck;

	@Autowired
	private CommService commService;

	/**
	 * 取得承認（検索）処理
	 *
	 * @param reqMap
	 *            INPUTパラメータ
	 * @return 承認情報データ
	 * @exception Exception
	 * @version 1.00
	 */
	@RequestMapping(value = "/seisanshoShonin-selectByWhere", method = RequestMethod.POST)
	public Map<String, Object> selectByWhere(@RequestParam Map<String, Object> reqMap) throws Exception {

		Map<String, Object> resultMap = new HashMap<String, Object>();

		// 入力チェック
		String errStr = inputCheckForSearch(reqMap);
		if (StringUtils.isNotEmpty(errStr)) {
			return setMsgToResultMap(resultMap, NSDConstant.MSGID_INPUT_ERROR, errStr);
		}

		SeisanshoShonin seisanshoShonin = new SeisanshoShonin();

		List<SeisanshoShonin> sssSNLst = new ArrayList<SeisanshoShonin>();

		// Mapの情報をBeanのプロパティにセット
		BeanUtils.populate(seisanshoShonin, reqMap);

		// サービス呼び出し
		sssSNLst = seisanshoShoninService.getshoninInfo(seisanshoShonin);

		// 検索結果を返却Mapに設定する
		setDataToResultMap(resultMap, sssSNLst);

		return resultMap;
	}

	/**
	 * 検索の入力データチェック
	 *
	 * @param reqMap
	 *            INPUTパラメータ
	 * @return エラーメッセージID
	 * @version 1.00
	 */
	private String inputCheckForSearch(Map<String, Object> reqMap) {

		List<InputCheck> inputCheckList = getCheckItemListForSearch(reqMap);
		return nsdDataCheck.dataCheck(inputCheckList);

	}

	/**
	 * 検索の入力チェックリストを定義
	 *
	 * @param reqMap
	 *            INPUTパラメータ
	 * @return
	 */
	private List<InputCheck> getCheckItemListForSearch(Map<String, Object> reqMap) {

		List<InputCheck> inputCheckList = new ArrayList<InputCheck>();
		Map<Integer, Object> args;

		// 使用開始年月日
		if (StringUtils.isNotEmpty((String) reqMap.get("siyoStartYmdFrom"))) {
			args = new HashMap<Integer, Object>();
			args.put(NSDConstant.CHECK_ITEM.DATE_FORMAT_CHECK.ordinal(), null);
			inputCheckList.add(setInputCheck(reqMap, "siyoStartYmdFrom", "使用開始年月日(From)：", args));
		}

		if (StringUtils.isNotEmpty((String) reqMap.get("siyoStartYmdTo"))) {
			args = new HashMap<Integer, Object>();
			args.put(NSDConstant.CHECK_ITEM.DATE_FORMAT_CHECK.ordinal(), null);
			inputCheckList.add(setInputCheck(reqMap, "siyoStartYmdTo", "使用開始年月日(To)：", args));
		}

		args = new HashMap<Integer, Object>();
		args.put(NSDConstant.CHECK_ITEM.DATE_COMPARE_CHECK.ordinal(), (String) reqMap.get("siyoStartYmdTo"));
		inputCheckList.add(setInputCheck(reqMap, "siyoStartYmdFrom", "使用開始年月日：", args));

		return inputCheckList;
	}

	/**
	 * 取得承認（照会）処理
	 *
	 * @param reqMap
	 *            INPUTパラメータ
	 * @return 承認情報データ
	 * @exception Exception
	 * @version 1.00
	 */
	@RequestMapping(value = "/seisanshoShonin-selectBySeisanShoNo", method = RequestMethod.POST)
	public Map<String, Object> selectBySeisanShoNo(@RequestParam Map<String, Object> reqMap) throws Exception {

		Map<String, Object> resultMap = new HashMap<String, Object>();

		SeisanshoShoninShokai seisanshoShoninShokai = new SeisanshoShoninShokai();
		SeisanshoShoninShokai sssSnSk = new SeisanshoShoninShokai();

		// Mapの情報をBeanのプロパティにセット
		BeanUtils.populate(seisanshoShoninShokai, reqMap);

		// サービス呼び出し
		sssSnSk = seisanshoShoninService.getshutokuInfoBySeisanShoNo(seisanshoShoninShokai);

		// 検索結果を返却Mapに設定する
		setDataToResultMap(resultMap, sssSnSk);

		return resultMap;
	}

	/**
	 * 取得（承認）印刷処理
	 *
	 * @param reqMap
	 *            INPUTパラメータ
	 * @return 取得情報データ
	 * @throws Exception
	 * @version 1.00
	 */
	@RequestMapping(value = "/seisanshoshutokuShoninkosin-printing", method = RequestMethod.POST)
	public Map<String, Object> printing(HttpServletRequest request, @RequestParam Map<String, Object> reqMap) throws Exception {
		Map<String, Object> resultMap = new HashMap<String, Object>();
		// 精算書ＩＤ
		String seisanShoId = (String) reqMap.get("seisanShoId");
		// 印刷処理
		List<String> pdfFileNameLst = seisanshoShoninService.printing(seisanShoId);

		return setDataToResultMap(resultMap, pdfFileNameLst);
	}

	/**
	 * 取得（承認）更新処理
	 *
	 * @param reqMap
	 *            INPUTパラメータ
	 * @return 取得情報データ
	 * @throws Exception
	 * @version 1.00
	 */
	@RequestMapping(value = "/seisanshoshutokuShoninkosin-updateInfo", method = RequestMethod.POST)
	public Map<String, Object> updateInfo(HttpServletRequest request, @RequestParam Map<String, Object> reqMap)
			throws Exception {

		Map<String, Object> resultMap = new HashMap<String, Object>();

		// 入力チェック
		String errStr = inputCheckForUpdate(reqMap);
		if (StringUtils.isNotEmpty(errStr)) {
			return setMsgToResultMap(resultMap, NSDConstant.MSGID_INPUT_ERROR, errStr);
		}

		Kss004 kss004 = new Kss004();
		// 精算書ＩＤ
		String seisanShoId = (String) reqMap.get("seisanShoId");
		kss004.setSeisanShoId(seisanShoId);

		// 更新前のチェック
		errStr = seisanshoShoninService.checkUpdate(kss004);
		if (StringUtils.isNotEmpty(errStr)) {
			return setMsgToResultMap(resultMap, errStr);
		}

		// 承認状態
		kss004.setShoninStatus((String) reqMap.get("shoninStatusCd"));
		// 更新年月日
		Date date = new Date();
		kss004.setUpdateDate(date);
		// 更新ユーザーＩＤ
		kss004.setUpdateUserId(this.getLoginUserInfo(request).getUserId());

		// 排他チェック
		String errId = commService.doHaita(kss004, (String)reqMap.get("updateDate"));
		if (!NSDConstant.BLANK_STRING.equals(errId)){
			return setMsgToResultMap(resultMap, errId);
		}

		// サービス呼び出し
		seisanshoShoninService.updateInfo(kss004);

		// 処理結果データ
		resultMap.put(NSDConstant.RESULT_DATA_NAME, "");

		return setMsgToResultMapNoLog(resultMap, NSDConstant.MSGID_UPDATE_SUCCES);
	}

	/**
	 * 更新の入力データチェック
	 *
	 * @param reqMap
	 *            INPUTパラメータ
	 * @return エラーメッセージID
	 * @version 1.00
	 */
	private String inputCheckForUpdate(Map<String, Object> reqMap) {

		List<InputCheck> inputCheckList = getCheckItemListForUpdate(reqMap);
		return nsdDataCheck.dataCheck(inputCheckList);

	}

	/**
	 * 更新の入力チェックリストを定義
	 *
	 * @param reqMap
	 *            INPUTパラメータ
	 * @return
	 */
	private List<InputCheck> getCheckItemListForUpdate(Map<String, Object> reqMap) {

		List<InputCheck> inputCheckList = new ArrayList<InputCheck>();
		Map<Integer, Object> args;

		args = new HashMap<Integer, Object>();
		args.put(NSDConstant.CHECK_ITEM.EMPTY_CHECK.ordinal(), null);
		inputCheckList.add(setInputCheck(reqMap, "shoninStatusCd", "承認状態：", args));

		return inputCheckList;
	}
}
