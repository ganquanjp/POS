/***********************************************************************
*
*業務名: 工事精算システム
*機能名: 除却（内容入力）(ログ出力処理)
*
*機能概要: 除却情報を処理する。
*
*JavaＶｅｒ：J2SE1.8.0準拠
*
*更新履歴: Ver.1.00 2018/03/06　NSD　新規作成
***********************************************************************/

package jp.co.nsd.nkssweb.controller.seisanshojokyaku;

import java.math.BigDecimal;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import jp.co.nsd.nkssweb.controller.BaseController;
import jp.co.nsd.nkssweb.dao.InputCheck;
import jp.co.nsd.nkssweb.dao.Kss007;
import jp.co.nsd.nkssweb.dao.SeisanshoJokyakuNaiyo;
import jp.co.nsd.nkssweb.dao.SeisanshoJokyakuNaiyoShokai;
import jp.co.nsd.nkssweb.service.CommService;
import jp.co.nsd.nkssweb.service.seisanshojokyaku.SeisanshoJokyakuNaiyoService;
import jp.co.nsd.nkssweb.utils.NSDConstant;
import jp.co.nsd.nkssweb.utils.NSDDataCheck;

/**
 * 除却（内容入力）処理
 *
 * @version 1.00
 */
@RestController
public class SeisanshoJokyakuNaiyoController extends BaseController {

	@Autowired
	private SeisanshoJokyakuNaiyoService seisanshoJokyakuNaiyoService;

	@Autowired
	private NSDDataCheck nsdDataCheck;

	@Autowired
	private CommService commService;

	/**
	 * 除却（内容入力）検索処理
	 *
	 * @param reqMap
	 *            INPUTパラメータ
	 * @return 除却情報データ
	 * @throws ParseException
	 * @version 1.00
	 */
	@RequestMapping(value = "/seisanshoJokyakuNaiyo-selectByWhere", method = RequestMethod.POST)
	public Map<String, Object> selectByWhere(@RequestParam Map<String, Object> reqMap) throws Exception {

		Map<String, Object> resultMap = new HashMap<String, Object>();

		// 入力チェック
		String errStr = inputCheckForSearch(reqMap);
		if (StringUtils.isNotEmpty(errStr)) {
			return setMsgToResultMap(resultMap, NSDConstant.MSGID_INPUT_ERROR, errStr);
		}

		SeisanshoJokyakuNaiyo seisanshoJokyakuNaiyo = new SeisanshoJokyakuNaiyo();

		List<SeisanshoJokyakuNaiyo> sssJkkNyLst = new ArrayList<>();

		// Mapの情報をBeanのプロパティにセット
		BeanUtils.populate(seisanshoJokyakuNaiyo, reqMap);

		// サービス呼び出し
		sssJkkNyLst = seisanshoJokyakuNaiyoService.getJokyakuNaiyoInfo(seisanshoJokyakuNaiyo);

		// 検索結果を返却Mapに設定する
		return setDataToResultMap(resultMap, sssJkkNyLst);

	}

	/**
	 * 検索の入力データチェック
	 *
	 * @param reqMap
	 *            INPUTパラメータ
	 * @return エラーメッセージID
	 * @version 1.00
	 */
	private String inputCheckForSearch(Map<String, Object> reqMap) {

		List<InputCheck> inputCheckList = getCheckItemListForSearch(reqMap);
		return nsdDataCheck.dataCheck(inputCheckList);

	}

	/**
	 * 検索の入力チェックリストを定義
	 *
	 * @param reqMap
	 *            INPUTパラメータ
	 * @return
	 */
	private List<InputCheck> getCheckItemListForSearch(Map<String, Object> reqMap) {

		List<InputCheck> inputCheckList = new ArrayList<InputCheck>();
		Map<Integer, Object> args;

		if (StringUtils.isNotEmpty((String) reqMap.get("jokyakuYoteYmdFrom"))) {
			args = new HashMap<Integer, Object>();
			args.put(NSDConstant.CHECK_ITEM.DATE_FORMAT_CHECK.ordinal(), null);
			inputCheckList.add(setInputCheck(reqMap, "jokyakuYoteYmdFrom", "除却予定年月日(From)：", args));
		}

		if (StringUtils.isNotEmpty((String) reqMap.get("jokyakuYoteYmdTo"))) {
			args = new HashMap<Integer, Object>();
			args.put(NSDConstant.CHECK_ITEM.DATE_FORMAT_CHECK.ordinal(), null);
			inputCheckList.add(setInputCheck(reqMap, "jokyakuYoteYmdTo", "除却予定年月日(To)：", args));
		}

		args = new HashMap<Integer, Object>();
		args.put(NSDConstant.CHECK_ITEM.DATE_COMPARE_CHECK.ordinal(), (String) reqMap.get("jokyakuYoteYmdTo"));
		inputCheckList.add(setInputCheck(reqMap, "jokyakuYoteYmdFrom", "除却予定年月日：", args));

		return inputCheckList;
	}

	/**
	 * 除却（内容入力）照会処理
	 *
	 * @param reqMap
	 *            INPUTパラメータ
	 * @return 除却情報データ
	 * @throws Exception
	 * @version 1.00
	 */
	@RequestMapping(value = "/seisanshoJokyakuNaiyo-selectBySeisanShoNo", method = RequestMethod.POST)
	public Map<String, Object> selectBySeisanShoNo(@RequestParam Map<String, Object> reqMap) throws Exception {

		Map<String, Object> resultMap = new HashMap<String, Object>();

		SeisanshoJokyakuNaiyoShokai seisanshoJokyakuNaiyoShokai = new SeisanshoJokyakuNaiyoShokai();

		// Mapの情報をBeanのプロパティにセット
		BeanUtils.populate(seisanshoJokyakuNaiyoShokai, reqMap);

		// サービス呼び出し
		SeisanshoJokyakuNaiyoShokai sssJkkNySkDto = seisanshoJokyakuNaiyoService
				.getJokyakuInfoBySeisanShoNo(seisanshoJokyakuNaiyoShokai);

		// 検索結果を返却Mapに設定する
		return setDataToResultMap(resultMap, sssJkkNySkDto);
	}

	/**
	 * 除却内容入力（更新）処理
	 *
	 * @param reqMap
	 *            INPUTパラメータ
	 * @throws Exception
	 * @version 1.00
	 */
	@RequestMapping(value = "/seisanshoJokyakuNaiyo-updateInfo", method = RequestMethod.POST)
	public Map<String, Object> updateInfo(HttpServletRequest request, @RequestParam Map<String, Object> reqMap)
			throws Exception {

		Map<String, Object> resultMap = new HashMap<String, Object>();

		// 入力チェック
		String errStr = inputCheckForUpdate(reqMap);
		if (StringUtils.isNotEmpty(errStr)) {
			return setMsgToResultMap(resultMap, NSDConstant.MSGID_INPUT_ERROR, errStr);
		}

		// 画面除却資産明細件数取得
		Set<String> set = countViewRecord(reqMap);

		Date date = new Date();
		List<Kss007> kss007UpdLst = new ArrayList<Kss007>();
		// 除却資産明細情報を取得
		for (int i = 0; i < set.size(); i++) {
			// MapKey
			String key;
			Kss007 kss007 = new Kss007();
			// 固定資産IDKEY
			key = "koteiSisanLst".concat("[" + i + "]").concat("[koteiCod]");
			kss007.setMotoKoteiShisanId((String) reqMap.get(key));
			// 履歴IDKEY
			key = "koteiSisanLst".concat("[" + i + "]").concat("[rrkCod]");
			kss007.setRirekiNo((String) reqMap.get(key));
			// 除却精算書IDKEY
			key = "koteiSisanLst".concat("[" + i + "]").concat("[jokyakuSeisanShoId]");
			kss007.setJokyakuSeisanShoId((String) reqMap.get(key));
			// 除却資産IDKEY
			key = "koteiSisanLst".concat("[" + i + "]").concat("[jokyakuShisanId]");
			kss007.setJokyakuShisanId((String) reqMap.get(key));
			// 除却種別コードKEY
			key = "koteiSisanLst".concat("[" + i + "]").concat("[jokyakuShubetsuCd]");
			kss007.setJokyakuShubetsuCd((String) reqMap.get(key));
			// 除却区分コードKEY
			key = "koteiSisanLst".concat("[" + i + "]").concat("[jokyakuKbn]");
			kss007.setJokyakuKbn((String) reqMap.get(key));
			// 除＿数量KEY
			key = "koteiSisanLst".concat("[" + i + "]").concat("[jokyakuSuryo]");
			kss007.setJokyakuSuryo(new BigDecimal((String) reqMap.get(key)));

			// 残＿数量は元＿数量から除_数量を減算し残数量を算出します。
			key = "koteiSisanLst".concat("[" + i + "]").concat("[meiSu]");
			kss007.setZanSuryo(new BigDecimal((String) reqMap.get(key)).subtract(kss007.getJokyakuSuryo()));

			// 除＿取得価額KEY
			key = "koteiSisanLst".concat("[" + i + "]").concat("[jokyakuGaku]");
			kss007.setJokyakuGaku(Long.parseLong((String) reqMap.get(key)));

			// 残＿取得価額は元＿取得価額から除_取得価額を減算し残数量を算出します。
			key = "koteiSisanLst".concat("[" + i + "]").concat("[getkgkYen]");
			kss007.setKsZgtkgkYen(new Long((String) reqMap.get(key)) - kss007.getJokyakuGaku());

			// 更新年月日
			kss007.setUpdateDate(date);
			// 更新ユーザーＩＤ
			kss007.setUpdateUserId(this.getLoginUserInfo(request).getUserId());

			// 排他チェック
			key = "koteiSisanLst".concat("[" + i + "]").concat("[updateDate]");
			String errId = commService.doHaita(kss007, (String)reqMap.get(key));
			if (!NSDConstant.BLANK_STRING.equals(errId)){
				return setMsgToResultMap(resultMap, errId);
			}

			kss007UpdLst.add(kss007);
		}

		// サービス呼び出し
		seisanshoJokyakuNaiyoService.updateInfo(kss007UpdLst);

		// 処理結果データ
		resultMap.put(NSDConstant.RESULT_DATA_NAME, "");

		return setMsgToResultMapNoLog(resultMap, NSDConstant.MSGID_UPDATE_SUCCES);
	}

	/**
	 * 除却内容入力（印刷）処理
	 *
	 * @param reqMap
	 *            INPUTパラメータ
	 * @throws Exception
	 * @version 1.00
	 */
	@RequestMapping(value = "/seisanshoJokyakuNaiyo-printing", method = RequestMethod.POST)
	public Map<String, Object> printing(HttpServletRequest request, @RequestParam Map<String, Object> reqMap) throws Exception {
		Map<String, Object> resultMap = new HashMap<String, Object>();
		// 除却精算書ＩＤ
		String jokyakuSeisanShoId = (String) reqMap.get("jokyakuSeisanShoId");
		// 印刷処理
		List<String> pdfFileNameLst = seisanshoJokyakuNaiyoService.printing(jokyakuSeisanShoId);

		return setDataToResultMap(resultMap, pdfFileNameLst);
	}
	/**
	 * 画面除却資産明細件数取得
	 *
	 * @param reqMap
	 * @return
	 */
	private Set<String> countViewRecord(Map<String, Object> reqMap) {
		Set<String> set = new HashSet<String>();
		for (Entry<String, Object> entry : reqMap.entrySet()) {
			String[] record = entry.getKey().replace("[", ",").replace("]", "").split(",");
			if (record.length == 3) {
				set.add(record[1]);
			}
		}
		return set;
	}

	/**
	 * 更新の入力データチェック
	 *
	 * @param reqMap
	 *            INPUTパラメータ
	 * @return エラーメッセージID
	 * @version 1.00
	 */
	private String inputCheckForUpdate(Map<String, Object> reqMap) {

		List<InputCheck> inputCheckList = getCheckItemListForUpdate(reqMap);
		return nsdDataCheck.dataCheck(inputCheckList);

	}

	/**
	 * 更新の入力チェックリストを定義
	 *
	 * @param reqMap
	 *            INPUTパラメータ
	 * @return
	 */
	private List<InputCheck> getCheckItemListForUpdate(Map<String, Object> reqMap) {

		List<InputCheck> inputCheckList = new ArrayList<InputCheck>();
		Map<Integer, Object> args;

		// 画面除却資産明細件数取得
		Set<String> set = countViewRecord(reqMap);

		// 画面明細部
		String id, name;
		for (int i = 0; i < set.size(); i++) {

			args = new HashMap<Integer, Object>();
			args.put(NSDConstant.CHECK_ITEM.EMPTY_CHECK.ordinal(), null);
			id = "koteiSisanLst".concat("[" + i + "]").concat("[jokyakuKbn]");
			name = "除却区分(行番号：".concat(String.valueOf(i + 1).concat(")："));
			inputCheckList.add(setInputCheck(reqMap, id, name, args));

			args = new HashMap<Integer, Object>();
			args.put(NSDConstant.CHECK_ITEM.EMPTY_CHECK.ordinal(), null);
			id = "koteiSisanLst".concat("[" + i + "]").concat("[jokyakuShubetsuCd]");
			name = "除却種別コード(行番号：".concat(String.valueOf(i + 1).concat(")："));
			inputCheckList.add(setInputCheck(reqMap, id, name, args));

			args = new HashMap<Integer, Object>();
			args.put(NSDConstant.CHECK_ITEM.EMPTY_CHECK.ordinal(), null);
			id = "koteiSisanLst".concat("[" + i + "]").concat("[jokyakuSuryo]");
			name = "除_数量(行番号：".concat(String.valueOf(i + 1).concat(")："));
			inputCheckList.add(setInputCheck(reqMap, id, name, args));

			// 除_数量＞０ AND 除_数量 ≦ 元_数量
			args = new HashMap<Integer, Object>();
			Map<String, String> rangeNum = new HashMap<String, String>();
			rangeNum.put("startValue", "0");
			rangeNum.put("endValue", (String) reqMap.get("koteiSisanLst".concat("[" + i + "]").concat("[meiSu]")));
			rangeNum.put("compareWay", "7");
			args.put(NSDConstant.CHECK_ITEM.NUMERIC_RANGE_CHECK.ordinal(), rangeNum);
			id = "koteiSisanLst".concat("[" + i + "]").concat("[jokyakuSuryo]");
			name = "除_数量(行番号：".concat(String.valueOf(i + 1).concat(")："));
			inputCheckList.add(setInputCheck(reqMap, id, name, args));

			args = new HashMap<Integer, Object>();
			args.put(NSDConstant.CHECK_ITEM.EMPTY_CHECK.ordinal(), null);
			id = "koteiSisanLst".concat("[" + i + "]").concat("[jokyakuGaku]");
			name = "除_取得価額(行番号：".concat(String.valueOf(i + 1).concat(")："));
			inputCheckList.add(setInputCheck(reqMap, id, name, args));

			// 除_取得価額＞０ AND 除_取得価額 ≦ 元_取得価額
			args = new HashMap<Integer, Object>();
			rangeNum = new HashMap<String, String>();
			rangeNum.put("startValue", "0");
			rangeNum.put("endValue", (String) reqMap.get("koteiSisanLst".concat("[" + i + "]").concat("[getkgkYen]")));
			rangeNum.put("compareWay", "7");
			args.put(NSDConstant.CHECK_ITEM.NUMERIC_RANGE_CHECK.ordinal(), rangeNum);
			id = "koteiSisanLst".concat("[" + i + "]").concat("[jokyakuGaku]");
			name = "除_取得価額(行番号：".concat(String.valueOf(i + 1).concat(")："));
			inputCheckList.add(setInputCheck(reqMap, id, name, args));

		}
		return inputCheckList;
	}

}
