package jp.co.nsd.nkssweb.config;


import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.tomcat.jdbc.pool.DataSource;
import org.mybatis.spring.SqlSessionFactoryBean;
import org.mybatis.spring.annotation.MapperScan;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.core.io.support.PathMatchingResourcePatternResolver;
import org.springframework.jdbc.datasource.DataSourceTransactionManager;

@Configuration
@MapperScan(basePackages = PostgresqlDataSourceConfig.Package, sqlSessionFactoryRef = "postgresqlSqlSessionFactory")
public class PostgresqlDataSourceConfig {

    static final String Package = "jp.co.nsd.nkssweb.dao.mapper";

    static final String MAPPER_LOCATION = "classpath:mapper/*.xml";

    @Value("${spring.datasource.pgs.url}")
    private String url;

    @Value("${spring.datasource.pgs.username}")
    private String user;

    @Value("${spring.datasource.pgs.password}")
    private String password;

    @Value("${spring.datasource.pgs.driver-class-name}")
    private String driverClass;

    @Bean(name = "postgresqlDataSource")
    @Primary
    @ConfigurationProperties(prefix="spring.datasource.pgs")
	public DataSource postgresqlDataSource(){
    	DataSource dataSource = new DataSource();
        dataSource.setDriverClassName(this.driverClass);
        dataSource.setUrl(this.url);
        dataSource.setUsername(this.user);
        dataSource.setPassword(this.password);
	    return dataSource;
	}

    @Bean(name = "postgresqlTransactionManager")
    @Primary
    public DataSourceTransactionManager postgresqlTransactionManager(){
        return new DataSourceTransactionManager((postgresqlDataSource()));
    }

    @Bean(name="postgresqlSqlSessionFactory")
    @Primary
    public SqlSessionFactory postgresqlSqlSessionFactory(@Qualifier("postgresqlDataSource") DataSource postgresqlDataSource) throws Exception {
    	final SqlSessionFactoryBean sessionFactoryBean = new SqlSessionFactoryBean();
        sessionFactoryBean.setDataSource(postgresqlDataSource);
        sessionFactoryBean.setMapperLocations(new PathMatchingResourcePatternResolver()
        .getResources(PostgresqlDataSourceConfig.MAPPER_LOCATION));
        return sessionFactoryBean.getObject();
    }

}
