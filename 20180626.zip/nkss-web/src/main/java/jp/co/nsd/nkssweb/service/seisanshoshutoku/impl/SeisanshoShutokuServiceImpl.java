package jp.co.nsd.nkssweb.service.seisanshoshutoku.impl;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

import jp.co.nsd.nkssweb.dao.Awdm12;
import jp.co.nsd.nkssweb.dao.Awdv02;
import jp.co.nsd.nkssweb.dao.Kss004;
import jp.co.nsd.nkssweb.dao.Kss005;
import jp.co.nsd.nkssweb.dao.Kss005Key;
import jp.co.nsd.nkssweb.dao.SeisanshoShutokuKensaku;
import jp.co.nsd.nkssweb.dao.SeisanshoShutokuShokai;
import jp.co.nsd.nkssweb.dao.mapper.CommMapper;
import jp.co.nsd.nkssweb.dao.mapper.Kss004Mapper;
import jp.co.nsd.nkssweb.dao.mapper.Kss005Mapper;
import jp.co.nsd.nkssweb.dao.mapper.Kss005MapperExt;
import jp.co.nsd.nkssweb.dao.mapper.SeisanshoShutokuMapper;
import jp.co.nsd.nkssweb.service.seisanshoshutoku.SeisanshoShutokuService;
import jp.co.nsd.nkssweb.utils.NSDConstant;

@Service
@Transactional(value = "postgresqlTransactionManager")
public class SeisanshoShutokuServiceImpl implements SeisanshoShutokuService {

	@Autowired
	private SeisanshoShutokuMapper seisanshoShutokuMapper;

	@Autowired
	private Kss004Mapper kss004Mapper;

	@Autowired
	private Kss005Mapper kss005Mapper;

	@Autowired
	private Kss005MapperExt kss005MapperExt;

	@Autowired
	private CommMapper commMapper;

	@Override
	public List<SeisanshoShutokuKensaku> getSeisanshoShutokuKensaku(SeisanshoShutokuKensaku selectCondition) {
		List<SeisanshoShutokuKensaku> sssStkList = new ArrayList<SeisanshoShutokuKensaku>();

		sssStkList = seisanshoShutokuMapper.kensaku(selectCondition);

		if (sssStkList.size() > 0) {
			for (int i = 1; i <= sssStkList.size(); i++) {
				sssStkList.get(i - 1).setRowNo(i);
			}
		} else {
			sssStkList = null;
		}

		return sssStkList;

	}

	@Override
	public List<SeisanshoShutokuShokai> getSeisanshoShutokuShokai(SeisanshoShutokuShokai selectCondition) {

		List<SeisanshoShutokuShokai> sssStkList = new ArrayList<SeisanshoShutokuShokai>();

		sssStkList = seisanshoShutokuMapper.shokai(selectCondition);

		if (sssStkList.size() > 0) {
			for (int i = 1; i <= sssStkList.size(); i++) {
				sssStkList.get(i - 1).setRowNo(i);
			}
		} else {
			sssStkList = null;
		}

		return sssStkList;

	}

	/**
	 * 取得・削除処理
	 *
	 * @param seisanshoShutoku
	 *            INPUTパラメータ
	 * @return cnt
	 * @version 1.00
	 */
	public int delByPyKey(String seisanShoId, String koteiShisanId) {

		Kss005Key kss005Key = new Kss005Key();
		// 精算書ＩＤ
		kss005Key.setSeisanShoId(seisanShoId);
		// 固定資産ＩＤ
		kss005Key.setKoteiShisanId(koteiShisanId);
		// 取得資産明細情報を削除
		seisanshoShutokuMapper.deleteByPyKey(kss005Key);

		return 0;
	}

	/**
	 * 取得新規登録を処理
	 *
	 * @param kss005
	 *            INPUTパラメータ
	 * @return cnt
	 * @version 1.00
	 * @throws Exception
	 */
	@Override
	public int insert(Kss005 kss005) throws Exception {

		// 取得資産明細情報を設定
		Kss005 kss005Info = setKss005(kss005);

		// 取得資産明細情報を登録
		int cnt = kss005Mapper.insert(kss005Info);

		return cnt;
	}

	/**
	 * 精算書取得・修正
	 *
	 * @param kss005
	 */
	@Override
	public int update(Kss005 kss005) throws Exception {

		// 取得資産明細情報を設定
		Kss005 kss005Info = setKss005(kss005);

		// 取得資産明細情報を登録
		int cnt = kss005MapperExt.updateByPrimaryKeySelective(kss005Info);

		if (cnt > 0) {
			Kss004 chkKss004 = new Kss004();
			// 精算書ＩＤ
			chkKss004.setSeisanShoId(kss005Info.getSeisanShoId());
			// 固定資産ＩＤ
			chkKss004.setKoteiShisanId(kss005Info.getKoteiShisanId());
			Kss004 kss004 = kss004Mapper.selectByPrimaryKey(chkKss004);
			if (null != kss004) {
				// 承認ステータスが「20：経理審査否認」の場合、「00：登録中」を変更します
				if (NSDConstant.SHONIN_STATUS_CODE_HININ.equals(kss004.getShoninStatus())) {
					// 承認状態
					kss004.setShoninStatus(NSDConstant.SHONIN_STATUS_CODE_TOROKU);
					// 承認状態を変更
					commMapper.updateStatus(kss004);
				}
			}
		}

		return cnt;
	}

	/**
	 * 取得資産情報を設定
	 *
	 * @param kss005
	 *            INPUTパラメータ
	 * @version 1.00
	 */
	private Kss005 setKss005(Kss005 kss005) {

		// 耐用年数＿商
		kss005.setTaiyoNensuSho(kss005.getTaiyoNensuZei());

		// 管理箇所コード
		kss005.setKanriSoshikiCd(kss005.getKanriSoshikiCd().trim());
		// 負担箇所コード
		kss005.setFutanSoshikiCd(kss005.getFutanSoshikiCd().trim());
		// 種類コード
		kss005.setShuruiCd(kss005.getShuruiCd().trim());

		Long kagakuYen = kss005.getBuppinGaku() + kss005.getKouhiGaku() + kss005.getSouKeihiGaku();
		// 原始取得価額
		kss005.setGenshiShutokuKagaku(kagakuYen);

		Awdv02 awdv02 = new Awdv02();
		// 種類コード
		awdv02.setShuCod(kss005.getShuruiCd());
		// 構造コード
		awdv02.setKouCod(kss005.getKouzouCd());
		// 資産単位コード
		awdv02.setSaiCod(kss005.getShisanTaniCd());
		// 項目１コード
		awdv02.setShu4Cod(kss005.getKamokuCd1());
		// 項目２コード
		awdv02.setShu5Cod(kss005.getKamokuCd2());
		// 項目３コード
		awdv02.setShu6Cod(kss005.getKamokuCd3());
		// 種構細４５６の情報を取得
		Map<String, Object> map = seisanshoShutokuMapper.getAwdv02Info(awdv02);
		// 種構細４５６の情報存在します
		if (null != map) {

			// 無形固定資産の場合は備忘価額に０を設定
			if ("42".equals(kss005.getShuruiCd()) || "43".equals(kss005.getShuruiCd())
					|| "51".equals(kss005.getShuruiCd()) || "61".equals(kss005.getShuruiCd())
					|| "12".equals(kss005.getShuruiCd()) || "305".equals(kss005.getKamokuCd1())
					|| "1".equals(map.get("sisankbn"))) {

				// 備忘価額＿税
				kss005.setBiboKagakuZei(0L);
				// 備忘価額＿商
				kss005.setBiboKagakuSho(0L);
			} else {
				// 備忘価額＿税
				kss005.setBiboKagakuZei(Long.valueOf(map.get("bibzyen").toString()));
				// 備忘価額＿商
				kss005.setBiboKagakuSho(Long.valueOf(map.get("bibsyen").toString()));
			}

			// 償却資産区分を判定
			String kmksbtCod3 = (String) map.get("kmksbtcod3");

			// 償却資産区分の存在チェック
			if (!StringUtils.isEmpty(kmksbtCod3)) {
				// 償却可能限度額_税・償却可能限度額_商
				if (NSDConstant.STRING_0.equals(kmksbtCod3)) {
					// 償却可能限度額_税
					kss005.setShokyakuGendoZei(kagakuYen - Long.valueOf(map.get("bibzyen").toString()));
					// 償却可能限度額_商
					kss005.setShokyakuGendoSho(kagakuYen - Long.valueOf(map.get("bibsyen").toString()));
				} else {
					// 償却可能限度額＿税
					kss005.setShokyakuGendoZei(0L);
					// 償却可能限度額＿商
					kss005.setShokyakuGendoSho(0L);
				}
			}

			// 申告種類コード
			kss005.setShinkokuShuruiCd((String) map.get("kmksbtcod2"));
			// 償却資産区分
			kss005.setShokyakuShisanKbn((String) map.get("kmksbtcod3"));
			// 連係要否フラグ
			kss005.setRenkeiYohiFlg((String) map.get("kmksbtcod4"));

			if ("1050".equals(kss005.getFutanSoshikiCd()) && ("30".equals(kss005.getShuruiCd())
					|| "40".equals(kss005.getShuruiCd()) || "41".equals(kss005.getShuruiCd())
					|| "50".equals(kss005.getShuruiCd()) || "60".equals(kss005.getShuruiCd()))) {
				// 償却方法＿税
				kss005.setSyokyakuHohoZei(NSDConstant.STRING_0);
			} else {
				// 償却方法＿税
				kss005.setSyokyakuHohoZei((String) map.get("kmksbtcod5"));
			}
			// 償却方法＿商
			kss005.setSyokyakuHohoSho((String) map.get("kmksbtcod6"));
			// 残存率_税
			kss005.setZanzonRitsuZei(Short.valueOf(map.get("zanzonritsuzei").toString()));
			// 残存率_商
			kss005.setZanzonRitsuSho(Short.valueOf(map.get("zanzonritsusho").toString()));
			// 自他資産区分
			kss005.setJitaShisanKbn((String) map.get("jtssnkbn"));
		} else {
			// 備忘価額＿税
			kss005.setBiboKagakuZei(0L);
			// 備忘価額＿商
			kss005.setBiboKagakuSho(0L);
			// 償却可能限度額＿税
			kss005.setShokyakuGendoZei(0L);
			// 償却可能限度額＿商
			kss005.setShokyakuGendoSho(0L);
			// 償却方法＿税
			kss005.setSyokyakuHohoZei(NSDConstant.STRING_0);
			// 償却方法＿商
			kss005.setSyokyakuHohoSho(NSDConstant.STRING_0);
			// 残存率_税
			kss005.setZanzonRitsuZei(Short.valueOf(NSDConstant.STRING_0));
			// 残存率_商
			kss005.setZanzonRitsuSho(Short.valueOf(NSDConstant.STRING_0));
			// 申告種類コード
			kss005.setShinkokuShuruiCd(NSDConstant.STRING_0);
			// 償却資産区分
			kss005.setShokyakuShisanKbn(NSDConstant.STRING_0);
			// 連係要否フラグ
			kss005.setRenkeiYohiFlg(NSDConstant.STRING_0);
			// 自他資産区分
			kss005.setJitaShisanKbn(NSDConstant.STRING_0);
		}

		// 負担率
		kss005.setFutanRitsu(new BigDecimal(100));
		// 申告取得価額
		kss005.setShinkokuShutokuKagaku(kagakuYen);
		// 一時償却額＿税
		kss005.setIchijiShokyakuZei(0L);
		// 一時償却額＿商
		kss005.setIchijiShokyakuSho(0L);
		// 割増償却額＿税
		kss005.setWariShokyakuGakuZei(0L);
		// 割増償却額＿商
		kss005.setWariShokyakuGakuSho(0L);
		// 増加償却額＿税
		kss005.setZokaShokyakuGakuZei(0L);
		// 増加償却額＿商
		kss005.setZokaShokyakuGakuSho(0L);
		// 陳腐化償却額＿税
		kss005.setChinpuKagakuZei(0L);
		// 陳腐化償却額＿商
		kss005.setChinpuKagakuSho(0L);
		// 税_最終残存率
		kss005.setSaishuZanzonRitsuZei(Short.valueOf("0"));
		// 商_最終残存率
		kss005.setSaishuZanzonRitsuSho(Short.valueOf("0"));
		// 償却区分＿税
		kss005.setShokyakuKbnZei(kss005.getSyokyakuHohoZei());
		// 償却区分＿商
		kss005.setShokyakuKbnSho(kss005.getSyokyakuHohoSho());
		// 初年度償却方法
		kss005.setShonendoShokyakuHoho(NSDConstant.STRING_0);
		// 設置場所より申告先・市町村を取得
		Awdm12 pAwdm12 = new Awdm12();
		pAwdm12.setMwcBashoCod(kss005.getSechiBashoCd());
		Awdm12 awdm12 = commMapper.getAwdm12(pAwdm12);

		if (null != awdm12) {
			// 申告先コード
			kss005.setShinkokuSakiCd(awdm12.getMwcShinCod());
			// 市町村コード
			kss005.setCityCd(awdm12.getMwcCityCod());
		} else {
			// 申告先コード
			kss005.setShinkokuSakiCd(null);
			// 市町村コード
			kss005.setCityCd(null);
		}

		return kss005;
	}
}
