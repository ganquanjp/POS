/***********************************************************************
*
*業務名: 工事精算システム
*機能名: ストアドプロシージャ
*
*機能概要: ストアドプロシージャを処理する。
*
*JavaＶｅｒ：J2SE1.8.0準拠
*
*更新履歴: Ver.1.00 2018/03/06　NSD　新規作成
***********************************************************************/
package jp.co.nsd.nkssweb.oracle.mapper;

import java.util.Map;

/**
 * ストアドプロシージャ処理
 *
 * @version 1.00
 */
public interface OracleStoredMapper {

	Map<String, Object> aysp001ProcMain(Map<String, Object> map);

}