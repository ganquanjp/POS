package jp.co.nsd.nkssweb.controller.seisanshotoroku;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.time.DateUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import jp.co.nsd.nkssweb.controller.BaseController;
import jp.co.nsd.nkssweb.dao.InputCheck;
import jp.co.nsd.nkssweb.dao.Kss002;
import jp.co.nsd.nkssweb.dao.Kss004;
import jp.co.nsd.nkssweb.dao.Kss011;
import jp.co.nsd.nkssweb.dao.Kss013;
import jp.co.nsd.nkssweb.dao.LoginUserInfo;
import jp.co.nsd.nkssweb.dao.SeisanshoToroku;
import jp.co.nsd.nkssweb.dao.mapper.SeisanshoTorokuMapper;
import jp.co.nsd.nkssweb.service.CommService;
import jp.co.nsd.nkssweb.service.InputCheckService;
import jp.co.nsd.nkssweb.service.seisanshotoroku.SeisanshoTorokuService;
import jp.co.nsd.nkssweb.utils.NSDCommUtils;
import jp.co.nsd.nkssweb.utils.NSDConstant;
import jp.co.nsd.nkssweb.utils.NSDDataCheck;
import jp.co.nsd.nkssweb.utils.NSDDateUtils;

@RestController
public class SeisanshoTorokuController extends BaseController {

	@Autowired
	private SeisanshoTorokuService seisanshoTorokuService;

	@Autowired
	private SeisanshoTorokuMapper sssTrkMapper;

	@Autowired
	private NSDDataCheck nsdDataCheck;

	@Autowired
	private CommService commService;

	@Autowired
	private InputCheckService inputCheckService;

	/*
	 * 精算書登録・検索
	 */
	@RequestMapping(value = "/seisanshoToroku-kensaku", method = RequestMethod.POST)
	public Map<String, Object> getSeisanshoTorokuKensaku(@RequestParam Map<String, Object> reqMap) throws Exception {

		Map<String, Object> resultMap = new HashMap<String, Object>();

		// 入力チェック
		String errStr = this.inputCheckForSearch(reqMap);
		if (StringUtils.isNotEmpty(errStr)) {
			return setMsgToResultMap(resultMap, NSDConstant.MSGID_INPUT_ERROR, errStr);
		}

		SeisanshoToroku selectCondition = new SeisanshoToroku();
		List<SeisanshoToroku> sssTrkList = new ArrayList<SeisanshoToroku>();

		// 画面入力した検索条件をBeanのプロパティにセット
		BeanUtils.populate(selectCondition, reqMap);

		// サービスを呼び出す
		sssTrkList = seisanshoTorokuService.getSeisanshoTorokuKensaku(selectCondition);

		// 検索結果を返却Mapに設定する
		setDataToResultMap(resultMap, sssTrkList);

		return resultMap;
	}

	/**
	 * 精算書登録(検索)の入力データチェック
	 *
	 * @param reqMap
	 *            INPUTパラメータ
	 * @return エラーメッセージID
	 * @version 1.00
	 */
	private String inputCheckForSearch(Map<String, Object> reqMap) {

		List<InputCheck> inputCheckList = getCheckItemListForSearch(reqMap);
		return nsdDataCheck.dataCheck(inputCheckList);

	}

	/**
	 * 検索の入力チェック内容リストを定義
	 *
	 * @param reqMap
	 *            INPUTパラメータ
	 * @return
	 */
	private List<InputCheck> getCheckItemListForSearch(Map<String, Object> reqMap) {

		List<InputCheck> inputCheckList = new ArrayList<InputCheck>();
		Map<Integer, Object> args;

		if (StringUtils.isNotEmpty((String) reqMap.get("siyoStartYmdFrom"))) {
			args = new HashMap<Integer, Object>();
			args.put(NSDConstant.CHECK_ITEM.DATE_FORMAT_CHECK.ordinal(), null);
			inputCheckList.add(setInputCheck(reqMap, "siyoStartYmdFrom", "使用開始年月日(From)：", args));
		}

		if (StringUtils.isNotEmpty((String) reqMap.get("siyoStartYmdTo"))) {
			args = new HashMap<Integer, Object>();
			args.put(NSDConstant.CHECK_ITEM.DATE_FORMAT_CHECK.ordinal(), null);
			inputCheckList.add(setInputCheck(reqMap, "siyoStartYmdTo", "使用開始年月日(To)：", args));
		}

		args = new HashMap<Integer, Object>();
		args.put(NSDConstant.CHECK_ITEM.DATE_COMPARE_CHECK.ordinal(), (String) reqMap.get("siyoStartYmdTo"));
		inputCheckList.add(setInputCheck(reqMap, "siyoStartYmdFrom", "使用開始年月日：", args));

		if (StringUtils.isNotEmpty((String) reqMap.get("tekiyoStartYmd"))) {
			args = new HashMap<Integer, Object>();
			args.put(NSDConstant.CHECK_ITEM.DATE_FORMAT_CHECK.ordinal(), null);
			inputCheckList.add(setInputCheck(reqMap, "tekiyoStartYmd", "適用期間(From)：", args));
		}

		if (StringUtils.isNotEmpty((String) reqMap.get("tekiyoEndYmd"))) {
			args = new HashMap<Integer, Object>();
			args.put(NSDConstant.CHECK_ITEM.DATE_FORMAT_CHECK.ordinal(), null);
			inputCheckList.add(setInputCheck(reqMap, "tekiyoEndYmd", "適用期間(To)：", args));
		}

		args = new HashMap<Integer, Object>();
		args.put(NSDConstant.CHECK_ITEM.DATE_COMPARE_CHECK.ordinal(), (String) reqMap.get("tekiyoEndYmd"));
		inputCheckList.add(setInputCheck(reqMap, "tekiyoStartYmd", "適用期間：", args));

		return inputCheckList;
	}

	/*
	 * 精算書登録・照会
	 */
	@RequestMapping(value = "/seisanshoToroku-shokai", method = RequestMethod.POST)
	public Map<String, Object> getSeisanshoTorokuShokai(@RequestParam Map<String, Object> reqMap) throws Exception {

		Map<String, Object> resultMap = new HashMap<String, Object>();

		SeisanshoToroku selectCondition = new SeisanshoToroku();

		List<SeisanshoToroku> sssTrkList = new ArrayList<SeisanshoToroku>();

		// 画面入力した検索条件をBeanのプロパティにセット
		BeanUtils.populate(selectCondition, reqMap);

		// サービスを呼び出す
		sssTrkList = seisanshoTorokuService.getSeisanshoTorokuShokai(selectCondition);

		// 検索結果を返却Mapに設定する
		setDataToResultMap(resultMap, sssTrkList);

		// 処理結果データ
		if (sssTrkList.size() > 0) {
			setDataToResultMap(resultMap, sssTrkList);
		} else {
			setMsgToResultMap(resultMap, NSDConstant.MSGID_NOT_FOUND_DATA);
		}

		return resultMap;
	}

	/**
	 * 精算書登録・削除
	 *
	 * @param reqMap
	 *            INPUTパラメータ
	 * @return 除却情報データ
	 * @throws Exception
	 * @version 1.00
	 */
	@RequestMapping(value = "/seisanshoToroku-delete", method = RequestMethod.POST)
	public Map<String, Object> delete(@RequestParam Map<String, Object> reqMap) throws Exception {

		Map<String, Object> resultMap = new HashMap<String, Object>();

		// 件名ＩＤ
		Long kenmeiId = Long.valueOf((String) reqMap.get("kenmeiId"));
		// 精算書ID
		String seisanShoId = (String) reqMap.get("seisanShoId");

		seisanshoTorokuService.deleteSeisansho(kenmeiId, seisanShoId);

		// 処理結果データ
		resultMap.put(NSDConstant.RESULT_DATA_NAME, "");

		return setMsgToResultMapNoLog(resultMap, NSDConstant.MSGID_DELETE_SUCCES);
	}

	/**
	 * 精算書登録（新規登録・初期表示）処理
	 *
	 * @param reqMap
	 *            INPUTパラメータ
	 * @return 除却情報データ
	 * @throws Exception
	 * @version 1.00
	 */
	@RequestMapping(value = "/seisanshotoroku-toroku-initShow", method = RequestMethod.POST)
	public Map<String, Object> initShowForInsert(HttpServletRequest request) throws Exception {

		Map<String, Object> resultMap = new HashMap<String, Object>();

		// 画面初期表示情報格納するマップ
		Map<String, Object> infoMap = new HashMap<String, Object>();

		// 画面適用開始日 ＝ 当日日付の２か月前の1日
		infoMap.put("tekiyoStartYmd", getFirstDayBefore2Month());

		// 画面適用終了日 ＝ ディフォルト終了日
		infoMap.put("tekiyoEndYmd", NSDConstant.DEFAULT_END_DATE);

		LoginUserInfo loginUserInfo = getLoginUserInfo(request);

		// 登録者氏名 ＝ ログイン者
		infoMap.put("loginUserInfo", loginUserInfo);

		// 検索結果を返却Mapに設定する
		return setDataToResultMap(resultMap, infoMap);
	}

	/**
	 * 当日日付の２か月前の1日を取得
	 *
	 * @return
	 */
	private String getFirstDayBefore2Month() {
		java.text.SimpleDateFormat format = new java.text.SimpleDateFormat("yyyy-MM-01");
		String firstDayBefore2Month = format.format(DateUtils.addMonths(Calendar.getInstance().getTime(), -2));
		return firstDayBefore2Month;
	}

	/**
	 * 精算書登録（新規登録・登録）処理
	 *
	 * @param reqMap
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value = "/seisanshoToroku-insertSeisansho", method = RequestMethod.POST)
	public Map<String, Object> insertSeisansho(HttpServletRequest request, @RequestParam Map<String, Object> reqMap)
			throws Exception {

		Map<String, Object> resultMap = new HashMap<String, Object>();

		// 入力チェック
		String errStr = inputCheckForInsert(reqMap, NSDConstant.ACTION_INSERT);
		if (StringUtils.isNotEmpty(errStr)) {
			return setMsgToResultMap(resultMap, NSDConstant.MSGID_INPUT_ERROR, errStr);
		}

		// 画面情報を取得
		List<Kss004> kss004List = new ArrayList<Kss004>();
		Kss002 kss002 = new Kss002();
		errStr = setInsertData(reqMap, request, kss004List, kss002);
		if (StringUtils.isNotEmpty(errStr)) {
			return setMsgToResultMap(resultMap, NSDConstant.MSGID_INPUT_ERROR, errStr);
		}

		// データ登録のサービスを呼び出す
		seisanshoTorokuService.insertSeisansho(kss002, kss004List);

		// 登録正常完了
		setMsgToResultMap(resultMap, NSDConstant.MSGID_INSERT_SUCCES);

		return resultMap;
	}

	/**
	 * 登録情報を設定
	 *
	 * @param reqMap
	 * @param kss004List
	 * @param kss002
	 * @param request
	 * @throws Exception
	 */
	private String setInsertData(Map<String, Object> reqMap, HttpServletRequest request, List<Kss004> kss004List,
			Kss002 kss002) throws Exception {
		// 画面情報を取得
		Kss004 kss004 = new Kss004();
		for (Entry<String, Object> itReq : reqMap.entrySet()) {
			// 適用開始日
			if ("tekiyoStartYmd".equals(itReq.getKey())) {
				kss002.setTekiyoStartYmd(NSDDateUtils.parseStrToCal(reqMap.get("tekiyoStartYmd").toString()).getTime());

				// 適用終了日
			} else if ("tekiyoEndYmd".equals(itReq.getKey())) {
				kss002.setTekiyoEndYmd(NSDDateUtils.parseStrToCal(reqMap.get("tekiyoEndYmd").toString()).getTime());

				// 使用開始年月日
			} else if ("siyoStartYmd".equals(itReq.getKey())) {
				kss004.setSiyoStartYmd(NSDDateUtils.parseStrToCal(reqMap.get("siyoStartYmd").toString()).getTime());
			} else {
				BeanUtils.copyProperty(kss004, itReq.getKey(), itReq.getValue());
				BeanUtils.copyProperty(kss002, itReq.getKey(), itReq.getValue());
			}
		}

		// 入力した件名データ関連チェック
		String errStr = null;
		errStr = checkKenmeiInsertOrUpdate(kss002, NSDConstant.ACTION_INSERT);
		if (StringUtils.isNotEmpty(errStr)) {
			return errStr;
		}

		Date date = new Date();
		String loginUserId = getLoginUserInfo(request).getUserId();

		// 件名マスタ登録データを設定する（画面に存在以外の項目を設定）
		kss002.setRenkeiStatus(NSDConstant.CODE_RENKEI_STATUS_0);
		// 登録ユーザーＩＤ
		kss002.setEntryUserId(loginUserId);
		// 登録年月日
		kss002.setEntryDate(date);
		// 更新ユーザーＩＤ
		kss002.setUpdateUserId(loginUserId);
		// 更新年月日
		kss002.setUpdateDate(date);

		// 精算書登録データを設定する（画面に存在以外の項目を設定）
		// 精算書ＩＤ
		kss004.setSeisanShoId(commService.getSequence(NSDConstant.KSS_SEQ_SEISAN_SHO_ID));
		// 精算書番号
		kss004.setSeisanShoNo(commService.getSequence(NSDConstant.KSS_SEQ_SEISAN_SHO_NO));
		// 精算箇所コード
		Kss011 kss011 = inputCheckService.getSoshikiInfoForInputCheck(((String) reqMap.get("soshikiRenNm")).trim());
		kss004.setSeisanSoshikiCd(kss011.getSoshikiCd());
		// 登録者コード
		Kss013 kss013 = inputCheckService.getUserInfoForInputCheck(((String) reqMap.get("torokushaName")).trim());
		kss004.setSeisanEntryUserId(kss013.getUserId());
		// 承認ステータス（''00':登録中を固定で登録）
		kss004.setShoninStatus(NSDConstant.SHONIN_STATUS_CODE_TOROKU);
		// 版数
		kss004.setHansu(new BigDecimal(commService.getSequence(NSDConstant.KSS_SEQ_HANSU)));
		// 登録ユーザーＩＤ
		kss004.setEntryUserId(loginUserId);
		// 登録年月日
		kss004.setEntryDate(date);
		// 更新ユーザーＩＤ
		kss004.setUpdateUserId(loginUserId);
		// 更新年月日
		kss004.setUpdateDate(date);
		// 予約件数
		int yoyakusu = Integer.valueOf(reqMap.get("yoyakusu").toString());
		Kss004 kss004Loop = new Kss004();
		// 予約件数分ループして、固定資産ＩＤと固定資産番号を精算書テーブルに登録する
		for (int i = 0; i < yoyakusu; i++) {
			kss004Loop = new Kss004();
			kss004Loop = (Kss004) BeanUtils.cloneBean(kss004);
			// 固定資産ＩＤ
			kss004Loop.setKoteiShisanId(commService.getSequence(NSDConstant.KSS_SEQ_KOTEI_SHISAN_ID));

			// 固定資産番号
			kss004Loop.setKoteiShisanNo(commService.getSequence(NSDConstant.KSS_SEQ_KOTEI_SHISAN_NO));
			kss004List.add(kss004Loop);
		}

		return errStr;
	}

	/**
	 * 精算書登録（新規登録・修正）処理
	 *
	 * @param reqMap
	 * @throws Exception
	 */
	@RequestMapping(value = "/seisanshoToroku-modifySeisansho", method = RequestMethod.POST)
	public Map<String, Object> modifySeisansho(HttpServletRequest request, @RequestParam Map<String, Object> reqMap)
			throws Exception {

		Map<String, Object> resultMap = new HashMap<String, Object>();

		// 入力チェック
		String errStr = inputCheckForInsert(reqMap, NSDConstant.ACTION_UPDATE);
		if (StringUtils.isNotEmpty(errStr)) {
			return setMsgToResultMap(resultMap, NSDConstant.MSGID_INPUT_ERROR, errStr);
		}

		// 画面情報を取得
		List<Kss004> kss004List = new ArrayList<Kss004>();
		Kss004 kss004 = new Kss004();
		Kss002 kss002 = new Kss002();
		errStr = setModifyData(reqMap, request, kss004List, kss004, kss002);
		if (StringUtils.isNotEmpty(errStr)) {
			return setMsgToResultMap(resultMap, NSDConstant.MSGID_INPUT_ERROR, errStr);
		}

		String errId = NSDConstant.BLANK_STRING;
		// 排他チェック
		errId = commService.doHaita(kss002, (String) reqMap.get("updateDate02"));
		if (!NSDConstant.BLANK_STRING.equals(errId)) {
			return setMsgToResultMap(resultMap, errId);
		}
		// 排他チェック
		errId = commService.doHaita(kss004, (String) reqMap.get("updateDate04"));
		if (!NSDConstant.BLANK_STRING.equals(errId)) {
			return setMsgToResultMap(resultMap, errId);
		}

		// データ修正のサービスを呼び出す
		seisanshoTorokuService.modifySeisansho(kss002, kss004, kss004List);

		// 登録正常完了
		setMsgToResultMap(resultMap, NSDConstant.MSGID_UPDATE_SUCCES);

		return resultMap;
	}

	/**
	 * 更新情報を設定
	 *
	 * @param reqMap
	 * @param request
	 * @param kss004List
	 * @param kss002
	 * @param kss004
	 * @throws Exception
	 */
	private String setModifyData(Map<String, Object> reqMap, HttpServletRequest request, List<Kss004> kss004List,
			Kss004 kss004, Kss002 kss002) throws Exception {
		// 画面情報を取得
		for (Entry<String, Object> itReq : reqMap.entrySet()) {
			// 適用開始日
			if ("tekiyoStartYmd".equals(itReq.getKey())) {
				kss002.setTekiyoStartYmd(NSDDateUtils.parseStrToCal(reqMap.get("tekiyoStartYmd").toString()).getTime());

				// 適用終了日
			} else if ("tekiyoEndYmd".equals(itReq.getKey())) {
				kss002.setTekiyoEndYmd(NSDDateUtils.parseStrToCal(reqMap.get("tekiyoEndYmd").toString()).getTime());

				// 使用開始年月日
			} else if ("siyoStartYmd".equals(itReq.getKey())) {
				kss004.setSiyoStartYmd(NSDDateUtils.parseStrToCal(reqMap.get("siyoStartYmd").toString()).getTime());

				// 更新年月日
			} else if ("updateDate02".equals(itReq.getKey())) {
				// 処理しない

				// 更新年月日
			} else if ("updateDate04".equals(itReq.getKey())) {
				// 処理しない

			} else {
				BeanUtils.copyProperty(kss004, itReq.getKey(), itReq.getValue());
				BeanUtils.copyProperty(kss002, itReq.getKey(), itReq.getValue());
			}
		}

		String errStr = null;

		// 入力した件名データ関連チェック
		errStr = checkKenmeiInsertOrUpdate(kss002, NSDConstant.ACTION_UPDATE);
		if (StringUtils.isNotEmpty(errStr)) {
			return errStr;
		}

		Date date = new Date();
		String loginUserId = getLoginUserInfo(request).getUserId();

		// 件名マスタ更新情報を設定する（画面に存在以外の項目を設定）
		// 更新ユーザーＩＤ
		kss002.setUpdateUserId(loginUserId);
		// 更新年月日
		kss002.setUpdateDate(date);

		// 精算書更新情報を設定する（画面に存在以外の項目を設定）
		// 精算箇所コード
		Kss011 kss011 = inputCheckService.getSoshikiInfoForInputCheck(((String) reqMap.get("soshikiRenNm")).trim());
		kss004.setSeisanSoshikiCd(kss011.getSoshikiCd());
		// 登録者コード
		Kss013 kss013 = inputCheckService.getUserInfoForInputCheck(((String) reqMap.get("torokushaName")).trim());
		kss004.setSeisanEntryUserId(kss013.getUserId());
		// 版数
		kss004.setHansu(new BigDecimal(commService.getSequence(NSDConstant.KSS_SEQ_HANSU)));
		// 更新ユーザーＩＤ
		kss004.setUpdateUserId(loginUserId);
		// 更新年月日
		kss004.setUpdateDate(date);

		// 追加予約数
		int yoyakusu = 0;
		if (StringUtils.isNotEmpty((String) reqMap.get("tsuikaYoyakusu"))) {
			yoyakusu = Integer.valueOf((String) reqMap.get("tsuikaYoyakusu"));
		}
		Kss004 kss004Loop = new Kss004();
		// 追加予約数分ループして、固定資産ＩＤと固定資産番号を精算書テーブルに登録する
		for (int i = 0; i < yoyakusu; i++) {
			kss004Loop = new Kss004();
			kss004Loop = (Kss004) BeanUtils.cloneBean(kss004);
			// 登録ユーザーＩＤ
			kss004Loop.setEntryUserId(kss004.getUpdateUserId());
			// 登録年月日
			kss004Loop.setEntryDate(kss004.getUpdateDate());
			// 固定資産ＩＤ
			kss004Loop.setKoteiShisanId(commService.getSequence(NSDConstant.KSS_SEQ_KOTEI_SHISAN_ID));
			// 固定資産番号
			kss004Loop.setKoteiShisanNo(commService.getSequence(NSDConstant.KSS_SEQ_KOTEI_SHISAN_NO));
			kss004List.add(kss004Loop);
		}

		return errStr;
	}

	/**
	 * 精算書登録・新規登録・更新の入力データチェック
	 *
	 * @param reqMap
	 *            INPUTパラメータ
	 * @param actionFlag
	 *            チェック区分
	 * @return エラーメッセージID
	 * @version 1.00
	 */
	private String inputCheckForInsert(Map<String, Object> reqMap, int actionFlag) {

		List<InputCheck> inputCheckList = getCheckItemListForInsertUpdate(reqMap, actionFlag);
		return nsdDataCheck.dataCheck(inputCheckList);

	}

	/**
	 * 登録、修正項目のチェック内容リストを定義
	 *
	 * @param reqMap
	 *            INPUTパラメータ
	 * @param actionFlag
	 *            登録・更新フラグ 0:登録 1:更新
	 * @param chkKbn
	 *            チェック区分
	 * @return
	 */
	private List<InputCheck> getCheckItemListForInsertUpdate(Map<String, Object> reqMap, int actionFlag) {

		List<InputCheck> inputCheckList = new ArrayList<InputCheck>();
		Map<Integer, Object> args;

		args = new HashMap<Integer, Object>();
		args.put(NSDConstant.CHECK_ITEM.EMPTY_CHECK.ordinal(), null);
		args.put(NSDConstant.CHECK_ITEM.IS_EXIST_SOSHIKIRENNM.ordinal(), null);
		inputCheckList.add(setInputCheck(reqMap, "soshikiRenNm", "精算箇所：", args));

		args = new HashMap<Integer, Object>();
		args.put(NSDConstant.CHECK_ITEM.EMPTY_CHECK.ordinal(), null);
		args.put(NSDConstant.CHECK_ITEM.DATE_FORMAT_CHECK.ordinal(), null);
		inputCheckList.add(setInputCheck(reqMap, "siyoStartYmd", "使用開始年月日：", args));

		args = new HashMap<Integer, Object>();
		args.put(NSDConstant.CHECK_ITEM.EMPTY_CHECK.ordinal(), null);
		args.put(NSDConstant.CHECK_ITEM.LENGTH_CHECK.ordinal(), 40);
		args.put(NSDConstant.CHECK_ITEM.IS_EXIST_SEIMEI.ordinal(), null);
		args.put(NSDConstant.CHECK_ITEM.IS_EXIST_USER_SOSHIKI.ordinal(), reqMap.get("soshikiRenNm"));
		inputCheckList.add(setInputCheck(reqMap, "torokushaName", "登録者氏名：", args));

		if (NSDConstant.ACTION_INSERT == actionFlag) {
			args = new HashMap<Integer, Object>();
			args.put(NSDConstant.CHECK_ITEM.EMPTY_CHECK.ordinal(), null);
			args.put(NSDConstant.CHECK_ITEM.NUMERIC_CHECK.ordinal(), null);
			Map<String, String> rangeNum = new HashMap<String, String>();
			rangeNum.put("startValue", "0");
			rangeNum.put("compareWay", "3");
			args.put(NSDConstant.CHECK_ITEM.NUMERIC_RANGE_CHECK.ordinal(), rangeNum);
			inputCheckList.add(setInputCheck(reqMap, "yoyakusu", "予約数：", args));
		}

		if (NSDConstant.ACTION_UPDATE == actionFlag) {
			args = new HashMap<Integer, Object>();
			args.put(NSDConstant.CHECK_ITEM.NUMERIC_CHECK.ordinal(), null);
			inputCheckList.add(setInputCheck(reqMap, "tsuikaYoyakusu", "追加予約数：", args));
		}

		args = new HashMap<Integer, Object>();
		args.put(NSDConstant.CHECK_ITEM.EMPTY_CHECK.ordinal(), null);
		inputCheckList.add(setInputCheck(reqMap, "kenmeiCd", "工事件名コード：", args));

		args = new HashMap<Integer, Object>();
		args.put(NSDConstant.CHECK_ITEM.EMPTY_CHECK.ordinal(), null);
		args.put(NSDConstant.CHECK_ITEM.MSGID_CHECK_IS_ZENKAKU.ordinal(), null);
		args.put(NSDConstant.CHECK_ITEM.LENGTH_CHECK.ordinal(), 20);
		inputCheckList.add(setInputCheck(reqMap, "kenmeiNm", "工事件名：", args));

		args = new HashMap<Integer, Object>();
		args.put(NSDConstant.CHECK_ITEM.EMPTY_CHECK.ordinal(), null);
		args.put(NSDConstant.CHECK_ITEM.DATE_FORMAT_CHECK.ordinal(), null);
		inputCheckList.add(setInputCheck(reqMap, "tekiyoStartYmd", "適用開始日：", args));

		args = new HashMap<Integer, Object>();
		args.put(NSDConstant.CHECK_ITEM.EMPTY_CHECK.ordinal(), null);
		args.put(NSDConstant.CHECK_ITEM.DATE_FORMAT_CHECK.ordinal(), null);
		inputCheckList.add(setInputCheck(reqMap, "tekiyoEndYmd", "適用終了日：", args));

		args = new HashMap<Integer, Object>();
		args.put(NSDConstant.CHECK_ITEM.DATE_COMPARE_CHECK.ordinal(), (String) reqMap.get("tekiyoEndYmd"));
		inputCheckList.add(setInputCheck(reqMap, "tekiyoStartYmd", "適用開始日：", args));

		args = new HashMap<Integer, Object>();
		args.put(NSDConstant.CHECK_ITEM.DATE_COMPARE_CHECK.ordinal(), (String) reqMap.get("tekiyoStartYmd"));
		reqMap.put("firstDayBefore2Month", getFirstDayBefore2Month());
		inputCheckList.add(setInputCheck(reqMap, "firstDayBefore2Month", "適用開始日：", args));

		args = new HashMap<Integer, Object>();
		args.put(NSDConstant.CHECK_ITEM.DATE_COMPARE_CHECK.ordinal(), NSDConstant.TEKIYT_YMD);
		inputCheckList.add(setInputCheck(reqMap, "tekiyoEndYmd", "適用終了日：", args));

		args = new HashMap<Integer, Object>();
		Map<String, String> kikan = new HashMap<String, String>();
		kikan.put("startDate", (String) reqMap.get("tekiyoStartYmd"));
		kikan.put("endDate", (String) reqMap.get("tekiyoEndYmd"));
		args.put(NSDConstant.CHECK_ITEM.DATE_KIKAN_CHECK.ordinal(), kikan);
		inputCheckList.add(setInputCheck(reqMap, "siyoStartYmd", "使用開始日：適用期間内", args));

		return inputCheckList;
	}

	/**
	 * 入力した件名データ関連チェック
	 *
	 * @param actionFlag
	 *            チェック区分
	 * @param parameterMap
	 */
	private String checkKenmeiInsertOrUpdate(Kss002 parameterKss002, int actionFlag) {

		Kss002 inParamKss002 = new Kss002();
		// 件名コード
		inParamKss002.setKenmeiCd(parameterKss002.getKenmeiCd());
		// 件名マスタ情報を取得
		Kss002 chkKss002 = sssTrkMapper.getKss002(inParamKss002);
		if (null != chkKss002) {
			if (!(chkKss002.getKenmeiNm().equals(parameterKss002.getKenmeiNm())
					&& chkKss002.getTekiyoStartYmd().equals(parameterKss002.getTekiyoStartYmd())
					&& chkKss002.getTekiyoEndYmd().equals(parameterKss002.getTekiyoEndYmd()))) {
				if (NSDConstant.ACTION_INSERT == actionFlag) {
					return NSDCommUtils.setKakoToStr(
							"工事件名：".concat(systemService.getMessage(NSDConstant.MSGID_KENMEI_INSERTED).getContent()));
				}
				if (NSDConstant.ACTION_UPDATE == actionFlag) {
					if (NSDConstant.STRING_1.equals(chkKss002.getRenkeiStatus())) {
						return NSDCommUtils.setKakoToStr(
								"工事件名：".concat(systemService.getMessage(NSDConstant.MSGID_RENKEI_COMPLETE).getContent()));
					}
				}
			}
		}

		return null;
	}

}
