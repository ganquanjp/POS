package jp.co.nsd.nkssweb.dao.mapper;

import jp.co.nsd.nkssweb.dao.Kss005;
import jp.co.nsd.nkssweb.dao.Kss005Key;

public interface Kss005Mapper {
    int deleteByPrimaryKey(Kss005Key key);

    int insert(Kss005 record);

    int insertSelective(Kss005 record);

    Kss005 selectByPrimaryKey(Kss005Key key);

    int updateByPrimaryKeySelective(Kss005 record);

    int updateByPrimaryKey(Kss005 record);
}