package jp.co.nsd.nkssweb.dao;

import java.util.Date;

public class Awdm12 {
    private String mwcShinCod;

    private String mwcCityCod;

    private String mwcBashoCod;

    private Integer mwcUpdateCnt;

    private Date mwcTorokDh;

    private String mwcTorshaCod;

    private Date mwcUpdateDh;

    private String mwcUpdshaCod;

    public String getMwcShinCod() {
        return mwcShinCod;
    }

    public void setMwcShinCod(String mwcShinCod) {
        this.mwcShinCod = mwcShinCod == null ? null : mwcShinCod.trim();
    }

    public String getMwcCityCod() {
        return mwcCityCod;
    }

    public void setMwcCityCod(String mwcCityCod) {
        this.mwcCityCod = mwcCityCod == null ? null : mwcCityCod.trim();
    }

    public String getMwcBashoCod() {
        return mwcBashoCod;
    }

    public void setMwcBashoCod(String mwcBashoCod) {
        this.mwcBashoCod = mwcBashoCod == null ? null : mwcBashoCod.trim();
    }

    public Integer getMwcUpdateCnt() {
        return mwcUpdateCnt;
    }

    public void setMwcUpdateCnt(Integer mwcUpdateCnt) {
        this.mwcUpdateCnt = mwcUpdateCnt;
    }

    public Date getMwcTorokDh() {
        return mwcTorokDh;
    }

    public void setMwcTorokDh(Date mwcTorokDh) {
        this.mwcTorokDh = mwcTorokDh;
    }

    public String getMwcTorshaCod() {
        return mwcTorshaCod;
    }

    public void setMwcTorshaCod(String mwcTorshaCod) {
        this.mwcTorshaCod = mwcTorshaCod == null ? null : mwcTorshaCod.trim();
    }

    public Date getMwcUpdateDh() {
        return mwcUpdateDh;
    }

    public void setMwcUpdateDh(Date mwcUpdateDh) {
        this.mwcUpdateDh = mwcUpdateDh;
    }

    public String getMwcUpdshaCod() {
        return mwcUpdshaCod;
    }

    public void setMwcUpdshaCod(String mwcUpdshaCod) {
        this.mwcUpdshaCod = mwcUpdshaCod == null ? null : mwcUpdshaCod.trim();
    }
}