package jp.co.nsd.nkssweb.dao;

import java.util.Date;

public class Kss013 {
    private String userId;

    private String sei;

    private String mei;

    private String seiMei;

    private Date nyushaYmd;

    private Date taishokuYmd;

    private String zaisekiKbn;

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId == null ? null : userId.trim();
    }

    public String getSei() {
        return sei;
    }

    public void setSei(String sei) {
        this.sei = sei == null ? null : sei.trim();
    }

    public String getMei() {
        return mei;
    }

    public void setMei(String mei) {
        this.mei = mei == null ? null : mei.trim();
    }

	public String getSeiMei() {
		return seiMei;
	}

	public void setSeiMei(String seiMei) {
		this.seiMei = seiMei;
	}

	public Date getNyushaYmd() {
        return nyushaYmd;
    }

    public void setNyushaYmd(Date nyushaYmd) {
        this.nyushaYmd = nyushaYmd;
    }

    public Date getTaishokuYmd() {
        return taishokuYmd;
    }

    public void setTaishokuYmd(Date taishokuYmd) {
        this.taishokuYmd = taishokuYmd;
    }

    public String getZaisekiKbn() {
        return zaisekiKbn;
    }

    public void setZaisekiKbn(String zaisekiKbn) {
        this.zaisekiKbn = zaisekiKbn == null ? null : zaisekiKbn.trim();
    }
}