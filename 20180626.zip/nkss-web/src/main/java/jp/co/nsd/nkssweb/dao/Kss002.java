package jp.co.nsd.nkssweb.dao;

import java.util.Date;

public class Kss002 {
    private Long kenmeiId;

    private String kenmeiCd;

    private String kenmeiNm;

    private Date tekiyoStartYmd;

    private Date tekiyoEndYmd;

    private String renkeiStatus;

    private Date entryDate;

    private String entryUserId;

    private Date updateDate;

    private String updateUserId;

    public Long getKenmeiId() {
        return kenmeiId;
    }

    public void setKenmeiId(Long kenmeiId) {
        this.kenmeiId = kenmeiId;
    }

    public String getKenmeiCd() {
        return kenmeiCd;
    }

    public void setKenmeiCd(String kenmeiCd) {
        this.kenmeiCd = kenmeiCd == null ? null : kenmeiCd.trim();
    }

    public String getKenmeiNm() {
        return kenmeiNm;
    }

    public void setKenmeiNm(String kenmeiNm) {
        this.kenmeiNm = kenmeiNm == null ? null : kenmeiNm.trim();
    }

    public Date getTekiyoStartYmd() {
        return tekiyoStartYmd;
    }

    public void setTekiyoStartYmd(Date tekiyoStartYmd) {
        this.tekiyoStartYmd = tekiyoStartYmd;
    }

    public Date getTekiyoEndYmd() {
        return tekiyoEndYmd;
    }

    public void setTekiyoEndYmd(Date tekiyoEndYmd) {
        this.tekiyoEndYmd = tekiyoEndYmd;
    }

    public String getRenkeiStatus() {
        return renkeiStatus;
    }

    public void setRenkeiStatus(String renkeiStatus) {
        this.renkeiStatus = renkeiStatus == null ? null : renkeiStatus.trim();
    }

    public Date getEntryDate() {
        return entryDate;
    }

    public void setEntryDate(Date entryDate) {
        this.entryDate = entryDate;
    }

    public String getEntryUserId() {
        return entryUserId;
    }

    public void setEntryUserId(String entryUserId) {
        this.entryUserId = entryUserId == null ? null : entryUserId.trim();
    }

    public Date getUpdateDate() {
        return updateDate;
    }

    public void setUpdateDate(Date updateDate) {
        this.updateDate = updateDate;
    }

    public String getUpdateUserId() {
        return updateUserId;
    }

    public void setUpdateUserId(String updateUserId) {
        this.updateUserId = updateUserId == null ? null : updateUserId.trim();
    }
}