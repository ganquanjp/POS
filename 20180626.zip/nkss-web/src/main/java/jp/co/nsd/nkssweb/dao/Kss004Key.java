package jp.co.nsd.nkssweb.dao;

public class Kss004Key {
    private String seisanShoId;

    private String koteiShisanId;

    public String getSeisanShoId() {
        return seisanShoId;
    }

    public void setSeisanShoId(String seisanShoId) {
        this.seisanShoId = seisanShoId == null ? null : seisanShoId.trim();
    }

    public String getKoteiShisanId() {
        return koteiShisanId;
    }

    public void setKoteiShisanId(String koteiShisanId) {
        this.koteiShisanId = koteiShisanId == null ? null : koteiShisanId.trim();
    }
}