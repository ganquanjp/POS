package jp.co.nsd.nkssweb.dao;

import java.util.Date;

public class Awda20 {
    private String awkKomokSbt;

    private String awkKmksbtCod;

    private String awkKmksbtKnj;

    private String awkMeishoKnj;

    private Integer awkUpdateCnt;

    private Date awkTorokDh;

    private String awkTorshaCod;

    private Date awkUpdateDh;

    private String awkUpdshaCod;

    public String getAwkKomokSbt() {
        return awkKomokSbt;
    }

    public void setAwkKomokSbt(String awkKomokSbt) {
        this.awkKomokSbt = awkKomokSbt == null ? null : awkKomokSbt.trim();
    }

    public String getAwkKmksbtCod() {
        return awkKmksbtCod;
    }

    public void setAwkKmksbtCod(String awkKmksbtCod) {
        this.awkKmksbtCod = awkKmksbtCod == null ? null : awkKmksbtCod.trim();
    }

    public String getAwkKmksbtKnj() {
        return awkKmksbtKnj;
    }

    public void setAwkKmksbtKnj(String awkKmksbtKnj) {
        this.awkKmksbtKnj = awkKmksbtKnj == null ? null : awkKmksbtKnj.trim();
    }

    public String getAwkMeishoKnj() {
        return awkMeishoKnj;
    }

    public void setAwkMeishoKnj(String awkMeishoKnj) {
        this.awkMeishoKnj = awkMeishoKnj == null ? null : awkMeishoKnj.trim();
    }

    public Integer getAwkUpdateCnt() {
        return awkUpdateCnt;
    }

    public void setAwkUpdateCnt(Integer awkUpdateCnt) {
        this.awkUpdateCnt = awkUpdateCnt;
    }

    public Date getAwkTorokDh() {
        return awkTorokDh;
    }

    public void setAwkTorokDh(Date awkTorokDh) {
        this.awkTorokDh = awkTorokDh;
    }

    public String getAwkTorshaCod() {
        return awkTorshaCod;
    }

    public void setAwkTorshaCod(String awkTorshaCod) {
        this.awkTorshaCod = awkTorshaCod == null ? null : awkTorshaCod.trim();
    }

    public Date getAwkUpdateDh() {
        return awkUpdateDh;
    }

    public void setAwkUpdateDh(Date awkUpdateDh) {
        this.awkUpdateDh = awkUpdateDh;
    }

    public String getAwkUpdshaCod() {
        return awkUpdshaCod;
    }

    public void setAwkUpdshaCod(String awkUpdshaCod) {
        this.awkUpdshaCod = awkUpdshaCod == null ? null : awkUpdshaCod.trim();
    }
}