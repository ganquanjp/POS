package jp.co.nsd.nkssweb.dao;

/**
 * 子固定資産一覧
 *
 * @version 1.00
 */
public class KosisanInfo {
	// 子固定資産一覧情報
	// 固定資産番号
	private String koteiShisanNo;
	// 総件数
	private Long shutokuSisanCnt;
	/**
	 * @return koteiShisanNo
	 */
	public String getKoteiShisanNo() {
		return koteiShisanNo;
	}

	/**
	 * @param koteiShisanNo セットする koteiShisanNo
	 */
	public void setKoteiShisanNo(String koteiShisanNo) {
		this.koteiShisanNo = koteiShisanNo;
	}

	/**
	 * @return shutokuSisanCnt
	 */
	public Long getShutokuSisanCnt() {
		return shutokuSisanCnt;
	}

	/**
	 * @param shutokuSisanCnt セットする shutokuSisanCnt
	 */
	public void setShutokuSisanCnt(Long shutokuSisanCnt) {
		this.shutokuSisanCnt = shutokuSisanCnt;
	}
}