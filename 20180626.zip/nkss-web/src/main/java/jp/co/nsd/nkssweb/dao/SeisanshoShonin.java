package jp.co.nsd.nkssweb.dao;

public class SeisanshoShonin {

	// 行番号
	private int rowNo;

	// 精算書番号
	private String seisanShoNo;

	// 精算箇所
	private String soshikiRenNm;

	// 使用開始年月日
	private String siyoStartYmd;

	// 使用開始年月日(From)
	private String siyoStartYmdFrom;

	// 使用開始年月日(To)
	private String siyoStartYmdTo;

	// 登録者氏名
	private String torokusyaNm;

	// 取得価額合計
	private String shutokuKagakuGokei;

	// 承認ステータス
	private String shoninStatusCd;

	// 承認状態
	private String shoninStatusNm;

	// 工事件名コード
	private String kenmeiCd;

	// 工事件名
	private String kenmeiNm;

	public int getRowNo() {
		return rowNo;
	}

	public void setRowNo(int rowNo) {
		this.rowNo = rowNo;
	}

	public String getSeisanShoNo() {
		return seisanShoNo;
	}

	public void setSeisanShoNo(String seisanShoNo) {
		this.seisanShoNo = seisanShoNo;
	}

	public String getSoshikiRenNm() {
		return soshikiRenNm;
	}

	public void setSoshikiRenNm(String soshikiRenNm) {
		this.soshikiRenNm = soshikiRenNm;
	}

	public String getSiyoStartYmd() {
		return siyoStartYmd;
	}

	public void setSiyoStartYmd(String siyoStartYmd) {
		this.siyoStartYmd = siyoStartYmd;
	}

	public String getSiyoStartYmdFrom() {
		return siyoStartYmdFrom;
	}

	public void setSiyoStartYmdFrom(String siyoStartYmdFrom) {
		this.siyoStartYmdFrom = siyoStartYmdFrom;
	}

	public String getSiyoStartYmdTo() {
		return siyoStartYmdTo;
	}

	public void setSiyoStartYmdTo(String siyoStartYmdTo) {
		this.siyoStartYmdTo = siyoStartYmdTo;
	}

	public String getTorokusyaNm() {
		return torokusyaNm;
	}

	public void setTorokusyaNm(String torokusyaNm) {
		this.torokusyaNm = torokusyaNm;
	}

	public String getShutokuKagakuGokei() {
		return shutokuKagakuGokei;
	}

	public void setShutokuKagakuGokei(String shutokuKagakuGokei) {
		this.shutokuKagakuGokei = shutokuKagakuGokei;
	}

	public String getShoninStatusCd() {
		return shoninStatusCd;
	}

	public void setShoninStatusCd(String shoninStatusCd) {
		this.shoninStatusCd = shoninStatusCd;
	}

	public String getShoninStatusNm() {
		return shoninStatusNm;
	}

	public void setShoninStatusNm(String shoninStatusNm) {
		this.shoninStatusNm = shoninStatusNm;
	}

	public String getKenmeiCd() {
		return kenmeiCd;
	}

	public void setKenmeiCd(String kenmeiCd) {
		this.kenmeiCd = kenmeiCd;
	}

	public String getKenmeiNm() {
		return kenmeiNm;
	}

	public void setKenmeiNm(String kenmeiNm) {
		this.kenmeiNm = kenmeiNm;
	}






}