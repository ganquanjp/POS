/***********************************************************************
*
*業務名: 工事精算システム
*機能名: 除却（承認）(サービス処理)
*
*機能概要: 除却（承認）情報を処理する。
*
*JavaＶｅｒ：J2SE1.8.0準拠
*
*更新履歴: Ver.1.00 2018/03/06　NSD　新規作成
***********************************************************************/
package jp.co.nsd.nkssweb.service.seisanshojokyaku.impl;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.beanutils.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import jp.co.nsd.nkssweb.dao.JokyakuSeisanDaityo;
import jp.co.nsd.nkssweb.dao.JokyakuSeisansho;
import jp.co.nsd.nkssweb.dao.KosisanInfo;
import jp.co.nsd.nkssweb.dao.KoteiSisan;
import jp.co.nsd.nkssweb.dao.Kss006;
import jp.co.nsd.nkssweb.dao.SeisanshoJokyakuKoteiSisan;
import jp.co.nsd.nkssweb.dao.SeisanshoJokyakuShonin;
import jp.co.nsd.nkssweb.dao.SeisanshoJokyakuShoninPrint;
import jp.co.nsd.nkssweb.dao.SeisanshoJokyakuShoninShokai;
import jp.co.nsd.nkssweb.dao.mapper.SeisanshoJokyakuShoninMapper;
import jp.co.nsd.nkssweb.oracle.mapper.KoteiSisanJyohoMapper;
import jp.co.nsd.nkssweb.service.CommService;
import jp.co.nsd.nkssweb.service.seisanshojokyaku.SeisanshoJokyakuShoninService;
import jp.co.nsd.nkssweb.utils.NSDConstant;
import jp.co.nsd.nkssweb.utils.NSDFileExporter;
import jp.co.nsd.nkssweb.utils.NSDProperties;
import net.sf.jasperreports.engine.data.JRBeanCollectionDataSource;

/**
 * 除却（承認）処理
 *
 * @see SeisanshoJokyakuShoninService
 * @version 1.00
 */
@Service
@Transactional(value = "postgresqlTransactionManager")
public class SeisanshoJokyakuShoninServiceImpl implements SeisanshoJokyakuShoninService {

	@Autowired
	private SeisanshoJokyakuShoninMapper seisanshoJokyakuShoninMapper;

	@Autowired
	private KoteiSisanJyohoMapper koteiSisanJyohoMapper;

	@Autowired
	private CommService commService;

	@Autowired
	private NSDProperties nsdProperties;

	@Autowired
	private NSDFileExporter nsdFileExporter;

	/**
	 * 除却（承認）検索処理
	 *
	 * @param SeisanshoJokyakuShonin
	 *            INPUTパラメータ
	 * @return sssJykList 除却情報データリスト
	 * @version 1.00
	 */
	public List<SeisanshoJokyakuShonin> getJokyakuShoninInfo(SeisanshoJokyakuShonin seisanshoJokyakuShonin) {

		// 除却情報を取得する
		List<SeisanshoJokyakuShonin> sssJykSnList = seisanshoJokyakuShoninMapper.selectByWhere(seisanshoJokyakuShonin);

		if (sssJykSnList.size() > 0) {

			for (int i = 0; i < sssJykSnList.size(); i++) {

				SeisanshoJokyakuShonin sssJykSn = sssJykSnList.get(i);

				// ROWNOを設定する
				sssJykSn.setRowNo(i + 1);

				// 承認状態名称
				sssJykSn.setShoninJotai(
						commService.getCodeName(NSDConstant.CD_SHONIN_STATUS, sssJykSn.getShoninStatus()));
			}
		} else {
			sssJykSnList = null;
		}

		return sssJykSnList;
	}

	/**
	 * 除却承認（照会）処理
	 *
	 * @param seisanshoJokyakuShoninShokai
	 *            INPUTパラメータ
	 * @return SeisanshoJokyakuShoninShokai 除却情報データ
	 * @throws Exception
	 * @version 1.00
	 */
	public SeisanshoJokyakuShoninShokai getJokyakuInfoBySeisanShoNo(
			SeisanshoJokyakuShoninShokai seisanshoJokyakuShoninShokai) throws Exception {

		// 除却情報
		SeisanshoJokyakuShoninShokai resultDto = new SeisanshoJokyakuShoninShokai();
		// 除却固定資産情報
		SeisanshoJokyakuKoteiSisan sssJykKsDto;

		// 除却資産情報を取得する
		List<SeisanshoJokyakuShoninShokai> sssJykSnSkList = seisanshoJokyakuShoninMapper
				.selectBySeisanShoNo(seisanshoJokyakuShoninShokai);

		List<SeisanshoJokyakuKoteiSisan> sssJykKsLst = new ArrayList<>();

		for (int i = 0; i < sssJykSnSkList.size(); i++) {
			// 除却資産情報
			SeisanshoJokyakuShoninShokai sssJykSnSkDto = sssJykSnSkList.get(i);

			// Mapの情報をBeanのプロパティにセット
			BeanUtils.copyProperties(resultDto, sssJykSnSkDto);

			// 承認状態名称
			resultDto.setShoninJotai(
					commService.getCodeName(NSDConstant.CD_SHONIN_STATUS, sssJykSnSkDto.getShoninStatus()));

			KoteiSisan koteiSisan = new KoteiSisan();

			// 固定ID
			koteiSisan.setKoteiCod(sssJykSnSkDto.getMotoKoteiShisanId());
			// 履歴ID
			koteiSisan.setRrkCod(sssJykSnSkDto.getRirekiNo());
			// 固定資産情報を取得する
			KoteiSisan ksDto = koteiSisanJyohoMapper.selectKoteiSisanByKoteiCod(koteiSisan);

			// 固定資産情報取得できないの場合
			if (null != ksDto) {

				sssJykKsDto = new SeisanshoJokyakuKoteiSisan();
				// ROWNO
				sssJykKsDto.setRowNo(i + 1);
				// 固定資産番号
				sssJykKsDto.setKoteiNo(ksDto.getKoteiNo());
				// 固定資産名称
				sssJykKsDto.setKoteiKnj(ksDto.getKoteiKnj());
				// 取得年月日
				sssJykKsDto.setGetYmd(ksDto.getGetYmd());
				// 使用開始年月日
				sssJykKsDto.setUseYmd(ksDto.getUseYmd());
				// 除_取得価額
				sssJykKsDto.setJokyakuGaku(sssJykSnSkDto.getJokyakuGaku());
				// 固定資産情報を追加
				sssJykKsLst.add(sssJykKsDto);
			}
		}

		if (sssJykKsLst.size() > 0) {
			// 固定資産情報リスト
			resultDto.setKoteiSisanLst(sssJykKsLst);
		} else {
			return null;
		}

		return resultDto;
	}

	/**
	 * 除却承認（更新）処理
	 *
	 * @param kss006
	 *            INPUTパラメータ
	 * @return 結果
	 * @throws Exception
	 * @version 1.00
	 */
	public int updateInfo(Kss006 kss006) throws Exception {

		// 版数採番
		String seqHansu = commService.getSequence(NSDConstant.KSS_SEQ_HANSU);

		// 版数
		kss006.setHansu(new BigDecimal(seqHansu));

		int cnt = seisanshoJokyakuShoninMapper.updateByPrimaryKey(kss006);

		return cnt;
	}

	/**
	 * 除却承認（印刷）
	 *
	 * @param jokyakuSeisanShoId
	 *            INPUTパラメータ
	 * @return 結果
	 * @throws Exception
	 */
	@Override
	public List<String> printing(String jokyakuSeisanShoId) throws Exception {

		List<Map<String, Object>> pdfMap = new ArrayList<>();

		Map<String, Object> map = null;

		// ファイル名
		String fileName = "除却精算書";

		// 子固定資産一覧
		List<String> kosisanNoLst = seisanshoJokyakuShoninMapper.getJokyakuOyakoteiInfo(jokyakuSeisanShoId);
		// 子固定資産：有無
		String oyakoteiFlg = NSDConstant.STRING_0;
		if (kosisanNoLst.size() > 0) {
			oyakoteiFlg = NSDConstant.STRING_1;
		}

		map = new HashMap<>();
		map.put("jrbcds", new JRBeanCollectionDataSource(setJokyakuSeisanshoPdf(jokyakuSeisanShoId, oyakoteiFlg)));
		map.put("templateFile",
				nsdProperties.getTemplateFilePath().concat(nsdProperties.getTemplatePdfNameKSS042P040()));
		// 除却精算書PDF
		pdfMap.add(map);

		map = new HashMap<>();
		map.put("jrbcds", new JRBeanCollectionDataSource(setJokyakuSeisanDaityoPdf(jokyakuSeisanShoId)));
		map.put("templateFile",
				nsdProperties.getTemplateFilePath().concat(nsdProperties.getTemplatePdfNameKSS041P050()));
		// 資産台帳別内訳PDF
		pdfMap.add(map);

		// 子固定資産：有
		if (NSDConstant.STRING_1.equals(oyakoteiFlg)) {
			map = new HashMap<>();
			map.put("jrbcds", new JRBeanCollectionDataSource(setJokyakuOyakoteiPdf(kosisanNoLst)));
			map.put("templateFile",
					nsdProperties.getTemplateFilePath().concat(nsdProperties.getTemplatePdfNameKSS041P060()));
			// 子固定資産一覧PDF
			pdfMap.add(map);
		}

		nsdFileExporter.exportPdf(pdfMap, fileName);

		// 帳票名称の保存
		List<String> pdfFileNameLst = new ArrayList<>();
		pdfFileNameLst.add(fileName);

		return pdfFileNameLst;
	}

	/**
	 * 除却精算書ＰＤＦのデータを設定
	 *
	 * @param jokyakuSeisanShoId
	 *            INPUTパラメータ
	 * @param oyakoteiFlg
	 *            INPUTパラメータ
	 * @return 結果
	 */
	private List<JokyakuSeisansho> setJokyakuSeisanshoPdf(String jokyakuSeisanShoId, String oyakoteiFlg) {

		List<JokyakuSeisansho> printLst = new ArrayList<>();

		SeisanshoJokyakuShoninPrint sssJkkSnInfo = seisanshoJokyakuShoninMapper
				.getJokyakuSeisanInfo(jokyakuSeisanShoId);

		JokyakuSeisansho printInfo = null;
		String nowDate = new SimpleDateFormat("yyyy/MM/dd").format(new Date());

		// 固定資産情報
		List<SeisanshoJokyakuShoninPrint> koteiShisanInfoLst = seisanshoJokyakuShoninMapper
				.getKoteiInfo(jokyakuSeisanShoId);

		for (SeisanshoJokyakuShoninPrint koteiShisanInfo : koteiShisanInfoLst) {

			printInfo = new JokyakuSeisansho();

			// 処理No.
			printInfo.setHansu(sssJkkSnInfo.getHansu());
			// 作成日
			printInfo.setSakuseiDate(nowDate);
			// 工事件名
			printInfo.setKenmei(sssJkkSnInfo.getKenmei());
			// 精算箇所
			String seisanSoshiki = "[".concat(sssJkkSnInfo.getSeisanSoshikiCd()).concat("]").concat("：")
					.concat(sssJkkSnInfo.getSoshikiRenNm());
			printInfo.setSeisanSoshiki(seisanSoshiki);
			// 精算書番号
			printInfo.setSeisanShoNo(sssJkkSnInfo.getJokyakuSeisanShoNo());
			// 除却予定年月日
			printInfo.setJokyakuYmd(sssJkkSnInfo.getJokyakuYmd());
			// 摘要
			printInfo.setTekiyo(sssJkkSnInfo.getTekiyo());
			// 総件数
			printInfo.setShutokuSisanCnt(sssJkkSnInfo.getShutokuSisanCnt());
			// 取得原価（商法・合計）
			printInfo.setRwggetkgksYenSum(sssJkkSnInfo.getJokyakuGakuSum());
			// 取得原価（税法・合計）
			printInfo.setRwggetkgkzYenSum(sssJkkSnInfo.getJokyakuGakuSum());
			// 減価償却累計額（商法・合計）
			printInfo.setKsJkgnrsYenSum(sssJkkSnInfo.getKsJkgnrsYenSum());
			// 減価償却累計額（税法・合計）
			printInfo.setKsJkgnrzYenSum(sssJkkSnInfo.getKsJkgnrzYenSum());
			// 減損損失累計額（商法・合計）
			printInfo.setRwgSonruisYenSum(sssJkkSnInfo.getRwgSonruisYenSum());
			// 減損損失累計額（税法・合計）
			printInfo.setRwgSonruizYenSum(sssJkkSnInfo.getRwgSonruizYenSum());
			// 帳簿価額（商法・合計）
			printInfo.setTyoBosYenSum(sssJkkSnInfo.getTyoBosYenSum());
			// 帳簿価額（税法・合計）
			printInfo.setTyoBozYenSum(sssJkkSnInfo.getTyoBozYenSum());
			// 除却損（商法・合計）
			printInfo.setKsJksonsYenSum(sssJkkSnInfo.getKsJksonsYenSum());
			// 除却損（税法・合計）
			printInfo.setKsJksonzYenSum(sssJkkSnInfo.getKsJksonzYenSum());
			// 種類
			String shurui = "[".concat(koteiShisanInfo.getShuruiCd()).concat("]").concat("：")
					.concat(koteiShisanInfo.getShuKnj());
			// 構造
			String kouzou = "[".concat(koteiShisanInfo.getKouzouCd()).concat("]").concat("：")
					.concat(koteiShisanInfo.getKouKnj());
			// 資産単位
			String shisanTani = "[".concat(koteiShisanInfo.getShisanTaniCd()).concat("]").concat("：")
					.concat(koteiShisanInfo.getSaiKnj());
			// 科目1
			String kamoku1 = "[".concat(koteiShisanInfo.getKamokuCd1()).concat("]").concat("：")
					.concat(koteiShisanInfo.getShu4Knj());
			// 科目2
			String kamoku2 = "[".concat(koteiShisanInfo.getKamokuCd2()).concat("]").concat("：")
					.concat(koteiShisanInfo.getShu5Knj());
			// 科目3
			String kamoku3 = "[".concat(koteiShisanInfo.getKamokuCd3()).concat("]").concat("：")
					.concat(koteiShisanInfo.getShu6Knj());
			String shubetsuCode = shurui.concat("/").concat(kouzou).concat("/").concat(shisanTani).concat("/")
					.concat(kamoku1).concat("/").concat(kamoku2).concat("/").concat(kamoku3);
			// 種類・構造・資産単位・科目1・科目2・科目3（種構資１２３）
			printInfo.setShubetsuCode(shubetsuCode);
			String torihikiSaki = "[".concat(koteiShisanInfo.getTorihikiSakiCd()).concat("]").concat("：")
					.concat(koteiShisanInfo.getTorihikiSakiNm());
			// 取引先
			printInfo.setTorihikiSaki(torihikiSaki);
			// 件数
			printInfo.setKenSu(koteiShisanInfo.getKenSu());
			// 取得原価（商法）
			printInfo.setRwggetkgksYen(koteiShisanInfo.getJokyakuGaku());
			// 取得原価（税法）
			printInfo.setRwggetkgkzYen(koteiShisanInfo.getJokyakuGaku());
			// 減価償却累計額（商法）
			printInfo.setKsJkgnrsYen(koteiShisanInfo.getKsJkgnrsYen());
			// 減価償却累計額（税法）
			printInfo.setKsJkgnrzYen(koteiShisanInfo.getKsJkgnrzYen());
			// 減損損失累計額（商法）
			printInfo.setRwgSonruisYen(koteiShisanInfo.getRwgSonruisYen());
			// 減損損失累計額（税法）
			printInfo.setRwgSonruiYen(koteiShisanInfo.getRwgSonruiYen());
			// 帳簿価額（商法）
			printInfo.setTyoBosYen(koteiShisanInfo.getTyoBosYen());
			// 帳簿価額（税法）
			printInfo.setTyoBozYen(koteiShisanInfo.getTyoBozYen());
			// 除却損（商法）
			printInfo.setKsJksonsYen(koteiShisanInfo.getKsJksonsYen());
			// 除却損（税法）
			printInfo.setKsJksonzYen(koteiShisanInfo.getKsJksonzYen());

			printLst.add(printInfo);
		}

		return printLst;
	}

	/**
	 * 資産台帳別内訳ＰＤＦのデータを設定
	 *
	 * @param jokyakuSeisanShoId
	 *            INPUTパラメータ
	 * @return 結果
	 */
	private List<JokyakuSeisanDaityo> setJokyakuSeisanDaityoPdf(String jokyakuSeisanShoId) {

		List<JokyakuSeisanDaityo> printLst = new ArrayList<>();

		JokyakuSeisanDaityo printInfo = null;

		// 固定資産情報
		List<SeisanshoJokyakuShoninPrint> jokyakuDaityoInfoLst = seisanshoJokyakuShoninMapper
				.getJokyakuDaityoInfo(jokyakuSeisanShoId);

		for (SeisanshoJokyakuShoninPrint jokyakuDaityoInfo : jokyakuDaityoInfoLst) {
			printInfo = new JokyakuSeisanDaityo();
			// 固定資産
			String koteiShisan = "[".concat(jokyakuDaityoInfo.getKoteiNo()).concat("]").concat("：")
					.concat(jokyakuDaityoInfo.getKoteiKnj());
			printInfo.setKoteiShisan(koteiShisan);
			// 取得年月日
			printInfo.setShutokuYmd(jokyakuDaityoInfo.getShutokuYmd());
			// 使用開始年月日
			printInfo.setSiyoStartYmd(jokyakuDaityoInfo.getSiyoStartYmd());
			// 管理箇所
			String kanriSoshiki = "[".concat(jokyakuDaityoInfo.getKanriCod()).concat("]").concat("：")
					.concat(jokyakuDaityoInfo.getKanriKnj());
			printInfo.setKanriSoshiki(kanriSoshiki);
			// 設置場所
			String sechiBasho = "[".concat(jokyakuDaityoInfo.getBashoCod()).concat("]").concat("：")
					.concat(jokyakuDaityoInfo.getBashoKnj());
			printInfo.setSechiBasho(sechiBasho);
			// 種類
			String shurui = "[".concat(jokyakuDaityoInfo.getShuruiCd()).concat("]").concat("：")
					.concat(jokyakuDaityoInfo.getShuKnj());
			// 構造
			String kouzou = "[".concat(jokyakuDaityoInfo.getKouzouCd()).concat("]").concat("：")
					.concat(jokyakuDaityoInfo.getKouKnj());
			// 資産単位
			String shisanTani = "[".concat(jokyakuDaityoInfo.getShisanTaniCd()).concat("]").concat("：")
					.concat(jokyakuDaityoInfo.getSaiKnj());
			// 科目1
			String kamoku1 = "[".concat(jokyakuDaityoInfo.getKamokuCd1()).concat("]").concat("：")
					.concat(jokyakuDaityoInfo.getShu4Knj());
			// 科目2
			String kamoku2 = "[".concat(jokyakuDaityoInfo.getKamokuCd2()).concat("]").concat("：")
					.concat(jokyakuDaityoInfo.getShu5Knj());
			// 科目3
			String kamoku3 = "[".concat(jokyakuDaityoInfo.getKamokuCd3()).concat("]").concat("：")
					.concat(jokyakuDaityoInfo.getShu6Knj());
			String shubetsuCode = shurui.concat("/").concat(kouzou).concat("/").concat(shisanTani).concat("/")
					.concat(kamoku1).concat("/").concat(kamoku2).concat("/").concat(kamoku3);
			// 種類・構造・資産単位・科目1・科目2・科目3（種構資１２３）
			printInfo.setShubetsuCode(shubetsuCode);
			String torihikiSaki = "[".concat(jokyakuDaityoInfo.getTorihikiSakiCd()).concat("]").concat("：")
					.concat(jokyakuDaityoInfo.getTorihikiSakiNm());
			// 取引先
			printInfo.setTorihikiSaki(torihikiSaki);
			// 摘要１
			printInfo.setTekiyo1(jokyakuDaityoInfo.getTekiyo1());
			// 摘要２
			printInfo.setTekiyo2(jokyakuDaityoInfo.getTekiyo2());
			// 摘要３
			printInfo.setTekiyo3(jokyakuDaityoInfo.getTekiyo3());
			// 摘要４
			printInfo.setTekiyo4(jokyakuDaityoInfo.getTekiyo4());
			// 摘要５
			printInfo.setTekiyo5(jokyakuDaityoInfo.getTekiyo5());
			// 子資産残
			if (NSDConstant.STRING_0.equals(jokyakuDaityoInfo.getKoshiKbn())) {

				// 子資産残
				printInfo.setKoshiZan("[無]");
			} else if (NSDConstant.STRING_1.equals(jokyakuDaityoInfo.getKoshiKbn())) {

				// 子資産残
				printInfo.setKoshiZan("[有]");
			} else {
				// 処理なし
			}
			String motoSuryoTani = String.valueOf(jokyakuDaityoInfo.getMotoMeiSu()).concat("(")
					.concat(jokyakuDaityoInfo.getTaniKnj()).concat(")");
			// 除却元数量(単位)
			printInfo.setMotoSuryoTani(motoSuryoTani);
			// 除却元取得原価
			printInfo.setMotoRwggetkgksyen(jokyakuDaityoInfo.getMotoGetkgkYen());
			String suryoTani = String.valueOf(jokyakuDaityoInfo.getJokyakuSuryo()).concat("(")
					.concat(jokyakuDaityoInfo.getTaniKnj()).concat(")");
			// 除却数量(単位)
			printInfo.setSuryoTani(suryoTani);
			// 除却取得原価
			printInfo.setRwggetkgksYen(jokyakuDaityoInfo.getJokyakuGaku());
			String aftSuryoTani = String
					.valueOf(jokyakuDaityoInfo.getMotoMeiSu().subtract(jokyakuDaityoInfo.getJokyakuSuryo())).concat("(")
					.concat(jokyakuDaityoInfo.getTaniKnj()).concat(")");
			// 除却後数量(単位)
			printInfo.setAftSuryoTani(aftSuryoTani);
			// 除却後取得原価
			printInfo.setAftRwggetkgksYen(
					jokyakuDaityoInfo.getMotoGetkgkYen().subtract(jokyakuDaityoInfo.getJokyakuGaku()));
			// 除却原価(物品)
			printInfo.setBuppinGaku(jokyakuDaityoInfo.getBuppinGaku());
			// 除却簿価(工費)
			printInfo.setKouhiGaku(jokyakuDaityoInfo.getKouhiGaku());
			// 除却簿価(合計)
			printInfo.setBokaSum(jokyakuDaityoInfo.getBokaSum());
			// 除却損
			printInfo.setKsJksonYen(jokyakuDaityoInfo.getKsJksonYen());

			printLst.add(printInfo);
		}

		return printLst;
	}

	/**
	 * 子固定資産一覧ＰＤＦのデータを設定
	 *
	 * @param jokyakuSeisanShoId
	 *            INPUTパラメータ
	 * @return 結果
	 */
	private List<KosisanInfo> setJokyakuOyakoteiPdf(List<String> kosisanNoLst) {

		// 固定資産番号
		StringBuffer sb = new StringBuffer();
		for (int i = 0; i < kosisanNoLst.size(); i++) {
			String koteiShisanNo = kosisanNoLst.get(i);
			if (i == 0) {
				// 固定資産番号
				sb.append(koteiShisanNo);
			} else {
				if (i >= 50) {
					sb.append(NSDConstant.HALF_SPACE);
					sb.append("他".concat(String.valueOf(kosisanNoLst.size() - 50)).concat("件あり"));
					break;
				} else {
					// 固定資産番号
					sb.append(NSDConstant.STRING_KANMA);
					sb.append(koteiShisanNo);
				}
			}
		}
		List<KosisanInfo> printLst = new ArrayList<>();

		KosisanInfo printKosisanInfo = new KosisanInfo();
		// 固定資産番号
		printKosisanInfo.setKoteiShisanNo(sb.toString());
		// 総件数
		printKosisanInfo.setShutokuSisanCnt(Long.valueOf(kosisanNoLst.size()));

		printLst.add(printKosisanInfo);

		return printLst;
	}
}
