package jp.co.nsd.nkssweb.dao;

import java.util.Date;

public class Kss009Key {
    private String daichoId;

    private Date sakuseiTimestamp;

    public String getDaichoId() {
        return daichoId;
    }

    public void setDaichoId(String daichoId) {
        this.daichoId = daichoId == null ? null : daichoId.trim();
    }

    public Date getSakuseiTimestamp() {
        return sakuseiTimestamp;
    }

    public void setSakuseiTimestamp(Date sakuseiTimestamp) {
        this.sakuseiTimestamp = sakuseiTimestamp;
    }
}