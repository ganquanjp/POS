package jp.co.nsd.nkssweb.dao.mapper;

import jp.co.nsd.nkssweb.dao.Kss005;

public interface Kss005MapperExt {

    int updateByPrimaryKeySelective(Kss005 record);

}