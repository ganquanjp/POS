package jp.co.nsd.nkssweb.dao;

import java.util.Date;

public class Awda02 {
    private String aw2ShuCod;

    private String aw2KouCod;

    private String aw2KouKnj;

    private String aw2JtssnKbn;

    private String aw2RenynFlg;

    private String aw2SisanKbn;

    private String aw2SkyKbn;

    private String aw2ShohohCod;

    private String aw2SshohohCod;

    private Short aw2ZeityoYs;

    private Short aw2ShotyoYs;

    private Integer aw2UpdateCnt;

    private Date aw2TorokDh;

    private String aw2TorshaCod;

    private Date aw2UpdateDh;

    private String aw2UpdshaCod;

    public String getAw2ShuCod() {
        return aw2ShuCod;
    }

    public void setAw2ShuCod(String aw2ShuCod) {
        this.aw2ShuCod = aw2ShuCod == null ? null : aw2ShuCod.trim();
    }

    public String getAw2KouCod() {
        return aw2KouCod;
    }

    public void setAw2KouCod(String aw2KouCod) {
        this.aw2KouCod = aw2KouCod == null ? null : aw2KouCod.trim();
    }

    public String getAw2KouKnj() {
        return aw2KouKnj;
    }

    public void setAw2KouKnj(String aw2KouKnj) {
        this.aw2KouKnj = aw2KouKnj == null ? null : aw2KouKnj.trim();
    }

    public String getAw2JtssnKbn() {
        return aw2JtssnKbn;
    }

    public void setAw2JtssnKbn(String aw2JtssnKbn) {
        this.aw2JtssnKbn = aw2JtssnKbn == null ? null : aw2JtssnKbn.trim();
    }

    public String getAw2RenynFlg() {
        return aw2RenynFlg;
    }

    public void setAw2RenynFlg(String aw2RenynFlg) {
        this.aw2RenynFlg = aw2RenynFlg == null ? null : aw2RenynFlg.trim();
    }

    public String getAw2SisanKbn() {
        return aw2SisanKbn;
    }

    public void setAw2SisanKbn(String aw2SisanKbn) {
        this.aw2SisanKbn = aw2SisanKbn == null ? null : aw2SisanKbn.trim();
    }

    public String getAw2SkyKbn() {
        return aw2SkyKbn;
    }

    public void setAw2SkyKbn(String aw2SkyKbn) {
        this.aw2SkyKbn = aw2SkyKbn == null ? null : aw2SkyKbn.trim();
    }

    public String getAw2ShohohCod() {
        return aw2ShohohCod;
    }

    public void setAw2ShohohCod(String aw2ShohohCod) {
        this.aw2ShohohCod = aw2ShohohCod == null ? null : aw2ShohohCod.trim();
    }

    public String getAw2SshohohCod() {
        return aw2SshohohCod;
    }

    public void setAw2SshohohCod(String aw2SshohohCod) {
        this.aw2SshohohCod = aw2SshohohCod == null ? null : aw2SshohohCod.trim();
    }

    public Short getAw2ZeityoYs() {
        return aw2ZeityoYs;
    }

    public void setAw2ZeityoYs(Short aw2ZeityoYs) {
        this.aw2ZeityoYs = aw2ZeityoYs;
    }

    public Short getAw2ShotyoYs() {
        return aw2ShotyoYs;
    }

    public void setAw2ShotyoYs(Short aw2ShotyoYs) {
        this.aw2ShotyoYs = aw2ShotyoYs;
    }

    public Integer getAw2UpdateCnt() {
        return aw2UpdateCnt;
    }

    public void setAw2UpdateCnt(Integer aw2UpdateCnt) {
        this.aw2UpdateCnt = aw2UpdateCnt;
    }

    public Date getAw2TorokDh() {
        return aw2TorokDh;
    }

    public void setAw2TorokDh(Date aw2TorokDh) {
        this.aw2TorokDh = aw2TorokDh;
    }

    public String getAw2TorshaCod() {
        return aw2TorshaCod;
    }

    public void setAw2TorshaCod(String aw2TorshaCod) {
        this.aw2TorshaCod = aw2TorshaCod == null ? null : aw2TorshaCod.trim();
    }

    public Date getAw2UpdateDh() {
        return aw2UpdateDh;
    }

    public void setAw2UpdateDh(Date aw2UpdateDh) {
        this.aw2UpdateDh = aw2UpdateDh;
    }

    public String getAw2UpdshaCod() {
        return aw2UpdshaCod;
    }

    public void setAw2UpdshaCod(String aw2UpdshaCod) {
        this.aw2UpdshaCod = aw2UpdshaCod == null ? null : aw2UpdshaCod.trim();
    }
}