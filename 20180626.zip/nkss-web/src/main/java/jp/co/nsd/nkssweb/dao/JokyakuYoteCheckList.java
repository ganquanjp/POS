package jp.co.nsd.nkssweb.dao;

import java.math.BigDecimal;

/**
 * 除却予定チェックリスト
 *
 * @version 1.00
 */
public class JokyakuYoteCheckList {
	// 除却予定チェックリスト情報
	// 子固定資産有無確認項目
	private String koSisanExists;
	// 作成日
	private String sakuseiDate;
	// 工事件名
	private String kenmei;
	// 精算箇所
	private String seisanSoshiki;
	// 精算書番号
	private String seisanShoNo;
	// 除却予定年月日
	private String jokyakuYoteYmd;
	// 摘要
	private String tekiyo;
	// 総件数
	private Long shutokuSisanCnt;
	// 取得原価（商法・合計）
	private BigDecimal rwggetkgksYenSum;
	// 取得原価（税法・合計）
	private BigDecimal rwggetkgkzYenSum;
	// 減価償却累計額（商法・合計）
	private BigDecimal ksJkgnrsYenSum;
	// 減価償却累計額（税法・合計）
	private BigDecimal ksJkgnrzYenSum;
	// 減損損失累計額（商法・合計）
	private BigDecimal rwgSonruisYenSum;
	// 減損損失累計額（税法・合計）
	private BigDecimal rwgSonruizYenSum;
	// 帳簿価額（商法・合計）
	private BigDecimal tyoBosYenSum;
	// 帳簿価額（税法・合計）
	private BigDecimal tyoBozYenSum;
	// 除却損（商法・合計）
	private BigDecimal ksJksonsYenSum;
	// 除却損（税法・合計）
	private BigDecimal ksJksonzYenSum;
	// 種類・構造・資産単位・科目1・科目2・科目3（種構資１２３）
	private String shubetsuCode;
	// 取引先
	private String torihikiSaki;
	// 件数
	private Long kenSu;
	// 取得原価（商法）
	private BigDecimal rwggetkgksYen;
	// 取得原価（税法）
	private BigDecimal rwggetkgkzYen;
	// 減価償却累計額（商法）
	private BigDecimal ksJkgnrsYen;
	// 減価償却累計額（税法）
	private BigDecimal ksJkgnrzYen;
	// 減損損失累計額（商法）
	private BigDecimal rwgSonruisYen;
	// 減損損失累計額（税法）
	private BigDecimal rwgSonruiYen;
	// 帳簿価額（商法）
	private BigDecimal tyoBosYen;
	// 帳簿価額（税法）
	private BigDecimal tyoBozYen;
	// 除却損（商法）
	private BigDecimal ksJksonsYen;
	// 除却損（税法）
	private BigDecimal ksJksonzYen;
	/**
	 * @return koSisanExists
	 */
	public String getKoSisanExists() {
		return koSisanExists;
	}
	/**
	 * @param koSisanExists セットする koSisanExists
	 */
	public void setKoSisanExists(String koSisanExists) {
		this.koSisanExists = koSisanExists;
	}
	/**
	 * @return sakuseiDate
	 */
	public String getSakuseiDate() {
		return sakuseiDate;
	}
	/**
	 * @param sakuseiDate セットする sakuseiDate
	 */
	public void setSakuseiDate(String sakuseiDate) {
		this.sakuseiDate = sakuseiDate;
	}
	/**
	 * @return kenmei
	 */
	public String getKenmei() {
		return kenmei;
	}
	/**
	 * @param kenmei セットする kenmei
	 */
	public void setKenmei(String kenmei) {
		this.kenmei = kenmei;
	}
	/**
	 * @return seisanSoshiki
	 */
	public String getSeisanSoshiki() {
		return seisanSoshiki;
	}
	/**
	 * @param seisanSoshiki セットする seisanSoshiki
	 */
	public void setSeisanSoshiki(String seisanSoshiki) {
		this.seisanSoshiki = seisanSoshiki;
	}
	/**
	 * @return seisanShoNo
	 */
	public String getSeisanShoNo() {
		return seisanShoNo;
	}
	/**
	 * @param seisanShoNo セットする seisanShoNo
	 */
	public void setSeisanShoNo(String seisanShoNo) {
		this.seisanShoNo = seisanShoNo;
	}
	/**
	 * @return jokyakuYoteYmd
	 */
	public String getJokyakuYoteYmd() {
		return jokyakuYoteYmd;
	}
	/**
	 * @param jokyakuYoteYmd セットする jokyakuYoteYmd
	 */
	public void setJokyakuYoteYmd(String jokyakuYoteYmd) {
		this.jokyakuYoteYmd = jokyakuYoteYmd;
	}
	/**
	 * @return tekiyo
	 */
	public String getTekiyo() {
		return tekiyo;
	}
	/**
	 * @param tekiyo セットする tekiyo
	 */
	public void setTekiyo(String tekiyo) {
		this.tekiyo = tekiyo;
	}
	/**
	 * @return shutokuSisanCnt
	 */
	public Long getShutokuSisanCnt() {
		return shutokuSisanCnt;
	}
	/**
	 * @param shutokuSisanCnt セットする shutokuSisanCnt
	 */
	public void setShutokuSisanCnt(Long shutokuSisanCnt) {
		this.shutokuSisanCnt = shutokuSisanCnt;
	}
	/**
	 * @return rwggetkgksYenSum
	 */
	public BigDecimal getRwggetkgksYenSum() {
		return rwggetkgksYenSum;
	}
	/**
	 * @param rwggetkgksYenSum セットする rwggetkgksYenSum
	 */
	public void setRwggetkgksYenSum(BigDecimal rwggetkgksYenSum) {
		this.rwggetkgksYenSum = rwggetkgksYenSum;
	}
	/**
	 * @return rwggetkgkzYenSum
	 */
	public BigDecimal getRwggetkgkzYenSum() {
		return rwggetkgkzYenSum;
	}
	/**
	 * @param rwggetkgkzYenSum セットする rwggetkgkzYenSum
	 */
	public void setRwggetkgkzYenSum(BigDecimal rwggetkgkzYenSum) {
		this.rwggetkgkzYenSum = rwggetkgkzYenSum;
	}
	/**
	 * @return ksJkgnrsYenSum
	 */
	public BigDecimal getKsJkgnrsYenSum() {
		return ksJkgnrsYenSum;
	}
	/**
	 * @param ksJkgnrsYenSum セットする ksJkgnrsYenSum
	 */
	public void setKsJkgnrsYenSum(BigDecimal ksJkgnrsYenSum) {
		this.ksJkgnrsYenSum = ksJkgnrsYenSum;
	}
	/**
	 * @return ksJkgnrzYenSum
	 */
	public BigDecimal getKsJkgnrzYenSum() {
		return ksJkgnrzYenSum;
	}
	/**
	 * @param ksJkgnrzYenSum セットする ksJkgnrzYenSum
	 */
	public void setKsJkgnrzYenSum(BigDecimal ksJkgnrzYenSum) {
		this.ksJkgnrzYenSum = ksJkgnrzYenSum;
	}
	/**
	 * @return rwgSonruisYenSum
	 */
	public BigDecimal getRwgSonruisYenSum() {
		return rwgSonruisYenSum;
	}
	/**
	 * @param rwgSonruisYenSum セットする rwgSonruisYenSum
	 */
	public void setRwgSonruisYenSum(BigDecimal rwgSonruisYenSum) {
		this.rwgSonruisYenSum = rwgSonruisYenSum;
	}
	/**
	 * @return rwgSonruizYenSum
	 */
	public BigDecimal getRwgSonruizYenSum() {
		return rwgSonruizYenSum;
	}
	/**
	 * @param rwgSonruizYenSum セットする rwgSonruizYenSum
	 */
	public void setRwgSonruizYenSum(BigDecimal rwgSonruizYenSum) {
		this.rwgSonruizYenSum = rwgSonruizYenSum;
	}
	/**
	 * @return tyoBosYenSum
	 */
	public BigDecimal getTyoBosYenSum() {
		return tyoBosYenSum;
	}
	/**
	 * @param tyoBosYenSum セットする tyoBosYenSum
	 */
	public void setTyoBosYenSum(BigDecimal tyoBosYenSum) {
		this.tyoBosYenSum = tyoBosYenSum;
	}
	/**
	 * @return tyoBozYenSum
	 */
	public BigDecimal getTyoBozYenSum() {
		return tyoBozYenSum;
	}
	/**
	 * @param tyoBozYenSum セットする tyoBozYenSum
	 */
	public void setTyoBozYenSum(BigDecimal tyoBozYenSum) {
		this.tyoBozYenSum = tyoBozYenSum;
	}
	/**
	 * @return ksJksonsYenSum
	 */
	public BigDecimal getKsJksonsYenSum() {
		return ksJksonsYenSum;
	}
	/**
	 * @param ksJksonsYenSum セットする ksJksonsYenSum
	 */
	public void setKsJksonsYenSum(BigDecimal ksJksonsYenSum) {
		this.ksJksonsYenSum = ksJksonsYenSum;
	}
	/**
	 * @return ksJksonzYenSum
	 */
	public BigDecimal getKsJksonzYenSum() {
		return ksJksonzYenSum;
	}
	/**
	 * @param ksJksonzYenSum セットする ksJksonzYenSum
	 */
	public void setKsJksonzYenSum(BigDecimal ksJksonzYenSum) {
		this.ksJksonzYenSum = ksJksonzYenSum;
	}
	/**
	 * @return shubetsuCode
	 */
	public String getShubetsuCode() {
		return shubetsuCode;
	}
	/**
	 * @param shubetsuCode セットする shubetsuCode
	 */
	public void setShubetsuCode(String shubetsuCode) {
		this.shubetsuCode = shubetsuCode;
	}
	/**
	 * @return torihikiSaki
	 */
	public String getTorihikiSaki() {
		return torihikiSaki;
	}
	/**
	 * @param torihikiSaki セットする torihikiSaki
	 */
	public void setTorihikiSaki(String torihikiSaki) {
		this.torihikiSaki = torihikiSaki;
	}
	/**
	 * @return kenSu
	 */
	public Long getKenSu() {
		return kenSu;
	}
	/**
	 * @param kenSu セットする kenSu
	 */
	public void setKenSu(Long kenSu) {
		this.kenSu = kenSu;
	}
	/**
	 * @return rwggetkgksYen
	 */
	public BigDecimal getRwggetkgksYen() {
		return rwggetkgksYen;
	}
	/**
	 * @param rwggetkgksYen セットする rwggetkgksYen
	 */
	public void setRwggetkgksYen(BigDecimal rwggetkgksYen) {
		this.rwggetkgksYen = rwggetkgksYen;
	}
	/**
	 * @return rwggetkgkzYen
	 */
	public BigDecimal getRwggetkgkzYen() {
		return rwggetkgkzYen;
	}
	/**
	 * @param rwggetkgkzYen セットする rwggetkgkzYen
	 */
	public void setRwggetkgkzYen(BigDecimal rwggetkgkzYen) {
		this.rwggetkgkzYen = rwggetkgkzYen;
	}
	/**
	 * @return ksJkgnrsYen
	 */
	public BigDecimal getKsJkgnrsYen() {
		return ksJkgnrsYen;
	}
	/**
	 * @param ksJkgnrsYen セットする ksJkgnrsYen
	 */
	public void setKsJkgnrsYen(BigDecimal ksJkgnrsYen) {
		this.ksJkgnrsYen = ksJkgnrsYen;
	}
	/**
	 * @return ksJkgnrzYen
	 */
	public BigDecimal getKsJkgnrzYen() {
		return ksJkgnrzYen;
	}
	/**
	 * @param ksJkgnrzYen セットする ksJkgnrzYen
	 */
	public void setKsJkgnrzYen(BigDecimal ksJkgnrzYen) {
		this.ksJkgnrzYen = ksJkgnrzYen;
	}
	/**
	 * @return rwgSonruisYen
	 */
	public BigDecimal getRwgSonruisYen() {
		return rwgSonruisYen;
	}
	/**
	 * @param rwgSonruisYen セットする rwgSonruisYen
	 */
	public void setRwgSonruisYen(BigDecimal rwgSonruisYen) {
		this.rwgSonruisYen = rwgSonruisYen;
	}
	/**
	 * @return rwgSonruiYen
	 */
	public BigDecimal getRwgSonruiYen() {
		return rwgSonruiYen;
	}
	/**
	 * @param rwgSonruiYen セットする rwgSonruiYen
	 */
	public void setRwgSonruiYen(BigDecimal rwgSonruiYen) {
		this.rwgSonruiYen = rwgSonruiYen;
	}
	/**
	 * @return tyoBosYen
	 */
	public BigDecimal getTyoBosYen() {
		return tyoBosYen;
	}
	/**
	 * @param tyoBosYen セットする tyoBosYen
	 */
	public void setTyoBosYen(BigDecimal tyoBosYen) {
		this.tyoBosYen = tyoBosYen;
	}
	/**
	 * @return tyoBozYen
	 */
	public BigDecimal getTyoBozYen() {
		return tyoBozYen;
	}
	/**
	 * @param tyoBozYen セットする tyoBozYen
	 */
	public void setTyoBozYen(BigDecimal tyoBozYen) {
		this.tyoBozYen = tyoBozYen;
	}
	/**
	 * @return ksJksonsYen
	 */
	public BigDecimal getKsJksonsYen() {
		return ksJksonsYen;
	}
	/**
	 * @param ksJksonsYen セットする ksJksonsYen
	 */
	public void setKsJksonsYen(BigDecimal ksJksonsYen) {
		this.ksJksonsYen = ksJksonsYen;
	}
	/**
	 * @return ksJksonzYen
	 */
	public BigDecimal getKsJksonzYen() {
		return ksJksonzYen;
	}
	/**
	 * @param ksJksonzYen セットする ksJksonzYen
	 */
	public void setKsJksonzYen(BigDecimal ksJksonzYen) {
		this.ksJksonzYen = ksJksonzYen;
	}

}