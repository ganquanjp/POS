package jp.co.nsd.nkssweb.dao;

import java.math.BigDecimal;
import java.sql.Date;

/**
 * 固定資産台帳情報
 *
 * @version 1.00
 */
public class KoteshisanDaityo {
	// 決算スケジュール情報
	// 工事件名
	private String mw1Kamoku;
	// 科目内訳コード
	private String mw1KamokuCod;
	// 科目内訳名称
	private String mw1KamokuKnj;
	// 精算書番号
	private String mw1SeisanNo;
	// 使用開始年月日
	private Date mw1UseYmd;
	// 取得年月日
	private Date mw1GetYmd;
	// 固定資産番号
	private String mw1KoteiNo;
	// 親固定資産番号
	private String mw2Komk06Kna;
	// 枝番
	private String mw2Komk07Kna;
	// 固定資産名称
	private String mw1KoteiKnj;
	// 種類
	private String shuRui;
	// 種類コード
	private String mw1ShuCod;
	// 種類名称
	private String aw1ShuKnj;
	// 構造
	private String kouZou;
	// 構造コード
	private String mw1KouCod;
	// 構造名称
	private String aw2KouKnj;
	// 資産単位
	private String siSanTani;
	// 細目コード
	private String mw1SaiCod;
	// 細目名称
	private String aw3SaiKnj;
	// 科目１
	private String shuRui4;
	// 種別４コード
	private String mw1Shu4Cod;
	// 種別４名称
	private String aw4Shu4Knj;
	// 科目２
	private String shuRui5;
	// 種別５コード
	private String mw1Shu5Cod;
	// 種別５名称
	private String aw5Shu5Knj;
	// 科目３
	private String shuRui6;
	// 種別６コード
	private String mw1Shu6Cod;
	// 種別６名称
	private String aw6Shu6Knj;
	// 取引先
	private String torihiki;
	// 取引先コード
	private String mw1TorihikiCod;
	// 取引先名称
	private String mw1TorihikiKnj;
	// 法定耐用年数
	private BigDecimal mw1ShotaiYs;
	// 残存耐用年数
	private BigDecimal zanZonTaiyoNensuS;
	// 商法経過年数
	private BigDecimal mw1SkeikaY;
	// 償却方法/新旧償却区分/申告種類
	private String awkMeishoKnj;
	// 償却率
	private String mw1SsykRit;
	// 物品
	private BigDecimal mw2Kagak1Yen;
	// 工費
	private BigDecimal mw2Kagak2Yen;
	// 総係費
	private BigDecimal mw2Kagak3Yen;
	// 取得価額
	private BigDecimal mw2GetkgkYen;
	// 前年度末簿価
	private BigDecimal maebkasYenS;
	// 会計年
	private String mwgKaikeiY;
	// 前期末簿価＿商
	private BigDecimal mw2MaebkasYen;
	// 当期償却額（予定）
	private BigDecimal mw2TkishsYen;
	// （差引）年度末簿価
	private BigDecimal mw2EndsYen;
	// 物品数量
	private BigDecimal mw2MeiSu;
	// 単位名称
	private String awfTaniKnj;
	// 管理箇所
	private String kanriSoshiki;
	// 管理箇所コード
	private String mw1KanriCod;
	// 管理箇所名称
	private String mw1KanriKnj;
	// 負担箇所
	private String futanSoshiki1;
	// 負担箇所コード
	private String mw1Futan1Cod;
	// 負担箇所名称
	private String mw1Futan1Knj;
	// 設置場所
	private String sechiBasho;
	// 場所コード
	private String mw2BashoCod;
	// 場所名称
	private String awaBashoKnj;
	// 製品名/型番/製品会社名称
	private String seihinKataSeizo;
	// 製品名称
	private String mw2SeihinKnj;
	// 型番
	private String mw2KataNo;
	// 製造会社名称
	private String mw2SeizoKnj;
	// 摘要１
	private String mw1MemoKnj;
	// 摘要２
	private String mw2MemoKnj;
	// 摘要３
	private String mw2Komk11Knj;
	// 摘要４
	private String mw2Komk12Knj;
	// 摘要５
	private String mw2Komk13Knj;
	// 旧資産コード
	private String mw2Komk08Kna;
	// 工事担当箇所
	private String mw2Komk15Knj;
	// 工事担当者
	private String mw2Komk14Knj;
	// 会計整理年月
	private String mw1KaikeiYm;
	// 分割元固定資産番号
	private String mw1KoteibktNo;
	// 除却年月日
	private Date mw2JyokykYmd;
	// 残存価額
	private BigDecimal mw2ZanzonsYen;
	// 残存耐用年数（税法）
	private String zanZonTaiyoNensuZ;
	// 法定耐用年数（税法）
	private BigDecimal mw1ZeitaiYs;
	// 固定資産.税法経過年数
	private BigDecimal mw1ZkeikaY;
	// 前年度末簿価（税法）
	private BigDecimal maebkasYenZ;
	// 前期末簿価＿税
	private BigDecimal mw2MaebkazYen;
	// 当期償却額（税法）
	private BigDecimal mw2TkishzYen;
	// 年度末簿価（税法）
	private BigDecimal mw2EndzYen;
	// 申告先名称
	private String aw8ShinkkKnj;
	// 年始前年評価額
	private BigDecimal mw2YbnhykYen;
	// 年始現在評価額
	private BigDecimal mw2YfnhykYen;
	// 休止年月日
	private Date mw2KyushiYmd;
	// 休止解除年月日
	private Date mw2KyskjyYmd;
	// 休止摘要
	private String mw2KysmemoKnj;

	/**
	 * @return mw1Kamoku
	 */
	public String getMw1Kamoku() {
		return mw1Kamoku;
	}
	/**
	 * @param mw1Kamoku セットする mw1Kamoku
	 */
	public void setMw1Kamoku(String mw1Kamoku) {
		this.mw1Kamoku = mw1Kamoku;
	}
	/**
	 * @return mw1KamokuCod
	 */
	public String getMw1KamokuCod() {
		return mw1KamokuCod;
	}
	/**
	 * @param mw1KamokuCod セットする mw1KamokuCod
	 */
	public void setMw1KamokuCod(String mw1KamokuCod) {
		this.mw1KamokuCod = mw1KamokuCod;
	}
	/**
	 * @return mw1KamokuKnj
	 */
	public String getMw1KamokuKnj() {
		return mw1KamokuKnj;
	}
	/**
	 * @param mw1KamokuKnj セットする mw1KamokuKnj
	 */
	public void setMw1KamokuKnj(String mw1KamokuKnj) {
		this.mw1KamokuKnj = mw1KamokuKnj;
	}
	/**
	 * @return mw1SeisanNo
	 */
	public String getMw1SeisanNo() {
		return mw1SeisanNo;
	}
	/**
	 * @param mw1SeisanNo セットする mw1SeisanNo
	 */
	public void setMw1SeisanNo(String mw1SeisanNo) {
		this.mw1SeisanNo = mw1SeisanNo;
	}
	/**
	 * @return mw1UseYmd
	 */
	public Date getMw1UseYmd() {
		return mw1UseYmd;
	}
	/**
	 * @param mw1UseYmd セットする mw1UseYmd
	 */
	public void setMw1UseYmd(Date mw1UseYmd) {
		this.mw1UseYmd = mw1UseYmd;
	}
	/**
	 * @return mw1GetYmd
	 */
	public Date getMw1GetYmd() {
		return mw1GetYmd;
	}
	/**
	 * @param mw1GetYmd セットする mw1GetYmd
	 */
	public void setMw1GetYmd(Date mw1GetYmd) {
		this.mw1GetYmd = mw1GetYmd;
	}
	/**
	 * @return mw1KoteiNo
	 */
	public String getMw1KoteiNo() {
		return mw1KoteiNo;
	}
	/**
	 * @param mw1KoteiNo セットする mw1KoteiNo
	 */
	public void setMw1KoteiNo(String mw1KoteiNo) {
		this.mw1KoteiNo = mw1KoteiNo;
	}
	/**
	 * @return mw2Komk06Kna
	 */
	public String getMw2Komk06Kna() {
		return mw2Komk06Kna;
	}
	/**
	 * @param mw2Komk06Kna セットする mw2Komk06Kna
	 */
	public void setMw2Komk06Kna(String mw2Komk06Kna) {
		this.mw2Komk06Kna = mw2Komk06Kna;
	}
	/**
	 * @return mw2Komk07Kna
	 */
	public String getMw2Komk07Kna() {
		return mw2Komk07Kna;
	}
	/**
	 * @param mw2Komk07Kna セットする mw2Komk07Kna
	 */
	public void setMw2Komk07Kna(String mw2Komk07Kna) {
		this.mw2Komk07Kna = mw2Komk07Kna;
	}
	/**
	 * @return mw1KoteiKnj
	 */
	public String getMw1KoteiKnj() {
		return mw1KoteiKnj;
	}
	/**
	 * @param mw1KoteiKnj セットする mw1KoteiKnj
	 */
	public void setMw1KoteiKnj(String mw1KoteiKnj) {
		this.mw1KoteiKnj = mw1KoteiKnj;
	}
	/**
	 * @return shuRui
	 */
	public String getShuRui() {
		return shuRui;
	}
	/**
	 * @param shuRui セットする shuRui
	 */
	public void setShuRui(String shuRui) {
		this.shuRui = shuRui;
	}
	/**
	 * @return mw1ShuCod
	 */
	public String getMw1ShuCod() {
		return mw1ShuCod;
	}
	/**
	 * @param mw1ShuCod セットする mw1ShuCod
	 */
	public void setMw1ShuCod(String mw1ShuCod) {
		this.mw1ShuCod = mw1ShuCod;
	}
	/**
	 * @return aw1ShuKnj
	 */
	public String getAw1ShuKnj() {
		return aw1ShuKnj;
	}
	/**
	 * @param aw1ShuKnj セットする aw1ShuKnj
	 */
	public void setAw1ShuKnj(String aw1ShuKnj) {
		this.aw1ShuKnj = aw1ShuKnj;
	}
	/**
	 * @return kouZou
	 */
	public String getKouZou() {
		return kouZou;
	}
	/**
	 * @param kouZou セットする kouZou
	 */
	public void setKouZou(String kouZou) {
		this.kouZou = kouZou;
	}
	/**
	 * @return mw1KouCod
	 */
	public String getMw1KouCod() {
		return mw1KouCod;
	}
	/**
	 * @param mw1KouCod セットする mw1KouCod
	 */
	public void setMw1KouCod(String mw1KouCod) {
		this.mw1KouCod = mw1KouCod;
	}
	/**
	 * @return aw2KouKnj
	 */
	public String getAw2KouKnj() {
		return aw2KouKnj;
	}
	/**
	 * @param aw2KouKnj セットする aw2KouKnj
	 */
	public void setAw2KouKnj(String aw2KouKnj) {
		this.aw2KouKnj = aw2KouKnj;
	}
	/**
	 * @return siSanTani
	 */
	public String getSiSanTani() {
		return siSanTani;
	}
	/**
	 * @param siSanTani セットする siSanTani
	 */
	public void setSiSanTani(String siSanTani) {
		this.siSanTani = siSanTani;
	}
	/**
	 * @return mw1SaiCod
	 */
	public String getMw1SaiCod() {
		return mw1SaiCod;
	}
	/**
	 * @param mw1SaiCod セットする mw1SaiCod
	 */
	public void setMw1SaiCod(String mw1SaiCod) {
		this.mw1SaiCod = mw1SaiCod;
	}
	/**
	 * @return aw3SaiKnj
	 */
	public String getAw3SaiKnj() {
		return aw3SaiKnj;
	}
	/**
	 * @param aw3SaiKnj セットする aw3SaiKnj
	 */
	public void setAw3SaiKnj(String aw3SaiKnj) {
		this.aw3SaiKnj = aw3SaiKnj;
	}
	/**
	 * @return shuRui4
	 */
	public String getShuRui4() {
		return shuRui4;
	}
	/**
	 * @param shuRui4 セットする shuRui4
	 */
	public void setShuRui4(String shuRui4) {
		this.shuRui4 = shuRui4;
	}
	/**
	 * @return mw1Shu4Cod
	 */
	public String getMw1Shu4Cod() {
		return mw1Shu4Cod;
	}
	/**
	 * @param mw1Shu4Cod セットする mw1Shu4Cod
	 */
	public void setMw1Shu4Cod(String mw1Shu4Cod) {
		this.mw1Shu4Cod = mw1Shu4Cod;
	}
	/**
	 * @return aw4Shu4Knj
	 */
	public String getAw4Shu4Knj() {
		return aw4Shu4Knj;
	}
	/**
	 * @param aw4Shu4Knj セットする aw4Shu4Knj
	 */
	public void setAw4Shu4Knj(String aw4Shu4Knj) {
		this.aw4Shu4Knj = aw4Shu4Knj;
	}
	/**
	 * @return shuRui5
	 */
	public String getShuRui5() {
		return shuRui5;
	}
	/**
	 * @param shuRui5 セットする shuRui5
	 */
	public void setShuRui5(String shuRui5) {
		this.shuRui5 = shuRui5;
	}
	/**
	 * @return mw1Shu5Cod
	 */
	public String getMw1Shu5Cod() {
		return mw1Shu5Cod;
	}
	/**
	 * @param mw1Shu5Cod セットする mw1Shu5Cod
	 */
	public void setMw1Shu5Cod(String mw1Shu5Cod) {
		this.mw1Shu5Cod = mw1Shu5Cod;
	}
	/**
	 * @return aw5Shu5Knj
	 */
	public String getAw5Shu5Knj() {
		return aw5Shu5Knj;
	}
	/**
	 * @param aw5Shu5Knj セットする aw5Shu5Knj
	 */
	public void setAw5Shu5Knj(String aw5Shu5Knj) {
		this.aw5Shu5Knj = aw5Shu5Knj;
	}
	/**
	 * @return shuRui6
	 */
	public String getShuRui6() {
		return shuRui6;
	}
	/**
	 * @param shuRui6 セットする shuRui6
	 */
	public void setShuRui6(String shuRui6) {
		this.shuRui6 = shuRui6;
	}
	/**
	 * @return mw1Shu6Cod
	 */
	public String getMw1Shu6Cod() {
		return mw1Shu6Cod;
	}
	/**
	 * @param mw1Shu6Cod セットする mw1Shu6Cod
	 */
	public void setMw1Shu6Cod(String mw1Shu6Cod) {
		this.mw1Shu6Cod = mw1Shu6Cod;
	}
	/**
	 * @return aw6Shu6Knj
	 */
	public String getAw6Shu6Knj() {
		return aw6Shu6Knj;
	}
	/**
	 * @param aw6Shu6Knj セットする aw6Shu6Knj
	 */
	public void setAw6Shu6Knj(String aw6Shu6Knj) {
		this.aw6Shu6Knj = aw6Shu6Knj;
	}
	/**
	 * @return torihiki
	 */
	public String getTorihiki() {
		return torihiki;
	}
	/**
	 * @param torihiki セットする torihiki
	 */
	public void setTorihiki(String torihiki) {
		this.torihiki = torihiki;
	}
	/**
	 * @return mw1TorihikiCod
	 */
	public String getMw1TorihikiCod() {
		return mw1TorihikiCod;
	}
	/**
	 * @param mw1TorihikiCod セットする mw1TorihikiCod
	 */
	public void setMw1TorihikiCod(String mw1TorihikiCod) {
		this.mw1TorihikiCod = mw1TorihikiCod;
	}
	/**
	 * @return mw1TorihikiKnj
	 */
	public String getMw1TorihikiKnj() {
		return mw1TorihikiKnj;
	}
	/**
	 * @param mw1TorihikiKnj セットする mw1TorihikiKnj
	 */
	public void setMw1TorihikiKnj(String mw1TorihikiKnj) {
		this.mw1TorihikiKnj = mw1TorihikiKnj;
	}
	/**
	 * @return mw1ShotaiYs
	 */
	public BigDecimal getMw1ShotaiYs() {
		return mw1ShotaiYs;
	}
	/**
	 * @param mw1ShotaiYs セットする mw1ShotaiYs
	 */
	public void setMw1ShotaiYs(BigDecimal mw1ShotaiYs) {
		this.mw1ShotaiYs = mw1ShotaiYs;
	}
	/**
	 * @return zanZonTaiyoNensuS
	 */
	public BigDecimal getZanZonTaiyoNensuS() {
		return zanZonTaiyoNensuS;
	}
	/**
	 * @param zanZonTaiyoNensuS セットする zanZonTaiyoNensuS
	 */
	public void setZanZonTaiyoNensuS(BigDecimal zanZonTaiyoNensuS) {
		this.zanZonTaiyoNensuS = zanZonTaiyoNensuS;
	}
	/**
	 * @return mw1SkeikaY
	 */
	public BigDecimal getMw1SkeikaY() {
		return mw1SkeikaY;
	}
	/**
	 * @param mw1SkeikaY セットする mw1SkeikaY
	 */
	public void setMw1SkeikaY(BigDecimal mw1SkeikaY) {
		this.mw1SkeikaY = mw1SkeikaY;
	}
	/**
	 * @return awkMeishoKnj
	 */
	public String getAwkMeishoKnj() {
		return awkMeishoKnj;
	}
	/**
	 * @param awkMeishoKnj セットする awkMeishoKnj
	 */
	public void setAwkMeishoKnj(String awkMeishoKnj) {
		this.awkMeishoKnj = awkMeishoKnj;
	}
	/**
	 * @return mw1SsykRit
	 */
	public String getMw1SsykRit() {
		return mw1SsykRit;
	}
	/**
	 * @param mw1SsykRit セットする mw1SsykRit
	 */
	public void setMw1SsykRit(String mw1SsykRit) {
		this.mw1SsykRit = mw1SsykRit;
	}
	/**
	 * @return mw2Kagak1Yen
	 */
	public BigDecimal getMw2Kagak1Yen() {
		return mw2Kagak1Yen;
	}
	/**
	 * @param mw2Kagak1Yen セットする mw2Kagak1Yen
	 */
	public void setMw2Kagak1Yen(BigDecimal mw2Kagak1Yen) {
		this.mw2Kagak1Yen = mw2Kagak1Yen;
	}
	/**
	 * @return mw2Kagak2Yen
	 */
	public BigDecimal getMw2Kagak2Yen() {
		return mw2Kagak2Yen;
	}
	/**
	 * @param mw2Kagak2Yen セットする mw2Kagak2Yen
	 */
	public void setMw2Kagak2Yen(BigDecimal mw2Kagak2Yen) {
		this.mw2Kagak2Yen = mw2Kagak2Yen;
	}
	/**
	 * @return mw2Kagak3Yen
	 */
	public BigDecimal getMw2Kagak3Yen() {
		return mw2Kagak3Yen;
	}
	/**
	 * @param mw2Kagak3Yen セットする mw2Kagak3Yen
	 */
	public void setMw2Kagak3Yen(BigDecimal mw2Kagak3Yen) {
		this.mw2Kagak3Yen = mw2Kagak3Yen;
	}
	/**
	 * @return mw2GetkgkYen
	 */
	public BigDecimal getMw2GetkgkYen() {
		return mw2GetkgkYen;
	}
	/**
	 * @param mw2GetkgkYen セットする mw2GetkgkYen
	 */
	public void setMw2GetkgkYen(BigDecimal mw2GetkgkYen) {
		this.mw2GetkgkYen = mw2GetkgkYen;
	}
	/**
	 * @return maebkasYenS
	 */
	public BigDecimal getMaebkasYenS() {
		return maebkasYenS;
	}
	/**
	 * @param maebkasYenS セットする maebkasYenS
	 */
	public void setMaebkasYenS(BigDecimal maebkasYenS) {
		this.maebkasYenS = maebkasYenS;
	}
	/**
	 * @return mwgKaikeiY
	 */
	public String getMwgKaikeiY() {
		return mwgKaikeiY;
	}
	/**
	 * @param mwgKaikeiY セットする mwgKaikeiY
	 */
	public void setMwgKaikeiY(String mwgKaikeiY) {
		this.mwgKaikeiY = mwgKaikeiY;
	}
	/**
	 * @return mw2MaebkasYen
	 */
	public BigDecimal getMw2MaebkasYen() {
		return mw2MaebkasYen;
	}
	/**
	 * @param mw2MaebkasYen セットする mw2MaebkasYen
	 */
	public void setMw2MaebkasYen(BigDecimal mw2MaebkasYen) {
		this.mw2MaebkasYen = mw2MaebkasYen;
	}
	/**
	 * @return mw2TkishsYen
	 */
	public BigDecimal getMw2TkishsYen() {
		return mw2TkishsYen;
	}
	/**
	 * @param mw2TkishsYen セットする mw2TkishsYen
	 */
	public void setMw2TkishsYen(BigDecimal mw2TkishsYen) {
		this.mw2TkishsYen = mw2TkishsYen;
	}
	/**
	 * @return mw2EndsYen
	 */
	public BigDecimal getMw2EndsYen() {
		return mw2EndsYen;
	}
	/**
	 * @param mw2EndsYen セットする mw2EndsYen
	 */
	public void setMw2EndsYen(BigDecimal mw2EndsYen) {
		this.mw2EndsYen = mw2EndsYen;
	}
	/**
	 * @return mw2MeiSu
	 */
	public BigDecimal getMw2MeiSu() {
		return mw2MeiSu;
	}
	/**
	 * @param mw2MeiSu セットする mw2MeiSu
	 */
	public void setMw2MeiSu(BigDecimal mw2MeiSu) {
		this.mw2MeiSu = mw2MeiSu;
	}
	/**
	 * @return awfTaniKnj
	 */
	public String getAwfTaniKnj() {
		return awfTaniKnj;
	}
	/**
	 * @param awfTaniKnj セットする awfTaniKnj
	 */
	public void setAwfTaniKnj(String awfTaniKnj) {
		this.awfTaniKnj = awfTaniKnj;
	}
	/**
	 * @return kanriSoshiki
	 */
	public String getKanriSoshiki() {
		return kanriSoshiki;
	}
	/**
	 * @param kanriSoshiki セットする kanriSoshiki
	 */
	public void setKanriSoshiki(String kanriSoshiki) {
		this.kanriSoshiki = kanriSoshiki;
	}
	/**
	 * @return mw1KanriCod
	 */
	public String getMw1KanriCod() {
		return mw1KanriCod;
	}
	/**
	 * @param mw1KanriCod セットする mw1KanriCod
	 */
	public void setMw1KanriCod(String mw1KanriCod) {
		this.mw1KanriCod = mw1KanriCod;
	}
	/**
	 * @return mw1KanriKnj
	 */
	public String getMw1KanriKnj() {
		return mw1KanriKnj;
	}
	/**
	 * @param mw1KanriKnj セットする mw1KanriKnj
	 */
	public void setMw1KanriKnj(String mw1KanriKnj) {
		this.mw1KanriKnj = mw1KanriKnj;
	}
	/**
	 * @return futanSoshiki1
	 */
	public String getFutanSoshiki1() {
		return futanSoshiki1;
	}
	/**
	 * @param futanSoshiki1 セットする futanSoshiki1
	 */
	public void setFutanSoshiki1(String futanSoshiki1) {
		this.futanSoshiki1 = futanSoshiki1;
	}
	/**
	 * @return mw1Futan1Cod
	 */
	public String getMw1Futan1Cod() {
		return mw1Futan1Cod;
	}
	/**
	 * @param mw1Futan1Cod セットする mw1Futan1Cod
	 */
	public void setMw1Futan1Cod(String mw1Futan1Cod) {
		this.mw1Futan1Cod = mw1Futan1Cod;
	}
	/**
	 * @return mw1Futan1Knj
	 */
	public String getMw1Futan1Knj() {
		return mw1Futan1Knj;
	}
	/**
	 * @param mw1Futan1Knj セットする mw1Futan1Knj
	 */
	public void setMw1Futan1Knj(String mw1Futan1Knj) {
		this.mw1Futan1Knj = mw1Futan1Knj;
	}
	/**
	 * @return sechiBasho
	 */
	public String getSechiBasho() {
		return sechiBasho;
	}
	/**
	 * @param sechiBasho セットする sechiBasho
	 */
	public void setSechiBasho(String sechiBasho) {
		this.sechiBasho = sechiBasho;
	}
	/**
	 * @return mw2BashoCod
	 */
	public String getMw2BashoCod() {
		return mw2BashoCod;
	}
	/**
	 * @param mw2BashoCod セットする mw2BashoCod
	 */
	public void setMw2BashoCod(String mw2BashoCod) {
		this.mw2BashoCod = mw2BashoCod;
	}
	/**
	 * @return awaBashoKnj
	 */
	public String getAwaBashoKnj() {
		return awaBashoKnj;
	}
	/**
	 * @param awaBashoKnj セットする awaBashoKnj
	 */
	public void setAwaBashoKnj(String awaBashoKnj) {
		this.awaBashoKnj = awaBashoKnj;
	}
	/**
	 * @return seihinKataSeizo
	 */
	public String getSeihinKataSeizo() {
		return seihinKataSeizo;
	}
	/**
	 * @param seihinKataSeizo セットする seihinKataSeizo
	 */
	public void setSeihinKataSeizo(String seihinKataSeizo) {
		this.seihinKataSeizo = seihinKataSeizo;
	}
	/**
	 * @return mw2SeihinKnj
	 */
	public String getMw2SeihinKnj() {
		return mw2SeihinKnj;
	}
	/**
	 * @param mw2SeihinKnj セットする mw2SeihinKnj
	 */
	public void setMw2SeihinKnj(String mw2SeihinKnj) {
		this.mw2SeihinKnj = mw2SeihinKnj;
	}
	/**
	 * @return mw2KataNo
	 */
	public String getMw2KataNo() {
		return mw2KataNo;
	}
	/**
	 * @param mw2KataNo セットする mw2KataNo
	 */
	public void setMw2KataNo(String mw2KataNo) {
		this.mw2KataNo = mw2KataNo;
	}
	/**
	 * @return mw2SeizoKnj
	 */
	public String getMw2SeizoKnj() {
		return mw2SeizoKnj;
	}
	/**
	 * @param mw2SeizoKnj セットする mw2SeizoKnj
	 */
	public void setMw2SeizoKnj(String mw2SeizoKnj) {
		this.mw2SeizoKnj = mw2SeizoKnj;
	}
	/**
	 * @return mw1MemoKnj
	 */
	public String getMw1MemoKnj() {
		return mw1MemoKnj;
	}
	/**
	 * @param mw1MemoKnj セットする mw1MemoKnj
	 */
	public void setMw1MemoKnj(String mw1MemoKnj) {
		this.mw1MemoKnj = mw1MemoKnj;
	}
	/**
	 * @return mw2MemoKnj
	 */
	public String getMw2MemoKnj() {
		return mw2MemoKnj;
	}
	/**
	 * @param mw2MemoKnj セットする mw2MemoKnj
	 */
	public void setMw2MemoKnj(String mw2MemoKnj) {
		this.mw2MemoKnj = mw2MemoKnj;
	}
	/**
	 * @return mw2Komk11Knj
	 */
	public String getMw2Komk11Knj() {
		return mw2Komk11Knj;
	}
	/**
	 * @param mw2Komk11Knj セットする mw2Komk11Knj
	 */
	public void setMw2Komk11Knj(String mw2Komk11Knj) {
		this.mw2Komk11Knj = mw2Komk11Knj;
	}
	/**
	 * @return mw2Komk12Knj
	 */
	public String getMw2Komk12Knj() {
		return mw2Komk12Knj;
	}
	/**
	 * @param mw2Komk12Knj セットする mw2Komk12Knj
	 */
	public void setMw2Komk12Knj(String mw2Komk12Knj) {
		this.mw2Komk12Knj = mw2Komk12Knj;
	}
	/**
	 * @return mw2Komk13Knj
	 */
	public String getMw2Komk13Knj() {
		return mw2Komk13Knj;
	}
	/**
	 * @param mw2Komk13Knj セットする mw2Komk13Knj
	 */
	public void setMw2Komk13Knj(String mw2Komk13Knj) {
		this.mw2Komk13Knj = mw2Komk13Knj;
	}
	/**
	 * @return mw2Komk08Kna
	 */
	public String getMw2Komk08Kna() {
		return mw2Komk08Kna;
	}
	/**
	 * @param mw2Komk08Kna セットする mw2Komk08Kna
	 */
	public void setMw2Komk08Kna(String mw2Komk08Kna) {
		this.mw2Komk08Kna = mw2Komk08Kna;
	}
	/**
	 * @return mw2Komk15Knj
	 */
	public String getMw2Komk15Knj() {
		return mw2Komk15Knj;
	}
	/**
	 * @param mw2Komk15Knj セットする mw2Komk15Knj
	 */
	public void setMw2Komk15Knj(String mw2Komk15Knj) {
		this.mw2Komk15Knj = mw2Komk15Knj;
	}
	/**
	 * @return mw2Komk14Knj
	 */
	public String getMw2Komk14Knj() {
		return mw2Komk14Knj;
	}
	/**
	 * @param mw2Komk14Knj セットする mw2Komk14Knj
	 */
	public void setMw2Komk14Knj(String mw2Komk14Knj) {
		this.mw2Komk14Knj = mw2Komk14Knj;
	}
	/**
	 * @return mw1KaikeiYm
	 */
	public String getMw1KaikeiYm() {
		return mw1KaikeiYm;
	}
	/**
	 * @param mw1KaikeiYm セットする mw1KaikeiYm
	 */
	public void setMw1KaikeiYm(String mw1KaikeiYm) {
		this.mw1KaikeiYm = mw1KaikeiYm;
	}
	/**
	 * @return mw1KoteibktNo
	 */
	public String getMw1KoteibktNo() {
		return mw1KoteibktNo;
	}
	/**
	 * @param mw1KoteibktNo セットする mw1KoteibktNo
	 */
	public void setMw1KoteibktNo(String mw1KoteibktNo) {
		this.mw1KoteibktNo = mw1KoteibktNo;
	}
	/**
	 * @return mw2JyokykYmd
	 */
	public Date getMw2JyokykYmd() {
		return mw2JyokykYmd;
	}
	/**
	 * @param mw2JyokykYmd セットする mw2JyokykYmd
	 */
	public void setMw2JyokykYmd(Date mw2JyokykYmd) {
		this.mw2JyokykYmd = mw2JyokykYmd;
	}
	/**
	 * @return mw2ZanzonsYen
	 */
	public BigDecimal getMw2ZanzonsYen() {
		return mw2ZanzonsYen;
	}
	/**
	 * @param mw2ZanzonsYen セットする mw2ZanzonsYen
	 */
	public void setMw2ZanzonsYen(BigDecimal mw2ZanzonsYen) {
		this.mw2ZanzonsYen = mw2ZanzonsYen;
	}
	/**
	 * @return zanZonTaiyoNensuZ
	 */
	public String getZanZonTaiyoNensuZ() {
		return zanZonTaiyoNensuZ;
	}
	/**
	 * @param zanZonTaiyoNensuZ セットする zanZonTaiyoNensuZ
	 */
	public void setZanZonTaiyoNensuZ(String zanZonTaiyoNensuZ) {
		this.zanZonTaiyoNensuZ = zanZonTaiyoNensuZ;
	}
	/**
	 * @return mw1ZeitaiYs
	 */
	public BigDecimal getMw1ZeitaiYs() {
		return mw1ZeitaiYs;
	}
	/**
	 * @param mw1ZeitaiYs セットする mw1ZeitaiYs
	 */
	public void setMw1ZeitaiYs(BigDecimal mw1ZeitaiYs) {
		this.mw1ZeitaiYs = mw1ZeitaiYs;
	}
	/**
	 * @return mw1ZkeikaY
	 */
	public BigDecimal getMw1ZkeikaY() {
		return mw1ZkeikaY;
	}
	/**
	 * @param mw1ZkeikaY セットする mw1ZkeikaY
	 */
	public void setMw1ZkeikaY(BigDecimal mw1ZkeikaY) {
		this.mw1ZkeikaY = mw1ZkeikaY;
	}
	/**
	 * @return maebkasYenZ
	 */
	public BigDecimal getMaebkasYenZ() {
		return maebkasYenZ;
	}
	/**
	 * @param maebkasYenZ セットする maebkasYenZ
	 */
	public void setMaebkasYenZ(BigDecimal maebkasYenZ) {
		this.maebkasYenZ = maebkasYenZ;
	}
	/**
	 * @return mw2MaebkazYen
	 */
	public BigDecimal getMw2MaebkazYen() {
		return mw2MaebkazYen;
	}
	/**
	 * @param mw2MaebkazYen セットする mw2MaebkazYen
	 */
	public void setMw2MaebkazYen(BigDecimal mw2MaebkazYen) {
		this.mw2MaebkazYen = mw2MaebkazYen;
	}
	/**
	 * @return mw2TkishzYen
	 */
	public BigDecimal getMw2TkishzYen() {
		return mw2TkishzYen;
	}
	/**
	 * @param mw2TkishzYen セットする mw2TkishzYen
	 */
	public void setMw2TkishzYen(BigDecimal mw2TkishzYen) {
		this.mw2TkishzYen = mw2TkishzYen;
	}
	/**
	 * @return mw2EndzYen
	 */
	public BigDecimal getMw2EndzYen() {
		return mw2EndzYen;
	}
	/**
	 * @param mw2EndzYen セットする mw2EndzYen
	 */
	public void setMw2EndzYen(BigDecimal mw2EndzYen) {
		this.mw2EndzYen = mw2EndzYen;
	}
	/**
	 * @return aw8ShinkkKnj
	 */
	public String getAw8ShinkkKnj() {
		return aw8ShinkkKnj;
	}
	/**
	 * @param aw8ShinkkKnj セットする aw8ShinkkKnj
	 */
	public void setAw8ShinkkKnj(String aw8ShinkkKnj) {
		this.aw8ShinkkKnj = aw8ShinkkKnj;
	}
	/**
	 * @return mw2YbnhykYen
	 */
	public BigDecimal getMw2YbnhykYen() {
		return mw2YbnhykYen;
	}
	/**
	 * @param mw2YbnhykYen セットする mw2YbnhykYen
	 */
	public void setMw2YbnhykYen(BigDecimal mw2YbnhykYen) {
		this.mw2YbnhykYen = mw2YbnhykYen;
	}
	/**
	 * @return mw2YfnhykYen
	 */
	public BigDecimal getMw2YfnhykYen() {
		return mw2YfnhykYen;
	}
	/**
	 * @param mw2YfnhykYen セットする mw2YfnhykYen
	 */
	public void setMw2YfnhykYen(BigDecimal mw2YfnhykYen) {
		this.mw2YfnhykYen = mw2YfnhykYen;
	}
	public Date getMw2KyushiYmd() {
		return mw2KyushiYmd;
	}
	public void setMw2KyushiYmd(Date mw2KyushiYmd) {
		this.mw2KyushiYmd = mw2KyushiYmd;
	}
	public Date getMw2KyskjyYmd() {
		return mw2KyskjyYmd;
	}
	public void setMw2KyskjyYmd(Date mw2KyskjyYmd) {
		this.mw2KyskjyYmd = mw2KyskjyYmd;
	}
	public String getMw2KysmemoKnj() {
		return mw2KysmemoKnj;
	}
	public void setMw2KysmemoKnj(String mw2KysmemoKnj) {
		this.mw2KysmemoKnj = mw2KysmemoKnj;
	}

}