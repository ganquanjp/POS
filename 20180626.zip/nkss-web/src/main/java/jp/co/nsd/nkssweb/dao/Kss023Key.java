package jp.co.nsd.nkssweb.dao;

public class Kss023Key {
    private String roleId;

    private String soshikiCd;

    public String getRoleId() {
        return roleId;
    }

    public void setRoleId(String roleId) {
        this.roleId = roleId == null ? null : roleId.trim();
    }

    public String getSoshikiCd() {
        return soshikiCd;
    }

    public void setSoshikiCd(String soshikiCd) {
        this.soshikiCd = soshikiCd == null ? null : soshikiCd.trim();
    }
}