package jp.co.nsd.nkssweb.service.seisanshoshutoku;

import java.util.List;

import jp.co.nsd.nkssweb.dao.Kss004;
import jp.co.nsd.nkssweb.dao.SeisanshoShonin;
import jp.co.nsd.nkssweb.dao.SeisanshoShoninShokai;
/**
 * 取得承認（検索・照会・更新）処理
 *
 * @version 1.00
 */
public interface SeisanshoShoninService {

	/**
	 * 取得承認情報取得（検索画面）
	 *
	 * @param selectCondition
	 * @return
	 */
	List<SeisanshoShonin> getshoninInfo(SeisanshoShonin selectCondition);

	/**
	 * 取得承認情報取得（照会画面）
	 *
	 * @param seisanshoJokyakuShokai
	 *            INPUTパラメータ
	 * @return　検索結果
	 */
	SeisanshoShoninShokai getshutokuInfoBySeisanShoNo(SeisanshoShoninShokai seisanshoShoninShokai);

	/**
	 * 取得承認情報更新
	 *
	 * @param kss004
	 *            INPUTパラメータ
	 * @return 結果
	 * @throws Exception
	 */
	int updateInfo(Kss004 kss004) throws Exception;

	/**
	 * UPDATE処理の前に追加のエラーチェックを行います。
	 *
	 * @param kss004
	 *            INPUTパラメータ
	 * @return 結果
	 * @throws Exception
	 */
	String checkUpdate(Kss004 kss004) throws Exception;

	/**
	 * 取得承認情報印刷
	 *
	 * @param seisanShoId
	 *            INPUTパラメータ
	 * @return 結果
	 * @throws Exception
	 */
	List<String> printing(String seisanShoId) throws Exception;

}
