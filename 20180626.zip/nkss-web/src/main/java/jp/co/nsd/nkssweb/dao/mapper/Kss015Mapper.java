package jp.co.nsd.nkssweb.dao.mapper;

import jp.co.nsd.nkssweb.dao.Kss015;
import jp.co.nsd.nkssweb.dao.Kss015Key;

public interface Kss015Mapper {
    int deleteByPrimaryKey(Kss015Key key);

    int insert(Kss015 record);

    int insertSelective(Kss015 record);

    Kss015 selectByPrimaryKey(Kss015Key key);

    int updateByPrimaryKeySelective(Kss015 record);

    int updateByPrimaryKey(Kss015 record);
}