package jp.co.nsd.nkssweb.service.seisanshotoroku.impl;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import jp.co.nsd.nkssweb.dao.SeisanshoTorokuKmskJhe;
import jp.co.nsd.nkssweb.dao.mapper.SeisanshoTorokuKmskJheMapper;
import jp.co.nsd.nkssweb.service.seisanshotoroku.SeisanshoTorokuKmskJheService;
import jp.co.nsd.nkssweb.utils.NSDConstant;
import jp.co.nsd.nkssweb.utils.NSDProperties;

@Service
@Transactional(value = "postgresqlTransactionManager")
public class SeisanshoTorokuKmskJheServiceImpl implements SeisanshoTorokuKmskJheService {

	@Autowired
	private SeisanshoTorokuKmskJheMapper sssTrkMapper;

	@Autowired
	private NSDProperties nsdProperties;

	@Override
	public void getKenmeiInfo(String userId) throws Exception {
		// システム時間取得
		Date toda = new Date();
		// ファイル出力パス設定
		String filePath = nsdProperties.getBatchCsvFileKmskjhe();
		// ファイル名前に含む出力日付設定
		SimpleDateFormat fileFormat = new SimpleDateFormat(NSDConstant.STRING_YYYYMMDD);
		String selectfileName = sssTrkMapper.selectFileName();
		String selectfileCreateYmd = sssTrkMapper.selectFileCreateYmd();

		SeisanshoTorokuKmskJhe seisanshoTorokuKmskJhe = new SeisanshoTorokuKmskJhe();
		// 登録ユーザーＩＤ
		seisanshoTorokuKmskJhe.setEntryUserId(userId);
		// 更新ユーザーＩＤ
		seisanshoTorokuKmskJhe.setUpdateUserId(userId);
		// ファイル出力日付を設定する
		seisanshoTorokuKmskJhe.setFileCreateYmd(toda);
		// DBにファイル名が存在するかどうかの判定
		if (null == selectfileName) {
			// DBにファイル名が存在しない場合、シーケンス番号（1）を登録する
			seisanshoTorokuKmskJhe.setSeqNo(1);
			sssTrkMapper.insertBySeqNo(seisanshoTorokuKmskJhe);
		} else {

			if (fileFormat.format(toda).toString().equals(selectfileCreateYmd)) {
				// DBにファイル名が存在する場合、シーケンス番号（+1）を加算する
				int selectseqNo = sssTrkMapper.selectSeqNo();
				seisanshoTorokuKmskJhe.setSeqNo(selectseqNo + 1);
				sssTrkMapper.updateBySeqNo(seisanshoTorokuKmskJhe);
			} else {
				seisanshoTorokuKmskJhe.setSeqNo(1);
				sssTrkMapper.updateBySeqNo(seisanshoTorokuKmskJhe);
			}

		}

		int selectseqNo = sssTrkMapper.selectSeqNo();
		// ファイル名前を設定する
		String fileName = filePath + fileFormat.format(toda).toString() + NSDConstant.STRING_HAIFUN + selectseqNo
				+ NSDConstant.STRING_FILE_NAME;
		List<SeisanshoTorokuKmskJhe> sssTrkList = new ArrayList<SeisanshoTorokuKmskJhe>();
		sssTrkList = sssTrkMapper.selectByWhere();

		// 出力ファイルの作成
		File file_w3 = new File(fileName);
		PrintWriter p = new PrintWriter(
				new BufferedWriter(new OutputStreamWriter(new FileOutputStream(file_w3), NSDConstant.SHIFT_JIS)));

		// 内容をセットする
		for (int i = 0; i < sssTrkList.size(); i++) {

			SeisanshoTorokuKmskJhe sssTrkkDto = sssTrkList.get(i);

			// 科目内訳コード
			p.print(sssTrkkDto.getKenmeiCd());
			p.print(NSDConstant.STRING_KANMA);
			// 適用期間（FROM）
			p.print(sssTrkkDto.getTekiyoStart());
			p.print(NSDConstant.STRING_KANMA);
			// 適用期間（TO）
			p.print(sssTrkkDto.getTekiyoEnd());
			p.print(NSDConstant.STRING_KANMA);
			// 使用フラグ
			p.print(NSDConstant.STRING_1);
			p.print(NSDConstant.STRING_KANMA);
			// 発生科目コード
			p.print(NSDConstant.STRING_KANMA);
			// 科目内訳名称
			p.print(sssTrkkDto.getKenmeiNm());
			p.print(NSDConstant.STRING_KANMA);
			// 責任組織１コード固定
			p.print(NSDConstant.STRING_KANMA);
			// 繰越区分
			p.print(NSDConstant.STRING_0);
			p.print(NSDConstant.STRING_KANMA);
			// 予定着工年月
			p.print(NSDConstant.STRING_KANMA);
			// 予定竣工年月
			p.print(NSDConstant.STRING_KANMA);
			// 予算額
			p.print(NSDConstant.STRING_0);
			p.print(NSDConstant.STRING_KANMA);
			// 予備１
			p.print(NSDConstant.STRING_KANMA);
			// 予備２
			p.print(NSDConstant.STRING_KANMA);
			// 予備３
			p.print(NSDConstant.STRING_KANMA);
			// 予備４
			p.print(NSDConstant.STRING_KANMA);
			// 予備５
			p.print(NSDConstant.STRING_KANMA);
			// 適用期間(To)無効フラグ
			p.print(NSDConstant.STRING_0);
			p.print(NSDConstant.STRING_KANMA);
			// 更新カウンタ
			p.print(NSDConstant.STRING_0);
			p.print(NSDConstant.STRING_KANMA);
			// 登録日時
			p.print(NSDConstant.STRING_KANMA);
			// 登録者コード
			p.print(NSDConstant.STRING_KANMA);
			// 更新日時、更新者コード
			p.print(NSDConstant.STRING_KANMA);
			// 改行
			p.println();

			seisanshoTorokuKmskJhe = new SeisanshoTorokuKmskJhe();
			seisanshoTorokuKmskJhe.setRenkeiStatus(NSDConstant.STRING_1);
			seisanshoTorokuKmskJhe.setKenmeiId(sssTrkkDto.getKenmeiId());
			seisanshoTorokuKmskJhe.setUpdateUserId(userId);
			sssTrkMapper.updateByPrimaryKey(seisanshoTorokuKmskJhe);

		}

		// ファイルに書き出し閉じる
		p.close();

	}
}
