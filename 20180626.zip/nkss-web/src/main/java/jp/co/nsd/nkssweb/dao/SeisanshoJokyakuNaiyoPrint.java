package jp.co.nsd.nkssweb.dao;

import java.math.BigDecimal;

public class SeisanshoJokyakuNaiyoPrint {

	// 除却精算書ＩＤ
	private String jokyakuSeisanShoId;

	// 工事件名
	private String kenmei;

	// 精算箇所コード
	private String seisanSoshikiCd;

	// 精算箇所名称
	private String soshikiRenNm;

	// 除却精算書番号
	private String jokyakuSeisanShoNo;

	// 除却予定年月日
	private String jokyakuYoteYmd;

	// 摘要
	private String tekiyo;

	// 総件数
	private Long shutokuSisanCnt;

	// 取得原価（合計）
	private BigDecimal jokyakuGakuSum;

	// 減価償却累計額（商法・合計）
	private BigDecimal ksJkgnrsYenSum;

	// 減価償却累計額（税法・合計）
	private BigDecimal ksJkgnrzYenSum;

	// 減損損失累計額（商法・合計）
	private BigDecimal rwgSonruisYenSum;

	// 減損損失累計額（税法・合計）
	private BigDecimal rwgSonruizYenSum;

	// 帳簿価額（商法・合計）
	private BigDecimal tyoBosYenSum;

	// 帳簿価額（税法・合計）
	private BigDecimal tyoBozYenSum;

	// 除却損（商法・合計）
	private BigDecimal ksJksonsYenSum;

	// 除却損（税法・合計）
	private BigDecimal ksJksonzYenSum;

	// 種類コード
	private String shuruiCd;

	// 構造コード
	private String kouzouCd;

	// 資産単位コード
	private String shisanTaniCd;

	// 種別４コード
	private String kamokuCd1;

	// 種別５コード
	private String kamokuCd2;

	// 種別６コード
	private String kamokuCd3;

	// 種類名称
	private String shuKnj;

	// 構造名称
	private String kouKnj;

	// 細目名称
	private String saiKnj;

	// 種別４名称
	private String shu4Knj;

	// 種別５名称
	private String shu5Knj;

	// 種別６名称
	private String shu6Knj;

	// 件数
	private Long kenSu;

	// 取得価額
	private BigDecimal jokyakuGaku;

	// 減価償却累計額（商法）
	private BigDecimal ksJkgnrsYen;

	// 減価償却累計額（税法）
	private BigDecimal ksJkgnrzYen;

	// 減損損失累計額（商法）
	private BigDecimal rwgSonruisYen;

	// 減損損失累計額（税法）
	private BigDecimal rwgSonruiYen;

	// 帳簿価額（商法）
	private BigDecimal tyoBosYen;

	// 帳簿価額（税法）
	private BigDecimal tyoBozYen;

	// 除却損（商法）
	private BigDecimal ksJksonsYen;

	// 除却損（税法）
	private BigDecimal ksJksonzYen;

	// 取引先コード
	private String torihikiSakiCd;

	// 取引先名称
	private String torihikiSakiNm;

	// 固定資産番号
	private String koteiNo;

	// 固定資産名称
	private String koteiKnj;

	// 場所コード
	private String bashoCod;

	// 場所名称
	private String bashoKnj;

	// 取引年月日
	private String shutokuYmd;

	// 使用開始日
	private String siyoStartYmd;

	// 単位コード
	private String taniCod;

	// 単位名称
	private String taniKnj;

	// 元数量
	private BigDecimal motoMeiSu;

	// 元取得価額
	private BigDecimal motoGetkgkYen;

	// 除数量
	private BigDecimal jokyakuSuryo;

	// 残＿数量
	private String zanSuryo;

	// 残＿取得価額
	private BigDecimal zangtkgkYen;

	// 除却簿価（物品）
	private BigDecimal buppinGaku;

	// 除却簿価（工費）
	private BigDecimal kouhiGaku;

	// 除却簿価（合計）
	private BigDecimal bokaSum;

	// 除却損＿商
	private BigDecimal ksJksonYen;

	// 摘要１
	private String tekiyo1;

	// 摘要２
	private String tekiyo2;

	// 摘要３
	private String tekiyo3;

	// 摘要４
	private String tekiyo4;

	// 摘要５
	private String tekiyo5;

	// 親子区分
	private String koshiKbn;

	// 管理コード
	private String kanriCod;

	// 管理名称
	private String kanriKnj;

	public String getJokyakuSeisanShoId() {
		return jokyakuSeisanShoId;
	}

	public void setJokyakuSeisanShoId(String jokyakuSeisanShoId) {
		this.jokyakuSeisanShoId = jokyakuSeisanShoId;
	}

	public String getKenmei() {
		return kenmei;
	}

	public void setKenmei(String kenmei) {
		this.kenmei = kenmei;
	}

	public String getSeisanSoshikiCd() {
		return seisanSoshikiCd;
	}

	public void setSeisanSoshikiCd(String seisanSoshikiCd) {
		this.seisanSoshikiCd = seisanSoshikiCd;
	}

	public String getSoshikiRenNm() {
		return soshikiRenNm;
	}

	public void setSoshikiRenNm(String soshikiRenNm) {
		this.soshikiRenNm = soshikiRenNm;
	}

	public String getJokyakuSeisanShoNo() {
		return jokyakuSeisanShoNo;
	}

	public void setJokyakuSeisanShoNo(String jokyakuSeisanShoNo) {
		this.jokyakuSeisanShoNo = jokyakuSeisanShoNo;
	}

	public String getJokyakuYoteYmd() {
		return jokyakuYoteYmd;
	}

	public void setJokyakuYoteYmd(String jokyakuYoteYmd) {
		this.jokyakuYoteYmd = jokyakuYoteYmd;
	}

	public String getTekiyo() {
		return tekiyo;
	}

	public void setTekiyo(String tekiyo) {
		this.tekiyo = tekiyo;
	}

	public Long getShutokuSisanCnt() {
		return shutokuSisanCnt;
	}

	public void setShutokuSisanCnt(Long shutokuSisanCnt) {
		this.shutokuSisanCnt = shutokuSisanCnt;
	}

	public BigDecimal getJokyakuGakuSum() {
		return jokyakuGakuSum;
	}

	public void setJokyakuGakuSum(BigDecimal jokyakuGakuSum) {
		this.jokyakuGakuSum = jokyakuGakuSum;
	}

	public BigDecimal getKsJkgnrsYenSum() {
		return ksJkgnrsYenSum;
	}

	public void setKsJkgnrsYenSum(BigDecimal ksJkgnrsYenSum) {
		this.ksJkgnrsYenSum = ksJkgnrsYenSum;
	}

	public BigDecimal getKsJkgnrzYenSum() {
		return ksJkgnrzYenSum;
	}

	public void setKsJkgnrzYenSum(BigDecimal ksJkgnrzYenSum) {
		this.ksJkgnrzYenSum = ksJkgnrzYenSum;
	}

	public BigDecimal getRwgSonruisYenSum() {
		return rwgSonruisYenSum;
	}

	public void setRwgSonruisYenSum(BigDecimal rwgSonruisYenSum) {
		this.rwgSonruisYenSum = rwgSonruisYenSum;
	}

	public BigDecimal getRwgSonruizYenSum() {
		return rwgSonruizYenSum;
	}

	public void setRwgSonruizYenSum(BigDecimal rwgSonruizYenSum) {
		this.rwgSonruizYenSum = rwgSonruizYenSum;
	}

	public BigDecimal getTyoBosYenSum() {
		return tyoBosYenSum;
	}

	public void setTyoBosYenSum(BigDecimal tyoBosYenSum) {
		this.tyoBosYenSum = tyoBosYenSum;
	}

	public BigDecimal getTyoBozYenSum() {
		return tyoBozYenSum;
	}

	public void setTyoBozYenSum(BigDecimal tyoBozYenSum) {
		this.tyoBozYenSum = tyoBozYenSum;
	}

	public BigDecimal getKsJksonsYenSum() {
		return ksJksonsYenSum;
	}

	public void setKsJksonsYenSum(BigDecimal ksJksonsYenSum) {
		this.ksJksonsYenSum = ksJksonsYenSum;
	}

	public BigDecimal getKsJksonzYenSum() {
		return ksJksonzYenSum;
	}

	public void setKsJksonzYenSum(BigDecimal ksJksonzYenSum) {
		this.ksJksonzYenSum = ksJksonzYenSum;
	}

	public String getShuruiCd() {
		return shuruiCd;
	}

	public void setShuruiCd(String shuruiCd) {
		this.shuruiCd = shuruiCd;
	}

	public String getKouzouCd() {
		return kouzouCd;
	}

	public void setKouzouCd(String kouzouCd) {
		this.kouzouCd = kouzouCd;
	}

	public String getShisanTaniCd() {
		return shisanTaniCd;
	}

	public void setShisanTaniCd(String shisanTaniCd) {
		this.shisanTaniCd = shisanTaniCd;
	}

	public String getKamokuCd1() {
		return kamokuCd1;
	}

	public void setKamokuCd1(String kamokuCd1) {
		this.kamokuCd1 = kamokuCd1;
	}

	public String getKamokuCd2() {
		return kamokuCd2;
	}

	public void setKamokuCd2(String kamokuCd2) {
		this.kamokuCd2 = kamokuCd2;
	}

	public String getKamokuCd3() {
		return kamokuCd3;
	}

	public void setKamokuCd3(String kamokuCd3) {
		this.kamokuCd3 = kamokuCd3;
	}

	public String getShuKnj() {
		return shuKnj;
	}

	public void setShuKnj(String shuKnj) {
		this.shuKnj = shuKnj;
	}

	public String getKouKnj() {
		return kouKnj;
	}

	public void setKouKnj(String kouKnj) {
		this.kouKnj = kouKnj;
	}

	public String getSaiKnj() {
		return saiKnj;
	}

	public void setSaiKnj(String saiKnj) {
		this.saiKnj = saiKnj;
	}

	public String getShu4Knj() {
		return shu4Knj;
	}

	public void setShu4Knj(String shu4Knj) {
		this.shu4Knj = shu4Knj;
	}

	public String getShu5Knj() {
		return shu5Knj;
	}

	public void setShu5Knj(String shu5Knj) {
		this.shu5Knj = shu5Knj;
	}

	public String getShu6Knj() {
		return shu6Knj;
	}

	public void setShu6Knj(String shu6Knj) {
		this.shu6Knj = shu6Knj;
	}

	public Long getKenSu() {
		return kenSu;
	}

	public void setKenSu(Long kenSu) {
		this.kenSu = kenSu;
	}

	public BigDecimal getJokyakuGaku() {
		return jokyakuGaku;
	}

	public void setJokyakuGaku(BigDecimal jokyakuGaku) {
		this.jokyakuGaku = jokyakuGaku;
	}

	public BigDecimal getKsJkgnrsYen() {
		return ksJkgnrsYen;
	}

	public void setKsJkgnrsYen(BigDecimal ksJkgnrsYen) {
		this.ksJkgnrsYen = ksJkgnrsYen;
	}

	public BigDecimal getKsJkgnrzYen() {
		return ksJkgnrzYen;
	}

	public void setKsJkgnrzYen(BigDecimal ksJkgnrzYen) {
		this.ksJkgnrzYen = ksJkgnrzYen;
	}

	public BigDecimal getRwgSonruisYen() {
		return rwgSonruisYen;
	}

	public void setRwgSonruisYen(BigDecimal rwgSonruisYen) {
		this.rwgSonruisYen = rwgSonruisYen;
	}

	public BigDecimal getRwgSonruiYen() {
		return rwgSonruiYen;
	}

	public void setRwgSonruiYen(BigDecimal rwgSonruiYen) {
		this.rwgSonruiYen = rwgSonruiYen;
	}

	public BigDecimal getTyoBosYen() {
		return tyoBosYen;
	}

	public void setTyoBosYen(BigDecimal tyoBosYen) {
		this.tyoBosYen = tyoBosYen;
	}

	public BigDecimal getTyoBozYen() {
		return tyoBozYen;
	}

	public void setTyoBozYen(BigDecimal tyoBozYen) {
		this.tyoBozYen = tyoBozYen;
	}

	public BigDecimal getKsJksonsYen() {
		return ksJksonsYen;
	}

	public void setKsJksonsYen(BigDecimal ksJksonsYen) {
		this.ksJksonsYen = ksJksonsYen;
	}

	public BigDecimal getKsJksonzYen() {
		return ksJksonzYen;
	}

	public void setKsJksonzYen(BigDecimal ksJksonzYen) {
		this.ksJksonzYen = ksJksonzYen;
	}

	public String getTorihikiSakiCd() {
		return torihikiSakiCd;
	}

	public void setTorihikiSakiCd(String torihikiSakiCd) {
		this.torihikiSakiCd = torihikiSakiCd;
	}

	public String getTorihikiSakiNm() {
		return torihikiSakiNm;
	}

	public void setTorihikiSakiNm(String torihikiSakiNm) {
		this.torihikiSakiNm = torihikiSakiNm;
	}

	public String getKoteiNo() {
		return koteiNo;
	}

	public void setKoteiNo(String koteiNo) {
		this.koteiNo = koteiNo;
	}

	public String getKoteiKnj() {
		return koteiKnj;
	}

	public void setKoteiKnj(String koteiKnj) {
		this.koteiKnj = koteiKnj;
	}

	public String getBashoCod() {
		return bashoCod;
	}

	public void setBashoCod(String bashoCod) {
		this.bashoCod = bashoCod;
	}

	public String getBashoKnj() {
		return bashoKnj;
	}

	public void setBashoKnj(String bashoKnj) {
		this.bashoKnj = bashoKnj;
	}

	public String getShutokuYmd() {
		return shutokuYmd;
	}

	public void setShutokuYmd(String shutokuYmd) {
		this.shutokuYmd = shutokuYmd;
	}

	public String getSiyoStartYmd() {
		return siyoStartYmd;
	}

	public void setSiyoStartYmd(String siyoStartYmd) {
		this.siyoStartYmd = siyoStartYmd;
	}

	public String getTaniCod() {
		return taniCod;
	}

	public void setTaniCod(String taniCod) {
		this.taniCod = taniCod;
	}

	public String getTaniKnj() {
		return taniKnj;
	}

	public void setTaniKnj(String taniKnj) {
		this.taniKnj = taniKnj;
	}

	public BigDecimal getMotoMeiSu() {
		return motoMeiSu;
	}

	public void setMotoMeiSu(BigDecimal motoMeiSu) {
		this.motoMeiSu = motoMeiSu;
	}

	public BigDecimal getMotoGetkgkYen() {
		return motoGetkgkYen;
	}

	public void setMotoGetkgkYen(BigDecimal motoGetkgkYen) {
		this.motoGetkgkYen = motoGetkgkYen;
	}

	public BigDecimal getJokyakuSuryo() {
		return jokyakuSuryo;
	}

	public void setJokyakuSuryo(BigDecimal jokyakuSuryo) {
		this.jokyakuSuryo = jokyakuSuryo;
	}

	public String getZanSuryo() {
		return zanSuryo;
	}

	public void setZanSuryo(String zanSuryo) {
		this.zanSuryo = zanSuryo;
	}

	public BigDecimal getZangtkgkYen() {
		return zangtkgkYen;
	}

	public void setZangtkgkYen(BigDecimal zangtkgkYen) {
		this.zangtkgkYen = zangtkgkYen;
	}

	public BigDecimal getBuppinGaku() {
		return buppinGaku;
	}

	public void setBuppinGaku(BigDecimal buppinGaku) {
		this.buppinGaku = buppinGaku;
	}

	public BigDecimal getKouhiGaku() {
		return kouhiGaku;
	}

	public void setKouhiGaku(BigDecimal kouhiGaku) {
		this.kouhiGaku = kouhiGaku;
	}

	public BigDecimal getBokaSum() {
		return bokaSum;
	}

	public void setBokaSum(BigDecimal bokaSum) {
		this.bokaSum = bokaSum;
	}

	public BigDecimal getKsJksonYen() {
		return ksJksonYen;
	}

	public void setKsJksonYen(BigDecimal ksJksonYen) {
		this.ksJksonYen = ksJksonYen;
	}

	public String getTekiyo1() {
		return tekiyo1;
	}

	public void setTekiyo1(String tekiyo1) {
		this.tekiyo1 = tekiyo1;
	}

	public String getTekiyo2() {
		return tekiyo2;
	}

	public void setTekiyo2(String tekiyo2) {
		this.tekiyo2 = tekiyo2;
	}

	public String getTekiyo3() {
		return tekiyo3;
	}

	public void setTekiyo3(String tekiyo3) {
		this.tekiyo3 = tekiyo3;
	}

	public String getTekiyo4() {
		return tekiyo4;
	}

	public void setTekiyo4(String tekiyo4) {
		this.tekiyo4 = tekiyo4;
	}

	public String getTekiyo5() {
		return tekiyo5;
	}

	public void setTekiyo5(String tekiyo5) {
		this.tekiyo5 = tekiyo5;
	}

	public String getKoshiKbn() {
		return koshiKbn;
	}

	public void setKoshiKbn(String koshiKbn) {
		this.koshiKbn = koshiKbn;
	}

	public String getKanriCod() {
		return kanriCod;
	}

	public void setKanriCod(String kanriCod) {
		this.kanriCod = kanriCod;
	}

	public String getKanriKnj() {
		return kanriKnj;
	}

	public void setKanriKnj(String kanriKnj) {
		this.kanriKnj = kanriKnj;
	}

}