package jp.co.nsd.nkssweb.service.impl;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.postgresql.util.PSQLException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import jp.co.nsd.nkssweb.dao.BunkatsuSyunyu;
import jp.co.nsd.nkssweb.dao.BunkatsuSyunyuKoteiInfo;
import jp.co.nsd.nkssweb.dao.Kss004;
import jp.co.nsd.nkssweb.dao.Kss005;
import jp.co.nsd.nkssweb.dao.Kss008;
import jp.co.nsd.nkssweb.dao.mapper.BunkatsuSyunyuMapper;
import jp.co.nsd.nkssweb.dao.mapper.CommMapper;
import jp.co.nsd.nkssweb.dao.mapper.Kss005Mapper;
import jp.co.nsd.nkssweb.dao.mapper.Kss008Mapper;
import jp.co.nsd.nkssweb.dao.mapper.StoredMapper;
import jp.co.nsd.nkssweb.service.BunkatsuSyunyuService;
import jp.co.nsd.nkssweb.service.CommService;
import jp.co.nsd.nkssweb.utils.NSDConstant;
import jp.co.nsd.nkssweb.utils.NSDDateUtils;

@Service
@Transactional(value = "postgresqlTransactionManager")
public class BunkatsuSyunyuServiceImpl implements BunkatsuSyunyuService {

	@Autowired
	private BunkatsuSyunyuMapper bunkatsuSyunyuMapper;

	@Autowired
	private CommService commService;

	@Autowired
	private Kss008Mapper kss008Mapper;

	@Autowired
	private Kss005Mapper kss005Mapper;

	@Autowired
	private StoredMapper storedMapper;

	@Autowired
	private CommMapper commMapper;

	/**
	 * 分割収入画面内容取得
	 *
	 */
	public List<BunkatsuSyunyu> getBunkatsuInfo(BunkatsuSyunyu selectCondition) {
		List<BunkatsuSyunyu> bktSnList = new ArrayList<BunkatsuSyunyu>();

		bktSnList = bunkatsuSyunyuMapper.selectByWhere(selectCondition);

		if (bktSnList.size() > 0) {
			for (int i = 1; i <= bktSnList.size(); i++) {

				BunkatsuSyunyu bktSnDto = bktSnList.get(i - 1);
				// ROWNOを設定する
				bktSnDto.setRowNo(i);

				// 連携対象
				bktSnDto.setShoninStatusNm(
						commService.getCodeName(NSDConstant.CD_SHONIN_STATUS, bktSnDto.getShoninStatus()));

				Map<String, Object> map = new HashMap<String, Object>();
				// 精算書ID
				map.put("seisanShoId", bktSnDto.getSeisanShoId());

				// 精算書固定資産情報を取得
				List<BunkatsuSyunyuKoteiInfo> bsKtInfoLst = bunkatsuSyunyuMapper.getSeisanshoKoteiInfo(map);

				for (int j = 1; j <= bsKtInfoLst.size(); j++) {

					BunkatsuSyunyuKoteiInfo bunkatsuSyunyuKoteiInfo = bsKtInfoLst.get(j - 1);

					bunkatsuSyunyuKoteiInfo.setRowNo(j);
				}

				bktSnDto.setBsKtInfoLst(bsKtInfoLst);
			}
		} else {
			bktSnList = null;
		}

		return bktSnList;

	}

	/**
	 * 分割情報更新画面初期化
	 *
	 * @param seisanShoId
	 * @return
	 */
	@Override
	public List<Map<String, Object>> initUpdInfo(List<String> seisanShoIdLst) {

		List<Map<String, Object>> result = new ArrayList<Map<String, Object>>();

		for (String item : seisanShoIdLst) {
			Map<String, Object> resultData = bunkatsuSyunyuMapper.initUpdInfo(item);

			result.add(resultData);
		}

		return result;
	}

	/**
	 * 分割情報更新処理
	 *
	 * @param insertKss008Lst
	 * @param updateKss008Lst
	 * @param Kss008Lst
	 * @return
	 */
	@Override
	public int update(List<Kss008> insertKss008Lst, List<Kss008> updateKss008Lst, List<Kss008> Kss008Lst,
			List<Kss004> kss004Lst, Map<String, Object> renkeiInfoMap) throws Exception {

		boolean renkeiFlg = false;

		// 分割収入更新処理（更新前ストアド1）の処理
		storedMapper.clearSisanIdListKs3040();

		// 更新前に処理
		for (Kss004 kss004 : kss004Lst) {
			// データ連係済は連係処理を実行します
			if (NSDConstant.SHONIN_STATUS_CODE_RENKEI.equals(kss004.getShoninStatus())) {
				try {
					Map<String, Object> map = new HashMap<String, Object>();
					map.put("seisanShoId", kss004.getSeisanShoId());
					// 分割収入更新処理（更新前ストアド2）の処理
					storedMapper.addSisanIdKs3040(map);
				} catch (Exception e) {
					throw new PSQLException("ファイル出力前処理でエラーが発生しました. error=[" + e.getMessage() + "]", null);
				}

				// 連係処理
				renkeiFlg = true;
			}

			Kss004 kss004upInfo = new Kss004();
			// 精算書ID
			kss004upInfo.setSeisanShoId(kss004.getSeisanShoId());
			// 承認状態
			kss004upInfo.setShoninStatus(kss004.getShoninStatus());
			// 理由
			kss004upInfo.setRiyu(kss004.getRiyu());

			// 更新年月日
			kss004upInfo.setUpdateDate(kss004.getUpdateDate());
			// 更新ユーザーＩＤ
			kss004upInfo.setUpdateUserId(kss004.getUpdateUserId());
			// 承認状態を変更
			commMapper.updateStatus(kss004upInfo);
		}

		// 登録処理
		for (Kss008 kss008 : insertKss008Lst) {

			kss008Mapper.insertSelective(kss008);

		}

		// 更新処理
		for (Kss008 kss008 : updateKss008Lst) {

			kss008Mapper.updateByPrimaryKeySelective(kss008);

		}

		// 更新後で処理
		for (Kss008 kss008 : Kss008Lst) {

			// 登録する月数を取得
			int MaxMonthcnt = 0;

			// 契約開始年月日
			Calendar keiyakuStartYmd = dateToCalendar(kss008.getKeiyakuStartYmd());
			keiyakuStartYmd.set(Calendar.DATE, 1);
			// 契約終了年月日
			Calendar keiyakuEndYmd = dateToCalendar(kss008.getKeiyakuEndYmd());
			keiyakuEndYmd.set(Calendar.DATE, 1);

			// 登録する月数分ループしカウントを保持する。
			while (!keiyakuStartYmd.after(keiyakuEndYmd)) {
				keiyakuStartYmd.add(Calendar.MONTH, 1);
				MaxMonthcnt = MaxMonthcnt + 1;
			}

			// 登録する月数があるかを判定
			if (MaxMonthcnt > 0) {

				List<Map<String, Object>> kagakuMap = bunkatsuSyunyuMapper.getShutokuKakaku(kss008.getSeisanShoId());

				for (Map<String, Object> map : kagakuMap) {

					Kss005 kss005 = new Kss005();
					// 精算書ID
					kss005.setSeisanShoId(String.valueOf(map.get("seisanshoid")));
					// 固定資産ID
					kss005.setKoteiShisanId(String.valueOf(map.get("koteishisanid")));
					// 項目１０
					kss005.setKomoku10(NSDDateUtils.dateToString(kss008.getServiceStartYmd(), "yyyy/MM/dd"));
					// 更新年月日
					kss005.setUpdateDate(kss008.getUpdateDate());
					// 更新ユーザーＩＤ
					kss005.setUpdateUserId(kss008.getUpdateUserId());

					kss005Mapper.updateByPrimaryKeySelective(kss005);
				}
			}
		}

		// 連係処理
		if (renkeiFlg) {
			// 分割収入更新処理（更新後ストアド）の処理
			try {
				Map<String, Object> map = new HashMap<String, Object>();
				map.put("hakouSoshikiCd", renkeiInfoMap.get("hakouSoshikiCd"));
				map.put("renkeidataSakuseiYmd", new java.sql.Date(Calendar.getInstance().getTimeInMillis()));
				map.put("kaikeiSeiriYm", renkeiInfoMap.get("kaikeiSeiriYm"));
				// 更新後の処理
				storedMapper.setAllKs3040(map);
			} catch (Exception e) {
				throw new PSQLException("ファイル出力前処理でエラーが発生しました. error=[" + e.getMessage() + "]", null);
			}
		}

		return 0;
	}

	private Calendar dateToCalendar(Date date) {

		Calendar calendar = Calendar.getInstance();
		calendar.setTime(date);
		return calendar;

	}
}
