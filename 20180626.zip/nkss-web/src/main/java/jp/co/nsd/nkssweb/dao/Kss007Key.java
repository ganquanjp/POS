package jp.co.nsd.nkssweb.dao;

public class Kss007Key {
    private String jokyakuSeisanShoId;

    private String jokyakuShisanId;

    public String getJokyakuSeisanShoId() {
        return jokyakuSeisanShoId;
    }

    public void setJokyakuSeisanShoId(String jokyakuSeisanShoId) {
        this.jokyakuSeisanShoId = jokyakuSeisanShoId == null ? null : jokyakuSeisanShoId.trim();
    }

    public String getJokyakuShisanId() {
        return jokyakuShisanId;
    }

    public void setJokyakuShisanId(String jokyakuShisanId) {
        this.jokyakuShisanId = jokyakuShisanId == null ? null : jokyakuShisanId.trim();
    }
}