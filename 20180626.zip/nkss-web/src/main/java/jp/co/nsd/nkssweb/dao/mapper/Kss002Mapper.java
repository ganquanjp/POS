package jp.co.nsd.nkssweb.dao.mapper;

import jp.co.nsd.nkssweb.dao.Kss002;

public interface Kss002Mapper {
    int deleteByPrimaryKey(Long kenmeiId);

    int insert(Kss002 record);

    int insertSelective(Kss002 record);

    Kss002 selectByPrimaryKey(Long kenmeiId);

    int updateByPrimaryKeySelective(Kss002 record);

    int updateByPrimaryKey(Kss002 record);
}