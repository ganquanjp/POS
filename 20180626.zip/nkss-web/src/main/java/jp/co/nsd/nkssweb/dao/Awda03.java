package jp.co.nsd.nkssweb.dao;

import java.util.Date;

public class Awda03 {
    private String aw3ShuCod;

    private String aw3KouCod;

    private String aw3SaiCod;

    private String aw3SaiKnj;

    private String aw3JtssnKbn;

    private String aw3RenynFlg;

    private String aw3SisanKbn;

    private String aw3SkyKbn;

    private String aw3ShohohCod;

    private String aw3SshohohCod;

    private Short aw3ZeityoYs;

    private Short aw3ShotyoYs;

    private Integer aw3UpdateCnt;

    private Date aw3TorokDh;

    private String aw3TorshaCod;

    private Date aw3UpdateDh;

    private String aw3UpdshaCod;

    public String getAw3ShuCod() {
        return aw3ShuCod;
    }

    public void setAw3ShuCod(String aw3ShuCod) {
        this.aw3ShuCod = aw3ShuCod == null ? null : aw3ShuCod.trim();
    }

    public String getAw3KouCod() {
        return aw3KouCod;
    }

    public void setAw3KouCod(String aw3KouCod) {
        this.aw3KouCod = aw3KouCod == null ? null : aw3KouCod.trim();
    }

    public String getAw3SaiCod() {
        return aw3SaiCod;
    }

    public void setAw3SaiCod(String aw3SaiCod) {
        this.aw3SaiCod = aw3SaiCod == null ? null : aw3SaiCod.trim();
    }

    public String getAw3SaiKnj() {
        return aw3SaiKnj;
    }

    public void setAw3SaiKnj(String aw3SaiKnj) {
        this.aw3SaiKnj = aw3SaiKnj == null ? null : aw3SaiKnj.trim();
    }

    public String getAw3JtssnKbn() {
        return aw3JtssnKbn;
    }

    public void setAw3JtssnKbn(String aw3JtssnKbn) {
        this.aw3JtssnKbn = aw3JtssnKbn == null ? null : aw3JtssnKbn.trim();
    }

    public String getAw3RenynFlg() {
        return aw3RenynFlg;
    }

    public void setAw3RenynFlg(String aw3RenynFlg) {
        this.aw3RenynFlg = aw3RenynFlg == null ? null : aw3RenynFlg.trim();
    }

    public String getAw3SisanKbn() {
        return aw3SisanKbn;
    }

    public void setAw3SisanKbn(String aw3SisanKbn) {
        this.aw3SisanKbn = aw3SisanKbn == null ? null : aw3SisanKbn.trim();
    }

    public String getAw3SkyKbn() {
        return aw3SkyKbn;
    }

    public void setAw3SkyKbn(String aw3SkyKbn) {
        this.aw3SkyKbn = aw3SkyKbn == null ? null : aw3SkyKbn.trim();
    }

    public String getAw3ShohohCod() {
        return aw3ShohohCod;
    }

    public void setAw3ShohohCod(String aw3ShohohCod) {
        this.aw3ShohohCod = aw3ShohohCod == null ? null : aw3ShohohCod.trim();
    }

    public String getAw3SshohohCod() {
        return aw3SshohohCod;
    }

    public void setAw3SshohohCod(String aw3SshohohCod) {
        this.aw3SshohohCod = aw3SshohohCod == null ? null : aw3SshohohCod.trim();
    }

    public Short getAw3ZeityoYs() {
        return aw3ZeityoYs;
    }

    public void setAw3ZeityoYs(Short aw3ZeityoYs) {
        this.aw3ZeityoYs = aw3ZeityoYs;
    }

    public Short getAw3ShotyoYs() {
        return aw3ShotyoYs;
    }

    public void setAw3ShotyoYs(Short aw3ShotyoYs) {
        this.aw3ShotyoYs = aw3ShotyoYs;
    }

    public Integer getAw3UpdateCnt() {
        return aw3UpdateCnt;
    }

    public void setAw3UpdateCnt(Integer aw3UpdateCnt) {
        this.aw3UpdateCnt = aw3UpdateCnt;
    }

    public Date getAw3TorokDh() {
        return aw3TorokDh;
    }

    public void setAw3TorokDh(Date aw3TorokDh) {
        this.aw3TorokDh = aw3TorokDh;
    }

    public String getAw3TorshaCod() {
        return aw3TorshaCod;
    }

    public void setAw3TorshaCod(String aw3TorshaCod) {
        this.aw3TorshaCod = aw3TorshaCod == null ? null : aw3TorshaCod.trim();
    }

    public Date getAw3UpdateDh() {
        return aw3UpdateDh;
    }

    public void setAw3UpdateDh(Date aw3UpdateDh) {
        this.aw3UpdateDh = aw3UpdateDh;
    }

    public String getAw3UpdshaCod() {
        return aw3UpdshaCod;
    }

    public void setAw3UpdshaCod(String aw3UpdshaCod) {
        this.aw3UpdshaCod = aw3UpdshaCod == null ? null : aw3UpdshaCod.trim();
    }
}