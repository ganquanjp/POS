package jp.co.nsd.nkssweb.dao;

/**
 * 固定資産台帳ファイル情報
 *
 * @version 1.00
 */
public class KoteshisanDaityoFileInfo {

	// 行番号
	private int rowNo;

	// 台帳ID
	private String daichoId;

	// 作成日付
	private String sakuseiDate;

	// 作成時刻
	private String sakuseiTime;

	// 台帳ファイル名
	private String daichoNm;

	// 作成区分名称
	private String sakuseiKbnNm;

	// 作成者名称
	private String sakuseiUserNm;

	public int getRowNo() {
		return rowNo;
	}

	public void setRowNo(int rowNo) {
		this.rowNo = rowNo;
	}

	public String getDaichoId() {
		return daichoId;
	}

	public void setDaichoId(String daichoId) {
		this.daichoId = daichoId;
	}

	public String getSakuseiDate() {
		return sakuseiDate;
	}

	public void setSakuseiDate(String sakuseiDate) {
		this.sakuseiDate = sakuseiDate;
	}

	public String getSakuseiTime() {
		return sakuseiTime;
	}

	public void setSakuseiTime(String sakuseiTime) {
		this.sakuseiTime = sakuseiTime;
	}

	public String getDaichoNm() {
		return daichoNm;
	}

	public void setDaichoNm(String daichoNm) {
		this.daichoNm = daichoNm;
	}

	public String getSakuseiKbnNm() {
		return sakuseiKbnNm;
	}

	public void setSakuseiKbnNm(String sakuseiKbnNm) {
		this.sakuseiKbnNm = sakuseiKbnNm;
	}

	public String getSakuseiUserNm() {
		return sakuseiUserNm;
	}

	public void setSakuseiUserNm(String sakuseiUserNm) {
		this.sakuseiUserNm = sakuseiUserNm;
	}

}