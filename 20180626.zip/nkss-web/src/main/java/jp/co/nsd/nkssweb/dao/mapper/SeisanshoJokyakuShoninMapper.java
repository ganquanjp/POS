/***********************************************************************
*
*業務名: 工事精算システム
*機能名: 除却（承認）(DB処理)
*
*機能概要: 除却情報を処理する。
*
*JavaＶｅｒ：J2SE1.8.0準拠
*
*更新履歴: Ver.1.00 2018/03/06　NSD　新規作成
***********************************************************************/
package jp.co.nsd.nkssweb.dao.mapper;

import java.util.List;

import jp.co.nsd.nkssweb.dao.Kss006;
import jp.co.nsd.nkssweb.dao.SeisanshoJokyakuShonin;
import jp.co.nsd.nkssweb.dao.SeisanshoJokyakuShoninPrint;
import jp.co.nsd.nkssweb.dao.SeisanshoJokyakuShoninShokai;

/**
 * 除却（承認）DB処理
 *
 * @version 1.00
 */
public interface SeisanshoJokyakuShoninMapper {

	/**
	 * 除却（承認）情報取得（検索）
	 *
	 * @param seisanshoJokyakuShonin
	 *            INPUTパラメータ
	 * @return　検索結果
	 */
	List<SeisanshoJokyakuShonin> selectByWhere(SeisanshoJokyakuShonin seisanshoJokyakuShonin);

	/**
	 * 除却（承認）情報取得（照会）
	 *
	 * @param seisanshoJokyakuShoninShokai
	 *            INPUTパラメータ
	 * @return　検索結果
	 */
	List<SeisanshoJokyakuShoninShokai> selectBySeisanShoNo(SeisanshoJokyakuShoninShokai seisanshoJokyakuShoninShokai);

	/**
	 * 除却（承認）情報取得（更新）
	 *
	 * @param kss006
	 *            INPUTパラメータ
	 * @return　検索結果
	 */
	int updateByPrimaryKey(Kss006 kss006);

	/**
	 * 除却情報取得（承認画面）（精算書情報）印刷(除却予定チェックリスト)
	 *
	 * @param jokyakuSeisanShoId
	 *            INPUTパラメータ
	 * @return 結果
	 * @throws Exception
	 */
	SeisanshoJokyakuShoninPrint getJokyakuSeisanInfo(String jokyakuSeisanShoId);

	/**
	 * 除却情報取得（承認画面）（固定資産情報）印刷(除却予定チェックリスト)
	 *
	 * @param jokyakuSeisanShoId
	 *            INPUTパラメータ
	 * @return 結果
	 * @throws Exception
	 */
	List<SeisanshoJokyakuShoninPrint> getKoteiInfo(String jokyakuSeisanShoId);

	/**
	 * 除却情報取得（承認）（固定資産情報）印刷(資産台帳別内訳)
	 *
	 * @param jokyakuSeisanShoId
	 *            INPUTパラメータ
	 * @return 結果
	 * @throws Exception
	 */
	List<SeisanshoJokyakuShoninPrint> getJokyakuDaityoInfo(String jokyakuSeisanShoId);

	/**
	 * 除却情報取得（承認）（固定資産番号）印刷(子固定資産一覧)
	 *
	 * @param jokyakuSeisanShoId
	 *            INPUTパラメータ
	 * @return 結果
	 * @throws Exception
	 */
	List<String> getJokyakuOyakoteiInfo(String jokyakuSeisanShoId);
}