package jp.co.nsd.nkssweb.controller;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import jp.co.nsd.nkssweb.dao.Abda09;
import jp.co.nsd.nkssweb.dao.BunkatsuSyunyu;
import jp.co.nsd.nkssweb.dao.InputCheck;
import jp.co.nsd.nkssweb.dao.Kss004;
import jp.co.nsd.nkssweb.dao.Kss008;
import jp.co.nsd.nkssweb.dao.mapper.Kss008Mapper;
import jp.co.nsd.nkssweb.service.BunkatsuSyunyuService;
import jp.co.nsd.nkssweb.service.CommService;
import jp.co.nsd.nkssweb.service.InputCheckService;
import jp.co.nsd.nkssweb.service.SystemService;
import jp.co.nsd.nkssweb.utils.NSDCommUtils;
import jp.co.nsd.nkssweb.utils.NSDConstant;
import jp.co.nsd.nkssweb.utils.NSDDataCheck;
import jp.co.nsd.nkssweb.utils.NSDDateUtils;

@RestController
public class BunkatsuSyunyuController extends BaseController {

	@Autowired
	private BunkatsuSyunyuService bunkatsuSyunyuService;

	@Autowired
	protected SystemService systemService;

	@Autowired
	protected InputCheckService inputCheckService;

	@Autowired
	private NSDDataCheck nsdDataCheck;

	@Autowired
	private Kss008Mapper kss008Mapper;

	@Autowired
	private CommService commService;

	/*
	 * 分割収入経理審査/連携（検索）画面から
	 *
	 * @param reqMap INPUTパラメータ
	 *
	 * @return 除却情報データ
	 *
	 * @exception IllegalAccessException
	 *
	 * @exception InvocationTargetException
	 *
	 * @version 1.00
	 */
	@RequestMapping(value = "/bunkatsuSyunyu-selectByWhere", method = RequestMethod.POST)
	public Map<String, Object> selectByWhere(@RequestParam Map<String, Object> reqMap) throws Exception {

		Map<String, Object> resultMap = new HashMap<String, Object>();

		// 入力チェック
		String errStr = inputCheckForSearch(reqMap);
		if (StringUtils.isNotEmpty(errStr)) {
			return setMsgToResultMap(resultMap, NSDConstant.MSGID_INPUT_ERROR, errStr);
		}

		BunkatsuSyunyu bunkatsuSyunyu = new BunkatsuSyunyu();
		List<BunkatsuSyunyu> bsLst = new ArrayList<>();
		// Mapの情報をBeanのプロパティにセット
		BeanUtils.populate(bunkatsuSyunyu, reqMap);

		bsLst = bunkatsuSyunyuService.getBunkatsuInfo(bunkatsuSyunyu);

		// 検索結果を返却Mapに設定する
		return setDataToResultMap(resultMap, bsLst);

	}

	/**
	 * 検索の入力データチェック
	 *
	 * @param reqMap
	 *            INPUTパラメータ
	 * @return エラーメッセージID
	 * @version 1.00
	 */
	private String inputCheckForSearch(Map<String, Object> reqMap) {

		List<InputCheck> inputCheckList = getCheckItemListForSearch(reqMap);
		return nsdDataCheck.dataCheck(inputCheckList);

	}

	/**
	 * 検索の入力チェックリストを定義
	 *
	 * @param reqMap
	 *            INPUTパラメータ
	 * @return
	 */
	private List<InputCheck> getCheckItemListForSearch(Map<String, Object> reqMap) {

		List<InputCheck> inputCheckList = new ArrayList<InputCheck>();
		Map<Integer, Object> args;

		// 使用開始年月日
		if (StringUtils.isNotEmpty((String) reqMap.get("siyoStartYmdF"))) {
			args = new HashMap<Integer, Object>();
			args.put(NSDConstant.CHECK_ITEM.DATE_FORMAT_CHECK.ordinal(), null);
			inputCheckList.add(setInputCheck(reqMap, "siyoStartYmdF", "使用開始年月日(From)：", args));
		}

		if (StringUtils.isNotEmpty((String) reqMap.get("siyoStartYmdT"))) {
			args = new HashMap<Integer, Object>();
			args.put(NSDConstant.CHECK_ITEM.DATE_FORMAT_CHECK.ordinal(), null);
			inputCheckList.add(setInputCheck(reqMap, "siyoStartYmdT", "使用開始年月日(To)：", args));
		}

		args = new HashMap<Integer, Object>();
		args.put(NSDConstant.CHECK_ITEM.DATE_COMPARE_CHECK.ordinal(), (String) reqMap.get("siyoStartYmdT"));
		inputCheckList.add(setInputCheck(reqMap, "siyoStartYmdF", "使用開始年月日：", args));

		// サービス開始年月日
		if (StringUtils.isNotEmpty((String) reqMap.get("serviceStartYmdF"))) {
			args = new HashMap<Integer, Object>();
			args.put(NSDConstant.CHECK_ITEM.DATE_FORMAT_CHECK.ordinal(), null);
			inputCheckList.add(setInputCheck(reqMap, "serviceStartYmdF", "サービス開始年月日(From)：", args));
		}

		if (StringUtils.isNotEmpty((String) reqMap.get("serviceStartYmdT"))) {
			args = new HashMap<Integer, Object>();
			args.put(NSDConstant.CHECK_ITEM.DATE_FORMAT_CHECK.ordinal(), null);
			inputCheckList.add(setInputCheck(reqMap, "serviceStartYmdT", "サービス開始年月日(To)：", args));
		}

		args = new HashMap<Integer, Object>();
		args.put(NSDConstant.CHECK_ITEM.DATE_COMPARE_CHECK.ordinal(), (String) reqMap.get("serviceStartYmdT"));
		inputCheckList.add(setInputCheck(reqMap, "serviceStartYmdF", "サービス開始年月日：", args));

		return inputCheckList;
	}

	/**
	 * 分割収入経理審査/連携（更新）画面初期化
	 *
	 * @param reqMap
	 *            INPUTパラメータ
	 * @return
	 */
	@RequestMapping(value = "/bunkatsuSyunyu-initUpdInfo", method = RequestMethod.POST)
	public Map<String, Object> initUpdInfo(@RequestParam Map<String, Object> reqMap) throws Exception {

		Map<String, Object> resultMap = new HashMap<String, Object>();

		// 分割収入経理審査/連携数取得
		Set<String> set = countSeisanshoRecord(reqMap);

		List<String> seisanShoIdLst = new ArrayList<String>();
		for (int i = 0; i < set.size(); i++) {
			String key = "seisanShoIdLst".concat("[" + i + "]").concat("[seisanShoId]");
			seisanShoIdLst.add(String.valueOf(reqMap.get(key)));
		}

		List<Map<String, Object>> lstMap = bunkatsuSyunyuService.initUpdInfo(seisanShoIdLst);

		// 検索結果を返却Mapに設定する
		return setDataToResultMap(resultMap, lstMap);
	}

	/**
	 * 分割収入経理審査/連携（更新）画面から
	 *
	 * @param reqMap
	 *            INPUTパラメータ
	 * @return
	 */
	@RequestMapping(value = "/bunkatsuSyunyu-update", method = RequestMethod.POST)
	public Map<String, Object> update(HttpServletRequest request, @RequestParam Map<String, Object> reqMap)
			throws Exception {

		Map<String, Object> resultMap = new HashMap<String, Object>();

		// 入力チェック
		String errStr = inputCheckForUpdate(reqMap);
		if (StringUtils.isNotEmpty(errStr)) {
			return setMsgToResultMap(resultMap, NSDConstant.MSGID_INPUT_ERROR, errStr);
		}

		// 分割収入経理審査/連携数取得
		Set<String> setSeisan = countSeisanshoRecord(reqMap);

		String key = null;
		List<String> seisanShoLst = new ArrayList<String>();
		for (int i = 0; i < setSeisan.size(); i++) {
			// 更新チェックを選択判断
			key = "seisanShoList".concat("[" + i + "]").concat("[upd]");
			// 更新チェック選択された
			if (Boolean.valueOf((String) reqMap.get(key))) {
				seisanShoLst.add(String.valueOf(i));
			}
		}

		// 更新チェックの判断
		if (seisanShoLst.size() == 0) {
			errStr = NSDCommUtils.setKakoToStr(
					"精算書情報：".concat(systemService.getMessage(NSDConstant.MSGID_CHECK_INVALID_SELECTED).getContent()));
			return setMsgToResultMap(resultMap, NSDConstant.MSGID_INPUT_ERROR, errStr);
		}

		SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd");
		List<Kss008> insertKss008Lst = new ArrayList<Kss008>();
		List<Kss008> updateKss008Lst = new ArrayList<Kss008>();
		List<Kss008> Kss008Lst = new ArrayList<Kss008>();
		List<Kss004> Kss004Lst = new ArrayList<Kss004>();
		Kss008 kss008 = new Kss008();
		Kss004 kss004 = new Kss004();
		Date date = new Date();
		String loginUserId = getLoginUserInfo(request).getUserId();
		// 更新情報を設定
		for (String seisanRecord : seisanShoLst) {
			kss008 = new Kss008();
			kss004 = new Kss004();

			// 精算書ID
			key = "seisanShoList".concat("[" + seisanRecord + "]").concat("[seisanShoId]");
			kss008.setSeisanShoId(String.valueOf(reqMap.get(key)));
			kss004.setSeisanShoId(String.valueOf(reqMap.get(key)));

			// サービス開始年月日
			key = "seisanShoList".concat("[" + seisanRecord + "]").concat("[serviceStartYmd]");
			if (null != reqMap.get(key)) {
				kss008.setServiceStartYmd(sdf.parse(String.valueOf(reqMap.get(key)).replaceAll("-", "/")));
			}

			// 契約開始年月日
			key = "seisanShoList".concat("[" + seisanRecord + "]").concat("[keiyakuStartYmd]");
			if (null != reqMap.get(key)) {
				kss008.setKeiyakuStartYmd(sdf.parse(String.valueOf(reqMap.get(key)).replaceAll("-", "/")));
			}

			// 契約終了年月日
			key = "seisanShoList".concat("[" + seisanRecord + "]").concat("[keiyakuEndYmd]");
			if (null != reqMap.get(key)) {
				kss008.setKeiyakuEndYmd(sdf.parse(String.valueOf(reqMap.get(key)).replaceAll("-", "/")));
			}

			// 承認ステータス
			key = "seisanShoList".concat("[" + seisanRecord + "]").concat("[shoninStatus]");
			kss004.setShoninStatus(String.valueOf(reqMap.get(key)));

			// 理由
			key = "seisanShoList".concat("[" + seisanRecord + "]").concat("[riyu]");
			kss004.setRiyu(String.valueOf(reqMap.get(key)));

			// 更新年月日
			kss008.setUpdateDate(date);
			// 更新ユーザーＩＤ
			kss008.setUpdateUserId(loginUserId);

			// 更新年月日
			kss004.setUpdateDate(date);
			// 更新ユーザーＩＤ
			kss004.setUpdateUserId(loginUserId);

			// 精算書情報
			Kss008Lst.add(kss008);
			Kss004Lst.add(kss004);

			Set<String> setKotei = countKoteiRecord(reqMap, seisanRecord);
			for (String koteiRecord : setKotei) {
				// 固定資産ID
				key = "seisanShoList".concat("[" + seisanRecord + "]").concat("[bsKtInfoLst]")
						.concat("[" + koteiRecord + "]").concat("[koteiShisanId]");
				kss008.setKoteiShisanId(String.valueOf(reqMap.get(key)));

				Kss008 kss008Info = (Kss008) BeanUtils.cloneBean(kss008);

				// 排他チェック
				Kss008 kss008Chk = kss008Mapper.selectByPrimaryKey(kss008Info);

				if (null != kss008Chk) {
					// 排他チェック
					key = "seisanShoList".concat("[" + seisanRecord + "]").concat("[updateDate]");
					String updateDate = String.valueOf(reqMap.get(key));
					String errId = commService.doHaita(kss008Info, updateDate);
					if (!NSDConstant.BLANK_STRING.equals(errId)){
						return setMsgToResultMap(resultMap, errId);
					}

					// 更新年月日
					kss008Info.setUpdateDate(date);
					// 更新ユーザーＩＤ
					kss008Info.setUpdateUserId(loginUserId);
					// 更新
					updateKss008Lst.add(kss008Info);
				} else {
					// 登録年月日
					kss008Info.setEntryDate(date);
					// 登録ユーザーＩＤ
					kss008Info.setEntryUserId(loginUserId);
					// 更新年月日
					kss008Info.setUpdateDate(date);
					// 更新ユーザーＩＤ
					kss008Info.setUpdateUserId(loginUserId);
					// 新規
					insertKss008Lst.add(kss008Info);
				}
			}
		}

		Map<String, Object> renkeiInfoMap = new HashMap<String, Object>();
		// 会計整理年月
		renkeiInfoMap.put("kaikeiSeiriYm", reqMap.get("kaikeiSeiriYm"));
		// パワー経理の発行組織
		renkeiInfoMap.put("hakouSoshikiCd", getHakouSoshikiCdBySoshikiNm(reqMap));

		//分割収入の更新
		bunkatsuSyunyuService.update(insertKss008Lst, updateKss008Lst, Kss008Lst, Kss004Lst, renkeiInfoMap);

		// 処理結果データ
		resultMap.put(NSDConstant.RESULT_DATA_NAME, "");

		return setMsgToResultMapNoLog(resultMap, NSDConstant.MSGID_UPDATE_SUCCES);

	}

	/**
	 * 分割収入経理審査/連携（更新）精算書の件数取得
	 *
	 * @param reqMap
	 * @return
	 */
	private Set<String> countSeisanshoRecord(Map<String, Object> reqMap) {
		Set<String> set = new HashSet<String>();

		for (Entry<String, Object> entry : reqMap.entrySet()) {
			String[] record = entry.getKey().replace("[", ",").replace("]", "").split(",");
			if (record.length == 3) {
				set.add(record[1]);
			}
		}

		return set;
	}

	/**
	 * 分割収入経理審査/連携（更新）精算書IDより固定情報の件数取得
	 *
	 * @param reqMap
	 * @return
	 */
	private Set<String> countKoteiRecord(Map<String, Object> reqMap, String seisanshoRecord) {

		Set<String> set = new HashSet<String>();

		Map<String, Object> itemMap = new HashMap<String, Object>();

		for (Entry<String, Object> entry : reqMap.entrySet()) {
			String[] record = entry.getKey().replace("[", ",").replace("]", "").split(",");

			// 固定情報
			if (record.length == 5 && record[1].equals(seisanshoRecord)) {
				itemMap.put(entry.getKey(), entry.getValue());
			}
		}

		for (Entry<String, Object> entry : itemMap.entrySet()) {
			String[] record = entry.getKey().replace("[", ",").replace("]", "").split(",");

			if (record.length == 5) {
				set.add(record[3]);
			}
		}
		return set;
	}

	/**
	 * 更新の入力データチェック
	 *
	 * @param reqMap
	 *            INPUTパラメータ
	 * @return エラーメッセージID
	 * @version 1.00
	 */
	private String inputCheckForUpdate(Map<String, Object> reqMap) {

		List<InputCheck> inputCheckList = getCheckItemListForUpdate(reqMap);
		return nsdDataCheck.dataCheck(inputCheckList);

	}

	/**
	 * 更新の入力チェックリストを定義
	 *
	 * @param reqMap
	 *            INPUTパラメータ
	 * @return
	 */
	private List<InputCheck> getCheckItemListForUpdate(Map<String, Object> reqMap) {

		List<InputCheck> inputCheckList = new ArrayList<InputCheck>();
		Map<Integer, Object> args;

		// 画面取得資産明細件数取得
		Set<String> set = countSeisanshoRecord(reqMap);

		// 画面明細部
		String id, name;
		boolean updChk;
		boolean dataRenKeiFlag = false;

		for (int i = 0; i < set.size(); i++) {

			// 画面チェックしてないレコードは、入力チェックを行わない。
			updChk = false;
			String keyUpd = "seisanShoList".concat("[" + i + "]").concat("[upd]");
			if (null != reqMap.get(keyUpd)) {
				updChk = Boolean.valueOf((String) reqMap.get(keyUpd));
			}
			if (!updChk) {
				continue;
			}

			args = new HashMap<Integer, Object>();
			args.put(NSDConstant.CHECK_ITEM.EMPTY_CHECK.ordinal(), null);
			args.put(NSDConstant.CHECK_ITEM.DATE_FORMAT_CHECK.ordinal(), null);
			id = "seisanShoList".concat("[" + i + "]").concat("[serviceStartYmd]");
			name = "サービス開始年月日(行番号：".concat(String.valueOf(i + 1).concat(")："));
			inputCheckList.add(setInputCheck(reqMap, id, name, args));

			args = new HashMap<Integer, Object>();
			args.put(NSDConstant.CHECK_ITEM.EMPTY_CHECK.ordinal(), null);
			args.put(NSDConstant.CHECK_ITEM.DATE_FORMAT_CHECK.ordinal(), null);
			id = "seisanShoList".concat("[" + i + "]").concat("[keiyakuStartYmd]");
			name = "契約期間(自)(行番号：".concat(String.valueOf(i + 1).concat(")："));
			inputCheckList.add(setInputCheck(reqMap, id, name, args));

			args = new HashMap<Integer, Object>();
			args.put(NSDConstant.CHECK_ITEM.EMPTY_CHECK.ordinal(), null);
			args.put(NSDConstant.CHECK_ITEM.DATE_FORMAT_CHECK.ordinal(), null);
			id = "seisanShoList".concat("[" + i + "]").concat("[keiyakuEndYmd]");
			name = "契約期間(至)(行番号：".concat(String.valueOf(i + 1).concat(")："));
			inputCheckList.add(setInputCheck(reqMap, id, name, args));


			args = new HashMap<Integer, Object>();
			args.put(NSDConstant.CHECK_ITEM.EMPTY_CHECK.ordinal(), null);
			id = "seisanShoList".concat("[" + i + "]").concat("[shoninStatus]");
			name = "承認状態(行番号：".concat(String.valueOf(i + 1).concat(")："));
			inputCheckList.add(setInputCheck(reqMap, id, name, args));

			// 承認状態＝「データ連携済」の場合
			if (NSDConstant.SHONIN_STATUS_CODE_RENKEI.equals((String) reqMap.get(id))) {
				dataRenKeiFlag = true;
			}
		}

		// 承認状態＝「データ連携済」の場合、パワー経理の発行組織は必須入力チェックを行う
		if (dataRenKeiFlag) {
			args = new HashMap<Integer, Object>();
			args.put(NSDConstant.CHECK_ITEM.EMPTY_CHECK.ordinal(), null);
			args.put(NSDConstant.CHECK_ITEM.IS_EXIST_ABDA09.ordinal(), setSelectAbda09ByWhere(reqMap));
			inputCheckList.add(setInputCheck(reqMap, "hakouSoshikiNm", "パワー経理の発行組織：", args));
		}

		return inputCheckList;
	}

	/**
	 * 組織定数検索条件を作成する
	 *
	 * @param reqMap
	 * @return
	 */
	private Abda09 setSelectAbda09ByWhere(Map<String, Object> reqMap) {

		Abda09 abda09 = new Abda09();

		// 画面入力した組織名
		abda09.setAb9SoshikKnj((String) reqMap.get("hakouSoshikiNm"));
		// システム日付
		abda09.setAb9TekiyfYmd(NSDDateUtils.parseStrToCal(NSDDateUtils.Now()).getTime());

		return abda09;
	}

	/**
	 * 画面組織名より組織コードを取得する
	 *
	 * @param reqMap
	 * @return
	 */
	private String getHakouSoshikiCdBySoshikiNm(Map<String, Object> reqMap) {

		String soshikiCd = NSDConstant.BLANK_STRING;
		Abda09 abda09 = inputCheckService.getAbda09ForInputCheck(setSelectAbda09ByWhere(reqMap));

		if (abda09 != null) {
			soshikiCd = abda09.getAb9SoshikCod();
		}

		return soshikiCd;
	}
}
