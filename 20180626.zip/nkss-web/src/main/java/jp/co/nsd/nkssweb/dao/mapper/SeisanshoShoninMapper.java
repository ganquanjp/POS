package jp.co.nsd.nkssweb.dao.mapper;

import java.util.List;

import jp.co.nsd.nkssweb.dao.Kss004;
import jp.co.nsd.nkssweb.dao.SeisanshoShonin;
import jp.co.nsd.nkssweb.dao.SeisanshoShoninPrint;
import jp.co.nsd.nkssweb.dao.SeisanshoShoninShokai;

public interface SeisanshoShoninMapper {
	/**
	 * 取得情報取得（検索画面）
	 *
	 * @param seisanshoShonin
	 *            INPUTパラメータ
	 * @return　検索結果
	 */
    List<SeisanshoShonin> selectByWhere(SeisanshoShonin record);

	/**
	 * 取得情報取得（照会画面）
	 *
	 * @param seisanshoJokyakuShokai
	 *            INPUTパラメータ
	 * @return　検索結果
	 */
	List<SeisanshoShoninShokai> selectBySeisanShoNo(SeisanshoShoninShokai seisanshoShoninShokai);

	/**
	 * 取得情報取得（更新画面）
	 *
	 * @param kss004
	 *            INPUTパラメータ
	 * @return　検索結果
	 */
	int updateByPrimaryKey(Kss004 kss004);

	/**
	 * 固定資産がリースであるかのフラグ取得用
	 *
	 * @param kss004
	 *            INPUTパラメータ
	 * @return 結果
	 * @throws Exception
	 */
	SeisanshoShoninShokai getChkKouCnt(Kss004 kss004);

	/**
	 * 固定資産がリースであるかのフラグ取得用
	 *
	 * @param kss004
	 *            INPUTパラメータ
	 * @return 結果
	 * @throws Exception
	 */
	List<SeisanshoShoninShokai> getChkLiaseFlg(Kss004 kss004);

	/**
	 * 固定資産の取引先・耐用年数が混在しているかの情報を取得
	 *
	 * @param kss004
	 *            INPUTパラメータ
	 * @return 結果
	 * @throws Exception
	 */
	List<SeisanshoShoninShokai> getChkToriTaiCnt(Kss004 kss004);

	/**
	 * 取得承認（精算書情報）印刷
	 *
	 * @param seisanShoId
	 *            INPUTパラメータ
	 * @return 結果
	 * @throws Exception
	 */
	SeisanshoShoninPrint getSeisanShoInfo(String seisanShoId);

	/**
	 * 取得承認（固定資産情報）印刷
	 *
	 * @param seisanShoId
	 *            INPUTパラメータ
	 * @return 結果
	 * @throws Exception
	 */
	List<SeisanshoShoninPrint> getKoteiInfo(String seisanShoId);


	/**
	 * 取得承認（資産台帳別内訳）印刷
	 *
	 * @param seisanShoId
	 *            INPUTパラメータ
	 * @return 結果
	 * @throws Exception
	 */
	List<SeisanshoShoninPrint> getSeisanDaityoInfo(String seisanShoId);

}