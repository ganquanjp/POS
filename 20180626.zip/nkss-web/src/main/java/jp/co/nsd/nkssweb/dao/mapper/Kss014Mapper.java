package jp.co.nsd.nkssweb.dao.mapper;

import jp.co.nsd.nkssweb.dao.Kss014;
import jp.co.nsd.nkssweb.dao.Kss014Key;

public interface Kss014Mapper {
    int deleteByPrimaryKey(Kss014Key key);

    int insert(Kss014 record);

    int insertSelective(Kss014 record);

    Kss014 selectByPrimaryKey(Kss014Key key);

    int updateByPrimaryKeySelective(Kss014 record);

    int updateByPrimaryKey(Kss014 record);
}