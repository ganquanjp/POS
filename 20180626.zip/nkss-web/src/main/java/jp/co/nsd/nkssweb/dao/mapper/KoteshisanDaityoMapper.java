package jp.co.nsd.nkssweb.dao.mapper;

import java.util.List;

import jp.co.nsd.nkssweb.dao.KoteshisanDaityo;
import jp.co.nsd.nkssweb.dao.KoteshisanDaityoFileInfo;

public interface KoteshisanDaityoMapper {

	List<KoteshisanDaityo> selectByWhere();

	String selectFileName();

	List<KoteshisanDaityoFileInfo> getKoteishisanDaityoFileInfo();

   String selectSakuseiTimestamp();
}