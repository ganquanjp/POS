/***********************************************************************
*
*業務名: 工事精算システム
*機能名: 除却（精算通告）(サービス処理)
*
*機能概要: 除却情報を処理する。
*
*JavaＶｅｒ：J2SE1.8.0準拠
*
*更新履歴: Ver.1.00 2018/03/06　NSD　新規作成
***********************************************************************/
package jp.co.nsd.nkssweb.service.seisanshojokyaku;

import java.util.List;

import jp.co.nsd.nkssweb.dao.Kss006;
import jp.co.nsd.nkssweb.dao.SeisanshoJokyakuSeisan;
import jp.co.nsd.nkssweb.dao.SeisanshoJokyakuSeisanShokai;

/**
 * 除却（精算通告）処理
 *
 * @version 1.00
 */
public interface SeisanshoJokyakuSeisanService {

	/**
	 * 除却（精算通告）検索
	 *
	 * @param seisanshoJokyakuSeisan
	 *            INPUTパラメータ
	 * @return 検索結果
	 */
	List<SeisanshoJokyakuSeisan> getJokyakuSeisanInfo(SeisanshoJokyakuSeisan seisanshoJokyakuSeisan);

	/**
	 * 除却（精算通告）照会
	 *
	 * @param seisanshoJokyakuSeisanShokai
	 *            INPUTパラメータ
	 * @return 検索結果
	 * @throws Exception
	 */
	SeisanshoJokyakuSeisanShokai getJokyakuInfoBySeisanShoNo(SeisanshoJokyakuSeisanShokai seisanshoJokyakuSeisanShokai)
			throws Exception;

	/**
	 * 除却（精算通告）更新
	 *
	 * @param kss006
	 *            INPUTパラメータ
	 * @return 更新件数
	 * @throws Exception
	 */
	int updateInfo(Kss006 kss006) throws Exception;
}
