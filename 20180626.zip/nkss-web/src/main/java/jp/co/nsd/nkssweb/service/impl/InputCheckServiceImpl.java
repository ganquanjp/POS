/***********************************************************************
*
*業務名: 参照ボタン処理
*機能名: 参照ボタン処理(サービス処理)
*
*機能概要: 参照ボタンを処理する。
*
*JavaＶｅｒ：J2SE1.8.0準拠
*
*更新履歴: Ver.1.00 2018/03/06　NSD　新規作成
***********************************************************************/
package jp.co.nsd.nkssweb.service.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import jp.co.nsd.nkssweb.dao.Abda09;
import jp.co.nsd.nkssweb.dao.Kss011;
import jp.co.nsd.nkssweb.dao.Kss013;
import jp.co.nsd.nkssweb.dao.mapper.InputCheckMapper;
import jp.co.nsd.nkssweb.service.InputCheckService;

/**
 * 入力チェック処理用サービス
 *
 * @author nsdH272059
 *
 */
@Service
public class InputCheckServiceImpl implements InputCheckService {

	@Autowired
	private InputCheckMapper inputCheckMapper;

	@Override
	public Kss011 getSoshikiInfoForInputCheck(String soshikiRenNm) {

		List<Kss011> kss011List = new ArrayList<Kss011>();

		kss011List = inputCheckMapper.getSoshikiInfoForInputCheck(soshikiRenNm);

		// 取得件数は１件以外の場合、入力チェックエラーとなる。
		if (kss011List.size() == 1) {
			return kss011List.get(0);
		}

		return null;
	}

	@Override
	public Kss013 getUserInfoForInputCheck(String seimei) {
		List<Kss013> kss013List = new ArrayList<Kss013>();

		kss013List = inputCheckMapper.getUserInfoForInputCheck(seimei);

		// 取得件数は１件以外の場合、入力チェックエラーとなる。
		if (kss013List.size() == 1) {
			return kss013List.get(0);
		}

		return null;
	}

	@Override
	public boolean isExistUserSoshikiForInputCheck(Map<String, String> sqlWhere) {

		String kensu = inputCheckMapper.isExistUserSoshikiForInputCheck(sqlWhere);

		// 取得件数は１件以外の場合、入力チェックエラーとなる。
		if (Integer.parseInt(kensu) == 1) {
			return true;
		}
		return false;
	}

	@Override
	public boolean isExistKoteiSisanInfoForInputCheck(Map<String, String> sqlWhere) {
		String kensu = inputCheckMapper.isExistKoteiSisanInfoForInputCheck(sqlWhere);

		if (Integer.parseInt(kensu) > 0) {
			return true;
		}
		return false;
	}

	@Override
	public Abda09 getAbda09ForInputCheck(Abda09 abda09) {

		List<Abda09> abda09List = new ArrayList<Abda09>();
		abda09List = inputCheckMapper.getAbda09ForInputCheck(abda09);

		// 取得件数は１件以外の場合、入力チェックエラーとなる。
		if (abda09List.size() == 1) {
			return abda09List.get(0);
		}
		return null;
	}
}
