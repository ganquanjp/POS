package jp.co.nsd.nkssweb.dao;

public class SeisanshoJokyakuKeiriUpdate {

	// 整理会計年月
	private int kaikeiYm;

	// パワー経理の発行組織
	private int siyoKnj;

	// 発行組織コード
	private int siyoCd;

	// 発行組織適用開始日
	private int siyoTekiyfYmd;

	// 発行組織適用終了日
	private int siyoTekiytYmd;

	// 会計整理年月日リスト
	private int kaikeiLst;

	// 発行組織リスト
	private int siyoLst;

	//除却データリストjokyakuDataLst
	private int jokyakuDataLst;

	public int getKaikeiYm() {
		return kaikeiYm;
	}

	public void setKaikeiYm(int kaikeiYm) {
		this.kaikeiYm = kaikeiYm;
	}

	public int getSiyoKnj() {
		return siyoKnj;
	}

	public void setSiyoKnj(int siyoKnj) {
		this.siyoKnj = siyoKnj;
	}

	public int getSiyoCd() {
		return siyoCd;
	}

	public void setSiyoCd(int siyoCd) {
		this.siyoCd = siyoCd;
	}

	public int getSiyoTekiyfYmd() {
		return siyoTekiyfYmd;
	}

	public void setSiyoTekiyfYmd(int siyoTekiyfYmd) {
		this.siyoTekiyfYmd = siyoTekiyfYmd;
	}

	public int getSiyoTekiytYmd() {
		return siyoTekiytYmd;
	}

	public void setSiyoTekiytYmd(int siyoTekiytYmd) {
		this.siyoTekiytYmd = siyoTekiytYmd;
	}

	public int getKaikeiLst() {
		return kaikeiLst;
	}

	public void setKaikeiLst(int kaikeiLst) {
		this.kaikeiLst = kaikeiLst;
	}

	public int getSiyoLst() {
		return siyoLst;
	}

	public void setSiyoLst(int siyoLst) {
		this.siyoLst = siyoLst;
	}

	public int getJokyakuDataLst() {
		return jokyakuDataLst;
	}

	public void setJokyakuDataLst(int jokyakuDataLst) {
		this.jokyakuDataLst = jokyakuDataLst;
	}

}