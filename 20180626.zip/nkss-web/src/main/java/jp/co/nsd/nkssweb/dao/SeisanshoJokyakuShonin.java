package jp.co.nsd.nkssweb.dao;

public class SeisanshoJokyakuShonin {

	// 行番号
	private int rowNo;

	// 除却精算書ＩＤ
	private String jokyakuSeisanShoId;

	// 除却資産ＩＤ
	private String jokyakuShisanId;

	// 除却精算書番号
	private String jokyakuSeisanShoNo;

	// 件名
	private String kenmeiNm;

	// 除却年月日(FROM)
	private String jokyakuYmdFrom;

	// 除却年月日(TO)
	private String jokyakuYmdTo;

	// 除却年月日
	private String jokyakuYmd;

	// 組織連結略名
	private String soshikiRenNm;

	// 除却取得価額合計
	private String jokyakuKagakuGokei;

	// 承認状態
	private String shoninJotai;

	// 承認ステータス
	private String shoninStatus;

	public int getRowNo() {
		return rowNo;
	}

	public void setRowNo(int rowNo) {
		this.rowNo = rowNo;
	}

	public String getJokyakuSeisanShoId() {
		return jokyakuSeisanShoId;
	}

	public void setJokyakuSeisanShoId(String jokyakuSeisanShoId) {
		this.jokyakuSeisanShoId = jokyakuSeisanShoId;
	}

	public String getJokyakuShisanId() {
		return jokyakuShisanId;
	}

	public void setJokyakuShisanId(String jokyakuShisanId) {
		this.jokyakuShisanId = jokyakuShisanId;
	}

	public String getJokyakuSeisanShoNo() {
		return jokyakuSeisanShoNo;
	}

	public void setJokyakuSeisanShoNo(String jokyakuSeisanShoNo) {
		this.jokyakuSeisanShoNo = jokyakuSeisanShoNo;
	}

	public String getKenmeiNm() {
		return kenmeiNm;
	}

	public void setKenmeiNm(String kenmeiNm) {
		this.kenmeiNm = kenmeiNm;
	}

	public String getJokyakuYmdFrom() {
		return jokyakuYmdFrom;
	}

	public void setJokyakuYmdFrom(String jokyakuYmdFrom) {
		this.jokyakuYmdFrom = jokyakuYmdFrom;
	}

	public String getJokyakuYmdTo() {
		return jokyakuYmdTo;
	}

	public void setJokyakuYmdTo(String jokyakuYmdTo) {
		this.jokyakuYmdTo = jokyakuYmdTo;
	}

	public String getJokyakuYmd() {
		return jokyakuYmd;
	}

	public void setJokyakuYmd(String jokyakuYmd) {
		this.jokyakuYmd = jokyakuYmd;
	}

	public String getSoshikiRenNm() {
		return soshikiRenNm;
	}

	public void setSoshikiRenNm(String soshikiRenNm) {
		this.soshikiRenNm = soshikiRenNm;
	}

	public String getJokyakuKagakuGokei() {
		return jokyakuKagakuGokei;
	}

	public void setJokyakuKagakuGokei(String jokyakuKagakuGokei) {
		this.jokyakuKagakuGokei = jokyakuKagakuGokei;
	}

	public String getShoninJotai() {
		return shoninJotai;
	}

	public void setShoninJotai(String shoninJotai) {
		this.shoninJotai = shoninJotai;
	}

	public String getShoninStatus() {
		return shoninStatus;
	}

	public void setShoninStatus(String shoninStatus) {
		this.shoninStatus = shoninStatus;
	}



}