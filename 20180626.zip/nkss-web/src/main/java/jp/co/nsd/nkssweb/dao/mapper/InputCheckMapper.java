package jp.co.nsd.nkssweb.dao.mapper;

import java.util.List;
import java.util.Map;

import jp.co.nsd.nkssweb.dao.Abda09;
import jp.co.nsd.nkssweb.dao.Kss011;
import jp.co.nsd.nkssweb.dao.Kss013;

public interface InputCheckMapper {

	/**
	 * 組織連結名で組織マスタを検索、データ存在の確認
	 *
	 * @param soshikiRenNm 組織連結名
	 * @return
	 */
	List<Kss011> getSoshikiInfoForInputCheck(String soshikiRenNm);

	/**
	 * ユーザー名でユーザー情報を検索、データ存在の確認
	 *
	 * @param seimei 姓+名
	 * @return
	 */
	List<Kss013> getUserInfoForInputCheck(String seimei);

	/**
	 * ユーザー名、組織コードで、DBを検索、ユーザーは該当組織に属してるを確認
	 * 取得件数は１件以外の場合、入力チェックエラーとなる。
	 *
	 * @param sqlWhere ユーザー名、組織コード
	 * @return
	 */
	String isExistUserSoshikiForInputCheck(Map<String, String> sqlWhere);

	/**
	 * 固定資産番号で固定資産、固定資産明細、税制改正を検索、データ存在の確認
	 *
	 * @param sqlWhere 固定資産番号、新規・更新・削除フラグ
	 * @return
	 */
	String isExistKoteiSisanInfoForInputCheck(Map<String, String> sqlWhere);

	/**
	 * 組織名で組織定数を検索、データ存在の確認
	 *
	 * @param soshikiNm 組織名
	 * @return
	 */
	List<Abda09> getAbda09ForInputCheck(Abda09 abda09);

}