/***********************************************************************
*
*業務名: 工事精算システム
*機能名: 除却（経理審査/連携）(ログ出力処理)
*
*機能概要: 除却情報を処理する。
*
*JavaＶｅｒ：J2SE1.8.0準拠
*
*更新履歴: Ver.1.00 2018/03/06　NSD　新規作成
***********************************************************************/

package jp.co.nsd.nkssweb.controller.seisanshojokyaku;

import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import jp.co.nsd.nkssweb.controller.BaseController;
import jp.co.nsd.nkssweb.dao.Abda09;
import jp.co.nsd.nkssweb.dao.InputCheck;
import jp.co.nsd.nkssweb.dao.Kss006;
import jp.co.nsd.nkssweb.dao.SeisanshoJokyakuKeiri;
import jp.co.nsd.nkssweb.service.CommService;
import jp.co.nsd.nkssweb.service.InputCheckService;
import jp.co.nsd.nkssweb.service.SystemService;
import jp.co.nsd.nkssweb.service.seisanshojokyaku.SeisanshoJokyakuKeiriService;
import jp.co.nsd.nkssweb.utils.NSDCommUtils;
import jp.co.nsd.nkssweb.utils.NSDConstant;
import jp.co.nsd.nkssweb.utils.NSDDataCheck;
import jp.co.nsd.nkssweb.utils.NSDDateUtils;

/**
 * 除却（経理審査/連携）処理
 *
 * @version 1.00
 */
@RestController
public class SeisanshoJokyakuKeiriController extends BaseController {

	@Autowired
	private SeisanshoJokyakuKeiriService seisanshoJokyakuKeiriService;

	@Autowired
	protected SystemService systemService;

	@Autowired
	protected InputCheckService inputCheckService;

	@Autowired
	private NSDDataCheck nsdDataCheck;

	@Autowired
	private CommService commService;

	/**
	 * 除却（経理審査/連携）処理
	 *
	 * @param reqMap
	 *            INPUTパラメータ
	 * @return 除却情報データ
	 * @exception Exception
	 * @version 1.00
	 */
	@RequestMapping(value = "/seisanshoJokyakuKeiri-selectByWhere", method = RequestMethod.POST)
	public Map<String, Object> selectByWhere(@RequestParam Map<String, Object> reqMap) throws Exception {

		Map<String, Object> resultMap = new HashMap<String, Object>();

		// 入力チェック
		String errStr = inputCheckForSearch(reqMap);
		if (StringUtils.isNotEmpty(errStr)) {
			return setMsgToResultMap(resultMap, NSDConstant.MSGID_INPUT_ERROR, errStr);
		}

		SeisanshoJokyakuKeiri seisanshoJokyakuKeiri = new SeisanshoJokyakuKeiri();

		List<SeisanshoJokyakuKeiri> sssJkkKrLst = new ArrayList<>();

		// Mapの情報をBeanのプロパティにセット
		BeanUtils.populate(seisanshoJokyakuKeiri, reqMap);

		// サービス呼び出し
		sssJkkKrLst = seisanshoJokyakuKeiriService.getJokyakuKeiriInfo(seisanshoJokyakuKeiri);

		// 検索結果を返却Mapに設定する
		return setDataToResultMap(resultMap, sssJkkKrLst);
	}

	/**
	 * 検索の入力データチェック
	 *
	 * @param reqMap
	 *            INPUTパラメータ
	 * @return エラーメッセージID
	 * @version 1.00
	 */
	private String inputCheckForSearch(Map<String, Object> reqMap) {

		List<InputCheck> inputCheckList = getCheckItemListForSearch(reqMap);
		return nsdDataCheck.dataCheck(inputCheckList);

	}

	/**
	 * 検索の入力チェックリストを定義
	 *
	 * @param reqMap
	 *            INPUTパラメータ
	 * @return
	 */
	private List<InputCheck> getCheckItemListForSearch(Map<String, Object> reqMap) {

		List<InputCheck> inputCheckList = new ArrayList<InputCheck>();
		Map<Integer, Object> args;

		// 除却年月日
		if (StringUtils.isNotEmpty((String) reqMap.get("jokyakuYmdFrom"))) {
			args = new HashMap<Integer, Object>();
			args.put(NSDConstant.CHECK_ITEM.DATE_FORMAT_CHECK.ordinal(), null);
			inputCheckList.add(setInputCheck(reqMap, "jokyakuYmdFrom", "除却年月日(From)：", args));
		}

		if (StringUtils.isNotEmpty((String) reqMap.get("jokyakuYmdTo"))) {
			args = new HashMap<Integer, Object>();
			args.put(NSDConstant.CHECK_ITEM.DATE_FORMAT_CHECK.ordinal(), null);
			inputCheckList.add(setInputCheck(reqMap, "jokyakuYmdTo", "除却年月日(To)：", args));
		}

		args = new HashMap<Integer, Object>();
		args.put(NSDConstant.CHECK_ITEM.DATE_COMPARE_CHECK.ordinal(), (String) reqMap.get("jokyakuYmdTo"));
		inputCheckList.add(setInputCheck(reqMap, "jokyakuYmdFrom", "除却年月日：", args));

		return inputCheckList;
	}

	/**
	 * 除却（経理審査/連携）更新処理
	 *
	 * @param reqMap
	 *            INPUTパラメータ
	 * @return 除却情報データ
	 * @exception IllegalAccessException
	 * @exception InvocationTargetException
	 * @version 1.00
	 * @throws Exception
	 */
	@RequestMapping(value = "/seisanshoJokyakuKeiri-updateInfo", method = RequestMethod.POST)
	public Map<String, Object> updateInfo(HttpServletRequest request, @RequestParam Map<String, Object> reqMap)
			throws Exception {

		Map<String, Object> resultMap = new HashMap<String, Object>();

		// 入力チェック
		String errStr = inputCheckForUpdate(reqMap);
		if (StringUtils.isNotEmpty(errStr)) {
			return setMsgToResultMap(resultMap, NSDConstant.MSGID_INPUT_ERROR, errStr);
		}

		// 除却資産件数
		Set<String> set = countViewRecord(reqMap);

		// 入力チェック
		// 発行組織コード
		String hakouSoshikiCd = getHakouSoshikiCdBySoshikiNm(reqMap);
		// 会計整理年月
		String kaikeiSeiriYm = (String) reqMap.get("kaikeiSeiriYm");

		Date date = new Date();
		// 更新チェック
		boolean updChk;
		List<Kss006> kss006UpdLst = new ArrayList<Kss006>();
		// 除却資産情報を取得
		for (int i = 0; i < set.size(); i++) {
			Kss006 kss006 = new Kss006();
			updChk = false;
			String keyUpd = "sisanInfoLst".concat("[" + i + "]").concat("[upd]");
			if (null != reqMap.get(keyUpd)) {
				updChk = Boolean.valueOf((String) reqMap.get(keyUpd));
			}
			if (!updChk) {
				continue;
			}

			// 承認状態
			String shoninStatus = (String) reqMap.get("sisanInfoLst".concat("[" + i + "]").concat("[shoninStatus]"));

			// 理由
			String riyu = (String) reqMap.get("sisanInfoLst".concat("[" + i + "]").concat("[riyu]"));
			// 除却資産書ＩＤ
			String jokyakuSeisanShoId = (String) reqMap
					.get("sisanInfoLst".concat("[" + i + "]").concat("[jokyakuSeisanShoId]"));

			// 除却資産書ＩＤ
			kss006.setJokyakuSeisanShoId(jokyakuSeisanShoId);
			// 承認状態
			kss006.setShoninStatus(shoninStatus);
			// 理由
			kss006.setRiyu(riyu);
			// 更新年月日
			kss006.setUpdateDate(date);
			// 更新ユーザーＩＤ
			kss006.setUpdateUserId(this.getLoginUserInfo(request).getUserId());

			// 排他チェック
			String errId = commService.doHaita(kss006, (String) reqMap.get("sisanInfoLst".concat("[" + i + "]").concat("[updateDate]")));
			if (!NSDConstant.BLANK_STRING.equals(errId)) {
				return setMsgToResultMap(resultMap, errId);
			}

			kss006UpdLst.add(kss006);
		}

		if (kss006UpdLst.size() == 0) {
			errStr = NSDCommUtils
					.setKakoToStr(systemService.getMessage(NSDConstant.MSGID_RECORD_NOT_SELECTED).getContent());
			return setMsgToResultMap(resultMap, NSDConstant.MSGID_INPUT_ERROR, errStr);
		}

		// サービス呼び出し
		seisanshoJokyakuKeiriService.updateInfo(kss006UpdLst, hakouSoshikiCd, kaikeiSeiriYm);

		// 処理結果データ
		resultMap.put(NSDConstant.RESULT_DATA_NAME, "");

		return setMsgToResultMapNoLog(resultMap, NSDConstant.MSGID_UPDATE_SUCCES);

	}

	/**
	 * 画面除却資産明細件数取得
	 *
	 * @param reqMap
	 * @return
	 */
	private Set<String> countViewRecord(Map<String, Object> reqMap) {
		Set<String> set = new HashSet<String>();

		for (Entry<String, Object> entry : reqMap.entrySet()) {
			String[] record = entry.getKey().replace("[", ",").replace("]", "").split(",");
			if (record.length == 3) {
				set.add(record[1]);
			}
		}

		return set;
	}

	/**
	 * 更新の入力データチェック
	 *
	 * @param reqMap
	 *            INPUTパラメータ
	 * @return エラーメッセージID
	 * @version 1.00
	 */
	private String inputCheckForUpdate(Map<String, Object> reqMap) {

		List<InputCheck> inputCheckList = getCheckItemListForUpdate(reqMap);
		return nsdDataCheck.dataCheck(inputCheckList);

	}

	/**
	 * 更新の入力チェックリストを定義
	 *
	 * @param reqMap
	 *            INPUTパラメータ
	 * @return
	 */
	private List<InputCheck> getCheckItemListForUpdate(Map<String, Object> reqMap) {

		List<InputCheck> inputCheckList = new ArrayList<InputCheck>();
		Map<Integer, Object> args;

		args = new HashMap<Integer, Object>();
		args.put(NSDConstant.CHECK_ITEM.EMPTY_CHECK.ordinal(), null);
		inputCheckList.add(setInputCheck(reqMap, "kaikeiSeiriYm", "会計整理年月：", args));

		// 画面除却資産明細件数取得
		Set<String> set = countViewRecord(reqMap);

		// 画面明細部
		String id;
		boolean updChk;
		boolean dataRenKeiFlag = false;

		for (int i = 0; i < set.size(); i++) {

			// 画面チェックしてないレコードは、入力チェックを行わない。
			updChk = false;
			String keyUpd = "sisanInfoLst".concat("[" + i + "]").concat("[upd]");
			if (null != reqMap.get(keyUpd)) {
				updChk = Boolean.valueOf((String) reqMap.get(keyUpd));
			}
			if (!updChk) {
				continue;
			}
			args = new HashMap<Integer, Object>();
			args.put(NSDConstant.CHECK_ITEM.EMPTY_CHECK.ordinal(), null);
			id = "sisanInfoLst".concat("[" + i + "]").concat("[shoninStatus]");
			inputCheckList.add(setInputCheck(reqMap, id, "承認状態：", args));

			// 承認状態＝「データ連携済」の場合
			if (NSDConstant.SHONIN_STATUS_CODE_RENKEI.equals((String) reqMap.get(id))) {
				dataRenKeiFlag = true;
			}

		}
		// 承認状態＝「データ連携済」の場合、パワー経理の発行組織は必須入力チェックを行う
		if (dataRenKeiFlag) {
			args = new HashMap<Integer, Object>();
			args.put(NSDConstant.CHECK_ITEM.EMPTY_CHECK.ordinal(), null);
			args.put(NSDConstant.CHECK_ITEM.IS_EXIST_ABDA09.ordinal(), setSelectAbda09ByWhere(reqMap));
			inputCheckList.add(setInputCheck(reqMap, "hakouSoshikiNm", "パワー経理の発行組織：", args));
		}

		return inputCheckList;
	}

	/**
	 * 組織定数検索条件を作成する
	 *
	 * @param reqMap
	 * @return
	 */
	private Abda09 setSelectAbda09ByWhere(Map<String, Object> reqMap) {

		Abda09 abda09 = new Abda09();

		// 画面入力した組織名
		abda09.setAb9SoshikKnj((String) reqMap.get("hakouSoshikiNm"));
		// システム日付
		abda09.setAb9TekiyfYmd(NSDDateUtils.parseStrToCal(NSDDateUtils.Now()).getTime());

		return abda09;
	}

	/**
	 * 画面組織名より組織コードを取得する
	 *
	 * @param reqMap
	 * @return
	 */
	private String getHakouSoshikiCdBySoshikiNm(Map<String, Object> reqMap) {

		String soshikiCd = NSDConstant.BLANK_STRING;
		Abda09 abda09 = inputCheckService.getAbda09ForInputCheck(setSelectAbda09ByWhere(reqMap));

		if (abda09 != null) {
			soshikiCd = abda09.getAb9SoshikCod();
		}

		return soshikiCd;
	}

}
