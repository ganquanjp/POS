/***********************************************************************
*
*業務名: 工事精算システム
*機能名: 除却（経理審査/連携）(DB処理)
*
*機能概要: 除却情報を処理する。
*
*JavaＶｅｒ：J2SE1.8.0準拠
*
*更新履歴: Ver.1.00 2018/03/06　NSD　新規作成
***********************************************************************/
package jp.co.nsd.nkssweb.dao.mapper;

import java.util.List;

import jp.co.nsd.nkssweb.dao.SeisanshoJokyakuKeiri;

/**
 * 除却（経理審査/連携）DB処理
 *
 * @version 1.00
 */
public interface SeisanshoJokyakuKeiriMapper {

	/**
	 * 除却（経理審査/連携）情報取得（検索）
	 *
	 * @param seisanshoJokyakuShonin
	 *            INPUTパラメータ
	 * @return　検索結果
	 */
	List<SeisanshoJokyakuKeiri> selectByWhere(SeisanshoJokyakuKeiri seisanshoJokyakuKeiri);

}