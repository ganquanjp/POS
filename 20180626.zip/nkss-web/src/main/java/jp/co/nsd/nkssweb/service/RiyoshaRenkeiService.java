package jp.co.nsd.nkssweb.service;

public interface RiyoshaRenkeiService {

	/**
	 * 利用者情報を取込
	 * @return
	 *
	 * @throws Exception
	 */
	void getRiyoshaInfo() throws Exception;

}
