package jp.co.nsd.nkssweb.dao;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

public class CodeShubetsu extends Kss016Key {
	private List<String> cd1List;

	private List<String> cd2List;

	public List<String> getCd1List() {
		return cd1List;
	}

	public List<String> getCd2List() {
		return cd2List;
	}

	public void setCodeShubetsu(Map<String, Object> map) {
		Iterator<Entry<String, Object>> iter = map.entrySet().iterator();
		if (iter.hasNext()) {
			cd1List = new ArrayList<String>();
			cd2List = new ArrayList<String>();
		}
		while (iter.hasNext()) {
			Entry<String, Object> entry = iter.next();
			String key = entry.getKey();
			Object value = entry.getValue();
			if (key.equals("cdShubetsu")) {
				this.setCdShubetsu(value.toString());
			} else if (key.substring(0, 3).equals("cd1")) {
				this.cd1List.add(value.toString());
			} else if (key.substring(0, 3).equals("cd2")) {
				this.cd2List.add(value.toString());
			} else {
				// 処理なし
			}
		}
	}

}