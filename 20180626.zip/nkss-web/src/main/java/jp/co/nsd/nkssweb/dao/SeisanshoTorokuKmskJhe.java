package jp.co.nsd.nkssweb.dao;

import java.util.Date;

public class SeisanshoTorokuKmskJhe {

	// 件名ID
	private String kenmeiId;
	// 件名CD
	private String kenmeiCd;
	// 適用期間(FROM)
	private String tekiyoStart;
	// 適用期間(TO)
	private String tekiyoEnd;
	// 件名
	private String kenmeiNm;
	// 連係ステータス
	private String RenkeiStatus;
	// ファイル名
	private String fileName;
	// シーケンス番号
	private int seqNo;
	// ファイル作成年月日
	private Date fileCreateYmd;
	// 登録年月日
	private Date entryDate;
	// 登録ユーザーＩＤ
	private String entryUserId;
	// 更新年月日
	private Date updateDate;
	// 更新ユーザーＩＤ
	private String updateUserId;
	public String getKenmeiId() {
		return kenmeiId;
	}
	public void setKenmeiId(String kenmeiId) {
		this.kenmeiId = kenmeiId;
	}
	public String getKenmeiCd() {
		return kenmeiCd;
	}
	public void setKenmeiCd(String kenmeiCd) {
		this.kenmeiCd = kenmeiCd;
	}
	public String getTekiyoStart() {
		return tekiyoStart;
	}
	public void setTekiyoStart(String tekiyoStart) {
		this.tekiyoStart = tekiyoStart;
	}
	public String getTekiyoEnd() {
		return tekiyoEnd;
	}
	public void setTekiyoEnd(String tekiyoEnd) {
		this.tekiyoEnd = tekiyoEnd;
	}
	public String getKenmeiNm() {
		return kenmeiNm;
	}
	public void setKenmeiNm(String kenmeiNm) {
		this.kenmeiNm = kenmeiNm;
	}
	public String getRenkeiStatus() {
		return RenkeiStatus;
	}
	public void setRenkeiStatus(String renkeiStatus) {
		RenkeiStatus = renkeiStatus;
	}
	public String getFileName() {
		return fileName;
	}
	public void setFileName(String fileName) {
		this.fileName = fileName;
	}
	public int getSeqNo() {
		return seqNo;
	}
	public void setSeqNo(int seqNo) {
		this.seqNo = seqNo;
	}
	public Date getFileCreateYmd() {
		return fileCreateYmd;
	}
	public void setFileCreateYmd(Date fileCreateYmd) {
		this.fileCreateYmd = fileCreateYmd;
	}
	public Date getEntryDate() {
		return entryDate;
	}
	public void setEntryDate(Date entryDate) {
		this.entryDate = entryDate;
	}
	public String getEntryUserId() {
		return entryUserId;
	}
	public void setEntryUserId(String entryUserId) {
		this.entryUserId = entryUserId;
	}
	public Date getUpdateDate() {
		return updateDate;
	}
	public void setUpdateDate(Date updateDate) {
		this.updateDate = updateDate;
	}
	public String getUpdateUserId() {
		return updateUserId;
	}
	public void setUpdateUserId(String updateUserId) {
		this.updateUserId = updateUserId;
	}





}