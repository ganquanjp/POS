package jp.co.nsd.nkssweb.dao;

import java.util.Date;

public class Kss014 extends Kss014Key {
    private String soshikiCd;

    private Date tekiyoStartYmd;

    public String getSoshikiCd() {
        return soshikiCd;
    }

    public void setSoshikiCd(String soshikiCd) {
        this.soshikiCd = soshikiCd == null ? null : soshikiCd.trim();
    }

    public Date getTekiyoStartYmd() {
        return tekiyoStartYmd;
    }

    public void setTekiyoStartYmd(Date tekiyoStartYmd) {
        this.tekiyoStartYmd = tekiyoStartYmd;
    }
}