package jp.co.nsd.nkssweb.interceptor.registry;

import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurerAdapter;

import jp.co.nsd.nkssweb.interceptor.LogHandlerInterceptor;
import jp.co.nsd.nkssweb.interceptor.UserLoginHandlerInterceptor;

@Configuration
public class LogInterceptor extends WebMvcConfigurerAdapter {

	/**
	 * インターセプトを登録する
	 */
	@Override
	public void addInterceptors(InterceptorRegistry registry) {

		// ログ出力
		registry.addInterceptor(new LogHandlerInterceptor())
				.addPathPatterns("/*");

		// ユーザーログイン状態(ログイン画面以外)
		registry.addInterceptor(new UserLoginHandlerInterceptor())
		.addPathPatterns("/*").excludePathPatterns("/system-userlogin");
	}
}
