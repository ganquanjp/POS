package jp.co.nsd.nkssweb.dao;

public class SeisanshoJokyakuKoteiSisan extends KoteiSisan {

	// 除却精算書ＩＤ
	private String jokyakuSeisanShoId;

	// 除却資産ＩＤ
	private String jokyakuShisanId;

	// 除却元固定資産ＩＤ
	private String motoKoteiShisanId;

	// 履歴番号
	private String rirekiNo;

	// 除_取得価額
	private String jokyakuGaku;

	// 除却種別コード
	private String jokyakuShubetsuCd;

	// 除却種別名称
	private String jokyakuShubetsuNm;

	// 除却区分コード
	private String jokyakuKbn;

	// 除却区分名称
	private String jokyakuKbnNm;

	// 除_数量
	private String jokyakuSuryo;

	// 資産単位コード
	private String shisanTaniCd;

	// 資産単位名称
	private String shisanTaniNm;

	// 精算箇所コード
	private String seisanSoshikiCd;

	// 登録者コード
	private String userId;

	// 更新年月日
	private String updateDate;

	public String getJokyakuSeisanShoId() {
		return jokyakuSeisanShoId;
	}

	public void setJokyakuSeisanShoId(String jokyakuSeisanShoId) {
		this.jokyakuSeisanShoId = jokyakuSeisanShoId;
	}

	public String getJokyakuShisanId() {
		return jokyakuShisanId;
	}

	public void setJokyakuShisanId(String jokyakuShisanId) {
		this.jokyakuShisanId = jokyakuShisanId;
	}

	public String getMotoKoteiShisanId() {
		return motoKoteiShisanId;
	}

	public void setMotoKoteiShisanId(String motoKoteiShisanId) {
		this.motoKoteiShisanId = motoKoteiShisanId;
	}

	public String getRirekiNo() {
		return rirekiNo;
	}

	public void setRirekiNo(String rirekiNo) {
		this.rirekiNo = rirekiNo;
	}

	public String getJokyakuGaku() {
		return jokyakuGaku;
	}

	public void setJokyakuGaku(String jokyakuGaku) {
		this.jokyakuGaku = jokyakuGaku;
	}

	public String getJokyakuShubetsuCd() {
		return jokyakuShubetsuCd;
	}

	public void setJokyakuShubetsuCd(String jokyakuShubetsuCd) {
		this.jokyakuShubetsuCd = jokyakuShubetsuCd;
	}

	public String getJokyakuShubetsuNm() {
		return jokyakuShubetsuNm;
	}

	public void setJokyakuShubetsuNm(String jokyakuShubetsuNm) {
		this.jokyakuShubetsuNm = jokyakuShubetsuNm;
	}

	public String getJokyakuKbn() {
		return jokyakuKbn;
	}

	public void setJokyakuKbn(String jokyakuKbn) {
		this.jokyakuKbn = jokyakuKbn;
	}

	public String getJokyakuKbnNm() {
		return jokyakuKbnNm;
	}

	public void setJokyakuKbnNm(String jokyakuKbnNm) {
		this.jokyakuKbnNm = jokyakuKbnNm;
	}

	public String getJokyakuSuryo() {
		return jokyakuSuryo;
	}

	public void setJokyakuSuryo(String jokyakuSuryo) {
		this.jokyakuSuryo = jokyakuSuryo;
	}

	public String getShisanTaniCd() {
		return shisanTaniCd;
	}

	public void setShisanTaniCd(String shisanTaniCd) {
		this.shisanTaniCd = shisanTaniCd;
	}

	public String getShisanTaniNm() {
		return shisanTaniNm;
	}

	public void setShisanTaniNm(String shisanTaniNm) {
		this.shisanTaniNm = shisanTaniNm;
	}

	public String getSeisanSoshikiCd() {
		return seisanSoshikiCd;
	}

	public void setSeisanSoshikiCd(String seisanSoshikiCd) {
		this.seisanSoshikiCd = seisanSoshikiCd;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getUpdateDate() {
		return updateDate;
	}

	public void setUpdateDate(String updateDate) {
		this.updateDate = updateDate;
	}

}