package jp.co.nsd.nkssweb.dao;

import java.math.BigDecimal;
import java.util.Date;

public class Kss005 extends Kss005Key {
    private String oyaKoteiShisanNo;

    private String oyaKoteiShisanEda;

    private Date shutokuYmd;

    private String koteiShisanNm;

    private String shuruiCd;

    private String kouzouCd;

    private String shisanTaniCd;

    private String kamokuCd1;

    private String kamokuCd2;

    private String kamokuCd3;

    private String jitaShisanKbn;

    private String torihikiSakiCd;

    private String seizoKaishaNm;

    private String seihinNm;

    private String kataban;

    private BigDecimal suryo;

    private String taniCd;

    private Long buppinGaku;

    private Long kouhiGaku;

    private Long souKeihiGaku;

    private String kanriSoshikiCd;

    private Date kanriTekiyoStartYmd;

    private String futanSoshikiCd;

    private Date futanTekiyoStartYmd;

    private String sechiBashoCd;

    private String shutokuRiyuCd;

    private Short taiyoNensuSho;

    private Short taiyoNensuZei;

    private String tekiyo1;

    private String tekiyo2;

    private String tekiyo3;

    private String tekiyo4;

    private String tekiyo5;

    private String kojiTantoUserNm;

    private String kojiTantoSoshikiCd;

    private Long biboKagakuZei;

    private Long biboKagakuSho;

    private Long shokyakuGendoZei;

    private Long shokyakuGendoSho;

    private String syokyakuHohoZei;

    private String syokyakuHohoSho;

    private Short zanzonRitsuZei;

    private Short zanzonRitsuSho;

    private String shinkokuSakiCd;

    private String shinkokuShuruiCd;

    private Date torihikiSakiTekiyoYmd;

    private String shokyakuShisanKbn;

    private String renkeiYohiFlg;

    private Long ichijiShokyakuSho;

    private Long ichijiShokyakuZei;

    private Long chinpuKagakuZei;

    private Long chinpuKagakuSho;

    private Long wariShokyakuGakuSho;

    private Long wariShokyakuGakuZei;

    private Long zokaShokyakuGakuSho;

    private Long zokaShokyakuGakuZei;

    private Long genshiShutokuKagaku;

    private Long shinkokuShutokuKagaku;

    private String shokyakuKbnSho;

    private String shokyakuKbnZei;

    private Short saishuZanzonRitsuSho;

    private Short saishuZanzonRitsuZei;

    private BigDecimal futanRitsu;

    private String shokyakuKamokuUchiCd;

    private String shonendoShokyakuHoho;

    private String ruikeiKamokuUchiCd;

    private String setsubiHozenKanriNo;

    private String cityCd;

    private String shisetsuCd;

    private String groupCd;

    private Long komoku01;

    private Long komoku02;

    private Long komoku03;

    private Long komoku04;

    private Long komoku05;

    private String komoku06;

    private String komoku07;

    private String komoku08;

    private String komoku09;

    private String komoku10;

    private String komoku11;

    private String komoku12;

    private String komoku13;

    private String komoku14;

    private String komoku15;

    private Date entryDate;

    private String entryUserId;

    private Date updateDate;

    private String updateUserId;

    public String getOyaKoteiShisanNo() {
        return oyaKoteiShisanNo;
    }

    public void setOyaKoteiShisanNo(String oyaKoteiShisanNo) {
        this.oyaKoteiShisanNo = oyaKoteiShisanNo == null ? null : oyaKoteiShisanNo.trim();
    }

    public String getOyaKoteiShisanEda() {
        return oyaKoteiShisanEda;
    }

    public void setOyaKoteiShisanEda(String oyaKoteiShisanEda) {
        this.oyaKoteiShisanEda = oyaKoteiShisanEda == null ? null : oyaKoteiShisanEda.trim();
    }

    public Date getShutokuYmd() {
        return shutokuYmd;
    }

    public void setShutokuYmd(Date shutokuYmd) {
        this.shutokuYmd = shutokuYmd;
    }

    public String getKoteiShisanNm() {
        return koteiShisanNm;
    }

    public void setKoteiShisanNm(String koteiShisanNm) {
        this.koteiShisanNm = koteiShisanNm == null ? null : koteiShisanNm.trim();
    }

    public String getShuruiCd() {
        return shuruiCd;
    }

    public void setShuruiCd(String shuruiCd) {
        this.shuruiCd = shuruiCd == null ? null : shuruiCd.trim();
    }

    public String getKouzouCd() {
        return kouzouCd;
    }

    public void setKouzouCd(String kouzouCd) {
        this.kouzouCd = kouzouCd == null ? null : kouzouCd.trim();
    }

    public String getShisanTaniCd() {
        return shisanTaniCd;
    }

    public void setShisanTaniCd(String shisanTaniCd) {
        this.shisanTaniCd = shisanTaniCd == null ? null : shisanTaniCd.trim();
    }

    public String getKamokuCd1() {
        return kamokuCd1;
    }

    public void setKamokuCd1(String kamokuCd1) {
        this.kamokuCd1 = kamokuCd1 == null ? null : kamokuCd1.trim();
    }

    public String getKamokuCd2() {
        return kamokuCd2;
    }

    public void setKamokuCd2(String kamokuCd2) {
        this.kamokuCd2 = kamokuCd2 == null ? null : kamokuCd2.trim();
    }

    public String getKamokuCd3() {
        return kamokuCd3;
    }

    public void setKamokuCd3(String kamokuCd3) {
        this.kamokuCd3 = kamokuCd3 == null ? null : kamokuCd3.trim();
    }

    public String getJitaShisanKbn() {
        return jitaShisanKbn;
    }

    public void setJitaShisanKbn(String jitaShisanKbn) {
        this.jitaShisanKbn = jitaShisanKbn == null ? null : jitaShisanKbn.trim();
    }

    public String getTorihikiSakiCd() {
        return torihikiSakiCd;
    }

    public void setTorihikiSakiCd(String torihikiSakiCd) {
        this.torihikiSakiCd = torihikiSakiCd == null ? null : torihikiSakiCd.trim();
    }

    public String getSeizoKaishaNm() {
        return seizoKaishaNm;
    }

    public void setSeizoKaishaNm(String seizoKaishaNm) {
        this.seizoKaishaNm = seizoKaishaNm == null ? null : seizoKaishaNm.trim();
    }

    public String getSeihinNm() {
        return seihinNm;
    }

    public void setSeihinNm(String seihinNm) {
        this.seihinNm = seihinNm == null ? null : seihinNm.trim();
    }

    public String getKataban() {
        return kataban;
    }

    public void setKataban(String kataban) {
        this.kataban = kataban == null ? null : kataban.trim();
    }

    public BigDecimal getSuryo() {
        return suryo;
    }

    public void setSuryo(BigDecimal suryo) {
        this.suryo = suryo;
    }

    public String getTaniCd() {
        return taniCd;
    }

    public void setTaniCd(String taniCd) {
        this.taniCd = taniCd == null ? null : taniCd.trim();
    }

    public Long getBuppinGaku() {
        return buppinGaku;
    }

    public void setBuppinGaku(Long buppinGaku) {
        this.buppinGaku = buppinGaku;
    }

    public Long getKouhiGaku() {
        return kouhiGaku;
    }

    public void setKouhiGaku(Long kouhiGaku) {
        this.kouhiGaku = kouhiGaku;
    }

    public Long getSouKeihiGaku() {
        return souKeihiGaku;
    }

    public void setSouKeihiGaku(Long souKeihiGaku) {
        this.souKeihiGaku = souKeihiGaku;
    }

    public String getKanriSoshikiCd() {
        return kanriSoshikiCd;
    }

    public void setKanriSoshikiCd(String kanriSoshikiCd) {
        this.kanriSoshikiCd = kanriSoshikiCd == null ? null : kanriSoshikiCd.trim();
    }

    public Date getKanriTekiyoStartYmd() {
        return kanriTekiyoStartYmd;
    }

    public void setKanriTekiyoStartYmd(Date kanriTekiyoStartYmd) {
        this.kanriTekiyoStartYmd = kanriTekiyoStartYmd;
    }

    public String getFutanSoshikiCd() {
        return futanSoshikiCd;
    }

    public void setFutanSoshikiCd(String futanSoshikiCd) {
        this.futanSoshikiCd = futanSoshikiCd == null ? null : futanSoshikiCd.trim();
    }

    public Date getFutanTekiyoStartYmd() {
        return futanTekiyoStartYmd;
    }

    public void setFutanTekiyoStartYmd(Date futanTekiyoStartYmd) {
        this.futanTekiyoStartYmd = futanTekiyoStartYmd;
    }

    public String getSechiBashoCd() {
        return sechiBashoCd;
    }

    public void setSechiBashoCd(String sechiBashoCd) {
        this.sechiBashoCd = sechiBashoCd == null ? null : sechiBashoCd.trim();
    }

    public String getShutokuRiyuCd() {
        return shutokuRiyuCd;
    }

    public void setShutokuRiyuCd(String shutokuRiyuCd) {
        this.shutokuRiyuCd = shutokuRiyuCd == null ? null : shutokuRiyuCd.trim();
    }

    public Short getTaiyoNensuSho() {
        return taiyoNensuSho;
    }

    public void setTaiyoNensuSho(Short taiyoNensuSho) {
        this.taiyoNensuSho = taiyoNensuSho;
    }

    public Short getTaiyoNensuZei() {
        return taiyoNensuZei;
    }

    public void setTaiyoNensuZei(Short taiyoNensuZei) {
        this.taiyoNensuZei = taiyoNensuZei;
    }

    public String getTekiyo1() {
        return tekiyo1;
    }

    public void setTekiyo1(String tekiyo1) {
        this.tekiyo1 = tekiyo1 == null ? null : tekiyo1.trim();
    }

    public String getTekiyo2() {
        return tekiyo2;
    }

    public void setTekiyo2(String tekiyo2) {
        this.tekiyo2 = tekiyo2 == null ? null : tekiyo2.trim();
    }

    public String getTekiyo3() {
        return tekiyo3;
    }

    public void setTekiyo3(String tekiyo3) {
        this.tekiyo3 = tekiyo3 == null ? null : tekiyo3.trim();
    }

    public String getTekiyo4() {
        return tekiyo4;
    }

    public void setTekiyo4(String tekiyo4) {
        this.tekiyo4 = tekiyo4 == null ? null : tekiyo4.trim();
    }

    public String getTekiyo5() {
        return tekiyo5;
    }

    public void setTekiyo5(String tekiyo5) {
        this.tekiyo5 = tekiyo5 == null ? null : tekiyo5.trim();
    }

    public String getKojiTantoUserNm() {
        return kojiTantoUserNm;
    }

    public void setKojiTantoUserNm(String kojiTantoUserNm) {
        this.kojiTantoUserNm = kojiTantoUserNm == null ? null : kojiTantoUserNm.trim();
    }

    public String getKojiTantoSoshikiCd() {
        return kojiTantoSoshikiCd;
    }

    public void setKojiTantoSoshikiCd(String kojiTantoSoshikiCd) {
        this.kojiTantoSoshikiCd = kojiTantoSoshikiCd == null ? null : kojiTantoSoshikiCd.trim();
    }

    public Long getBiboKagakuZei() {
        return biboKagakuZei;
    }

    public void setBiboKagakuZei(Long biboKagakuZei) {
        this.biboKagakuZei = biboKagakuZei;
    }

    public Long getBiboKagakuSho() {
        return biboKagakuSho;
    }

    public void setBiboKagakuSho(Long biboKagakuSho) {
        this.biboKagakuSho = biboKagakuSho;
    }

    public Long getShokyakuGendoZei() {
        return shokyakuGendoZei;
    }

    public void setShokyakuGendoZei(Long shokyakuGendoZei) {
        this.shokyakuGendoZei = shokyakuGendoZei;
    }

    public Long getShokyakuGendoSho() {
        return shokyakuGendoSho;
    }

    public void setShokyakuGendoSho(Long shokyakuGendoSho) {
        this.shokyakuGendoSho = shokyakuGendoSho;
    }

    public String getSyokyakuHohoZei() {
        return syokyakuHohoZei;
    }

    public void setSyokyakuHohoZei(String syokyakuHohoZei) {
        this.syokyakuHohoZei = syokyakuHohoZei == null ? null : syokyakuHohoZei.trim();
    }

    public String getSyokyakuHohoSho() {
        return syokyakuHohoSho;
    }

    public void setSyokyakuHohoSho(String syokyakuHohoSho) {
        this.syokyakuHohoSho = syokyakuHohoSho == null ? null : syokyakuHohoSho.trim();
    }

    public Short getZanzonRitsuZei() {
        return zanzonRitsuZei;
    }

    public void setZanzonRitsuZei(Short zanzonRitsuZei) {
        this.zanzonRitsuZei = zanzonRitsuZei;
    }

    public Short getZanzonRitsuSho() {
        return zanzonRitsuSho;
    }

    public void setZanzonRitsuSho(Short zanzonRitsuSho) {
        this.zanzonRitsuSho = zanzonRitsuSho;
    }

    public String getShinkokuSakiCd() {
        return shinkokuSakiCd;
    }

    public void setShinkokuSakiCd(String shinkokuSakiCd) {
        this.shinkokuSakiCd = shinkokuSakiCd == null ? null : shinkokuSakiCd.trim();
    }

    public String getShinkokuShuruiCd() {
        return shinkokuShuruiCd;
    }

    public void setShinkokuShuruiCd(String shinkokuShuruiCd) {
        this.shinkokuShuruiCd = shinkokuShuruiCd == null ? null : shinkokuShuruiCd.trim();
    }

    public Date getTorihikiSakiTekiyoYmd() {
        return torihikiSakiTekiyoYmd;
    }

    public void setTorihikiSakiTekiyoYmd(Date torihikiSakiTekiyoYmd) {
        this.torihikiSakiTekiyoYmd = torihikiSakiTekiyoYmd;
    }

    public String getShokyakuShisanKbn() {
        return shokyakuShisanKbn;
    }

    public void setShokyakuShisanKbn(String shokyakuShisanKbn) {
        this.shokyakuShisanKbn = shokyakuShisanKbn == null ? null : shokyakuShisanKbn.trim();
    }

    public String getRenkeiYohiFlg() {
        return renkeiYohiFlg;
    }

    public void setRenkeiYohiFlg(String renkeiYohiFlg) {
        this.renkeiYohiFlg = renkeiYohiFlg == null ? null : renkeiYohiFlg.trim();
    }

    public Long getIchijiShokyakuSho() {
        return ichijiShokyakuSho;
    }

    public void setIchijiShokyakuSho(Long ichijiShokyakuSho) {
        this.ichijiShokyakuSho = ichijiShokyakuSho;
    }

    public Long getIchijiShokyakuZei() {
        return ichijiShokyakuZei;
    }

    public void setIchijiShokyakuZei(Long ichijiShokyakuZei) {
        this.ichijiShokyakuZei = ichijiShokyakuZei;
    }

    public Long getChinpuKagakuZei() {
        return chinpuKagakuZei;
    }

    public void setChinpuKagakuZei(Long chinpuKagakuZei) {
        this.chinpuKagakuZei = chinpuKagakuZei;
    }

    public Long getChinpuKagakuSho() {
        return chinpuKagakuSho;
    }

    public void setChinpuKagakuSho(Long chinpuKagakuSho) {
        this.chinpuKagakuSho = chinpuKagakuSho;
    }

    public Long getWariShokyakuGakuSho() {
        return wariShokyakuGakuSho;
    }

    public void setWariShokyakuGakuSho(Long wariShokyakuGakuSho) {
        this.wariShokyakuGakuSho = wariShokyakuGakuSho;
    }

    public Long getWariShokyakuGakuZei() {
        return wariShokyakuGakuZei;
    }

    public void setWariShokyakuGakuZei(Long wariShokyakuGakuZei) {
        this.wariShokyakuGakuZei = wariShokyakuGakuZei;
    }

    public Long getZokaShokyakuGakuSho() {
        return zokaShokyakuGakuSho;
    }

    public void setZokaShokyakuGakuSho(Long zokaShokyakuGakuSho) {
        this.zokaShokyakuGakuSho = zokaShokyakuGakuSho;
    }

    public Long getZokaShokyakuGakuZei() {
        return zokaShokyakuGakuZei;
    }

    public void setZokaShokyakuGakuZei(Long zokaShokyakuGakuZei) {
        this.zokaShokyakuGakuZei = zokaShokyakuGakuZei;
    }

    public Long getGenshiShutokuKagaku() {
        return genshiShutokuKagaku;
    }

    public void setGenshiShutokuKagaku(Long genshiShutokuKagaku) {
        this.genshiShutokuKagaku = genshiShutokuKagaku;
    }

    public Long getShinkokuShutokuKagaku() {
        return shinkokuShutokuKagaku;
    }

    public void setShinkokuShutokuKagaku(Long shinkokuShutokuKagaku) {
        this.shinkokuShutokuKagaku = shinkokuShutokuKagaku;
    }

    public String getShokyakuKbnSho() {
        return shokyakuKbnSho;
    }

    public void setShokyakuKbnSho(String shokyakuKbnSho) {
        this.shokyakuKbnSho = shokyakuKbnSho == null ? null : shokyakuKbnSho.trim();
    }

    public String getShokyakuKbnZei() {
        return shokyakuKbnZei;
    }

    public void setShokyakuKbnZei(String shokyakuKbnZei) {
        this.shokyakuKbnZei = shokyakuKbnZei == null ? null : shokyakuKbnZei.trim();
    }

    public Short getSaishuZanzonRitsuSho() {
        return saishuZanzonRitsuSho;
    }

    public void setSaishuZanzonRitsuSho(Short saishuZanzonRitsuSho) {
        this.saishuZanzonRitsuSho = saishuZanzonRitsuSho;
    }

    public Short getSaishuZanzonRitsuZei() {
        return saishuZanzonRitsuZei;
    }

    public void setSaishuZanzonRitsuZei(Short saishuZanzonRitsuZei) {
        this.saishuZanzonRitsuZei = saishuZanzonRitsuZei;
    }

    public BigDecimal getFutanRitsu() {
        return futanRitsu;
    }

    public void setFutanRitsu(BigDecimal futanRitsu) {
        this.futanRitsu = futanRitsu;
    }

    public String getShokyakuKamokuUchiCd() {
        return shokyakuKamokuUchiCd;
    }

    public void setShokyakuKamokuUchiCd(String shokyakuKamokuUchiCd) {
        this.shokyakuKamokuUchiCd = shokyakuKamokuUchiCd == null ? null : shokyakuKamokuUchiCd.trim();
    }

    public String getShonendoShokyakuHoho() {
        return shonendoShokyakuHoho;
    }

    public void setShonendoShokyakuHoho(String shonendoShokyakuHoho) {
        this.shonendoShokyakuHoho = shonendoShokyakuHoho == null ? null : shonendoShokyakuHoho.trim();
    }

    public String getRuikeiKamokuUchiCd() {
        return ruikeiKamokuUchiCd;
    }

    public void setRuikeiKamokuUchiCd(String ruikeiKamokuUchiCd) {
        this.ruikeiKamokuUchiCd = ruikeiKamokuUchiCd == null ? null : ruikeiKamokuUchiCd.trim();
    }

    public String getSetsubiHozenKanriNo() {
        return setsubiHozenKanriNo;
    }

    public void setSetsubiHozenKanriNo(String setsubiHozenKanriNo) {
        this.setsubiHozenKanriNo = setsubiHozenKanriNo == null ? null : setsubiHozenKanriNo.trim();
    }

    public String getCityCd() {
        return cityCd;
    }

    public void setCityCd(String cityCd) {
        this.cityCd = cityCd == null ? null : cityCd.trim();
    }

    public String getShisetsuCd() {
        return shisetsuCd;
    }

    public void setShisetsuCd(String shisetsuCd) {
        this.shisetsuCd = shisetsuCd == null ? null : shisetsuCd.trim();
    }

    public String getGroupCd() {
        return groupCd;
    }

    public void setGroupCd(String groupCd) {
        this.groupCd = groupCd == null ? null : groupCd.trim();
    }

    public Long getKomoku01() {
        return komoku01;
    }

    public void setKomoku01(Long komoku01) {
        this.komoku01 = komoku01;
    }

    public Long getKomoku02() {
        return komoku02;
    }

    public void setKomoku02(Long komoku02) {
        this.komoku02 = komoku02;
    }

    public Long getKomoku03() {
        return komoku03;
    }

    public void setKomoku03(Long komoku03) {
        this.komoku03 = komoku03;
    }

    public Long getKomoku04() {
        return komoku04;
    }

    public void setKomoku04(Long komoku04) {
        this.komoku04 = komoku04;
    }

    public Long getKomoku05() {
        return komoku05;
    }

    public void setKomoku05(Long komoku05) {
        this.komoku05 = komoku05;
    }

    public String getKomoku06() {
        return komoku06;
    }

    public void setKomoku06(String komoku06) {
        this.komoku06 = komoku06 == null ? null : komoku06.trim();
    }

    public String getKomoku07() {
        return komoku07;
    }

    public void setKomoku07(String komoku07) {
        this.komoku07 = komoku07 == null ? null : komoku07.trim();
    }

    public String getKomoku08() {
        return komoku08;
    }

    public void setKomoku08(String komoku08) {
        this.komoku08 = komoku08 == null ? null : komoku08.trim();
    }

    public String getKomoku09() {
        return komoku09;
    }

    public void setKomoku09(String komoku09) {
        this.komoku09 = komoku09 == null ? null : komoku09.trim();
    }

    public String getKomoku10() {
        return komoku10;
    }

    public void setKomoku10(String komoku10) {
        this.komoku10 = komoku10 == null ? null : komoku10.trim();
    }

    public String getKomoku11() {
        return komoku11;
    }

    public void setKomoku11(String komoku11) {
        this.komoku11 = komoku11 == null ? null : komoku11.trim();
    }

    public String getKomoku12() {
        return komoku12;
    }

    public void setKomoku12(String komoku12) {
        this.komoku12 = komoku12 == null ? null : komoku12.trim();
    }

    public String getKomoku13() {
        return komoku13;
    }

    public void setKomoku13(String komoku13) {
        this.komoku13 = komoku13 == null ? null : komoku13.trim();
    }

    public String getKomoku14() {
        return komoku14;
    }

    public void setKomoku14(String komoku14) {
        this.komoku14 = komoku14 == null ? null : komoku14.trim();
    }

    public String getKomoku15() {
        return komoku15;
    }

    public void setKomoku15(String komoku15) {
        this.komoku15 = komoku15 == null ? null : komoku15.trim();
    }

    public Date getEntryDate() {
        return entryDate;
    }

    public void setEntryDate(Date entryDate) {
        this.entryDate = entryDate;
    }

    public String getEntryUserId() {
        return entryUserId;
    }

    public void setEntryUserId(String entryUserId) {
        this.entryUserId = entryUserId == null ? null : entryUserId.trim();
    }

    public Date getUpdateDate() {
        return updateDate;
    }

    public void setUpdateDate(Date updateDate) {
        this.updateDate = updateDate;
    }

    public String getUpdateUserId() {
        return updateUserId;
    }

    public void setUpdateUserId(String updateUserId) {
        this.updateUserId = updateUserId == null ? null : updateUserId.trim();
    }
}