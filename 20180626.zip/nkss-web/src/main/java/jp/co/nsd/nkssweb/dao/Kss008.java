package jp.co.nsd.nkssweb.dao;

import java.util.Date;

public class Kss008 extends Kss008Key {
    private Date serviceStartYmd;

    private Date keiyakuStartYmd;

    private Date keiyakuEndYmd;

    private Date entryDate;

    private String entryUserId;

    private Date updateDate;

    private String updateUserId;

    public Date getServiceStartYmd() {
        return serviceStartYmd;
    }

    public void setServiceStartYmd(Date serviceStartYmd) {
        this.serviceStartYmd = serviceStartYmd;
    }

    public Date getKeiyakuStartYmd() {
        return keiyakuStartYmd;
    }

    public void setKeiyakuStartYmd(Date keiyakuStartYmd) {
        this.keiyakuStartYmd = keiyakuStartYmd;
    }

    public Date getKeiyakuEndYmd() {
        return keiyakuEndYmd;
    }

    public void setKeiyakuEndYmd(Date keiyakuEndYmd) {
        this.keiyakuEndYmd = keiyakuEndYmd;
    }

    public Date getEntryDate() {
        return entryDate;
    }

    public void setEntryDate(Date entryDate) {
        this.entryDate = entryDate;
    }

    public String getEntryUserId() {
        return entryUserId;
    }

    public void setEntryUserId(String entryUserId) {
        this.entryUserId = entryUserId == null ? null : entryUserId.trim();
    }

    public Date getUpdateDate() {
        return updateDate;
    }

    public void setUpdateDate(Date updateDate) {
        this.updateDate = updateDate;
    }

    public String getUpdateUserId() {
        return updateUserId;
    }

    public void setUpdateUserId(String updateUserId) {
        this.updateUserId = updateUserId == null ? null : updateUserId.trim();
    }
}