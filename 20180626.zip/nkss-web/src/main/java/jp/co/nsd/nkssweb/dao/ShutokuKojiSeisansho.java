package jp.co.nsd.nkssweb.dao;

import java.math.BigDecimal;

/**
 * 工事精算書（取得）
 *
 * @version 1.00
 */
public class ShutokuKojiSeisansho {
	// 工事精算書（取得）情報
	// 処理No.
	private String hansu;
	// 作成日
	private String sakuseiDate;
	// 工事件名
	private String kenmei;
	// 精算箇所
	private String seisanSoshiki;
	// 精算書番号
	private String seisanShoNo;
	// 使用開始年月日
	private String siyoStartYmd;
	// 摘要
	private String tekiyo;
	// 総件数
	private Long shutokuSisanCnt;
	// 総額
	private BigDecimal shutokuKagaku;
	// 種類・構造・資産単位・科目1・科目2・科目3（種構資１２３）
	private String shubetsuCode;
	// 取引先
	private String torihikiSaki;
	// 件数
	private Long kenSu;
	// 取得価額
	private BigDecimal rwgGetkgkYen;
	/**
	 * @return hansu
	 */
	public String getHansu() {
		return hansu;
	}
	/**
	 * @param hansu セットする hansu
	 */
	public void setHansu(String hansu) {
		this.hansu = hansu;
	}
	/**
	 * @return sakuseiDate
	 */
	public String getSakuseiDate() {
		return sakuseiDate;
	}
	/**
	 * @param sakuseiDate セットする sakuseiDate
	 */
	public void setSakuseiDate(String sakuseiDate) {
		this.sakuseiDate = sakuseiDate;
	}
	/**
	 * @return kenmei
	 */
	public String getKenmei() {
		return kenmei;
	}
	/**
	 * @param kenmei セットする kenmei
	 */
	public void setKenmei(String kenmei) {
		this.kenmei = kenmei;
	}
	/**
	 * @return seisanSoshiki
	 */
	public String getSeisanSoshiki() {
		return seisanSoshiki;
	}
	/**
	 * @param seisanSoshiki セットする seisanSoshiki
	 */
	public void setSeisanSoshiki(String seisanSoshiki) {
		this.seisanSoshiki = seisanSoshiki;
	}
	/**
	 * @return seisanShoNo
	 */
	public String getSeisanShoNo() {
		return seisanShoNo;
	}
	/**
	 * @param seisanShoNo セットする seisanShoNo
	 */
	public void setSeisanShoNo(String seisanShoNo) {
		this.seisanShoNo = seisanShoNo;
	}
	/**
	 * @return siyoStartYmd
	 */
	public String getSiyoStartYmd() {
		return siyoStartYmd;
	}
	/**
	 * @param siyoStartYmd セットする siyoStartYmd
	 */
	public void setSiyoStartYmd(String siyoStartYmd) {
		this.siyoStartYmd = siyoStartYmd;
	}
	/**
	 * @return tekiyo
	 */
	public String getTekiyo() {
		return tekiyo;
	}
	/**
	 * @param tekiyo セットする tekiyo
	 */
	public void setTekiyo(String tekiyo) {
		this.tekiyo = tekiyo;
	}
	/**
	 * @return shutokuSisanCnt
	 */
	public Long getShutokuSisanCnt() {
		return shutokuSisanCnt;
	}
	/**
	 * @param shutokuSisanCnt セットする shutokuSisanCnt
	 */
	public void setShutokuSisanCnt(Long shutokuSisanCnt) {
		this.shutokuSisanCnt = shutokuSisanCnt;
	}
	/**
	 * @return shutokuKagaku
	 */
	public BigDecimal getShutokuKagaku() {
		return shutokuKagaku;
	}
	/**
	 * @param shutokuKagaku セットする shutokuKagaku
	 */
	public void setShutokuKagaku(BigDecimal shutokuKagaku) {
		this.shutokuKagaku = shutokuKagaku;
	}
	/**
	 * @return shubetsuCode
	 */
	public String getShubetsuCode() {
		return shubetsuCode;
	}
	/**
	 * @param shubetsuCode セットする shubetsuCode
	 */
	public void setShubetsuCode(String shubetsuCode) {
		this.shubetsuCode = shubetsuCode;
	}
	/**
	 * @return torihikiSaki
	 */
	public String getTorihikiSaki() {
		return torihikiSaki;
	}
	/**
	 * @param torihikiSaki セットする torihikiSaki
	 */
	public void setTorihikiSaki(String torihikiSaki) {
		this.torihikiSaki = torihikiSaki;
	}
	/**
	 * @return kenSu
	 */
	public Long getKenSu() {
		return kenSu;
	}
	/**
	 * @param kenSu セットする kenSu
	 */
	public void setKenSu(Long kenSu) {
		this.kenSu = kenSu;
	}
	/**
	 * @return rwgGetkgkYen
	 */
	public BigDecimal getRwgGetkgkYen() {
		return rwgGetkgkYen;
	}
	/**
	 * @param rwgGetkgkYen セットする rwgGetkgkYen
	 */
	public void setRwgGetkgkYen(BigDecimal rwgGetkgkYen) {
		this.rwgGetkgkYen = rwgGetkgkYen;
	}

}