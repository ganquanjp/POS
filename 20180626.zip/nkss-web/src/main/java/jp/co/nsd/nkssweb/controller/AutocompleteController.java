/***********************************************************************
*
*業務名: 工事精算システム
*機能名: 候補内容(共通処理)
*
*機能概要: 入力中の内容を部分一致にて検索し、
*          候補を入力フォーム下部に表示のデータを取得する
*
*JavaＶｅｒ：J2SE1.8.0準拠
*
*更新履歴: Ver.1.00 2018/03/13　NSD　新規作成
***********************************************************************/

package jp.co.nsd.nkssweb.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import jp.co.nsd.nkssweb.dao.Aads01;
import jp.co.nsd.nkssweb.dao.Abda09;
import jp.co.nsd.nkssweb.dao.InputCheck;
import jp.co.nsd.nkssweb.dao.Kss002;
import jp.co.nsd.nkssweb.dao.Kss011;
import jp.co.nsd.nkssweb.dao.Kss013;
import jp.co.nsd.nkssweb.service.AutocompleteService;
import jp.co.nsd.nkssweb.service.SystemService;
import jp.co.nsd.nkssweb.utils.NSDConstant;
import jp.co.nsd.nkssweb.utils.NSDDataCheck;

/**
 * 候補内容(共通処理)
 *
 * @version 1.00
 */
@RestController
public class AutocompleteController extends BaseController {

	@Autowired
	private AutocompleteService autocompleteService;

	@Autowired
	protected SystemService systemService;

	@Autowired
	private NSDDataCheck nsdDataCheck;

	/**
	 * ユーザ情報全件取得
	 *
	 * @version 1.00
	 */
	@RequestMapping(value = "/autocomplete-selectUserMaster", method = RequestMethod.GET)
	public Map<String, Object> selectUserMaster() throws Exception {

		Map<String, Object> resultMap = new HashMap<String, Object>();

		List<Kss013> kss013List = new ArrayList<Kss013>();

		// サービスを呼び出す
		kss013List = autocompleteService.getUserMaster();

		// 処理結果データ
		setDataToResultMap(resultMap, kss013List);

		return resultMap;
	}

	/*
	 * 件名マスタ全件取得
	 */
	@RequestMapping(value = "/autocomplete-selectKenmeiMaster", method = RequestMethod.GET)
	public Map<String, Object> selectKenmeiMaster(
			@RequestParam(value = "siyoStartYmd",required = false) String siyoStartYmd) throws Exception {

		Map<String, Object> resultMap = new HashMap<String, Object>();

		// 入力チェック
		String errStr = inputCheckForSearchKenmeiMaster(siyoStartYmd);
		if (StringUtils.isNotEmpty(errStr)) {
			return setMsgToResultMap(resultMap, NSDConstant.MSGID_INPUT_ERROR, errStr);
		}

		List<Kss002> kss002List = new ArrayList<Kss002>();

		// サービスを呼び出す
		kss002List = autocompleteService.getKenmeiMaster(siyoStartYmd);

		// 処理結果データ
		setDataToResultMap(resultMap, kss002List);

		return resultMap;
	}

	/**
	 * 件名マスタ検索の入力データチェック
	 *
	 * @param siyoStartYmd
	 * @return
	 */
	private String inputCheckForSearchKenmeiMaster(String siyoStartYmd) {

		List<InputCheck> inputCheckList = getCheckItemListForSearchKenmeiMaster(siyoStartYmd);
		return nsdDataCheck.dataCheck(inputCheckList);

	}

	/**
	 * 件名マスタ検索の入力チェックリストを定義
	 *
	 * @param reqMap
	 *            INPUTパラメータ
	 * @return
	 */
	private List<InputCheck> getCheckItemListForSearchKenmeiMaster(String siyoStartYmd) {

		List<InputCheck> inputCheckList = new ArrayList<InputCheck>();
		Map<Integer, Object> args;

		// 使用開始年月日
		if (StringUtils.isNotEmpty(siyoStartYmd)) {
			Map<String, Object> map = new HashMap<String, Object>();
			map.put("siyoStartYmd", siyoStartYmd);
			args = new HashMap<Integer, Object>();
			args.put(NSDConstant.CHECK_ITEM.DATE_FORMAT_CHECK.ordinal(), null);
			inputCheckList.add(setInputCheck(map, "siyoStartYmd", "使用開始年月日：", args));
		}

		return inputCheckList;
	}

	/*
	 * 組織マスタ全件取得
	 */
	@RequestMapping(value = "/autocomplete-selectSoshikiMaster", method = RequestMethod.GET)
	public Map<String, Object> selectSoshikiMaster() throws Exception {

		Map<String, Object> resultMap = new HashMap<String, Object>();

		List<Kss011> kss011List = new ArrayList<Kss011>();

		// サービスを呼び出す
		kss011List = autocompleteService.getSoshikiMaster();

		// 処理結果データ
		setDataToResultMap(resultMap, kss011List);

		return resultMap;
	}

	/*
	 * 組織定数の名称を取得
	 */
	@RequestMapping(value = "/autocomplete-selectSoshikTeisuMaster", method = RequestMethod.GET)
	public Map<String, Object> selectSoshikTeisuMaster() throws Exception {

		Map<String, Object> resultMap = new HashMap<String, Object>();

		List<Abda09> abda09List = new ArrayList<Abda09>();

		// サービスを呼び出す
		abda09List = autocompleteService.getSoshikTeisuMaster();

		// 処理結果データ
		setDataToResultMap(resultMap, abda09List);

		return resultMap;
	}

	/*
	 * 会計整理年月を取得
	 */
	@RequestMapping(value = "/autocomplete-selectKaikeiYmMaster", method = RequestMethod.POST)
	public Map<String, Object> selectKaikeiYmMaster() throws Exception {

		Map<String, Object> resultMap = new HashMap<String, Object>();

		List<Aads01> aads01List = new ArrayList<Aads01>();

		// サービスを呼び出す
		aads01List = autocompleteService.getKaikeiYmMaster();

		// 処理結果データ
		setDataToResultMap(resultMap, aads01List);

		return resultMap;
	}
}
