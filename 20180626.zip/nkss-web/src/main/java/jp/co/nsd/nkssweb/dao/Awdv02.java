package jp.co.nsd.nkssweb.dao;

public class Awdv02 {
    private String shuCod;

    private String kouCod;

    private String saiCod;

    private String shu4Cod;

    private String shu5Cod;

    private String shu6Cod;

    private String shuKnj;

    private String kouKnj;

    private String saiKnj;

    private String shu4Knj;

    private String shu5Knj;

    private String shu6Knj;

    private Short zeizanRit;

    private Short shozanRit;

    private Short zlstzanRit;

    private Short slstzanRit;

    private String kotshuCod;

    private String jtssnKbn;

    private String renynFlg;

    private String sisanKbn;

    private String skyKbn;

    private String shkhohCod;

    private String sshkhohCod;

    private Short zeitaiYs;

    private Short shotaiYs;

    public String getShuCod() {
        return shuCod;
    }

    public void setShuCod(String shuCod) {
        this.shuCod = shuCod == null ? null : shuCod.trim();
    }

    public String getKouCod() {
        return kouCod;
    }

    public void setKouCod(String kouCod) {
        this.kouCod = kouCod == null ? null : kouCod.trim();
    }

    public String getSaiCod() {
        return saiCod;
    }

    public void setSaiCod(String saiCod) {
        this.saiCod = saiCod == null ? null : saiCod.trim();
    }

    public String getShu4Cod() {
        return shu4Cod;
    }

    public void setShu4Cod(String shu4Cod) {
        this.shu4Cod = shu4Cod == null ? null : shu4Cod.trim();
    }

    public String getShu5Cod() {
        return shu5Cod;
    }

    public void setShu5Cod(String shu5Cod) {
        this.shu5Cod = shu5Cod == null ? null : shu5Cod.trim();
    }

    public String getShu6Cod() {
        return shu6Cod;
    }

    public void setShu6Cod(String shu6Cod) {
        this.shu6Cod = shu6Cod == null ? null : shu6Cod.trim();
    }

    public String getShuKnj() {
        return shuKnj;
    }

    public void setShuKnj(String shuKnj) {
        this.shuKnj = shuKnj == null ? null : shuKnj.trim();
    }

    public String getKouKnj() {
        return kouKnj;
    }

    public void setKouKnj(String kouKnj) {
        this.kouKnj = kouKnj == null ? null : kouKnj.trim();
    }

    public String getSaiKnj() {
        return saiKnj;
    }

    public void setSaiKnj(String saiKnj) {
        this.saiKnj = saiKnj == null ? null : saiKnj.trim();
    }

    public String getShu4Knj() {
        return shu4Knj;
    }

    public void setShu4Knj(String shu4Knj) {
        this.shu4Knj = shu4Knj == null ? null : shu4Knj.trim();
    }

    public String getShu5Knj() {
        return shu5Knj;
    }

    public void setShu5Knj(String shu5Knj) {
        this.shu5Knj = shu5Knj == null ? null : shu5Knj.trim();
    }

    public String getShu6Knj() {
        return shu6Knj;
    }

    public void setShu6Knj(String shu6Knj) {
        this.shu6Knj = shu6Knj == null ? null : shu6Knj.trim();
    }

    public Short getZeizanRit() {
        return zeizanRit;
    }

    public void setZeizanRit(Short zeizanRit) {
        this.zeizanRit = zeizanRit;
    }

    public Short getShozanRit() {
        return shozanRit;
    }

    public void setShozanRit(Short shozanRit) {
        this.shozanRit = shozanRit;
    }

    public Short getZlstzanRit() {
        return zlstzanRit;
    }

    public void setZlstzanRit(Short zlstzanRit) {
        this.zlstzanRit = zlstzanRit;
    }

    public Short getSlstzanRit() {
        return slstzanRit;
    }

    public void setSlstzanRit(Short slstzanRit) {
        this.slstzanRit = slstzanRit;
    }

    public String getKotshuCod() {
        return kotshuCod;
    }

    public void setKotshuCod(String kotshuCod) {
        this.kotshuCod = kotshuCod == null ? null : kotshuCod.trim();
    }

    public String getJtssnKbn() {
        return jtssnKbn;
    }

    public void setJtssnKbn(String jtssnKbn) {
        this.jtssnKbn = jtssnKbn == null ? null : jtssnKbn.trim();
    }

    public String getRenynFlg() {
        return renynFlg;
    }

    public void setRenynFlg(String renynFlg) {
        this.renynFlg = renynFlg == null ? null : renynFlg.trim();
    }

    public String getSisanKbn() {
        return sisanKbn;
    }

    public void setSisanKbn(String sisanKbn) {
        this.sisanKbn = sisanKbn == null ? null : sisanKbn.trim();
    }

    public String getSkyKbn() {
        return skyKbn;
    }

    public void setSkyKbn(String skyKbn) {
        this.skyKbn = skyKbn == null ? null : skyKbn.trim();
    }

    public String getShkhohCod() {
        return shkhohCod;
    }

    public void setShkhohCod(String shkhohCod) {
        this.shkhohCod = shkhohCod == null ? null : shkhohCod.trim();
    }

    public String getSshkhohCod() {
        return sshkhohCod;
    }

    public void setSshkhohCod(String sshkhohCod) {
        this.sshkhohCod = sshkhohCod == null ? null : sshkhohCod.trim();
    }

    public Short getZeitaiYs() {
        return zeitaiYs;
    }

    public void setZeitaiYs(Short zeitaiYs) {
        this.zeitaiYs = zeitaiYs;
    }

    public Short getShotaiYs() {
        return shotaiYs;
    }

    public void setShotaiYs(Short shotaiYs) {
        this.shotaiYs = shotaiYs;
    }
}