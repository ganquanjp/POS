package jp.co.nsd.nkssweb.service;

import java.util.Map;

import jp.co.nsd.nkssweb.dao.Abda09;
import jp.co.nsd.nkssweb.dao.Kss011;
import jp.co.nsd.nkssweb.dao.Kss013;

public interface InputCheckService {

	/**
	 * 組織連結名で組織マスタを検索、データ存在の確認
	 * 取得件数は１件以外の場合、入力チェックエラーとなる。
	 *
	 * @param soshikiRenNm
	 * @return
	 */
	Kss011 getSoshikiInfoForInputCheck (String soshikiRenNm);

	/**
	 * ユーザー名でユーザー情報を検索、データ存在の確認
	 * 取得件数は１件以外の場合、入力チェックエラーとなる。
	 *
	 * @param seimei
	 * @return
	 */
	Kss013 getUserInfoForInputCheck(String seimei);

	/**
	 * ユーザー名、組織コードで、DBを検索、ユーザーは該当組織に属してるを確認
	 * 取得件数は１件以外の場合、入力チェックエラーとなる。
	 *
	 * @param sqlWhere
	 * @return
	 */
	boolean isExistUserSoshikiForInputCheck(Map<String, String> sqlWhere);

	/**
	 * 固定資産番号で固定資産、固定資産明細、税制改正を検索、データ存在の確認
	 * 件数＞０の場合、存在しているを確認できます。
	 *
	 * @param sqlWhere 固定資産番号、新規・更新・削除フラグ
	 * @return
	 */
	boolean isExistKoteiSisanInfoForInputCheck(Map<String, String> sqlWhere);

	/**
	 * 組織名で組織定数を検索、データ存在の確認
	 *
	 * @param soshikiNm 組織名
	 * @return
	 */
	Abda09 getAbda09ForInputCheck(Abda09 abda09);
}
