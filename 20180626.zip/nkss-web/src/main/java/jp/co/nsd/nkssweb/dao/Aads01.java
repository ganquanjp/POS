package jp.co.nsd.nkssweb.dao;

import java.util.Date;

public class Aads01 {
    private String sa1KaikeiYm;

    private Date sa1InfromYmd;

    private Date sa1IntoYmd;

    private Date sa1SnkigYmd;

    private Date sa1GetsjsYmd;

    private Date sa1GetsmtDh;

    private Date sa1NendmtYmd;

    private Integer sa1UpdateCnt;

    private Date sa1TorokDh;

    private String sa1TorshaCod;

    private Date sa1UpdateDh;

    private String sa1UpdshaCod;

    public String getSa1KaikeiYm() {
        return sa1KaikeiYm;
    }

    public void setSa1KaikeiYm(String sa1KaikeiYm) {
        this.sa1KaikeiYm = sa1KaikeiYm == null ? null : sa1KaikeiYm.trim();
    }

    public Date getSa1InfromYmd() {
        return sa1InfromYmd;
    }

    public void setSa1InfromYmd(Date sa1InfromYmd) {
        this.sa1InfromYmd = sa1InfromYmd;
    }

    public Date getSa1IntoYmd() {
        return sa1IntoYmd;
    }

    public void setSa1IntoYmd(Date sa1IntoYmd) {
        this.sa1IntoYmd = sa1IntoYmd;
    }

    public Date getSa1SnkigYmd() {
        return sa1SnkigYmd;
    }

    public void setSa1SnkigYmd(Date sa1SnkigYmd) {
        this.sa1SnkigYmd = sa1SnkigYmd;
    }

    public Date getSa1GetsjsYmd() {
        return sa1GetsjsYmd;
    }

    public void setSa1GetsjsYmd(Date sa1GetsjsYmd) {
        this.sa1GetsjsYmd = sa1GetsjsYmd;
    }

    public Date getSa1GetsmtDh() {
        return sa1GetsmtDh;
    }

    public void setSa1GetsmtDh(Date sa1GetsmtDh) {
        this.sa1GetsmtDh = sa1GetsmtDh;
    }

    public Date getSa1NendmtYmd() {
        return sa1NendmtYmd;
    }

    public void setSa1NendmtYmd(Date sa1NendmtYmd) {
        this.sa1NendmtYmd = sa1NendmtYmd;
    }

    public Integer getSa1UpdateCnt() {
        return sa1UpdateCnt;
    }

    public void setSa1UpdateCnt(Integer sa1UpdateCnt) {
        this.sa1UpdateCnt = sa1UpdateCnt;
    }

    public Date getSa1TorokDh() {
        return sa1TorokDh;
    }

    public void setSa1TorokDh(Date sa1TorokDh) {
        this.sa1TorokDh = sa1TorokDh;
    }

    public String getSa1TorshaCod() {
        return sa1TorshaCod;
    }

    public void setSa1TorshaCod(String sa1TorshaCod) {
        this.sa1TorshaCod = sa1TorshaCod == null ? null : sa1TorshaCod.trim();
    }

    public Date getSa1UpdateDh() {
        return sa1UpdateDh;
    }

    public void setSa1UpdateDh(Date sa1UpdateDh) {
        this.sa1UpdateDh = sa1UpdateDh;
    }

    public String getSa1UpdshaCod() {
        return sa1UpdshaCod;
    }

    public void setSa1UpdshaCod(String sa1UpdshaCod) {
        this.sa1UpdshaCod = sa1UpdshaCod == null ? null : sa1UpdshaCod.trim();
    }
}