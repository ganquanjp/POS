package jp.co.nsd.nkssweb.dao;

import java.math.BigDecimal;
import java.util.Date;

public class Kss007 extends Kss007Key {
    private String motoKoteiShisanId;

    private String rirekiNo;

    private String jokyakuKbn;

    private String shuruiCd;

    private String kouzouCd;

    private String shisanTaniCd;

    private String kamokuCd1;

    private String kamokuCd2;

    private String kamokuCd3;

    private String jokyakuShubetsuCd;

    private BigDecimal jokyakuSuryo;

    private BigDecimal zanSuryo;

    private Long jokyakuGaku;

    private String chozoBunruiCd;

    private Long ksSelYen;

    private Long ksJkgenzYen;

    private Long ksJkgensYen;

    private Long ksJktk1Yen;

    private Long ksJktk1sYen;

    private Long ksJktk2Yen;

    private Long ksJktk2sYen;

    private Long ksJktk3Yen;

    private Long ksJktk3sYen;

    private Long ksJktk4Yen;

    private Long ksJktk4sYen;

    private Long ksJkgnrzYen;

    private Long ksJkgnrsYen;

    private Long ksJkbkazYen;

    private Long ksJkbkasYen;

    private Long ksJksonzYen;

    private Long ksJksonsYen;

    private Long biboKagakuZei;

    private Long biboKagakuSho;

    private Long ksJkagk1Yen;

    private Long ksJkagk2Yen;

    private Long ksJkagk3Yen;

    private Long ksJgtgnsYen;

    private Long ksJgendzYen;

    private Long ksJgendsYen;

    private Long ksJzanzYen;

    private Long ksJzansYen;

    private Long ksJmbkazYen;

    private Long ksJmbkasYen;

    private Long ksJmbkakYen;

    private Long ksJgnrzYen;

    private Long ksJgnrsYen;

    private Long ksJshorYen;

    private Long ksJnbkazYen;

    private Long ksJnbkasYen;

    private Long ksJnbkakYen;

    private Long ksJtkshzYen;

    private Long ksJtkshsYen;

    private Long ksJendzYen;

    private Long ksJendsYen;

    private Long ksJstbkzYen;

    private Long ksJstbksYen;

    private Long ksJtk1Yen;

    private Long ksJtk2Yen;

    private Long ksJtk3Yen;

    private Long ksJtk4Yen;

    private Long ksJtk1sYen;

    private Long ksJtk2sYen;

    private Long ksJtk3sYen;

    private Long ksJtk4sYen;

    private Long ksJtkr1Yen;

    private Long ksJtkr2Yen;

    private Long ksJtkr3Yen;

    private Long ksJtkr4Yen;

    private Long ksJtkr1sYen;

    private Long ksJtkr2sYen;

    private Long ksJtkr3sYen;

    private Long ksJtkr4sYen;

    private Long ksJsncsiYen;

    private Long ksJsnstkYen;

    private Long ksJyfbkaYen;

    private Long ksJyfhykYen;

    private Long ksJybbkaYen;

    private Long ksJybhykYen;

    private Long ksZkagk1Yen;

    private Long ksZkagk2Yen;

    private Long ksZkagk3Yen;

    private Long ksZgtkgkYen;

    private Long ksZgtgnsYen;

    private Long ksZgendzYen;

    private Long ksZgendsYen;

    private Long ksZzanzYen;

    private Long ksZzansYen;

    private Long ksZmbkazYen;

    private Long ksZmbkasYen;

    private Long ksZmbkakYen;

    private Long ksZgnrzYen;

    private Long ksZgnrsYen;

    private Long ksZshorYen;

    private Long ksZnbkazYen;

    private Long ksZnbkasYen;

    private Long ksZnbkakYen;

    private Long ksZtkshzYen;

    private Long ksZtkshsYen;

    private Long ksZendzYen;

    private Long ksZendsYen;

    private Long ksZstbkzYen;

    private Long ksZstbksYen;

    private Long ksZtk1Yen;

    private Long ksZtk2Yen;

    private Long ksZtk3Yen;

    private Long ksZtk4Yen;

    private Long ksZtk1sYen;

    private Long ksZtk2sYen;

    private Long ksZtk3sYen;

    private Long ksZtk4sYen;

    private Long ksZtkr1Yen;

    private Long ksZtkr2Yen;

    private Long ksZtkr3Yen;

    private Long ksZtkr4Yen;

    private Long ksZtkr1sYen;

    private Long ksZtkr2sYen;

    private Long ksZtkr3sYen;

    private Long ksZtkr4sYen;

    private Long ksZsncsiYen;

    private Long ksZsnstkYen;

    private Long ksZyfbkaYen;

    private Long ksZyfhykYen;

    private Long ksZybbkaYen;

    private Long ksZybhykYen;

    private String ksMeiCod;

    private String ksMeicoCod;

    private String ksMeirrkCod;

    private Long ksJkgensonYen;

    private Long ksJksonruiYen;

    private Long ksJgensonYen;

    private Long ksJsonruiYen;

    private Long ksJsonstaYen;

    private Long ksZgensonYen;

    private Long ksZsonruiYen;

    private Long ksZsonstaYen;

    private Date entryDate;

    private String entryUserId;

    private Date updateDate;

    private String updateUserId;

    public String getMotoKoteiShisanId() {
        return motoKoteiShisanId;
    }

    public void setMotoKoteiShisanId(String motoKoteiShisanId) {
        this.motoKoteiShisanId = motoKoteiShisanId == null ? null : motoKoteiShisanId.trim();
    }

    public String getRirekiNo() {
        return rirekiNo;
    }

    public void setRirekiNo(String rirekiNo) {
        this.rirekiNo = rirekiNo == null ? null : rirekiNo.trim();
    }

    public String getJokyakuKbn() {
        return jokyakuKbn;
    }

    public void setJokyakuKbn(String jokyakuKbn) {
        this.jokyakuKbn = jokyakuKbn == null ? null : jokyakuKbn.trim();
    }

    public String getShuruiCd() {
        return shuruiCd;
    }

    public void setShuruiCd(String shuruiCd) {
        this.shuruiCd = shuruiCd == null ? null : shuruiCd.trim();
    }

    public String getKouzouCd() {
        return kouzouCd;
    }

    public void setKouzouCd(String kouzouCd) {
        this.kouzouCd = kouzouCd == null ? null : kouzouCd.trim();
    }

    public String getShisanTaniCd() {
        return shisanTaniCd;
    }

    public void setShisanTaniCd(String shisanTaniCd) {
        this.shisanTaniCd = shisanTaniCd == null ? null : shisanTaniCd.trim();
    }

    public String getKamokuCd1() {
        return kamokuCd1;
    }

    public void setKamokuCd1(String kamokuCd1) {
        this.kamokuCd1 = kamokuCd1 == null ? null : kamokuCd1.trim();
    }

    public String getKamokuCd2() {
        return kamokuCd2;
    }

    public void setKamokuCd2(String kamokuCd2) {
        this.kamokuCd2 = kamokuCd2 == null ? null : kamokuCd2.trim();
    }

    public String getKamokuCd3() {
        return kamokuCd3;
    }

    public void setKamokuCd3(String kamokuCd3) {
        this.kamokuCd3 = kamokuCd3 == null ? null : kamokuCd3.trim();
    }

    public String getJokyakuShubetsuCd() {
        return jokyakuShubetsuCd;
    }

    public void setJokyakuShubetsuCd(String jokyakuShubetsuCd) {
        this.jokyakuShubetsuCd = jokyakuShubetsuCd == null ? null : jokyakuShubetsuCd.trim();
    }

    public BigDecimal getJokyakuSuryo() {
        return jokyakuSuryo;
    }

    public void setJokyakuSuryo(BigDecimal jokyakuSuryo) {
        this.jokyakuSuryo = jokyakuSuryo;
    }

    public BigDecimal getZanSuryo() {
        return zanSuryo;
    }

    public void setZanSuryo(BigDecimal zanSuryo) {
        this.zanSuryo = zanSuryo;
    }

    public Long getJokyakuGaku() {
        return jokyakuGaku;
    }

    public void setJokyakuGaku(Long jokyakuGaku) {
        this.jokyakuGaku = jokyakuGaku;
    }

    public String getChozoBunruiCd() {
        return chozoBunruiCd;
    }

    public void setChozoBunruiCd(String chozoBunruiCd) {
        this.chozoBunruiCd = chozoBunruiCd == null ? null : chozoBunruiCd.trim();
    }

    public Long getKsSelYen() {
        return ksSelYen;
    }

    public void setKsSelYen(Long ksSelYen) {
        this.ksSelYen = ksSelYen;
    }

    public Long getKsJkgenzYen() {
        return ksJkgenzYen;
    }

    public void setKsJkgenzYen(Long ksJkgenzYen) {
        this.ksJkgenzYen = ksJkgenzYen;
    }

    public Long getKsJkgensYen() {
        return ksJkgensYen;
    }

    public void setKsJkgensYen(Long ksJkgensYen) {
        this.ksJkgensYen = ksJkgensYen;
    }

    public Long getKsJktk1Yen() {
        return ksJktk1Yen;
    }

    public void setKsJktk1Yen(Long ksJktk1Yen) {
        this.ksJktk1Yen = ksJktk1Yen;
    }

    public Long getKsJktk1sYen() {
        return ksJktk1sYen;
    }

    public void setKsJktk1sYen(Long ksJktk1sYen) {
        this.ksJktk1sYen = ksJktk1sYen;
    }

    public Long getKsJktk2Yen() {
        return ksJktk2Yen;
    }

    public void setKsJktk2Yen(Long ksJktk2Yen) {
        this.ksJktk2Yen = ksJktk2Yen;
    }

    public Long getKsJktk2sYen() {
        return ksJktk2sYen;
    }

    public void setKsJktk2sYen(Long ksJktk2sYen) {
        this.ksJktk2sYen = ksJktk2sYen;
    }

    public Long getKsJktk3Yen() {
        return ksJktk3Yen;
    }

    public void setKsJktk3Yen(Long ksJktk3Yen) {
        this.ksJktk3Yen = ksJktk3Yen;
    }

    public Long getKsJktk3sYen() {
        return ksJktk3sYen;
    }

    public void setKsJktk3sYen(Long ksJktk3sYen) {
        this.ksJktk3sYen = ksJktk3sYen;
    }

    public Long getKsJktk4Yen() {
        return ksJktk4Yen;
    }

    public void setKsJktk4Yen(Long ksJktk4Yen) {
        this.ksJktk4Yen = ksJktk4Yen;
    }

    public Long getKsJktk4sYen() {
        return ksJktk4sYen;
    }

    public void setKsJktk4sYen(Long ksJktk4sYen) {
        this.ksJktk4sYen = ksJktk4sYen;
    }

    public Long getKsJkgnrzYen() {
        return ksJkgnrzYen;
    }

    public void setKsJkgnrzYen(Long ksJkgnrzYen) {
        this.ksJkgnrzYen = ksJkgnrzYen;
    }

    public Long getKsJkgnrsYen() {
        return ksJkgnrsYen;
    }

    public void setKsJkgnrsYen(Long ksJkgnrsYen) {
        this.ksJkgnrsYen = ksJkgnrsYen;
    }

    public Long getKsJkbkazYen() {
        return ksJkbkazYen;
    }

    public void setKsJkbkazYen(Long ksJkbkazYen) {
        this.ksJkbkazYen = ksJkbkazYen;
    }

    public Long getKsJkbkasYen() {
        return ksJkbkasYen;
    }

    public void setKsJkbkasYen(Long ksJkbkasYen) {
        this.ksJkbkasYen = ksJkbkasYen;
    }

    public Long getKsJksonzYen() {
        return ksJksonzYen;
    }

    public void setKsJksonzYen(Long ksJksonzYen) {
        this.ksJksonzYen = ksJksonzYen;
    }

    public Long getKsJksonsYen() {
        return ksJksonsYen;
    }

    public void setKsJksonsYen(Long ksJksonsYen) {
        this.ksJksonsYen = ksJksonsYen;
    }

    public Long getBiboKagakuZei() {
        return biboKagakuZei;
    }

    public void setBiboKagakuZei(Long biboKagakuZei) {
        this.biboKagakuZei = biboKagakuZei;
    }

    public Long getBiboKagakuSho() {
        return biboKagakuSho;
    }

    public void setBiboKagakuSho(Long biboKagakuSho) {
        this.biboKagakuSho = biboKagakuSho;
    }

    public Long getKsJkagk1Yen() {
        return ksJkagk1Yen;
    }

    public void setKsJkagk1Yen(Long ksJkagk1Yen) {
        this.ksJkagk1Yen = ksJkagk1Yen;
    }

    public Long getKsJkagk2Yen() {
        return ksJkagk2Yen;
    }

    public void setKsJkagk2Yen(Long ksJkagk2Yen) {
        this.ksJkagk2Yen = ksJkagk2Yen;
    }

    public Long getKsJkagk3Yen() {
        return ksJkagk3Yen;
    }

    public void setKsJkagk3Yen(Long ksJkagk3Yen) {
        this.ksJkagk3Yen = ksJkagk3Yen;
    }

    public Long getKsJgtgnsYen() {
        return ksJgtgnsYen;
    }

    public void setKsJgtgnsYen(Long ksJgtgnsYen) {
        this.ksJgtgnsYen = ksJgtgnsYen;
    }

    public Long getKsJgendzYen() {
        return ksJgendzYen;
    }

    public void setKsJgendzYen(Long ksJgendzYen) {
        this.ksJgendzYen = ksJgendzYen;
    }

    public Long getKsJgendsYen() {
        return ksJgendsYen;
    }

    public void setKsJgendsYen(Long ksJgendsYen) {
        this.ksJgendsYen = ksJgendsYen;
    }

    public Long getKsJzanzYen() {
        return ksJzanzYen;
    }

    public void setKsJzanzYen(Long ksJzanzYen) {
        this.ksJzanzYen = ksJzanzYen;
    }

    public Long getKsJzansYen() {
        return ksJzansYen;
    }

    public void setKsJzansYen(Long ksJzansYen) {
        this.ksJzansYen = ksJzansYen;
    }

    public Long getKsJmbkazYen() {
        return ksJmbkazYen;
    }

    public void setKsJmbkazYen(Long ksJmbkazYen) {
        this.ksJmbkazYen = ksJmbkazYen;
    }

    public Long getKsJmbkasYen() {
        return ksJmbkasYen;
    }

    public void setKsJmbkasYen(Long ksJmbkasYen) {
        this.ksJmbkasYen = ksJmbkasYen;
    }

    public Long getKsJmbkakYen() {
        return ksJmbkakYen;
    }

    public void setKsJmbkakYen(Long ksJmbkakYen) {
        this.ksJmbkakYen = ksJmbkakYen;
    }

    public Long getKsJgnrzYen() {
        return ksJgnrzYen;
    }

    public void setKsJgnrzYen(Long ksJgnrzYen) {
        this.ksJgnrzYen = ksJgnrzYen;
    }

    public Long getKsJgnrsYen() {
        return ksJgnrsYen;
    }

    public void setKsJgnrsYen(Long ksJgnrsYen) {
        this.ksJgnrsYen = ksJgnrsYen;
    }

    public Long getKsJshorYen() {
        return ksJshorYen;
    }

    public void setKsJshorYen(Long ksJshorYen) {
        this.ksJshorYen = ksJshorYen;
    }

    public Long getKsJnbkazYen() {
        return ksJnbkazYen;
    }

    public void setKsJnbkazYen(Long ksJnbkazYen) {
        this.ksJnbkazYen = ksJnbkazYen;
    }

    public Long getKsJnbkasYen() {
        return ksJnbkasYen;
    }

    public void setKsJnbkasYen(Long ksJnbkasYen) {
        this.ksJnbkasYen = ksJnbkasYen;
    }

    public Long getKsJnbkakYen() {
        return ksJnbkakYen;
    }

    public void setKsJnbkakYen(Long ksJnbkakYen) {
        this.ksJnbkakYen = ksJnbkakYen;
    }

    public Long getKsJtkshzYen() {
        return ksJtkshzYen;
    }

    public void setKsJtkshzYen(Long ksJtkshzYen) {
        this.ksJtkshzYen = ksJtkshzYen;
    }

    public Long getKsJtkshsYen() {
        return ksJtkshsYen;
    }

    public void setKsJtkshsYen(Long ksJtkshsYen) {
        this.ksJtkshsYen = ksJtkshsYen;
    }

    public Long getKsJendzYen() {
        return ksJendzYen;
    }

    public void setKsJendzYen(Long ksJendzYen) {
        this.ksJendzYen = ksJendzYen;
    }

    public Long getKsJendsYen() {
        return ksJendsYen;
    }

    public void setKsJendsYen(Long ksJendsYen) {
        this.ksJendsYen = ksJendsYen;
    }

    public Long getKsJstbkzYen() {
        return ksJstbkzYen;
    }

    public void setKsJstbkzYen(Long ksJstbkzYen) {
        this.ksJstbkzYen = ksJstbkzYen;
    }

    public Long getKsJstbksYen() {
        return ksJstbksYen;
    }

    public void setKsJstbksYen(Long ksJstbksYen) {
        this.ksJstbksYen = ksJstbksYen;
    }

    public Long getKsJtk1Yen() {
        return ksJtk1Yen;
    }

    public void setKsJtk1Yen(Long ksJtk1Yen) {
        this.ksJtk1Yen = ksJtk1Yen;
    }

    public Long getKsJtk2Yen() {
        return ksJtk2Yen;
    }

    public void setKsJtk2Yen(Long ksJtk2Yen) {
        this.ksJtk2Yen = ksJtk2Yen;
    }

    public Long getKsJtk3Yen() {
        return ksJtk3Yen;
    }

    public void setKsJtk3Yen(Long ksJtk3Yen) {
        this.ksJtk3Yen = ksJtk3Yen;
    }

    public Long getKsJtk4Yen() {
        return ksJtk4Yen;
    }

    public void setKsJtk4Yen(Long ksJtk4Yen) {
        this.ksJtk4Yen = ksJtk4Yen;
    }

    public Long getKsJtk1sYen() {
        return ksJtk1sYen;
    }

    public void setKsJtk1sYen(Long ksJtk1sYen) {
        this.ksJtk1sYen = ksJtk1sYen;
    }

    public Long getKsJtk2sYen() {
        return ksJtk2sYen;
    }

    public void setKsJtk2sYen(Long ksJtk2sYen) {
        this.ksJtk2sYen = ksJtk2sYen;
    }

    public Long getKsJtk3sYen() {
        return ksJtk3sYen;
    }

    public void setKsJtk3sYen(Long ksJtk3sYen) {
        this.ksJtk3sYen = ksJtk3sYen;
    }

    public Long getKsJtk4sYen() {
        return ksJtk4sYen;
    }

    public void setKsJtk4sYen(Long ksJtk4sYen) {
        this.ksJtk4sYen = ksJtk4sYen;
    }

    public Long getKsJtkr1Yen() {
        return ksJtkr1Yen;
    }

    public void setKsJtkr1Yen(Long ksJtkr1Yen) {
        this.ksJtkr1Yen = ksJtkr1Yen;
    }

    public Long getKsJtkr2Yen() {
        return ksJtkr2Yen;
    }

    public void setKsJtkr2Yen(Long ksJtkr2Yen) {
        this.ksJtkr2Yen = ksJtkr2Yen;
    }

    public Long getKsJtkr3Yen() {
        return ksJtkr3Yen;
    }

    public void setKsJtkr3Yen(Long ksJtkr3Yen) {
        this.ksJtkr3Yen = ksJtkr3Yen;
    }

    public Long getKsJtkr4Yen() {
        return ksJtkr4Yen;
    }

    public void setKsJtkr4Yen(Long ksJtkr4Yen) {
        this.ksJtkr4Yen = ksJtkr4Yen;
    }

    public Long getKsJtkr1sYen() {
        return ksJtkr1sYen;
    }

    public void setKsJtkr1sYen(Long ksJtkr1sYen) {
        this.ksJtkr1sYen = ksJtkr1sYen;
    }

    public Long getKsJtkr2sYen() {
        return ksJtkr2sYen;
    }

    public void setKsJtkr2sYen(Long ksJtkr2sYen) {
        this.ksJtkr2sYen = ksJtkr2sYen;
    }

    public Long getKsJtkr3sYen() {
        return ksJtkr3sYen;
    }

    public void setKsJtkr3sYen(Long ksJtkr3sYen) {
        this.ksJtkr3sYen = ksJtkr3sYen;
    }

    public Long getKsJtkr4sYen() {
        return ksJtkr4sYen;
    }

    public void setKsJtkr4sYen(Long ksJtkr4sYen) {
        this.ksJtkr4sYen = ksJtkr4sYen;
    }

    public Long getKsJsncsiYen() {
        return ksJsncsiYen;
    }

    public void setKsJsncsiYen(Long ksJsncsiYen) {
        this.ksJsncsiYen = ksJsncsiYen;
    }

    public Long getKsJsnstkYen() {
        return ksJsnstkYen;
    }

    public void setKsJsnstkYen(Long ksJsnstkYen) {
        this.ksJsnstkYen = ksJsnstkYen;
    }

    public Long getKsJyfbkaYen() {
        return ksJyfbkaYen;
    }

    public void setKsJyfbkaYen(Long ksJyfbkaYen) {
        this.ksJyfbkaYen = ksJyfbkaYen;
    }

    public Long getKsJyfhykYen() {
        return ksJyfhykYen;
    }

    public void setKsJyfhykYen(Long ksJyfhykYen) {
        this.ksJyfhykYen = ksJyfhykYen;
    }

    public Long getKsJybbkaYen() {
        return ksJybbkaYen;
    }

    public void setKsJybbkaYen(Long ksJybbkaYen) {
        this.ksJybbkaYen = ksJybbkaYen;
    }

    public Long getKsJybhykYen() {
        return ksJybhykYen;
    }

    public void setKsJybhykYen(Long ksJybhykYen) {
        this.ksJybhykYen = ksJybhykYen;
    }

    public Long getKsZkagk1Yen() {
        return ksZkagk1Yen;
    }

    public void setKsZkagk1Yen(Long ksZkagk1Yen) {
        this.ksZkagk1Yen = ksZkagk1Yen;
    }

    public Long getKsZkagk2Yen() {
        return ksZkagk2Yen;
    }

    public void setKsZkagk2Yen(Long ksZkagk2Yen) {
        this.ksZkagk2Yen = ksZkagk2Yen;
    }

    public Long getKsZkagk3Yen() {
        return ksZkagk3Yen;
    }

    public void setKsZkagk3Yen(Long ksZkagk3Yen) {
        this.ksZkagk3Yen = ksZkagk3Yen;
    }

    public Long getKsZgtkgkYen() {
        return ksZgtkgkYen;
    }

    public void setKsZgtkgkYen(Long ksZgtkgkYen) {
        this.ksZgtkgkYen = ksZgtkgkYen;
    }

    public Long getKsZgtgnsYen() {
        return ksZgtgnsYen;
    }

    public void setKsZgtgnsYen(Long ksZgtgnsYen) {
        this.ksZgtgnsYen = ksZgtgnsYen;
    }

    public Long getKsZgendzYen() {
        return ksZgendzYen;
    }

    public void setKsZgendzYen(Long ksZgendzYen) {
        this.ksZgendzYen = ksZgendzYen;
    }

    public Long getKsZgendsYen() {
        return ksZgendsYen;
    }

    public void setKsZgendsYen(Long ksZgendsYen) {
        this.ksZgendsYen = ksZgendsYen;
    }

    public Long getKsZzanzYen() {
        return ksZzanzYen;
    }

    public void setKsZzanzYen(Long ksZzanzYen) {
        this.ksZzanzYen = ksZzanzYen;
    }

    public Long getKsZzansYen() {
        return ksZzansYen;
    }

    public void setKsZzansYen(Long ksZzansYen) {
        this.ksZzansYen = ksZzansYen;
    }

    public Long getKsZmbkazYen() {
        return ksZmbkazYen;
    }

    public void setKsZmbkazYen(Long ksZmbkazYen) {
        this.ksZmbkazYen = ksZmbkazYen;
    }

    public Long getKsZmbkasYen() {
        return ksZmbkasYen;
    }

    public void setKsZmbkasYen(Long ksZmbkasYen) {
        this.ksZmbkasYen = ksZmbkasYen;
    }

    public Long getKsZmbkakYen() {
        return ksZmbkakYen;
    }

    public void setKsZmbkakYen(Long ksZmbkakYen) {
        this.ksZmbkakYen = ksZmbkakYen;
    }

    public Long getKsZgnrzYen() {
        return ksZgnrzYen;
    }

    public void setKsZgnrzYen(Long ksZgnrzYen) {
        this.ksZgnrzYen = ksZgnrzYen;
    }

    public Long getKsZgnrsYen() {
        return ksZgnrsYen;
    }

    public void setKsZgnrsYen(Long ksZgnrsYen) {
        this.ksZgnrsYen = ksZgnrsYen;
    }

    public Long getKsZshorYen() {
        return ksZshorYen;
    }

    public void setKsZshorYen(Long ksZshorYen) {
        this.ksZshorYen = ksZshorYen;
    }

    public Long getKsZnbkazYen() {
        return ksZnbkazYen;
    }

    public void setKsZnbkazYen(Long ksZnbkazYen) {
        this.ksZnbkazYen = ksZnbkazYen;
    }

    public Long getKsZnbkasYen() {
        return ksZnbkasYen;
    }

    public void setKsZnbkasYen(Long ksZnbkasYen) {
        this.ksZnbkasYen = ksZnbkasYen;
    }

    public Long getKsZnbkakYen() {
        return ksZnbkakYen;
    }

    public void setKsZnbkakYen(Long ksZnbkakYen) {
        this.ksZnbkakYen = ksZnbkakYen;
    }

    public Long getKsZtkshzYen() {
        return ksZtkshzYen;
    }

    public void setKsZtkshzYen(Long ksZtkshzYen) {
        this.ksZtkshzYen = ksZtkshzYen;
    }

    public Long getKsZtkshsYen() {
        return ksZtkshsYen;
    }

    public void setKsZtkshsYen(Long ksZtkshsYen) {
        this.ksZtkshsYen = ksZtkshsYen;
    }

    public Long getKsZendzYen() {
        return ksZendzYen;
    }

    public void setKsZendzYen(Long ksZendzYen) {
        this.ksZendzYen = ksZendzYen;
    }

    public Long getKsZendsYen() {
        return ksZendsYen;
    }

    public void setKsZendsYen(Long ksZendsYen) {
        this.ksZendsYen = ksZendsYen;
    }

    public Long getKsZstbkzYen() {
        return ksZstbkzYen;
    }

    public void setKsZstbkzYen(Long ksZstbkzYen) {
        this.ksZstbkzYen = ksZstbkzYen;
    }

    public Long getKsZstbksYen() {
        return ksZstbksYen;
    }

    public void setKsZstbksYen(Long ksZstbksYen) {
        this.ksZstbksYen = ksZstbksYen;
    }

    public Long getKsZtk1Yen() {
        return ksZtk1Yen;
    }

    public void setKsZtk1Yen(Long ksZtk1Yen) {
        this.ksZtk1Yen = ksZtk1Yen;
    }

    public Long getKsZtk2Yen() {
        return ksZtk2Yen;
    }

    public void setKsZtk2Yen(Long ksZtk2Yen) {
        this.ksZtk2Yen = ksZtk2Yen;
    }

    public Long getKsZtk3Yen() {
        return ksZtk3Yen;
    }

    public void setKsZtk3Yen(Long ksZtk3Yen) {
        this.ksZtk3Yen = ksZtk3Yen;
    }

    public Long getKsZtk4Yen() {
        return ksZtk4Yen;
    }

    public void setKsZtk4Yen(Long ksZtk4Yen) {
        this.ksZtk4Yen = ksZtk4Yen;
    }

    public Long getKsZtk1sYen() {
        return ksZtk1sYen;
    }

    public void setKsZtk1sYen(Long ksZtk1sYen) {
        this.ksZtk1sYen = ksZtk1sYen;
    }

    public Long getKsZtk2sYen() {
        return ksZtk2sYen;
    }

    public void setKsZtk2sYen(Long ksZtk2sYen) {
        this.ksZtk2sYen = ksZtk2sYen;
    }

    public Long getKsZtk3sYen() {
        return ksZtk3sYen;
    }

    public void setKsZtk3sYen(Long ksZtk3sYen) {
        this.ksZtk3sYen = ksZtk3sYen;
    }

    public Long getKsZtk4sYen() {
        return ksZtk4sYen;
    }

    public void setKsZtk4sYen(Long ksZtk4sYen) {
        this.ksZtk4sYen = ksZtk4sYen;
    }

    public Long getKsZtkr1Yen() {
        return ksZtkr1Yen;
    }

    public void setKsZtkr1Yen(Long ksZtkr1Yen) {
        this.ksZtkr1Yen = ksZtkr1Yen;
    }

    public Long getKsZtkr2Yen() {
        return ksZtkr2Yen;
    }

    public void setKsZtkr2Yen(Long ksZtkr2Yen) {
        this.ksZtkr2Yen = ksZtkr2Yen;
    }

    public Long getKsZtkr3Yen() {
        return ksZtkr3Yen;
    }

    public void setKsZtkr3Yen(Long ksZtkr3Yen) {
        this.ksZtkr3Yen = ksZtkr3Yen;
    }

    public Long getKsZtkr4Yen() {
        return ksZtkr4Yen;
    }

    public void setKsZtkr4Yen(Long ksZtkr4Yen) {
        this.ksZtkr4Yen = ksZtkr4Yen;
    }

    public Long getKsZtkr1sYen() {
        return ksZtkr1sYen;
    }

    public void setKsZtkr1sYen(Long ksZtkr1sYen) {
        this.ksZtkr1sYen = ksZtkr1sYen;
    }

    public Long getKsZtkr2sYen() {
        return ksZtkr2sYen;
    }

    public void setKsZtkr2sYen(Long ksZtkr2sYen) {
        this.ksZtkr2sYen = ksZtkr2sYen;
    }

    public Long getKsZtkr3sYen() {
        return ksZtkr3sYen;
    }

    public void setKsZtkr3sYen(Long ksZtkr3sYen) {
        this.ksZtkr3sYen = ksZtkr3sYen;
    }

    public Long getKsZtkr4sYen() {
        return ksZtkr4sYen;
    }

    public void setKsZtkr4sYen(Long ksZtkr4sYen) {
        this.ksZtkr4sYen = ksZtkr4sYen;
    }

    public Long getKsZsncsiYen() {
        return ksZsncsiYen;
    }

    public void setKsZsncsiYen(Long ksZsncsiYen) {
        this.ksZsncsiYen = ksZsncsiYen;
    }

    public Long getKsZsnstkYen() {
        return ksZsnstkYen;
    }

    public void setKsZsnstkYen(Long ksZsnstkYen) {
        this.ksZsnstkYen = ksZsnstkYen;
    }

    public Long getKsZyfbkaYen() {
        return ksZyfbkaYen;
    }

    public void setKsZyfbkaYen(Long ksZyfbkaYen) {
        this.ksZyfbkaYen = ksZyfbkaYen;
    }

    public Long getKsZyfhykYen() {
        return ksZyfhykYen;
    }

    public void setKsZyfhykYen(Long ksZyfhykYen) {
        this.ksZyfhykYen = ksZyfhykYen;
    }

    public Long getKsZybbkaYen() {
        return ksZybbkaYen;
    }

    public void setKsZybbkaYen(Long ksZybbkaYen) {
        this.ksZybbkaYen = ksZybbkaYen;
    }

    public Long getKsZybhykYen() {
        return ksZybhykYen;
    }

    public void setKsZybhykYen(Long ksZybhykYen) {
        this.ksZybhykYen = ksZybhykYen;
    }

    public String getKsMeiCod() {
        return ksMeiCod;
    }

    public void setKsMeiCod(String ksMeiCod) {
        this.ksMeiCod = ksMeiCod == null ? null : ksMeiCod.trim();
    }

    public String getKsMeicoCod() {
        return ksMeicoCod;
    }

    public void setKsMeicoCod(String ksMeicoCod) {
        this.ksMeicoCod = ksMeicoCod == null ? null : ksMeicoCod.trim();
    }

    public String getKsMeirrkCod() {
        return ksMeirrkCod;
    }

    public void setKsMeirrkCod(String ksMeirrkCod) {
        this.ksMeirrkCod = ksMeirrkCod == null ? null : ksMeirrkCod.trim();
    }

    public Long getKsJkgensonYen() {
        return ksJkgensonYen;
    }

    public void setKsJkgensonYen(Long ksJkgensonYen) {
        this.ksJkgensonYen = ksJkgensonYen;
    }

    public Long getKsJksonruiYen() {
        return ksJksonruiYen;
    }

    public void setKsJksonruiYen(Long ksJksonruiYen) {
        this.ksJksonruiYen = ksJksonruiYen;
    }

    public Long getKsJgensonYen() {
        return ksJgensonYen;
    }

    public void setKsJgensonYen(Long ksJgensonYen) {
        this.ksJgensonYen = ksJgensonYen;
    }

    public Long getKsJsonruiYen() {
        return ksJsonruiYen;
    }

    public void setKsJsonruiYen(Long ksJsonruiYen) {
        this.ksJsonruiYen = ksJsonruiYen;
    }

    public Long getKsJsonstaYen() {
        return ksJsonstaYen;
    }

    public void setKsJsonstaYen(Long ksJsonstaYen) {
        this.ksJsonstaYen = ksJsonstaYen;
    }

    public Long getKsZgensonYen() {
        return ksZgensonYen;
    }

    public void setKsZgensonYen(Long ksZgensonYen) {
        this.ksZgensonYen = ksZgensonYen;
    }

    public Long getKsZsonruiYen() {
        return ksZsonruiYen;
    }

    public void setKsZsonruiYen(Long ksZsonruiYen) {
        this.ksZsonruiYen = ksZsonruiYen;
    }

    public Long getKsZsonstaYen() {
        return ksZsonstaYen;
    }

    public void setKsZsonstaYen(Long ksZsonstaYen) {
        this.ksZsonstaYen = ksZsonstaYen;
    }

    public Date getEntryDate() {
        return entryDate;
    }

    public void setEntryDate(Date entryDate) {
        this.entryDate = entryDate;
    }

    public String getEntryUserId() {
        return entryUserId;
    }

    public void setEntryUserId(String entryUserId) {
        this.entryUserId = entryUserId == null ? null : entryUserId.trim();
    }

    public Date getUpdateDate() {
        return updateDate;
    }

    public void setUpdateDate(Date updateDate) {
        this.updateDate = updateDate;
    }

    public String getUpdateUserId() {
        return updateUserId;
    }

    public void setUpdateUserId(String updateUserId) {
        this.updateUserId = updateUserId == null ? null : updateUserId.trim();
    }
}