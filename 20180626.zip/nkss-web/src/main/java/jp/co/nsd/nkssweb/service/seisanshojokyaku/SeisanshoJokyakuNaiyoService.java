/***********************************************************************
*
*業務名: 工事精算システム
*機能名: 除却（登録・修正・削除）(サービス処理)
*
*機能概要: 除却情報を処理する。
*
*JavaＶｅｒ：J2SE1.8.0準拠
*
*更新履歴: Ver.1.00 2018/03/06　NSD　新規作成
***********************************************************************/
package jp.co.nsd.nkssweb.service.seisanshojokyaku;

import java.util.List;

import jp.co.nsd.nkssweb.dao.Kss007;
import jp.co.nsd.nkssweb.dao.SeisanshoJokyakuNaiyo;
import jp.co.nsd.nkssweb.dao.SeisanshoJokyakuNaiyoShokai;

/**
 * 除却（内容入力）処理
 *
 * @version 1.00
 */
public interface SeisanshoJokyakuNaiyoService {

	/**
	 * 除却（内容入力）検索
	 *
	 * @param seisanshoJokyakuNaiyo
	 *            INPUTパラメータ
	 * @return 検索結果
	 */
	List<SeisanshoJokyakuNaiyo> getJokyakuNaiyoInfo(SeisanshoJokyakuNaiyo seisanshoJokyakuNaiyo);

	/**
	 * 除却（内容入力）照会
	 *
	 * @param seisanshoJokyakuNaiyoShokai
	 *            INPUTパラメータ
	 * @return 検索結果
	 * @throws Exception
	 */
	SeisanshoJokyakuNaiyoShokai getJokyakuInfoBySeisanShoNo(SeisanshoJokyakuNaiyoShokai seisanshoJokyakuNaiyoShokai)
			throws Exception;

	/**
	 * 除却（内容入力）更新
	 *
	 * @param kss007UpdLst
	 *            INPUTパラメータ
	 * @return 更新件数
	 * @throws Exception
	 */
	int updateInfo(List<Kss007> kss007UpdLst) throws Exception;

	/**
	 * 除却（内容入力）印刷
	 *
	 * @param jokyakuSeisanShoId
	 *            INPUTパラメータ
	 * @return 結果
	 * @throws Exception
	 */
	List<String> printing(String jokyakuSeisanShoId) throws Exception;
}
