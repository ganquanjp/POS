package jp.co.nsd.nkssweb.controller.seisanshotoroku;

import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import jp.co.nsd.nkssweb.controller.BaseController;
import jp.co.nsd.nkssweb.service.seisanshotoroku.SeisanshoTorokuKmskJheService;
import jp.co.nsd.nkssweb.utils.NSDConstant;

@RestController
public class SeisanshoTorokuKmskJheController extends BaseController {

	@Autowired
	private SeisanshoTorokuKmskJheService seisanshoTorokuKmskJheService;

	/*
	 * 精算書登録・件名即時反映
	 */
	@RequestMapping(value = "/seisanshoTorokuKmskJhe-selectByWhere", method = RequestMethod.POST)
	public Map<String, Object> selectByBat(HttpServletRequest request, @RequestParam Map<String, Object> reqMap)
			throws Exception {

		Map<String, Object> resultMap = new HashMap<String, Object>();

		// サービス呼び出し
		seisanshoTorokuKmskJheService.getKenmeiInfo(getLoginUserInfo(request).getUserId());

		setMsgToResultMap(resultMap, NSDConstant.MSGID_INSERT_SUCCES);

		return resultMap;
	}

}
