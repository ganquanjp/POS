/***********************************************************************
*
*業務名: 工事精算システム
*機能名: 【バッチ】利用者連携
*
*機能概要: 【バッチ】ユーザー情報 / 所属情報を取り込む
*
*JavaＶｅｒ：J2SE1.8.0準拠
*
*更新履歴: Ver.1.00 2018/05/22　NSD　新規作成
***********************************************************************/
package jp.co.nsd.nkssbatch;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.mybatis.spring.annotation.MapperScan;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.PropertySource;

import jp.co.nsd.nkssweb.service.KoteshisanDaityoService;
import jp.co.nsd.nkssweb.service.RiyoshaRenkeiService;
import jp.co.nsd.nkssweb.service.seisanshotoroku.SeisanshoTorokuKmskJheService;
import jp.co.nsd.nkssweb.utils.NSDConstant;

@SpringBootApplication
@MapperScan("jp.co.nsd.nkssweb.dao.mapper")
@ComponentScan("jp.co.nsd.nkssweb.*")
@PropertySource("application.properties")
public class NkssBatch implements CommandLineRunner {

	@Autowired
	private RiyoshaRenkeiService riyoshaRenkeiService;

	@Autowired
	private KoteshisanDaityoService koteshisanDaityoService;

	@Autowired
	private SeisanshoTorokuKmskJheService seisanshoTorokuKmskJheService;

	public static void main(String[] args) {
		SpringApplication application = new SpringApplication(NkssBatch.class);
		application.setWebEnvironment(false);
		try {
			application.run(args);
			System.exit(0);
		}catch (Exception e) {

			boolean rs = false;
			if(NSDConstant.BATCH_CLASS_NAME_RIYOSHARENKEI.equals((String) args[0])){
	            String regEx = "FileNotFoundException";
	            Pattern pat = Pattern.compile(regEx);
	            Matcher mat = pat.matcher(e.getCause().toString());
	            rs = mat.find();
			}
			if (rs) {
				// コアシステム（基幹）サーバのファイル格納ディレクトリに利用者連携ファイルが存在しない場合、連動されるまで1分間隔で5分間wait処理を行う
				System.exit(2);
			}else{
				// 上記以外の異常
				System.exit(1);
			}
		}
	}

	/**
	 * Spring Boot起動時にCommandLineRunner#runメソッドが呼び出される
	 */
	public void run(String... args) throws Exception {

		if (NSDConstant.BATCH_CLASS_NAME_RIYOSHARENKEI.equals((String) args[0])) {

			// 利用者連携処理を呼び出し
			riyoshaRenkeiService.getRiyoshaInfo();

		} else if (NSDConstant.BATCH_CLASS_NAME_KOTESHISANDAITYO.equals((String) args[0])) {

			// 帳票出力処理を呼び出し
			// オペレータID：BATCH
			koteshisanDaityoService.getKoteshisanDaityo(NSDConstant.STRING_SAKUSEI_USER_ID_BATCH);

		} else if (NSDConstant.BATCH_CLASS_NAME_KENMEISOKUJIHANE.equals((String) args[0])) {

			// 帳票出力処理を呼び出し
			// オペレータID：BATCH
			seisanshoTorokuKmskJheService.getKenmeiInfo(NSDConstant.STRING_SAKUSEI_USER_ID_BATCH);

		} else {
			// 処理なし
		}

	}
}