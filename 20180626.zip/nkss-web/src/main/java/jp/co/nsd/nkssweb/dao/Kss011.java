package jp.co.nsd.nkssweb.dao;

import java.util.Date;

public class Kss011 {
    private String soshikiCd;

    private Date tekiyoStartYmd;

    private String disabledFlg;

    private String soshikiNm;

    private String soshikiRenNm;

    private Integer sortKey;

    private Long soshikiLevel;

    private String oyaSoshikiCd;

	public String getSoshikiCd() {
		return soshikiCd;
	}

	public void setSoshikiCd(String soshikiCd) {
		this.soshikiCd = soshikiCd;
	}

	public Date getTekiyoStartYmd() {
		return tekiyoStartYmd;
	}

	public void setTekiyoStartYmd(Date tekiyoStartYmd) {
		this.tekiyoStartYmd = tekiyoStartYmd;
	}

	public String getDisabledFlg() {
		return disabledFlg;
	}

	public void setDisabledFlg(String disabledFlg) {
		this.disabledFlg = disabledFlg;
	}

	public String getSoshikiNm() {
		return soshikiNm;
	}

	public void setSoshikiNm(String soshikiNm) {
		this.soshikiNm = soshikiNm;
	}

	public String getSoshikiRenNm() {
		return soshikiRenNm;
	}

	public void setSoshikiRenNm(String soshikiRenNm) {
		this.soshikiRenNm = soshikiRenNm;
	}

	public Integer getSortKey() {
		return sortKey;
	}

	public void setSortKey(Integer sortKey) {
		this.sortKey = sortKey;
	}

	public Long getSoshikiLevel() {
		return soshikiLevel;
	}

	public void setSoshikiLevel(Long soshikiLevel) {
		this.soshikiLevel = soshikiLevel;
	}

	public String getOyaSoshikiCd() {
		return oyaSoshikiCd;
	}

	public void setOyaSoshikiCd(String oyaSoshikiCd) {
		this.oyaSoshikiCd = oyaSoshikiCd;
	}





}