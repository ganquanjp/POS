package jp.co.nsd.nkssweb.dao;

import java.util.Date;

public class Abda09 {
    private String ab9SoshikCod;

    private Date ab9TekiyfYmd;

    private Date ab9TekiytYmd;

    private String ab9SiyoFlg;

    private String ab9SeksokFlg;

    private String ab9SeksosDef;

    private String ab9SoshikKnj;

    private String ab9SydaikFlg;

    private String ab9JoisosCod;

    private String ab9Shuyk1Cod;

    private String ab9Shuyk2Cod;

    private String ab9Shuyk3Cod;

    private String ab9KsssosCod;

    private String ab9KossanKbn;

    private String ab9StsoshKbn;

    private String ab9StsoshCod;

    private String ab9StssosFlg;

    private String ab9SoshikKbn;

    private String ab9TekingFlg;

    private Integer ab9UpdateCnt;

    private Date ab9TorokDh;

    private String ab9TorshaCod;

    private Date ab9UpdateDh;

    private String ab9UpdshaCod;

    public String getAb9SoshikCod() {
        return ab9SoshikCod;
    }

    public void setAb9SoshikCod(String ab9SoshikCod) {
        this.ab9SoshikCod = ab9SoshikCod == null ? null : ab9SoshikCod.trim();
    }

    public Date getAb9TekiyfYmd() {
        return ab9TekiyfYmd;
    }

    public void setAb9TekiyfYmd(Date ab9TekiyfYmd) {
        this.ab9TekiyfYmd = ab9TekiyfYmd;
    }

    public Date getAb9TekiytYmd() {
        return ab9TekiytYmd;
    }

    public void setAb9TekiytYmd(Date ab9TekiytYmd) {
        this.ab9TekiytYmd = ab9TekiytYmd;
    }

    public String getAb9SiyoFlg() {
        return ab9SiyoFlg;
    }

    public void setAb9SiyoFlg(String ab9SiyoFlg) {
        this.ab9SiyoFlg = ab9SiyoFlg == null ? null : ab9SiyoFlg.trim();
    }

    public String getAb9SeksokFlg() {
        return ab9SeksokFlg;
    }

    public void setAb9SeksokFlg(String ab9SeksokFlg) {
        this.ab9SeksokFlg = ab9SeksokFlg == null ? null : ab9SeksokFlg.trim();
    }

    public String getAb9SeksosDef() {
        return ab9SeksosDef;
    }

    public void setAb9SeksosDef(String ab9SeksosDef) {
        this.ab9SeksosDef = ab9SeksosDef == null ? null : ab9SeksosDef.trim();
    }

    public String getAb9SoshikKnj() {
        return ab9SoshikKnj;
    }

    public void setAb9SoshikKnj(String ab9SoshikKnj) {
        this.ab9SoshikKnj = ab9SoshikKnj == null ? null : ab9SoshikKnj.trim();
    }

    public String getAb9SydaikFlg() {
        return ab9SydaikFlg;
    }

    public void setAb9SydaikFlg(String ab9SydaikFlg) {
        this.ab9SydaikFlg = ab9SydaikFlg == null ? null : ab9SydaikFlg.trim();
    }

    public String getAb9JoisosCod() {
        return ab9JoisosCod;
    }

    public void setAb9JoisosCod(String ab9JoisosCod) {
        this.ab9JoisosCod = ab9JoisosCod == null ? null : ab9JoisosCod.trim();
    }

    public String getAb9Shuyk1Cod() {
        return ab9Shuyk1Cod;
    }

    public void setAb9Shuyk1Cod(String ab9Shuyk1Cod) {
        this.ab9Shuyk1Cod = ab9Shuyk1Cod == null ? null : ab9Shuyk1Cod.trim();
    }

    public String getAb9Shuyk2Cod() {
        return ab9Shuyk2Cod;
    }

    public void setAb9Shuyk2Cod(String ab9Shuyk2Cod) {
        this.ab9Shuyk2Cod = ab9Shuyk2Cod == null ? null : ab9Shuyk2Cod.trim();
    }

    public String getAb9Shuyk3Cod() {
        return ab9Shuyk3Cod;
    }

    public void setAb9Shuyk3Cod(String ab9Shuyk3Cod) {
        this.ab9Shuyk3Cod = ab9Shuyk3Cod == null ? null : ab9Shuyk3Cod.trim();
    }

    public String getAb9KsssosCod() {
        return ab9KsssosCod;
    }

    public void setAb9KsssosCod(String ab9KsssosCod) {
        this.ab9KsssosCod = ab9KsssosCod == null ? null : ab9KsssosCod.trim();
    }

    public String getAb9KossanKbn() {
        return ab9KossanKbn;
    }

    public void setAb9KossanKbn(String ab9KossanKbn) {
        this.ab9KossanKbn = ab9KossanKbn == null ? null : ab9KossanKbn.trim();
    }

    public String getAb9StsoshKbn() {
        return ab9StsoshKbn;
    }

    public void setAb9StsoshKbn(String ab9StsoshKbn) {
        this.ab9StsoshKbn = ab9StsoshKbn == null ? null : ab9StsoshKbn.trim();
    }

    public String getAb9StsoshCod() {
        return ab9StsoshCod;
    }

    public void setAb9StsoshCod(String ab9StsoshCod) {
        this.ab9StsoshCod = ab9StsoshCod == null ? null : ab9StsoshCod.trim();
    }

    public String getAb9StssosFlg() {
        return ab9StssosFlg;
    }

    public void setAb9StssosFlg(String ab9StssosFlg) {
        this.ab9StssosFlg = ab9StssosFlg == null ? null : ab9StssosFlg.trim();
    }

    public String getAb9SoshikKbn() {
        return ab9SoshikKbn;
    }

    public void setAb9SoshikKbn(String ab9SoshikKbn) {
        this.ab9SoshikKbn = ab9SoshikKbn == null ? null : ab9SoshikKbn.trim();
    }

    public String getAb9TekingFlg() {
        return ab9TekingFlg;
    }

    public void setAb9TekingFlg(String ab9TekingFlg) {
        this.ab9TekingFlg = ab9TekingFlg == null ? null : ab9TekingFlg.trim();
    }

    public Integer getAb9UpdateCnt() {
        return ab9UpdateCnt;
    }

    public void setAb9UpdateCnt(Integer ab9UpdateCnt) {
        this.ab9UpdateCnt = ab9UpdateCnt;
    }

    public Date getAb9TorokDh() {
        return ab9TorokDh;
    }

    public void setAb9TorokDh(Date ab9TorokDh) {
        this.ab9TorokDh = ab9TorokDh;
    }

    public String getAb9TorshaCod() {
        return ab9TorshaCod;
    }

    public void setAb9TorshaCod(String ab9TorshaCod) {
        this.ab9TorshaCod = ab9TorshaCod == null ? null : ab9TorshaCod.trim();
    }

    public Date getAb9UpdateDh() {
        return ab9UpdateDh;
    }

    public void setAb9UpdateDh(Date ab9UpdateDh) {
        this.ab9UpdateDh = ab9UpdateDh;
    }

    public String getAb9UpdshaCod() {
        return ab9UpdshaCod;
    }

    public void setAb9UpdshaCod(String ab9UpdshaCod) {
        this.ab9UpdshaCod = ab9UpdshaCod == null ? null : ab9UpdshaCod.trim();
    }
}