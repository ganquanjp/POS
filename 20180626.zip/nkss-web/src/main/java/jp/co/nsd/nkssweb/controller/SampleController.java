package jp.co.nsd.nkssweb.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import jp.co.nsd.nkssweb.dao.Sample;
import jp.co.nsd.nkssweb.service.SampleService;
import jp.co.nsd.nkssweb.utils.NSDConstant;

@RestController
public class SampleController extends BaseController {

	@Autowired
	private SampleService sampleService;

	@RequestMapping(value = "/sample-selectOne", method = RequestMethod.GET)
	public Map<String, Object> selectOne(@RequestParam(value = "userId", required = true) String userId) {

		// 返却値初期化
		Map<String, Object> resultMap = new HashMap<String, Object>();

		Sample sample = new Sample();

		try {
			// サービス呼出
			sample = sampleService.selectByPrimaryKey(userId);
		} catch (Exception e) {
			// エラーメッセージを返却Mapに設定する
			return setMsgToResultMap(resultMap, e);
		}

		// 検索結果を返却Mapに設定する
		setDataToResultMap(resultMap, sample);

		// 画面へ返却値を返却する
		return resultMap;
	}

	@RequestMapping(value = "/sample-selectAll", method = RequestMethod.GET)
	public Map<String, Object> selectAll() {

		// 返却値初期化
		Map<String, Object> resultMap = new HashMap<String, Object>();

		List<Sample> sampleList = new ArrayList<Sample>();

		try {
			// サービス呼出
			sampleList = sampleService.selectAll();

		} catch (Exception e) {
			// エラーメッセージを返却Mapに設定する
			return setMsgToResultMap(resultMap, e);
		}

		// 検索結果を返却Mapに設定する
		setDataToResultMap(resultMap, sampleList);

		// 画面へ返却値を返却する
		return resultMap;
	}

	@RequestMapping(value = "/sample-selectByWhere", method = RequestMethod.GET)
	public Map<String, Object> selectByWhere() {

		// 返却値初期化
		Map<String, Object> resultMap = new HashMap<String, Object>();
		List<Sample> sampleList = new ArrayList<Sample>();

		try {
			// サービス呼出
			sampleList = sampleService.selectByWhere();

		} catch (Exception e) {
			// エラーメッセージを返却Mapに設定する
			return setMsgToResultMap(resultMap, e);
		}

		// 検索結果を返却Mapに設定する
		setDataToResultMap(resultMap, sampleList);

		// 画面へ返却値を返却する
		return resultMap;
	}

	@RequestMapping(value = "/sample-callTestFunction", method = RequestMethod.GET)
	public Map<String, Object> callTestFunction(@RequestParam(value = "userId", required = true) String userId) {

		// 返却値初期化
		Map<String, Object> resultMap = new HashMap<String, Object>();

		try {
			// サービス呼出
			sampleService.callTestFunction(userId);

		} catch (Exception e) {
			// エラーメッセージを返却Mapに設定する
			return setMsgToResultMap(resultMap, e);
		}

		// 正常完了メッセージを返却する
		setMsgToResultMap(resultMap, NSDConstant.MSGID_INSERT_SUCCES);

		return resultMap;
	}
}
