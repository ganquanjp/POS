package jp.co.nsd.nkssweb.dao;

public class Aads01Collection extends Aads01 {

	// 行番
	private int rowNo;

	public int getRowNo() {
		return rowNo;
	}

	public void setRowNo(int rowNo) {
		this.rowNo = rowNo;
	}

}