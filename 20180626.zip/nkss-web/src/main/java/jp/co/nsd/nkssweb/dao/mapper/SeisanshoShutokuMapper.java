package jp.co.nsd.nkssweb.dao.mapper;

import java.util.List;
import java.util.Map;

import jp.co.nsd.nkssweb.dao.Awdv02;
import jp.co.nsd.nkssweb.dao.Kss005;
import jp.co.nsd.nkssweb.dao.Kss005Key;
import jp.co.nsd.nkssweb.dao.SeisanshoShutokuKensaku;
import jp.co.nsd.nkssweb.dao.SeisanshoShutokuShokai;

public interface SeisanshoShutokuMapper {

    List<SeisanshoShutokuKensaku> kensaku(SeisanshoShutokuKensaku record);

    List<SeisanshoShutokuShokai> shokai(SeisanshoShutokuShokai record);

    /**
     * 取得・削除
     *
     * @param key
     *            INPUTパラメータ
     * @return　検索結果
     */
    int deleteByPyKey(Kss005Key key);

    /**
     * 種類情報
     *
     * @param kss005
     *            INPUTパラメータ
     * @return　検索結果
     */
    List<Kss005> getShuruiInfo(Kss005 kss005);

	/**
	 * 条件より対象データが存在するかのチェック
	 *
	 * @return
	 */
	Integer getChkAwdv02(Awdv02 awdv02);

	/**
	 * 条件より種構細４５６の情報を取得
	 *
	 * @return
	 */
	Map<String, Object> getAwdv02Info(Awdv02 awdv02);
}