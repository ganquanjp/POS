package jp.co.nsd.nkssweb.utils;

import java.io.File;
import java.io.UnsupportedEncodingException;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

/**
 * プロパティファイルの値を読込
 *
 * @author nsdH272059
 *
 */
@Component
public class NSDProperties {

	@Value("${template.path}")
	private String templateFilePath;

	@Value("${template.excelname}")
	private String templateExcelName;

	@Value("${template.pdfname.KSS031-P040}")
	private String templatePdfNameKSS031P040;

	@Value("${template.pdfname.KSS031-P050}")
	private String templatePdfNameKSS031P050;

	@Value("${template.pdfname.KSS041-P040}")
	private String templatePdfNameKSS041P040;

	@Value("${template.pdfname.KSS041-P050}")
	private String templatePdfNameKSS041P050;

	@Value("${template.pdfname.KSS041-P060}")
	private String templatePdfNameKSS041P060;

	@Value("${template.pdfname.KSS042-P040}")
	private String templatePdfNameKSS042P040;

	@Value("${output.path.excel}")
	private String excelPath;

	@Value("${output.path.pdf}")
	private String pdfPath;

	@Value("${page.size}")
	private int pageSize;

	@Value("${batch.path.riyosharenkei}")
	private String batchPathRiyoshaRenkei;

	@Value("${batch.csvfile.kss011}")
	private String batchCsvFileKss011;

	@Value("${batch.csvfile.kss013}")
	private String batchCsvFileKss013;

	@Value("${batch.csvfile.kss014}")
	private String batchCsvFileKss014;

	@Value("${output.kmskjhe}")
	private String batchCsvFileKmskjhe;

	@Value("${ADAuthenticate.doAuth}")
	private String doAuthFlag;

	@Value("${ADAuthenticate.host}")
	private String ADAuthHost;

	@Value("${ADAuthenticate.port}")
	private String ADAuthPort;

	@Value("${ADAuthenticate.domain}")
	private String ADAuthDomain;

	public String getTemplateFilePath() {
		return templateFilePath;
	}

	public String getTemplateExcelName() {
		return getFileNameWithUTF8(templateExcelName);
	}

	public String getTemplatePdfNameKSS031P040() {
		return getFileNameWithUTF8(templatePdfNameKSS031P040);
	}

	public String getTemplatePdfNameKSS031P050() {
		return getFileNameWithUTF8(templatePdfNameKSS031P050);
	}

	public String getTemplatePdfNameKSS041P040() {
		return getFileNameWithUTF8(templatePdfNameKSS041P040);
	}

	public String getTemplatePdfNameKSS041P050() {
		return getFileNameWithUTF8(templatePdfNameKSS041P050);
	}

	public String getTemplatePdfNameKSS041P060() {
		return getFileNameWithUTF8(templatePdfNameKSS041P060);
	}

	public String getTemplatePdfNameKSS042P040() {
		return getFileNameWithUTF8(templatePdfNameKSS042P040);
	}

	public String getExcelPath() {
		createFolder(excelPath);
		return excelPath;
	}

	public String getPdfPath() {
		createFolder(pdfPath);
		return pdfPath;
	}

	public int getPageSize() {
		return pageSize;
	}

	public void setPageSize(int pageSize) {
		this.pageSize = pageSize;
	}

	public String getBatchPathRiyoshaRenkei() {
		createFolder(batchPathRiyoshaRenkei);
		return batchPathRiyoshaRenkei;
	}

	public String getBatchCsvFileKss011() {
		return getFileNameWithUTF8(batchCsvFileKss011);
	}

	public String getBatchCsvFileKss013() {
		return getFileNameWithUTF8(batchCsvFileKss013);
	}

	public String getBatchCsvFileKss014() {
		return getFileNameWithUTF8(batchCsvFileKss014);
	}

	public String getBatchCsvFileKmskjhe() {
		createFolder(batchCsvFileKmskjhe);
		return batchCsvFileKmskjhe;
	}

	public String getDoAuthFlag() {
		return doAuthFlag;
	}

	public void setDoAuthFlag(String doAuthFlag) {
		this.doAuthFlag = doAuthFlag;
	}

	public String getADAuthHost() {
		return ADAuthHost;
	}

	public void setADAuthHost(String aDAuthHost) {
		ADAuthHost = aDAuthHost;
	}

	public String getADAuthPort() {
		return ADAuthPort;
	}

	public void setADAuthPort(String aDAuthPort) {
		ADAuthPort = aDAuthPort;
	}

	public String getADAuthDomain() {
		return ADAuthDomain;
	}

	public void setADAuthDomain(String aDAuthDomain) {
		ADAuthDomain = aDAuthDomain;
	}

	/**
	 * ファイル名のエンコード転換
	 *
	 * @param filename
	 * @return
	 */
	private String getFileNameWithUTF8(String filename) {
		try {
			filename = NSDCommUtils.converISO8859ToUTF8(filename);
		} catch (UnsupportedEncodingException e) {
			filename = "";
		}

		return filename;
	}

	/**
	 * フォルダー存在してない場合、新規する。
	 *
	 * @param path
	 */
	private void createFolder(String path) {
		File file = new File(path);

		if (file.exists()) {
			if (!file.isDirectory()) {
				file.delete();
				file.mkdirs();
			}
		} else {
			file.mkdirs();
		}
	}
}
