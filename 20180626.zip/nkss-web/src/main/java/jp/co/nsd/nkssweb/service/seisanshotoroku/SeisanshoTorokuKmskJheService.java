package jp.co.nsd.nkssweb.service.seisanshotoroku;

public interface SeisanshoTorokuKmskJheService {

	/**
	 * 件名即時反映
	 *
	 * @param userId
	 *            オペレータID バッチ："BATCH"、画面：ログインユーザーID
	 * @return
	 * @throws Exception
	 */
	void getKenmeiInfo(String userId) throws Exception;

}
