package jp.co.nsd.nkssweb.dao;

public class BunkatsuSyunyuKoteiInfo {

	// ROWNO
	private int rowNo;

	// 精算書ID
	private String seisanShoId;

	// 固定資産ID
	private String koteiShisanId;

	// 固定資産番号
	private String koteiShisanNo;

	// 固定資産名称
	private String koteiShisanNm;

	// 取引先名称
	private String torihkKnj;

	// 取得年月日
	private String shutokuYmd;

	// 取得価額
	private String shutokuKagaku;

	// 種類
	private String shuKnj;

	// 構造
	private String kouKnj;

	// 資産単位
	private String saiKnj;

	// 科目1
	private String shu4Knj;

	// 科目2
	private String shu5Knj;

	// 科目3
	private String shu6Knj;

	// 備忘価額_税
	private String biboKagakuZei;

	// 備忘価額_商
	private String biboKagakuSho;

	// 償却可能限度額_税
	private String shokyakuGendoZei;

	// 償却可能限度額_商
	private String shokyakuGendoSho;

	// 償却方法_税
	private String syokyakuHohoZei;

	// 償却方法_商
	private String syokyakuHohoSho;

	// 残存率_税
	private String zanzonRitsuZei;

	// 残存率_商
	private String zanzonRitsuSho;

	// 耐用年数＿税
	private String taiyoNensuSho;

	// 耐用年数＿商
	private String taiyoNensuZei;

	public int getRowNo() {
		return rowNo;
	}

	public void setRowNo(int rowNo) {
		this.rowNo = rowNo;
	}

	public String getSeisanShoId() {
		return seisanShoId;
	}

	public void setSeisanShoId(String seisanShoId) {
		this.seisanShoId = seisanShoId;
	}

	public String getKoteiShisanId() {
		return koteiShisanId;
	}

	public void setKoteiShisanId(String koteiShisanId) {
		this.koteiShisanId = koteiShisanId;
	}

	public String getKoteiShisanNo() {
		return koteiShisanNo;
	}

	public void setKoteiShisanNo(String koteiShisanNo) {
		this.koteiShisanNo = koteiShisanNo;
	}

	public String getKoteiShisanNm() {
		return koteiShisanNm;
	}

	public void setKoteiShisanNm(String koteiShisanNm) {
		this.koteiShisanNm = koteiShisanNm;
	}

	public String getTorihkKnj() {
		return torihkKnj;
	}

	public void setTorihkKnj(String torihkKnj) {
		this.torihkKnj = torihkKnj;
	}

	public String getShutokuYmd() {
		return shutokuYmd;
	}

	public void setShutokuYmd(String shutokuYmd) {
		this.shutokuYmd = shutokuYmd;
	}

	public String getShutokuKagaku() {
		return shutokuKagaku;
	}

	public void setShutokuKagaku(String shutokuKagaku) {
		this.shutokuKagaku = shutokuKagaku;
	}

	public String getShuKnj() {
		return shuKnj;
	}

	public void setShuKnj(String shuKnj) {
		this.shuKnj = shuKnj;
	}

	public String getKouKnj() {
		return kouKnj;
	}

	public void setKouKnj(String kouKnj) {
		this.kouKnj = kouKnj;
	}

	public String getSaiKnj() {
		return saiKnj;
	}

	public void setSaiKnj(String saiKnj) {
		this.saiKnj = saiKnj;
	}

	public String getShu4Knj() {
		return shu4Knj;
	}

	public void setShu4Knj(String shu4Knj) {
		this.shu4Knj = shu4Knj;
	}

	public String getShu5Knj() {
		return shu5Knj;
	}

	public void setShu5Knj(String shu5Knj) {
		this.shu5Knj = shu5Knj;
	}

	public String getShu6Knj() {
		return shu6Knj;
	}

	public void setShu6Knj(String shu6Knj) {
		this.shu6Knj = shu6Knj;
	}

	public String getBiboKagakuZei() {
		return biboKagakuZei;
	}

	public void setBiboKagakuZei(String biboKagakuZei) {
		this.biboKagakuZei = biboKagakuZei;
	}

	public String getBiboKagakuSho() {
		return biboKagakuSho;
	}

	public void setBiboKagakuSho(String biboKagakuSho) {
		this.biboKagakuSho = biboKagakuSho;
	}

	public String getShokyakuGendoZei() {
		return shokyakuGendoZei;
	}

	public void setShokyakuGendoZei(String shokyakuGendoZei) {
		this.shokyakuGendoZei = shokyakuGendoZei;
	}

	public String getShokyakuGendoSho() {
		return shokyakuGendoSho;
	}

	public void setShokyakuGendoSho(String shokyakuGendoSho) {
		this.shokyakuGendoSho = shokyakuGendoSho;
	}

	public String getSyokyakuHohoZei() {
		return syokyakuHohoZei;
	}

	public void setSyokyakuHohoZei(String syokyakuHohoZei) {
		this.syokyakuHohoZei = syokyakuHohoZei;
	}

	public String getSyokyakuHohoSho() {
		return syokyakuHohoSho;
	}

	public void setSyokyakuHohoSho(String syokyakuHohoSho) {
		this.syokyakuHohoSho = syokyakuHohoSho;
	}

	public String getZanzonRitsuZei() {
		return zanzonRitsuZei;
	}

	public void setZanzonRitsuZei(String zanzonRitsuZei) {
		this.zanzonRitsuZei = zanzonRitsuZei;
	}

	public String getZanzonRitsuSho() {
		return zanzonRitsuSho;
	}

	public void setZanzonRitsuSho(String zanzonRitsuSho) {
		this.zanzonRitsuSho = zanzonRitsuSho;
	}

	public String getTaiyoNensuSho() {
		return taiyoNensuSho;
	}

	public void setTaiyoNensuSho(String taiyoNensuSho) {
		this.taiyoNensuSho = taiyoNensuSho;
	}

	public String getTaiyoNensuZei() {
		return taiyoNensuZei;
	}

	public void setTaiyoNensuZei(String taiyoNensuZei) {
		this.taiyoNensuZei = taiyoNensuZei;
	}
}