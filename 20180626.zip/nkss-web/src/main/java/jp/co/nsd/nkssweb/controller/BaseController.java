package jp.co.nsd.nkssweb.controller;

import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.ExceptionHandler;

import jp.co.nsd.nkssweb.dao.InputCheck;
import jp.co.nsd.nkssweb.dao.LoginUserInfo;
import jp.co.nsd.nkssweb.dao.Message;
import jp.co.nsd.nkssweb.service.SystemService;
import jp.co.nsd.nkssweb.utils.NSDConstant;

public class BaseController {

	@Autowired
	protected SystemService systemService;

	protected Logger logger = LoggerFactory.getLogger(this.getClass());

	/**
	 * 返却結果の設定
	 *
	 * @param dataList
	 * @return
	 */
	protected Map<String, Object> setDataToResultMap(Map<String, Object> resultMap, Object resultData) {

		// 処理結果データ
		if (null == resultData) {
			setMsgToResultMap(resultMap, NSDConstant.MSGID_NOT_FOUND_DATA);
		} else {
			resultMap.put(NSDConstant.RESULT_DATA_NAME, resultData);
		}

		return resultMap;
	}

	/**
	 * エラーメッセージをログに出力
	 *
	 * @param dataList
	 * @return
	 */
	protected void outputLog(Message message) {

		if (NSDConstant.LOG_LEVEL_ERROR.equals(message.getMsgLevel())) {
			logger.error(message.getContent());
		} else if (NSDConstant.LOG_LEVEL_WARN.equals(message.getMsgLevel())) {
			logger.warn(message.getContent());
		} else if (NSDConstant.LOG_LEVEL_INFO.equals(message.getMsgLevel())) {
			logger.info(message.getContent());
		} else if (NSDConstant.LOG_LEVEL_DEBUG.equals(message.getMsgLevel())) {
			logger.debug(message.getContent());
		} else if (NSDConstant.LOG_LEVEL_TRACE.equals(message.getMsgLevel())) {
			logger.trace(message.getContent());
		} else {
			// 処理なし
		}

	}

	/**
	 * DBよりメッセージを取得し、返却Mapに設定(ログ出力)
	 *
	 * @param resultMap
	 * @param msgId
	 * @return
	 */
	protected Map<String, Object> setMsgToResultMap(Map<String, Object> resultMap, String msgId) {

		// 画面表示メッセージ
		resultMap = setMsgToResultMapNoLog(resultMap, msgId);

		// ログに出力
		outputLog((Message) resultMap.get(NSDConstant.RESULT_MSG_NAME));

		return resultMap;
	}

	/**
	 * DBよりメッセージを取得し、返却Mapに設定(ログ出力)
	 *
	 * @param msgId
	 * @return
	 */
	protected Map<String, Object> setMsgToResultMap(Map<String, Object> resultMap, String msgId, String msgSubsidy) {

		// 画面表示メッセージ
		resultMap = setMsgToResultMapNoLog(resultMap, msgId, msgSubsidy);

		// ログに出力
		outputLog((Message) resultMap.get(NSDConstant.RESULT_MSG_NAME));

		return resultMap;
	}

	/**
	 * DBよりメッセージを取得し、返却Mapに設定(ログ出力)
	 *
	 * @param resultMap
	 * @param e
	 * @return
	 */
	protected Map<String, Object> setMsgToResultMap(Map<String, Object> resultMap, Exception e) {

		// 画面表示メッセージを取得する
		Message message = new Message();

		// ログに出力
		message.setMsgId(NSDConstant.MSGID_SYSTEM_ERROR);
		message.setContent(e.getMessage());
		outputLog(message);

		message = systemService.getMessage(NSDConstant.MSGID_SYSTEM_ERROR);
		resultMap.put(NSDConstant.RESULT_MSG_NAME, message);

		return resultMap;
	}

	/**
	 * Exceptioneエラー、返却Mapに設定(ログ出力)
	 *
	 * @param e
	 * @return
	 */
	@ExceptionHandler
	protected Map<String, Object> exception(Exception e) {

		Map<String, Object> resultMap = new HashMap<String, Object>();
		// 画面表示メッセージを取得する
		Message message = new Message();

		// ログに出力
		message.setMsgId(NSDConstant.MSGID_SYSTEM_ERROR);
		message.setContent(e.getMessage());
		outputLog(message);

		message = systemService.getMessage(NSDConstant.MSGID_SYSTEM_ERROR);
		resultMap.put(NSDConstant.RESULT_MSG_NAME, message);

		return resultMap;
	}

	/**
	 * DBよりメッセージを取得し、返却Mapに設定(ログ出力しない)
	 *
	 * @param resultMap
	 * @param msgId
	 * @return
	 */
	protected Map<String, Object> setMsgToResultMapNoLog(Map<String, Object> resultMap, String msgId) {

		// 画面表示メッセージ
		Message message = systemService.getMessage(msgId);
		resultMap.put(NSDConstant.RESULT_MSG_NAME, message);

		return resultMap;
	}

	/**
	 * DBよりメッセージを取得し、返却Mapに設定(ログ出力しない)
	 *
	 * @param resultMap
	 * @param msgId
	 * @return
	 */
	protected Map<String, Object> setMsgToResultMapNoLog(Map<String, Object> resultMap, String msgId, String msgSubsidy) {

		// 画面表示メッセージ
		Message message = systemService.getMessage(msgId);
		message.setContent(message.getContent().concat(msgSubsidy));
		resultMap.put(NSDConstant.RESULT_MSG_NAME, message);

		return resultMap;
	}

	/**
	 * ログインユーザー情報の取得
	 *
	 * @param request
	 * @return
	 */
	protected LoginUserInfo getLoginUserInfo(HttpServletRequest request) {
		return (LoginUserInfo) request.getSession().getAttribute("LoginUserInfo");
	}

	/**
	 * ログインユーザー情報はセッションにセットする
	 *
	 * @param request
	 * @return
	 */
	protected void setLoginUserInfo(HttpServletRequest request, LoginUserInfo loginUserInfo) {
		request.getSession().setAttribute("LoginUserInfo", loginUserInfo);
	}


	/**
	 * 入力チェック設定
	 * @param reqMap
	 * @param id
	 * @param name
	 * @param args
	 * @return
	 */
	protected InputCheck setInputCheck(Map<String, Object> reqMap, String id, String name, Map<Integer, Object> args) {
		InputCheck inputCheck = new InputCheck();
		inputCheck.setItemId(id);
		inputCheck.setItemName(name);
		if (StringUtils.isNotEmpty((String)reqMap.get(inputCheck.getItemId()))){
			inputCheck.setItemValue(reqMap.get(inputCheck.getItemId()).toString().trim());
		}
		inputCheck.setArgs(args);
		return inputCheck;
	}
}
