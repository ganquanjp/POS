package jp.co.nsd.nkssweb.service.seisanshotoroku;

import java.util.List;
import java.util.Map;

import jp.co.nsd.nkssweb.dao.Kss002;
import jp.co.nsd.nkssweb.dao.Kss004;
import jp.co.nsd.nkssweb.dao.SeisanshoToroku;

public interface SeisanshoTorokuService {

	/**
	 * 精算書登録・検索
	 *
	 * @return
	 */
	List<SeisanshoToroku> getSeisanshoTorokuKensaku(SeisanshoToroku selectCondition);

	/**
	 * 精算書登録・照会
	 *
	 * @return
	 */
	List<SeisanshoToroku> getSeisanshoTorokuShokai(SeisanshoToroku selectCondition);

	/**
	 * 精算書削除
	 *
	 * @param kenmeiId
	 *            件名ID
	 * @param seisanShoId
	 *            精算書ID
	 */
	void deleteSeisansho(Long kenmeiId, String seisanShoId);

	/**
	 * 精算書登録
	 *
	 * @param kss002
	 * @param kss004List
	 */
	void insertSeisansho(Kss002 kss002, List<Kss004> kss004List);

	/**
	 * 件名テーブルに未連携データを取得
	 *
	 * @param parameterMap
	 *            INPUTパラメータ
	 * @return 取得件数
	 */
	int selectKenmeiCdCnt(Map<String, Object> parameterMap);

	/**
	 * 科目内訳定数から入力した件名データを取得
	 *
	 * @param parameterMap
	 *            INPUTパラメータ
	 * @return 取得件数
	 */
	int selectAb8KenmeiCdCnt(Map<String, Object> parameterMap);

	/**
	 * 件名コード及び適用期間Fromが同一のデータを取得
	 *
	 * @param parameterMap
	 *            INPUTパラメータ
	 * @return 取得件数
	 */
	String selectAb8SameTekiyoFData(Map<String, Object> parameterMap);

	/**
	 * 適用期間が重複するデータを取得
	 *
	 * @param parameterMap
	 *            INPUTパラメータ
	 * @return 取得件数
	 */
	int selectAb8Kikan(Map<String, Object> parameterMap);

	/**
	 * 科目内訳定数廃止登録データの存在判定を取得
	 *
	 * @param parameterMap
	 *            INPUTパラメータ
	 * @return 取得件数
	 */
	String selectAb8HaiciData(Map<String, Object> parameterMap);

	/**
	 * 精算書修正
	 *
	 * @param kss002
	 * @param kss004
	 * @param kss004List
	 */
	void modifySeisansho(Kss002 kss002, Kss004 kss004, List<Kss004> kss004List);

}
