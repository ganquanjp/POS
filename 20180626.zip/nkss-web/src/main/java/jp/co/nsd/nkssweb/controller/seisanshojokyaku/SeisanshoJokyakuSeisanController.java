/***********************************************************************
*
*業務名: 工事精算システム
*機能名: 除却（精算通告）(ログ出力処理)
*
*機能概要: 除却情報を処理する。
*
*JavaＶｅｒ：J2SE1.8.0準拠
*
*更新履歴: Ver.1.00 2018/03/06　NSD　新規作成
***********************************************************************/

package jp.co.nsd.nkssweb.controller.seisanshojokyaku;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import jp.co.nsd.nkssweb.controller.BaseController;
import jp.co.nsd.nkssweb.dao.InputCheck;
import jp.co.nsd.nkssweb.dao.Kss006;
import jp.co.nsd.nkssweb.dao.SeisanshoJokyakuSeisan;
import jp.co.nsd.nkssweb.dao.SeisanshoJokyakuSeisanShokai;
import jp.co.nsd.nkssweb.service.CommService;
import jp.co.nsd.nkssweb.service.SystemService;
import jp.co.nsd.nkssweb.service.seisanshojokyaku.SeisanshoJokyakuSeisanService;
import jp.co.nsd.nkssweb.utils.NSDConstant;
import jp.co.nsd.nkssweb.utils.NSDDataCheck;

/**
 * 除却（精算通告）処理
 *
 * @version 1.00
 */
@RestController
public class SeisanshoJokyakuSeisanController extends BaseController {

	@Autowired
	private SeisanshoJokyakuSeisanService seisanshoJokyakuSeisanService;

	@Autowired
	protected SystemService systemService;

	@Autowired
	private CommService commService;

	@Autowired
	private NSDDataCheck nsdDataCheck;

	/**
	 * 除却（精算通告）検索処理
	 *
	 * @param reqMap
	 *            INPUTパラメータ
	 * @return 除却情報データ
	 * @throws Exception
	 * @version 1.00
	 */
	@RequestMapping(value = "/seisanshoJokyakuSeisan-selectByWhere", method = RequestMethod.POST)
	public Map<String, Object> selectByWhere(@RequestParam Map<String, Object> reqMap) throws Exception {

		Map<String, Object> resultMap = new HashMap<String, Object>();

		// 入力チェック
		String errStr = inputCheckForSearch(reqMap);
		if (StringUtils.isNotEmpty(errStr)) {
			return setMsgToResultMap(resultMap, NSDConstant.MSGID_INPUT_ERROR, errStr);
		}

		SeisanshoJokyakuSeisan seisanshoJokyakuSeisan = new SeisanshoJokyakuSeisan();

		List<SeisanshoJokyakuSeisan> sssJkkSsLst = new ArrayList<>();

		// Mapの情報をBeanのプロパティにセット
		BeanUtils.populate(seisanshoJokyakuSeisan, reqMap);

		// サービス呼び出し
		sssJkkSsLst = seisanshoJokyakuSeisanService.getJokyakuSeisanInfo(seisanshoJokyakuSeisan);
		// 検索結果を返却Mapに設定する
		return setDataToResultMap(resultMap, sssJkkSsLst);
	}

	/**
	 * 検索の入力データチェック
	 *
	 * @param reqMap
	 *            INPUTパラメータ
	 * @return エラーメッセージID
	 * @version 1.00
	 */
	private String inputCheckForSearch(Map<String, Object> reqMap) {

		List<InputCheck> inputCheckList = getCheckItemListForSearch(reqMap);
		return nsdDataCheck.dataCheck(inputCheckList);

	}

	/**
	 * 検索の入力チェックリストを定義
	 *
	 * @param reqMap
	 *            INPUTパラメータ
	 * @return
	 */
	private List<InputCheck> getCheckItemListForSearch(Map<String, Object> reqMap) {

		List<InputCheck> inputCheckList = new ArrayList<InputCheck>();
		Map<Integer, Object> args;

		// 除却年月日
		if (StringUtils.isNotEmpty((String) reqMap.get("jokyakuYmdFrom"))) {
			args = new HashMap<Integer, Object>();
			args.put(NSDConstant.CHECK_ITEM.DATE_FORMAT_CHECK.ordinal(), null);
			inputCheckList.add(setInputCheck(reqMap, "jokyakuYmdFrom", "除却年月日(From)：", args));
		}

		if (StringUtils.isNotEmpty((String) reqMap.get("jokyakuYmdTo"))) {
			args = new HashMap<Integer, Object>();
			args.put(NSDConstant.CHECK_ITEM.DATE_FORMAT_CHECK.ordinal(), null);
			inputCheckList.add(setInputCheck(reqMap, "jokyakuYmdTo", "除却年月日(To)：", args));
		}

		args = new HashMap<Integer, Object>();
		args.put(NSDConstant.CHECK_ITEM.DATE_COMPARE_CHECK.ordinal(), (String) reqMap.get("jokyakuYmdTo"));
		inputCheckList.add(setInputCheck(reqMap, "jokyakuYmdFrom", "除却年月日：", args));

		return inputCheckList;
	}

	/**
	 * 除却（精算通告）照会処理
	 *
	 * @param reqMap
	 *            INPUTパラメータ
	 * @return 除却情報データ
	 * @throws Exception
	 * @version 1.00
	 */
	@RequestMapping(value = "/seisanshoJokyakuSeisan-selectBySeisanShoNo", method = RequestMethod.POST)
	public Map<String, Object> selectBySeisanShoNo(@RequestParam Map<String, Object> reqMap) throws Exception {

		Map<String, Object> resultMap = new HashMap<String, Object>();

		SeisanshoJokyakuSeisanShokai seisanshoJokyakuSeisanShokai = new SeisanshoJokyakuSeisanShokai();

		// Mapの情報をBeanのプロパティにセット
		BeanUtils.populate(seisanshoJokyakuSeisanShokai, reqMap);

		// サービス呼び出し
		SeisanshoJokyakuSeisanShokai sssJkkSsSkDto = seisanshoJokyakuSeisanService
				.getJokyakuInfoBySeisanShoNo(seisanshoJokyakuSeisanShokai);

		// 検索結果を返却Mapに設定する
		return setDataToResultMap(resultMap, sssJkkSsSkDto);
	}

	/**
	 * 除却（精算通告）更新処理
	 *
	 * @param reqMap
	 *            INPUTパラメータ
	 * @throws Exception
	 * @version 1.00
	 */
	@RequestMapping(value = "/seisanshoJokyakuSeisan-updateInfo", method = RequestMethod.POST)
	public Map<String, Object> updateInfo(HttpServletRequest request, @RequestParam Map<String, Object> reqMap) throws Exception {

		Map<String, Object> resultMap = new HashMap<String, Object>();

		// 入力チェック
		String errStr = inputCheckForUpdate(reqMap);
		if (StringUtils.isNotEmpty(errStr)) {
			return setMsgToResultMap(resultMap, NSDConstant.MSGID_INPUT_ERROR, errStr);
		}

		// 除却資産書ＩＤ
		String jokyakuSeisanShoId = (String) reqMap.get("jokyakuSeisanShoId");

		Date date = new Date();

		SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd");

		// 除却年月日
		String jokyakuYmd = (String) reqMap.get("jokyakuYmd");

		Kss006 kss006 = new Kss006();
		// 除却資産書ＩＤ
		kss006.setJokyakuSeisanShoId(jokyakuSeisanShoId);
		// 除却年月日
		if (StringUtils.isEmpty(jokyakuYmd)) {
			kss006.setJokyakuYmd(null);
		} else {
			kss006.setJokyakuYmd(sdf.parse(jokyakuYmd.replaceAll("-", "/")));
		}

		// 更新年月日
		kss006.setUpdateDate(date);
		// 更新ユーザーＩＤ
		kss006.setUpdateUserId(this.getLoginUserInfo(request).getUserId());

		// 排他チェック
		String errId = commService.doHaita(kss006, (String)reqMap.get("updateDate"));
		if (!NSDConstant.BLANK_STRING.equals(errId)){
			return setMsgToResultMap(resultMap, errId);
		}

		// サービス呼び出し
		seisanshoJokyakuSeisanService.updateInfo(kss006);

		// 処理結果データ
		resultMap.put(NSDConstant.RESULT_DATA_NAME, "");

		return setMsgToResultMapNoLog(resultMap, NSDConstant.MSGID_UPDATE_SUCCES);
	}

	/**
	 * 更新の入力データチェック
	 *
	 * @param reqMap
	 *            INPUTパラメータ
	 * @return エラーメッセージID
	 * @version 1.00
	 */
	private String inputCheckForUpdate(Map<String, Object> reqMap) {

		List<InputCheck> inputCheckList = getCheckItemListForUpdate(reqMap);
		return nsdDataCheck.dataCheck(inputCheckList);

	}

	/**
	 * 更新の入力チェックリストを定義
	 *
	 * @param reqMap
	 *            INPUTパラメータ
	 * @return
	 */
	private List<InputCheck> getCheckItemListForUpdate(Map<String, Object> reqMap) {

		List<InputCheck> inputCheckList = new ArrayList<InputCheck>();
		Map<Integer, Object> args;

		// 除却年月日
		if (StringUtils.isNotEmpty((String) reqMap.get("jokyakuYmd"))) {
			args = new HashMap<Integer, Object>();
			args.put(NSDConstant.CHECK_ITEM.DATE_FORMAT_CHECK.ordinal(), null);
			inputCheckList.add(setInputCheck(reqMap, "jokyakuYmd", "除却年月日：", args));
		}

		return inputCheckList;
	}
}
