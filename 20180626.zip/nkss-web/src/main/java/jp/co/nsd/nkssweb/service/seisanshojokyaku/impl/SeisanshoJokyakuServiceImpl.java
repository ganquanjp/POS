/***********************************************************************
*
*業務名: 工事精算システム
*機能名: 除却（登録・修正・削除）(サービス処理)
*
*機能概要: 除却情報を処理する。
*
*JavaＶｅｒ：J2SE1.8.0準拠
*
*更新履歴: Ver.1.00 2018/03/06　NSD　新規作成
***********************************************************************/
package jp.co.nsd.nkssweb.service.seisanshojokyaku.impl;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.beanutils.BeanUtils;
import org.postgresql.util.PSQLException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import jp.co.nsd.nkssweb.dao.KoteiSisan;
import jp.co.nsd.nkssweb.dao.Kss006;
import jp.co.nsd.nkssweb.dao.Kss007;
import jp.co.nsd.nkssweb.dao.Kss007Key;
import jp.co.nsd.nkssweb.dao.SeisanshoJokyaku;
import jp.co.nsd.nkssweb.dao.SeisanshoJokyakuKoteiSisan;
import jp.co.nsd.nkssweb.dao.SeisanshoJokyakuShokai;
import jp.co.nsd.nkssweb.dao.SeisanshoJokyakuShokaiList;
import jp.co.nsd.nkssweb.dao.mapper.Kss006Mapper;
import jp.co.nsd.nkssweb.dao.mapper.Kss007Mapper;
import jp.co.nsd.nkssweb.dao.mapper.SeisanshoJokyakuMapper;
import jp.co.nsd.nkssweb.dao.mapper.StoredMapper;
import jp.co.nsd.nkssweb.oracle.mapper.KoteiSisanJyohoMapper;
import jp.co.nsd.nkssweb.oracle.mapper.OracleStoredMapper;
import jp.co.nsd.nkssweb.service.CommService;
import jp.co.nsd.nkssweb.service.seisanshojokyaku.SeisanshoJokyakuService;
import jp.co.nsd.nkssweb.utils.NSDConstant;

/**
 * 除却（登録・修正・削除）処理
 *
 * @see SeisanshoJokyakuService
 * @version 1.00
 */
@Service
public class SeisanshoJokyakuServiceImpl implements SeisanshoJokyakuService {

	@Autowired
	private SeisanshoJokyakuMapper seisanshoJokyakuMapper;

	@Autowired
	private KoteiSisanJyohoMapper koteiSisanJyohoMapper;

	@Autowired
	private Kss006Mapper kss006Mapper;

	@Autowired
	private Kss007Mapper kss007Mapper;

	@Autowired
	private CommService commService;

	@Autowired
	private StoredMapper storedMapper;

	@Autowired
	private OracleStoredMapper oracleStoredMapper;

	/**
	 * 除却（検索）処理
	 *
	 * @param seisanshoJokyaku
	 *            INPUTパラメータ
	 * @return sssJykList 除却情報データリスト
	 * @version 1.00
	 */
	public List<SeisanshoJokyaku> getJokyakuInfo(SeisanshoJokyaku seisanshoJokyaku) {

		// 除却情報を取得する
		List<SeisanshoJokyaku> sssJykList = seisanshoJokyakuMapper.selectByWhere(seisanshoJokyaku);

		if (sssJykList.size() > 0) {
			for (int i = 1; i <= sssJykList.size(); i++) {
				// ROWNOを設定する
				sssJykList.get(i - 1).setRowNo(i);
			}

		} else {
			sssJykList = null;
		}

		return sssJykList;
	}

	/**
	 * 除却（照会）処理
	 *
	 * @param seisanshoJokyakuShokai
	 *            INPUTパラメータ
	 * @return SeisanshoJokyakuShokaiList 除却情報データ
	 * @version 1.00
	 */
	public SeisanshoJokyakuShokaiList getJokyakuInfoBySeisanShoNo(SeisanshoJokyakuShokai selectCondition)
			throws Exception {

		// 除却情報
		SeisanshoJokyakuShokaiList resultDto = new SeisanshoJokyakuShokaiList();

		// 除却資産情報を取得する
		List<SeisanshoJokyakuShokai> sssJykSkList = seisanshoJokyakuMapper.selectBySeisanShoNo(selectCondition);

		List<SeisanshoJokyakuKoteiSisan> sssJykKsLst = new ArrayList<>();

		int rowNo = 0;
		for (int i = 0; i < sssJykSkList.size(); i++) {
			// 除却資産情報
			SeisanshoJokyakuShokai sssJykSkDto = sssJykSkList.get(i);

			// 除却固定資産情報
			SeisanshoJokyakuKoteiSisan sssJykKsDto = new SeisanshoJokyakuKoteiSisan();

			// Mapの情報をBeanのプロパティにセット
			BeanUtils.copyProperties(resultDto, sssJykSkDto);

			KoteiSisan koteiSisan = new KoteiSisan();
			// 固定ID
			koteiSisan.setKoteiCod(sssJykSkDto.getMotoKoteiShisanId());
			// 履歴ID
			koteiSisan.setRrkCod(sssJykSkDto.getRrkCod());
			// 固定資産情報を取得する
			KoteiSisan ksLstDto = koteiSisanJyohoMapper.selectKoteiSisanByKoteiCod(koteiSisan);

			// 固定資産情報取得できた場合
			if (null != ksLstDto) {
				rowNo += 1;
				// 固定資産情報
				KoteiSisan ksDto = ksLstDto;
				// ROWNO
				ksDto.setRowNo(rowNo);

				// 子資産残
				if (NSDConstant.STRING_0.equals(ksDto.getKoshiKbn())) {
					// 無
					ksDto.setKoshiKbn(NSDConstant.NASI);
				} else if (NSDConstant.STRING_1.equals(ksDto.getKoshiKbn())) {
					// 有
					ksDto.setKoshiKbn(NSDConstant.ARI);
				} else {
					// 処理なし
				}

				BeanUtils.copyProperties(sssJykKsDto, ksDto);

				// 除却資産ID
				sssJykKsDto.setJokyakuShisanId(sssJykSkDto.getJokyakuShisanId());

				// 固定資産情報を追加
				sssJykKsLst.add(sssJykKsDto);
			}

		}
		// 固定資産情報リスト
		resultDto.setKoteiSisanLst(sssJykKsLst);

		if (sssJykKsLst.size() == 0) {
			return null;
		}

		return resultDto;
	}

	/**
	 * 除却（削除）処理
	 *
	 * @param seisanshoJokyaku
	 *            INPUTパラメータ
	 * @param userId
	 *            INPUTパラメータ
	 * @return cnt
	 * @version 1.00
	 */
	@Transactional(value = "postgresqlTransactionManager")
	public int delByPyKey(String jokyakuSeisanShoId, String userId) {

		Kss007Key kss007Key = new Kss007Key();
		// 除却精算書ＩＤ
		kss007Key.setJokyakuSeisanShoId(jokyakuSeisanShoId);

		List<Kss007> kss007Lst = seisanshoJokyakuMapper.selectByPyKey(kss007Key);

		// 除却資産明細情報を削除
		int kss007cnt = seisanshoJokyakuMapper.deleteByPyKey(kss007Key);
		// 削除件数判断(除却資産明細)
		if (kss007cnt > 0) {
			Date date = new Date();
			// 除却資産情報を削除
			int kss006cnt = kss006Mapper.deleteByPrimaryKey(jokyakuSeisanShoId);

			// 削除件数判断(除却資産)
			if (kss006cnt > 0) {
				for (int i = 0; i < kss007Lst.size(); i++) {

					Kss007 kss007 = kss007Lst.get(i);

					// 更新日付
					kss007.setUpdateDate(date);
					// 更新者コード
					kss007.setUpdateUserId(userId);

					// 除却精算制御区分更新処理
					setJkkseiKbn(kss007, NSDConstant.JYOKYAKU_SEISAN_SEIGYO_0);
				}
			}
		}
		return 0;
	}

	/**
	 * 除却（登録）処理
	 *
	 * @param kss006
	 *            INPUTパラメータ
	 * @param kss007Lst
	 *            INPUTパラメータ
	 * @return cnt
	 * @version 1.00
	 * @throws Exception
	 */
	public int insertInfo(Kss006 kss006, List<Kss007> kss007Lst) throws Exception {
		List<Kss007> kss007rollBackLst = new ArrayList<Kss007>();
		List<SeisanshoJokyaku> jkkseiKbnbefUplist = new ArrayList<SeisanshoJokyaku>();
		try {
			// 除却精算書ＩＤ採番
			String seqJokyakuSeisanShoId = commService.getSequence(NSDConstant.KSS_SEQ_SEISAN_SHO_ID);
			// 除却精算書番号採番
			String seqjokyakuSeisanShoNo = commService.getSequence(NSDConstant.KSS_SEQ_JOKYAKU_SEISAN_SHO_NO);
			// 版数採番
			String seqHansu = commService.getSequence(NSDConstant.KSS_SEQ_HANSU);
			// 除却精算書ＩＤ
			kss006.setJokyakuSeisanShoId(seqJokyakuSeisanShoId);
			// 除却精算書番号
			kss006.setJokyakuSeisanShoNo(seqjokyakuSeisanShoNo);
			// 版数
			kss006.setHansu(new BigDecimal(seqHansu));
			// 承認ステータス
			kss006.setShoninStatus(NSDConstant.SHONIN_STATUS_CODE_TOROKU);

			// 除却資産ＩＤ
			String seqjokyakuShisanId = NSDConstant.BLANK_STRING;
			// 除却資産登録
			int cnt = kss006Mapper.insertSelective(kss006);
			if (0 < cnt) {
				// 除却資産明細
				for (Kss007 kss007 : kss007Lst) {
					SeisanshoJokyaku seisanshoJokyaku = new SeisanshoJokyaku();
					kss007 = setKss007Default(kss007);
					// 除却精算書ＩＤ
					kss007.setJokyakuSeisanShoId(kss006.getJokyakuSeisanShoId());
					// 除却資産ＩＤ
					seqjokyakuShisanId = commService.getSequence(NSDConstant.KSS_SEQ_KOTEI_SHISAN_ID);
					kss007.setJokyakuShisanId(seqjokyakuShisanId);
					// 除却区分コード(「0:全部除却」を設定)
					kss007.setJokyakuKbn(NSDConstant.STRING_0);
					// 除却種別コード(「4:その他」を設定)
					kss007.setJokyakuShubetsuCd(NSDConstant.SHUBETU_CD_SONOTA);

					// 除却資産明細登録

					cnt = kss007Mapper.insertSelective(kss007);
					kss007rollBackLst.add(kss007);
					if (0 < cnt) {
						// 除却精算制御区分更新処理
						seisanshoJokyaku = setJkkseiKbn(kss007, NSDConstant.JYOKYAKU_SEISAN_SEIGYO_1);
						jkkseiKbnbefUplist.add(seisanshoJokyaku);
					}
				}

				// 除却（登録）ストアド処理
				try {
					Map<String, Object> map = new HashMap<String, Object>();
					map.put("jokyakuSeisanShoId", kss006.getJokyakuSeisanShoId());
					map.put("shoriKbn", "0");
					// 登録後の処理
					doSetAllKs2020BefOra(map);
					doSetAllKs2020AftOra(map);
				} catch (Exception e) {
					throw new PSQLException("減価償却計算処理でエラーが発生しました. error=[" + e.getMessage() + "]", null);
				}
			}
		} catch (Exception e) {
			kss006Mapper.deleteByPrimaryKey(kss006.getJokyakuSeisanShoId());
			for (Kss007 kss007 : kss007rollBackLst) {
				kss007Mapper.deleteByPrimaryKey(kss007);
			}
			for (SeisanshoJokyaku seisanshoJokyaku : jkkseiKbnbefUplist) {
				Map<String, Object> paramMap = new HashMap<>();
				// 除却精算制御区分
				paramMap.put("jkkseiKbn", seisanshoJokyaku.getMw1JkkseiKbn());
				// 固定資産ID
				paramMap.put("koteiCod", seisanshoJokyaku.getMw1KoteiCod());
				// 履歴ID
				paramMap.put("rrkCod", seisanshoJokyaku.getMw1RrkCod());
				// 更新日付
				paramMap.put("updateDate", seisanshoJokyaku.getMw1UpdateDh());
				// 更新者コード
				paramMap.put("updshaCod", seisanshoJokyaku.getMw1UpdshaCod());

				seisanshoJokyakuMapper.updateByPrimaryKey(paramMap);
			}

			throw e;
		}

		return 0;
	}

	/**
	 * ストアド処理を行う
	 *
	 * @param map
	 *            INPUTパラメータ
	 * @throws Exception
	 */
	@Transactional(value = "postgresqlTransactionManager")
	private void doSetAllKs2020BefOra(Map<String, Object> map) throws Exception {

		storedMapper.setAllKs2020BefOra(map);
	}

	/**
	 * ストアド処理を行う
	 *
	 * @param map
	 *            INPUTパラメータ
	 * @throws Exception
	 */
	@Transactional(value = "postgresqlTransactionManager")
	private void doSetAllKs2020AftOra(Map<String, Object> map) throws Exception {

		String seisanshoNo = storedMapper.getSeisanshoNoAydm04((String) map.get("jokyakuSeisanShoId"));

		Map<String, Object> jkkymMap = new HashMap<String, Object>();
		jkkymMap.put("jsisanId", (String) map.get("jokyakuSeisanShoId"));
		jkkymMap.put("shoriKbn", (String) map.get("shoriKbn"));
		String jyokyakuYm = storedMapper.getJyokaykuYmKs2030(jkkymMap);

		String userCode = storedMapper.getUserIdKs0000();

		// パワー経理側処理
		Map<String, Object> oraMap = new HashMap<String, Object>();
		oraMap.put("seisanshoNo", seisanshoNo);
		oraMap.put("shoriKbn", map.get("shoriKbn"));
		oraMap.put("jyokyakuYm", jyokyakuYm);
		oraMap.put("userCode", userCode);
		oraMap.put("rc", 0);
		oraMap.put("errKoteiNo", "");
		oraMap.put("errMsg", "");
		oracleStoredMapper.aysp001ProcMain(oraMap);

		Object rc = oraMap.get("rc");
		String str = String.valueOf(rc);
		if (Integer.parseInt(str) != 0) {
			throw new Exception("償却費計算でエラーが発生しました. error=[" + "rc=[" + str + "]" + ",err_kotei_no=[" + (String) oraMap.get("errKoteiNo") + "]" + ", err_msg=[" + (String) oraMap.get("errMsg") + "]" );
		}

		storedMapper.setAllKs2020AftOra(map);
	}

	/**
	 * 除却（更新）処理
	 *
	 * @param kss006
	 *            INPUTパラメータ
	 * @param kss007UpdLst
	 *            INPUTパラメータ
	 * @param kss007DelLst
	 *            INPUTパラメータ
	 * @return cnt
	 * @version 1.00
	 * @throws Exception
	 */
	public int updateInfo(Kss006 kss006, List<Kss007> kss007UpdLst, List<Kss007> kss007DelLst) throws Exception {
		List<Kss007> kss007befUplist = new ArrayList<Kss007>();
		List<Kss007> kss007befDelList = new ArrayList<Kss007>();
		List<Kss007> kss007befInsList = new ArrayList<Kss007>();
		List<SeisanshoJokyaku> jkkseiKbnbefUplist = new ArrayList<SeisanshoJokyaku>();
		Kss006 kss006befUp = new Kss006();
		Kss006 kss006befDel = new Kss006();
		Kss007 Kss007bef = new Kss007();
		try {
			// 版数採番
			String seqHansu = commService.getSequence(NSDConstant.KSS_SEQ_HANSU);
			// 版数
			kss006.setHansu(new BigDecimal(seqHansu));
			// 除却資産更新
			kss006befUp = kss006Mapper.selectByPrimaryKey(kss006.getJokyakuSeisanShoId());
			int cnt = kss006Mapper.updateByPrimaryKeySelective(kss006);
			if (0 < cnt) {
				// 除却資産明細(更新)
				for (Kss007 kss007 : kss007UpdLst) {
					SeisanshoJokyaku seisanshoJokyaku = new SeisanshoJokyaku();
					Kss007 chkKss007 = kss007Mapper.selectByPrimaryKey(kss007);

					// データ存在の場合（更新）
					if (null != chkKss007) {

						String koteiKey1 = chkKss007.getMotoKoteiShisanId().concat("|").concat(chkKss007.getRirekiNo());
						String koteiKey2 = kss007.getMotoKoteiShisanId().concat("|").concat(kss007.getRirekiNo());

						if (koteiKey1.equals(koteiKey2)) {
							// 除却資産明細更新
							cnt = kss007Mapper.updateByPrimaryKeySelective(kss007);
							kss007befUplist.add(chkKss007);
							continue;
						} else {
							// 除却資産明細削除
							cnt = kss007Mapper.deleteByPrimaryKey(chkKss007);
							kss007befDelList.add(chkKss007);

							// 削除成功の場合
							if (0 < cnt) {
								// 除却精算制御区分更新処理
								seisanshoJokyaku = setJkkseiKbn(chkKss007, NSDConstant.JYOKYAKU_SEISAN_SEIGYO_0);
								jkkseiKbnbefUplist.add(seisanshoJokyaku);
								// 除却資産明細登録
								kss007 = setKss007Default(kss007);
								// 登録年月日
								kss007.setEntryDate(kss007.getUpdateDate());
								// 登録ユーザーＩＤ
								kss007.setEntryUserId(kss007.getUpdateUserId());
								// 除却資産明細登録
								cnt = kss007Mapper.insertSelective(kss007);
								kss007befInsList.add(kss007);

								if (0 < cnt) {
									// 除却精算制御区分更新処理
									seisanshoJokyaku = setJkkseiKbn(kss007, NSDConstant.JYOKYAKU_SEISAN_SEIGYO_1);
									jkkseiKbnbefUplist.add(seisanshoJokyaku);
								}
							}
						}
					} else {
						// データ存在しないの場合（登録）
						kss007 = setKss007Default(kss007);
						// 除却資産ＩＤ
						kss007.setJokyakuShisanId(commService.getSequence(NSDConstant.KSS_SEQ_KOTEI_SHISAN_ID));
						// 除却区分コード(「0:全部除却」を設定)
						kss007.setJokyakuKbn(NSDConstant.STRING_0);
						// 除却種別コード(「4:その他」を設定)
						kss007.setJokyakuShubetsuCd(NSDConstant.SHUBETU_CD_SONOTA);
						// 登録年月日
						kss007.setEntryDate(kss007.getUpdateDate());
						// 登録ユーザーＩＤ
						kss007.setEntryUserId(kss007.getUpdateUserId());
						// 除却資産明細登録
						kss007befInsList.add(kss007);
						cnt = kss007Mapper.insertSelective(kss007);

						if (0 < cnt) {
							// 除却精算制御区分更新処理
							seisanshoJokyaku = setJkkseiKbn(kss007, NSDConstant.JYOKYAKU_SEISAN_SEIGYO_1);
							jkkseiKbnbefUplist.add(seisanshoJokyaku);
						}
					}
				}

				// 除却資産明細(削除)
				for (Kss007 kss007 : kss007DelLst) {
					SeisanshoJokyaku seisanshoJokyaku = new SeisanshoJokyaku();
					Kss007bef = kss007Mapper.selectByPrimaryKey(kss007);
					// 除却資産明細削除
					cnt = kss007Mapper.deleteByPrimaryKey(kss007);
					kss007befDelList.add(Kss007bef);

					if (0 < cnt) {
						// 除却精算制御区分更新処理
						seisanshoJokyaku = setJkkseiKbn(kss007, NSDConstant.JYOKYAKU_SEISAN_SEIGYO_0);
						jkkseiKbnbefUplist.add(seisanshoJokyaku);
					}
				}

				Kss007Key kss007Key = new Kss007Key();
				// 除却精算書ＩＤ
				kss007Key.setJokyakuSeisanShoId(kss006.getJokyakuSeisanShoId());
				List<Kss007> kss007Lst = seisanshoJokyakuMapper.selectByPyKey(kss007Key);
				// 除却資産明細全件削除の判断
				// 除却資産明細(削除)
				kss006befDel = kss006Mapper.selectByPrimaryKey(kss006.getJokyakuSeisanShoId());
				if (kss007Lst.size() == 0) {
					kss006Mapper.deleteByPrimaryKey(kss006.getJokyakuSeisanShoId());
				}
				// 除却（更新）ストアド処理
				try {
					Map<String, Object> map = new HashMap<String, Object>();
					map.put("jokyakuSeisanShoId", kss006.getJokyakuSeisanShoId());
					map.put("shoriKbn", "0");
					// 更新後の処理
					doSetAllKs2020BefOra(map);
					doSetAllKs2020AftOra(map);
				} catch (Exception e) {
					throw new PSQLException("減価償却計算処理でエラーが発生しました. error=[" + e.getMessage() + "]", null);
				}
			}
		} catch (Exception e) {

			kss006Mapper.updateByPrimaryKeySelective(kss006befUp);

			if (kss006Mapper.selectByPrimaryKey(kss006befDel.getJokyakuSeisanShoId()) == null) {
				kss006Mapper.insertSelective(kss006befDel);
			}

			for (Kss007 kss007 : kss007befUplist) {
				kss007Mapper.updateByPrimaryKeySelective(kss007);
			}

			for (Kss007 kss007 : kss007befDelList) {
				if (kss007 != null) {
					kss007Mapper.insertSelective(kss007);
				}
			}

			for (Kss007 kss007 : kss007befInsList) {
				kss007Mapper.deleteByPrimaryKey(kss007);
			}
			for (SeisanshoJokyaku seisanshoJokyaku : jkkseiKbnbefUplist) {
				Map<String, Object> paramMap = new HashMap<>();
				// 除却精算制御区分
				paramMap.put("jkkseiKbn", seisanshoJokyaku.getMw1JkkseiKbn());
				// 固定資産ID
				paramMap.put("koteiCod", seisanshoJokyaku.getMw1KoteiCod());
				// 履歴ID
				paramMap.put("rrkCod", seisanshoJokyaku.getMw1RrkCod());
				// 更新日付
				paramMap.put("updateDate", seisanshoJokyaku.getMw1UpdateDh());
				// 更新者コード
				paramMap.put("updshaCod", seisanshoJokyaku.getMw1UpdshaCod());

				seisanshoJokyakuMapper.updateByPrimaryKey(paramMap);
			}

			throw e;
		}

		return 0;
	}

	/**
	 * 除却精算制御区分更新処理
	 *
	 * @param kss007
	 *            INPUTパラメータ
	 * @version 1.00
	 * @return
	 */
	@Transactional(value = "postgresqlTransactionManager")
	protected SeisanshoJokyaku setJkkseiKbn(Kss007 kss007, String kkkseiKbn) {
		SeisanshoJokyaku seisanshoJokyaku = new SeisanshoJokyaku();

		Map<String, Object> paramMap = new HashMap<>();
		// 除却精算制御区分
		paramMap.put("jkkseiKbn", kkkseiKbn);
		// 固定資産ID
		paramMap.put("koteiCod", kss007.getMotoKoteiShisanId());
		// 履歴ID
		paramMap.put("rrkCod", kss007.getRirekiNo());
		// 更新日付
		paramMap.put("updateDate", kss007.getUpdateDate());
		// 更新者コード
		paramMap.put("updshaCod", kss007.getUpdateUserId());

		// 固定資産更新
		seisanshoJokyaku = seisanshoJokyakuMapper.selectJjkkseiByPrimaryKey(paramMap);
		seisanshoJokyakuMapper.updateByPrimaryKey(paramMap);
		return seisanshoJokyaku;

	}

	/**
	 * 除却資産明細データセット
	 *
	 * @param kss007
	 *            INPUTパラメータ
	 * @version 1.00
	 */
	protected Kss007 setKss007Default(Kss007 kss007) {

		// 残＿数量
		kss007.setZanSuryo(BigDecimal.ZERO);
		// 貯蔵品分類コード
		kss007.setChozoBunruiCd(NSDConstant.STRING_0);
		// 処分価額
		kss007.setKsSelYen(0L);
		// 除却時減価償却費＿税
		kss007.setKsJkgenzYen(0L);
		// 除却時減価償却費＿商
		kss007.setKsJkgensYen(0L);
		// 除却時一時償却額＿税
		kss007.setKsJktk1Yen(0L);
		// 除却時一時償却額＿商
		kss007.setKsJktk1sYen(0L);
		// 除却時割増償却額＿税
		kss007.setKsJktk2Yen(0L);
		// 除却時割増償却額＿商
		kss007.setKsJktk2sYen(0L);
		// 除却時増加償却額＿税
		kss007.setKsJktk3Yen(0L);
		// 除却時増加償却額＿商
		kss007.setKsJktk3sYen(0L);
		// 除却時陳腐化償却額＿税
		kss007.setKsJktk4Yen(0L);
		// 除却時陳腐化償却額＿商
		kss007.setKsJktk4sYen(0L);
		// 除却時減価償却累計額＿税
		kss007.setKsJkgnrzYen(0L);
		// 除却時減価償却累計額＿商
		kss007.setKsJkgnrsYen(0L);
		// 除却時簿価＿税
		kss007.setKsJkbkazYen(0L);
		// 除却時簿価＿商
		kss007.setKsJkbkasYen(0L);
		// 除却損＿税
		kss007.setKsJksonzYen(0L);
		// 除却損＿商
		kss007.setKsJksonsYen(0L);
		// 備忘価額＿税
		kss007.setBiboKagakuZei(0L);
		// 備忘価額＿商
		kss007.setBiboKagakuSho(0L);
		// 除＿取得原価内訳１
		kss007.setKsJkagk1Yen(0L);
		// 除＿取得原価内訳２
		kss007.setKsJkagk2Yen(0L);
		// 除＿取得原価内訳３
		kss007.setKsJkagk3Yen(0L);
		// 除＿原始取得価額
		kss007.setKsJgtgnsYen(0L);
		// 除＿償却可能限度額＿税
		kss007.setKsJgendzYen(0L);
		// 除＿償却可能限度額＿商
		kss007.setKsJgendsYen(0L);
		// 除＿残存価額＿税
		kss007.setKsJzanzYen(0L);
		// 除＿残存価額＿商
		kss007.setKsJzansYen(0L);
		// 除＿前期末簿価＿税
		kss007.setKsJmbkazYen(0L);
		// 除＿前期末簿価＿商
		kss007.setKsJmbkasYen(0L);
		// 除＿前期末簿価＿計上
		kss007.setKsJmbkakYen(0L);
		// 除＿減価償却累計額＿税
		kss007.setKsJgnrzYen(0L);
		// 除＿減価償却累計額＿商
		kss007.setKsJgnrsYen(0L);
		// 除＿減価償却累計額＿計上
		kss007.setKsJshorYen(0L);
		// 除＿現在償却累計額＿税
		kss007.setKsJnbkazYen(0L);
		// 除＿現在償却累計額＿商
		kss007.setKsJnbkasYen(0L);
		// 除＿現在償却累計額＿計上
		kss007.setKsJnbkakYen(0L);
		// 除＿当期償却額＿税
		kss007.setKsJtkshzYen(0L);
		// 除＿当期償却額＿商
		kss007.setKsJtkshsYen(0L);
		// 除＿期末時簿価＿税
		kss007.setKsJendzYen(0L);
		// 除＿期末時簿価＿商
		kss007.setKsJendsYen(0L);
		// 除＿適用開始年度期首簿価＿税
		kss007.setKsJstbkzYen(0L);
		// 除＿適用開始年度期首簿価＿商
		kss007.setKsJstbksYen(0L);
		// 除＿一時償却額＿税
		kss007.setKsJtk1Yen(0L);
		// 除＿割増償却額＿税
		kss007.setKsJtk2Yen(0L);
		// 除＿増加償却額＿税
		kss007.setKsJtk3Yen(0L);
		// 除＿陳腐化償却額＿税
		kss007.setKsJtk4Yen(0L);
		// 除＿一時償却額＿商
		kss007.setKsJtk1sYen(0L);
		// 除＿割増償却額＿商
		kss007.setKsJtk2sYen(0L);
		// 除＿増加償却額＿商
		kss007.setKsJtk3sYen(0L);
		// 除＿陳腐化償却額＿商
		kss007.setKsJtk4sYen(0L);
		// 除＿一時償却累計額＿税
		kss007.setKsJtkr1Yen(0L);
		// 除＿割増償却累計額＿税
		kss007.setKsJtkr2Yen(0L);
		// 除＿増加償却累計額＿税
		kss007.setKsJtkr3Yen(0L);
		// 除＿陳腐化償却累計額＿税
		kss007.setKsJtkr4Yen(0L);
		// 除＿一時償却累計額＿商
		kss007.setKsJtkr1sYen(0L);
		// 除＿割増償却累計額＿商
		kss007.setKsJtkr2sYen(0L);
		// 除＿増加償却累計額＿商
		kss007.setKsJtkr3sYen(0L);
		// 除＿陳腐化償却累計額＿商
		kss007.setKsJtkr4sYen(0L);
		// 除＿申告取得価額調整
		kss007.setKsJsncsiYen(0L);
		// 除＿申告取得価額
		kss007.setKsJsnstkYen(0L);
		// 除＿年始現在簿価
		kss007.setKsJyfbkaYen(0L);
		// 除＿年始現在評価額
		kss007.setKsJyfhykYen(0L);
		// 除＿年始前年簿価
		kss007.setKsJybbkaYen(0L);
		// 除＿年始前年評価額
		kss007.setKsJybhykYen(0L);
		// 残＿取得原価内訳１
		kss007.setKsZkagk1Yen(0L);
		// 残＿取得原価内訳２
		kss007.setKsZkagk2Yen(0L);
		// 残＿取得原価内訳３
		kss007.setKsZkagk3Yen(0L);
		// 残＿取得価額
		kss007.setKsZgtkgkYen(0L);
		// 残＿原始取得価額
		kss007.setKsZgtgnsYen(0L);
		// 残＿償却可能限度額＿税
		kss007.setKsZgendzYen(0L);
		// 残＿償却可能限度額＿商
		kss007.setKsZgendsYen(0L);
		// 残＿残存価額＿税
		kss007.setKsZzanzYen(0L);
		// 残＿残存価額＿商
		kss007.setKsZzansYen(0L);
		// 残＿前期末簿価＿税
		kss007.setKsZmbkazYen(0L);
		// 残＿前期末簿価＿商
		kss007.setKsZmbkasYen(0L);
		// 残＿前期末簿価＿計上
		kss007.setKsZmbkakYen(0L);
		// 残＿減価償却累計額＿税
		kss007.setKsZgnrzYen(0L);
		// 残＿減価償却累計額＿商
		kss007.setKsZgnrsYen(0L);
		// 残＿減価償却累計額＿計上
		kss007.setKsZshorYen(0L);
		// 残＿現在償却累計額＿税
		kss007.setKsZnbkazYen(0L);
		// 残＿現在償却累計額＿商
		kss007.setKsZnbkasYen(0L);
		// 残＿現在償却累計額＿計上
		kss007.setKsZnbkakYen(0L);
		// 残＿当期償却額＿税
		kss007.setKsZtkshzYen(0L);
		// 残＿当期償却額＿商
		kss007.setKsZtkshsYen(0L);
		// 残＿期末時簿価＿税
		kss007.setKsZendzYen(0L);
		// 残＿期末時簿価＿商
		kss007.setKsZendsYen(0L);
		// 残＿適用開始年度期首簿価＿税
		kss007.setKsZstbkzYen(0L);
		// 残＿適用開始年度期首簿価＿商
		kss007.setKsZstbksYen(0L);
		// 残＿一時償却額＿税
		kss007.setKsZtk1Yen(0L);
		// 残＿割増償却額＿税
		kss007.setKsZtk2Yen(0L);
		// 残＿増加償却額＿税
		kss007.setKsZtk3Yen(0L);
		// 残＿陳腐化償却額＿税
		kss007.setKsZtk4Yen(0L);
		// 残＿一時償却額＿商
		kss007.setKsZtk1sYen(0L);
		// 残＿割増償却額＿商
		kss007.setKsZtk2sYen(0L);
		// 残＿増加償却額＿商
		kss007.setKsZtk3sYen(0L);
		// 残＿陳腐化償却額＿商
		kss007.setKsZtk4sYen(0L);
		// 残＿一時償却累計額＿税
		kss007.setKsZtkr1Yen(0L);
		// 残＿割増償却累計額＿税
		kss007.setKsZtkr2Yen(0L);
		// 残＿増加償却累計額＿税
		kss007.setKsZtkr3Yen(0L);
		// 残＿陳腐化償却累計額＿税
		kss007.setKsZtkr4Yen(0L);
		// 残＿一時償却累計額＿商
		kss007.setKsZtkr1sYen(0L);
		// 残＿割増償却累計額＿商
		kss007.setKsZtkr2sYen(0L);
		// 残＿増加償却累計額＿商
		kss007.setKsZtkr3sYen(0L);
		// 残＿陳腐化償却累計額＿商
		kss007.setKsZtkr4sYen(0L);
		// 残＿申告取得価額調整
		kss007.setKsZsncsiYen(0L);
		// 残＿申告取得価額
		kss007.setKsZsnstkYen(0L);
		// 残＿年始現在簿価
		kss007.setKsZyfbkaYen(0L);
		// 残＿年始現在評価額
		kss007.setKsZyfhykYen(0L);
		// 残＿年始前年簿価
		kss007.setKsZybbkaYen(0L);
		// 残＿年始前年評価額
		kss007.setKsZybhykYen(0L);
		// 明細ＩＤ
		kss007.setKsMeiCod(NSDConstant.STRING_0);
		// 明細子ＩＤ
		kss007.setKsMeicoCod(NSDConstant.STRING_0);
		// 明細履歴番号
		kss007.setKsMeirrkCod(NSDConstant.STRING_0);
		// 除却時減損損失額
		kss007.setKsJkgensonYen(0L);
		// 除却時減損損失累計額
		kss007.setKsJksonruiYen(0L);
		// 除＿減損損失額
		kss007.setKsJgensonYen(0L);
		// 除＿減損損失累計額
		kss007.setKsJsonruiYen(0L);
		// 除＿減損計上時簿価
		kss007.setKsJsonstaYen(0L);
		// 残＿減損損失額
		kss007.setKsZgensonYen(0L);
		// 残＿減損損失累計額
		kss007.setKsZsonruiYen(0L);
		// 残＿減損計上時簿価
		kss007.setKsZsonstaYen(0L);

		return kss007;
	}
}
