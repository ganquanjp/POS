package jp.co.nsd.nkssweb.dao;

import java.util.List;

public class SeisanshoJokyakuNaiyoShokai {

	// 除却精算書ＩＤ
	private String jokyakuSeisanShoId;

	// 除却資産ＩＤ
	private String jokyakuShisanId;

	// 除却元固定資産ＩＤ
	private String motoKoteiShisanId;

	// 履歴番号
	private String rirekiNo;

	// 除却精算書番号
	private String jokyakuSeisanShoNo;

	// 件名
	private String kenmeiNm;

	// 除却予定年月日
	private String jokyakuYoteYmd;

	// 除却年月日
	private String jokyakuYmd;

	// 摘要
	private String tekiyo;

	// 組織連結略名
	private String soshikiRenNm;

	// 登録者氏名
	private String seiMei;

	// 除_取得価額
	private String jokyakuGaku;

	// 除_取得価額
	private String jokyakuSuryo;

	// 除却種別コード
	private String jokyakuShubetsuCd;

	// 除却種別名称
	private String jokyakuShubetsuNm;

	// 除却区分コード
	private String jokyakuKbn;

	// 除却区分名称
	private String jokyakuKbnNm;

	// 資産単位コード
	private String shisanTaniCd;

	// 除却資産明細の更新時刻
	private String updateDate;

	// 固定資産情報
	private List<SeisanshoJokyakuKoteiSisan> koteiSisanLst;

	public String getJokyakuSeisanShoId() {
		return jokyakuSeisanShoId;
	}

	public void setJokyakuSeisanShoId(String jokyakuSeisanShoId) {
		this.jokyakuSeisanShoId = jokyakuSeisanShoId;
	}

	public String getJokyakuShisanId() {
		return jokyakuShisanId;
	}

	public void setJokyakuShisanId(String jokyakuShisanId) {
		this.jokyakuShisanId = jokyakuShisanId;
	}

	public String getMotoKoteiShisanId() {
		return motoKoteiShisanId;
	}

	public void setMotoKoteiShisanId(String motoKoteiShisanId) {
		this.motoKoteiShisanId = motoKoteiShisanId;
	}

	public String getRirekiNo() {
		return rirekiNo;
	}

	public void setRirekiNo(String rirekiNo) {
		this.rirekiNo = rirekiNo;
	}

	public String getJokyakuSeisanShoNo() {
		return jokyakuSeisanShoNo;
	}

	public void setJokyakuSeisanShoNo(String jokyakuSeisanShoNo) {
		this.jokyakuSeisanShoNo = jokyakuSeisanShoNo;
	}

	public String getKenmeiNm() {
		return kenmeiNm;
	}

	public void setKenmeiNm(String kenmeiNm) {
		this.kenmeiNm = kenmeiNm;
	}

	public String getJokyakuYoteYmd() {
		return jokyakuYoteYmd;
	}

	public void setJokyakuYoteYmd(String jokyakuYoteYmd) {
		this.jokyakuYoteYmd = jokyakuYoteYmd;
	}

	public String getJokyakuYmd() {
		return jokyakuYmd;
	}

	public void setJokyakuYmd(String jokyakuYmd) {
		this.jokyakuYmd = jokyakuYmd;
	}

	public String getTekiyo() {
		return tekiyo;
	}

	public void setTekiyo(String tekiyo) {
		this.tekiyo = tekiyo;
	}

	public String getSoshikiRenNm() {
		return soshikiRenNm;
	}

	public void setSoshikiRenNm(String soshikiRenNm) {
		this.soshikiRenNm = soshikiRenNm;
	}

	public String getSeiMei() {
		return seiMei;
	}

	public void setSeiMei(String seiMei) {
		this.seiMei = seiMei;
	}

	public String getJokyakuGaku() {
		return jokyakuGaku;
	}

	public void setJokyakuGaku(String jokyakuGaku) {
		this.jokyakuGaku = jokyakuGaku;
	}

	public String getJokyakuSuryo() {
		return jokyakuSuryo;
	}

	public void setJokyakuSuryo(String jokyakuSuryo) {
		this.jokyakuSuryo = jokyakuSuryo;
	}

	public String getJokyakuShubetsuCd() {
		return jokyakuShubetsuCd;
	}

	public void setJokyakuShubetsuCd(String jokyakuShubetsuCd) {
		this.jokyakuShubetsuCd = jokyakuShubetsuCd;
	}

	public String getJokyakuShubetsuNm() {
		return jokyakuShubetsuNm;
	}

	public void setJokyakuShubetsuNm(String jokyakuShubetsuNm) {
		this.jokyakuShubetsuNm = jokyakuShubetsuNm;
	}

	public String getJokyakuKbn() {
		return jokyakuKbn;
	}

	public void setJokyakuKbn(String jokyakuKbn) {
		this.jokyakuKbn = jokyakuKbn;
	}

	public String getJokyakuKbnNm() {
		return jokyakuKbnNm;
	}

	public void setJokyakuKbnNm(String jokyakuKbnNm) {
		this.jokyakuKbnNm = jokyakuKbnNm;
	}

	public String getShisanTaniCd() {
		return shisanTaniCd;
	}

	public void setShisanTaniCd(String shisanTaniCd) {
		this.shisanTaniCd = shisanTaniCd;
	}

	public List<SeisanshoJokyakuKoteiSisan> getKoteiSisanLst() {
		return koteiSisanLst;
	}

	public void setKoteiSisanLst(List<SeisanshoJokyakuKoteiSisan> koteiSisanLst) {
		this.koteiSisanLst = koteiSisanLst;
	}

	public String getUpdateDate() {
		return updateDate;
	}

	public void setUpdateDate(String updateDate) {
		this.updateDate = updateDate;
	}

}