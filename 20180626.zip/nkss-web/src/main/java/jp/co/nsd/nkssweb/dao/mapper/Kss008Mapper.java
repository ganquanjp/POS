package jp.co.nsd.nkssweb.dao.mapper;

import jp.co.nsd.nkssweb.dao.Kss008;
import jp.co.nsd.nkssweb.dao.Kss008Key;

public interface Kss008Mapper {
    int deleteByPrimaryKey(Kss008Key key);

    int insert(Kss008 record);

    int insertSelective(Kss008 record);

    Kss008 selectByPrimaryKey(Kss008Key key);

    int updateByPrimaryKeySelective(Kss008 record);

    int updateByPrimaryKey(Kss008 record);
}