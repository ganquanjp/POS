package jp.co.nsd.nkssweb.dao;

import java.util.Date;

public class Kss009 extends Kss009Key {
    private String daichoNm;

    private String sakuseiKbn;

    private String sakuseiUserId;

    private Date entryDate;

    private String entryUserId;

    private Date updateDate;

    private String updateUserId;

    public String getDaichoNm() {
        return daichoNm;
    }

    public void setDaichoNm(String daichoNm) {
        this.daichoNm = daichoNm == null ? null : daichoNm.trim();
    }

    public String getSakuseiKbn() {
        return sakuseiKbn;
    }

    public void setSakuseiKbn(String sakuseiKbn) {
        this.sakuseiKbn = sakuseiKbn == null ? null : sakuseiKbn.trim();
    }

    public String getSakuseiUserId() {
        return sakuseiUserId;
    }

    public void setSakuseiUserId(String sakuseiUserId) {
        this.sakuseiUserId = sakuseiUserId == null ? null : sakuseiUserId.trim();
    }

    public Date getEntryDate() {
        return entryDate;
    }

    public void setEntryDate(Date entryDate) {
        this.entryDate = entryDate;
    }

    public String getEntryUserId() {
        return entryUserId;
    }

    public void setEntryUserId(String entryUserId) {
        this.entryUserId = entryUserId == null ? null : entryUserId.trim();
    }

    public Date getUpdateDate() {
        return updateDate;
    }

    public void setUpdateDate(Date updateDate) {
        this.updateDate = updateDate;
    }

    public String getUpdateUserId() {
        return updateUserId;
    }

    public void setUpdateUserId(String updateUserId) {
        this.updateUserId = updateUserId == null ? null : updateUserId.trim();
    }
}