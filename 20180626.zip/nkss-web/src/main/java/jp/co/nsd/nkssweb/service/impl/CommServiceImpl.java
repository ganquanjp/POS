/***********************************************************************
*
*業務名: システム共通処理
*機能名: システム共通処理(サービス処理)
*
*機能概要: システム共通処理
*
*JavaＶｅｒ：J2SE1.8.0準拠
*
*更新履歴: Ver.1.00 2018/03/06　NSD　新規作成
***********************************************************************/
package jp.co.nsd.nkssweb.service.impl;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import jp.co.nsd.nkssweb.dao.Abda09;
import jp.co.nsd.nkssweb.dao.Awda01;
import jp.co.nsd.nkssweb.dao.Awda02;
import jp.co.nsd.nkssweb.dao.Awda03;
import jp.co.nsd.nkssweb.dao.Awda04;
import jp.co.nsd.nkssweb.dao.Awda05;
import jp.co.nsd.nkssweb.dao.Awda06;
import jp.co.nsd.nkssweb.dao.Awda15;
import jp.co.nsd.nkssweb.dao.Awda20;
import jp.co.nsd.nkssweb.dao.Awdm12;
import jp.co.nsd.nkssweb.dao.Awdv02;
import jp.co.nsd.nkssweb.dao.CodeShubetsu;
import jp.co.nsd.nkssweb.dao.Kss002;
import jp.co.nsd.nkssweb.dao.Kss004;
import jp.co.nsd.nkssweb.dao.Kss005;
import jp.co.nsd.nkssweb.dao.Kss006;
import jp.co.nsd.nkssweb.dao.Kss007;
import jp.co.nsd.nkssweb.dao.Kss008;
import jp.co.nsd.nkssweb.dao.Kss015;
import jp.co.nsd.nkssweb.dao.Kss016;
import jp.co.nsd.nkssweb.dao.Kss016Key;
import jp.co.nsd.nkssweb.dao.mapper.CommMapper;
import jp.co.nsd.nkssweb.dao.mapper.Kss002Mapper;
import jp.co.nsd.nkssweb.dao.mapper.Kss004Mapper;
import jp.co.nsd.nkssweb.dao.mapper.Kss005Mapper;
import jp.co.nsd.nkssweb.dao.mapper.Kss006Mapper;
import jp.co.nsd.nkssweb.dao.mapper.Kss007Mapper;
import jp.co.nsd.nkssweb.dao.mapper.Kss008Mapper;
import jp.co.nsd.nkssweb.dao.mapper.Kss015Mapper;
import jp.co.nsd.nkssweb.dao.mapper.Kss016Mapper;
import jp.co.nsd.nkssweb.service.CommService;
import jp.co.nsd.nkssweb.utils.NSDConstant;
import jp.co.nsd.nkssweb.utils.NSDDateUtils;

/**
 * 共通処理用サービス
 *
 * @see CommService
 * @version 1.00
 */
@Service
public class CommServiceImpl implements CommService {

	@Autowired
	private CommMapper commMapper;

	@Autowired
	private Kss002Mapper kss002Mapper;

	@Autowired
	private Kss004Mapper kss004Mapper;

	@Autowired
	private Kss005Mapper kss005Mapper;

	@Autowired
	private Kss006Mapper kss006Mapper;

	@Autowired
	private Kss007Mapper kss007Mapper;

	@Autowired
	private Kss008Mapper kss008Mapper;

	@Autowired
	private Kss015Mapper kss015Mapper;

	@Autowired
	private Kss016Mapper kss016Mapper;

	public String getSequence(String seqId) {

		Map<String, Object> seqMap = new HashMap<>();
		seqMap.put("seqId", seqId);
		seqMap.put("seqLen", NSDConstant.SEQ_LEN_MAP.get(seqId));

		// 採番処理サービス呼び出し
		return commMapper.getSequence(seqMap);
	}

	@Override
	public String getCodeName(String codeShubetsu, String cd1) {

		Kss016Key kss016key = new Kss016Key();
		kss016key.setCdShubetsu(codeShubetsu);
		kss016key.setCd1(cd1);
		kss016key.setCd2(NSDConstant.BLANK_STRING);
		Kss016 kss016 = kss016Mapper.selectByPrimaryKey(kss016key);
		return kss016.getCdKnj();

	}

	/**
	 * 条件よりコードマスタにコード情報を取得
	 *
	 * @param codeShubetsu
	 * @return
	 * @version 1.00
	 */
	@Override
	public List<Kss016> getCodeShubetsuList(CodeShubetsu codeShubetsu) {
		return commMapper.getCodeShubetsuList(codeShubetsu);
	}

	/**
	 * 条件よりパワー経理の発行組織を取得
	 *
	 * @param abda09
	 * @return
	 */
	@Override
	public List<Abda09> getHakouSoshiki(Abda09 abda09) {
		return commMapper.getHakouSoshiki(abda09);
	}

	/**
	 * 条件より種類を取得
	 *
	 * @param awda01
	 * @return
	 */
	@Override
	public List<Awda01> getShuNmLst(Awda01 awda01) {
		return commMapper.getShuNmLst(awda01);
	}

	/**
	 * 条件より構造を取得
	 *
	 * @param awda02
	 * @return
	 */
	@Override
	public List<Awda02> getKouNmLst(Awda02 awda02) {
		return commMapper.getKouNmLst(awda02);
	}

	/**
	 * 条件より細目を取得
	 *
	 * @param awda03
	 * @return
	 */
	@Override
	public List<Awda03> getSaiNmLst(Awda03 awda03) {
		return commMapper.getSaiNmLst(awda03);
	}

	/**
	 * 条件より種別４を取得
	 *
	 * @param awda04
	 * @return
	 */
	@Override
	public List<Awda04> getShu4NmLst(Awda04 awda04) {
		return commMapper.getShu4NmLst(awda04);
	}

	/**
	 * 条件より種別５を取得
	 *
	 * @param awda05
	 * @return
	 */
	@Override
	public List<Awda05> getShu5NmLst(Awda05 awda05) {
		return commMapper.getShu5NmLst(awda05);
	}

	/**
	 * 条件より種別６を取得
	 *
	 * @param awda06
	 * @return
	 */
	@Override
	public List<Awda06> getShu6NmLst(Awda06 awda06) {
		return commMapper.getShu6NmLst(awda06);
	}

	/**
	 * 条件より単位を取得
	 *
	 * @param awda15
	 * @return
	 */
	@Override
	public List<Awda15> getTaniLst(Awda15 awda15) {
		return commMapper.getTaniLst(awda15);
	}

	/**
	 * 条件より名称定数を取得
	 *
	 * @param awda20
	 * @return
	 */
	@Override
	public List<Awda20> getMeiShouLst(Awda20 awda20) {
		return commMapper.getMeiShouLst(awda20);
	}

	/**
	 * 設置場所より申告先・市町村を取得
	 *
	 * @return
	 */
	@Override
	public Awdm12 getAwdm12(Awdm12 awdm12) {
		return commMapper.getAwdm12(awdm12);
	}

	/**
	 * 条件より種構細４５６の情報を取得
	 *
	 * @return
	 */
	@Override
	public List<Awdv02> getAwdv02(Awdv02 awdv02) {
		return commMapper.getAwdv02(awdv02);
	}

	@Override
	public String doHaita(Object table, String preUpdate) {

		String errId = NSDConstant.BLANK_STRING;

		Date curDate = new Date();

		if (Kss002.class.isInstance(table)) {
			Kss002 kss002 = (Kss002) table;
			Kss002 haita = kss002Mapper.selectByPrimaryKey(kss002.getKenmeiId());
			if (haita == null) {
				errId = NSDConstant.MSGID_REC_DELETEED;
			} else {
				curDate = haita.getUpdateDate();
			}
		} else if (Kss004.class.isInstance(table)) {
			Kss004 kss004 = (Kss004) table;
			Kss004 haita = null;
			if (StringUtils.isEmpty(kss004.getKoteiShisanId())) {
				haita = commMapper.selectBySeisanShoId(kss004);
			} else {
				haita = kss004Mapper.selectByPrimaryKey(kss004);
			}
			if (haita == null) {
				errId = NSDConstant.MSGID_REC_DELETEED;
			} else {
				curDate = haita.getUpdateDate();
			}
		} else if (Kss005.class.isInstance(table)) {
			Kss005 kss005 = (Kss005) table;
			Kss005 haita = kss005Mapper.selectByPrimaryKey(kss005);
			if (haita == null) {
				errId = NSDConstant.MSGID_REC_DELETEED;
			} else {
				curDate = haita.getUpdateDate();
			}
		} else if (Kss006.class.isInstance(table)) {
			Kss006 kss006 = (Kss006) table;
			Kss006 haita = kss006Mapper.selectByPrimaryKey(kss006.getJokyakuSeisanShoId());
			if (haita == null) {
				errId = NSDConstant.MSGID_REC_DELETEED;
			} else {
				curDate = haita.getUpdateDate();
			}
		} else if (Kss007.class.isInstance(table)) {
			Kss007 kss007 = (Kss007) table;
			Kss007 haita = kss007Mapper.selectByPrimaryKey(kss007);
			if (haita == null) {
				errId = NSDConstant.MSGID_REC_DELETEED;
			} else {
				curDate = haita.getUpdateDate();
			}
		} else if (Kss008.class.isInstance(table)) {
			Kss008 kss008 = (Kss008) table;
			Kss008 haita = kss008Mapper.selectByPrimaryKey(kss008);
			if (haita == null) {
				errId = NSDConstant.MSGID_REC_DELETEED;
			} else {
				curDate = haita.getUpdateDate();
			}
		} else if (Kss015.class.isInstance(table)) {
			Kss015 kss015 = (Kss015) table;
			Kss015 haita = kss015Mapper.selectByPrimaryKey(kss015);
			if (haita == null) {
				errId = NSDConstant.MSGID_REC_DELETEED;
			} else {
				curDate = haita.getUpdateDate();
			}
		} else {
			return NSDConstant.MSGID_SYSTEM_ERROR;
		}

		if (StringUtils.isEmpty(errId)) {
			if (!NSDDateUtils.compareDateByMillisecond(preUpdate, curDate)) {
				errId = NSDConstant.MSGID_SUPDATE_LOCK;
			}
		}

		return errId;
	}

	@Override
	public String doHaita(Object table, String preUpdate, int actionFlag) {
		String errId = this.doHaita(table, preUpdate);

		if (actionFlag == NSDConstant.ACTION_INSERT) {
			if (errId.equals(NSDConstant.MSGID_REC_DELETEED)) {
				errId = NSDConstant.MSGID_REC_INSERTED;
			}
		}

		return errId;
	}
}
