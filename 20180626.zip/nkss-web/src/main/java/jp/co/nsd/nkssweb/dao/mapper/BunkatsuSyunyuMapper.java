package jp.co.nsd.nkssweb.dao.mapper;

import java.util.List;
import java.util.Map;

import jp.co.nsd.nkssweb.dao.BunkatsuSyunyu;
import jp.co.nsd.nkssweb.dao.BunkatsuSyunyuKoteiInfo;

public interface BunkatsuSyunyuMapper {

    List<BunkatsuSyunyu> selectByWhere(BunkatsuSyunyu record);

    List<BunkatsuSyunyuKoteiInfo> getSeisanshoKoteiInfo(Map<String, Object> map);

    Map<String, Object> initUpdInfo(String seisanShoId);

    List<Map<String, Object>> getShutokuKakaku(String seisanShoId);

}