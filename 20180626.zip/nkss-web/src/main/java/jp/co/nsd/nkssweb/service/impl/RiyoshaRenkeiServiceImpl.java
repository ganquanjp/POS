/***********************************************************************
*
*業務名: 利用者連携処理
*機能名: 利用者連携処理(サービス処理)
*
*機能概要: ユーザー情報 / 所属情報を取り込む
*
*JavaＶｅｒ：J2SE1.8.0準拠
*
*更新履歴: Ver.1.00 2018/05/22　NSD　新規作成
***********************************************************************/
package jp.co.nsd.nkssweb.service.impl;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStreamReader;
import java.util.Arrays;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

import jp.co.nsd.nkssweb.dao.Kss011;
import jp.co.nsd.nkssweb.dao.Kss013;
import jp.co.nsd.nkssweb.dao.Kss014;
import jp.co.nsd.nkssweb.dao.mapper.CommMapper;
import jp.co.nsd.nkssweb.dao.mapper.Kss011Mapper;
import jp.co.nsd.nkssweb.dao.mapper.Kss013Mapper;
import jp.co.nsd.nkssweb.dao.mapper.Kss014Mapper;
import jp.co.nsd.nkssweb.service.RiyoshaRenkeiService;
import jp.co.nsd.nkssweb.utils.NSDConstant;
import jp.co.nsd.nkssweb.utils.NSDDateUtils;
import jp.co.nsd.nkssweb.utils.NSDProperties;

/**
 * 利用者連携処理用サービス
 *
 * @see RiyoshaRenkeiService
 * @version 1.00
 */
@Service
@Transactional(value = "postgresqlTransactionManager")
public class RiyoshaRenkeiServiceImpl implements RiyoshaRenkeiService {

	@Autowired
	private NSDProperties nsdProperties;

	@Autowired
	private Kss011Mapper kss011Mapper;

	@Autowired
	private Kss013Mapper kss013Mapper;

	@Autowired
	private Kss014Mapper kss014Mapper;

	@Autowired
	private CommMapper commMapper;

	// データ開始行
	private int dataStartLine = 2;

	// クォーテーション有無
	private boolean quotation = true;

	private final String DATE_FORMAT = "yyyy-MM-dd";

	private final String MOJI_ENCODE = "Shift-JIS";

	public void getRiyoshaInfo() throws Exception {

		try {
			// 組織マスタ情報を取込
			readCsvFileToKss011();
		} catch (Exception e) {
			if (e instanceof FileNotFoundException) {
				try {
					// ユーザー情報を取込
					readCsvFileToKss013();
				} catch (Exception e2) {
					if (e2 instanceof FileNotFoundException) {
						try {
							// 組織所属情報を取込
							readCsvFileToKss014();
						} catch (Exception e3) {
							if (e3 instanceof FileNotFoundException) {
								throw new FileNotFoundException(e.getMessage() + e2.getMessage() + e3.getMessage());
							}
							throw new Exception(e.getMessage() + e2.getMessage() + e3.getMessage());
						}
						throw new FileNotFoundException(e.getMessage() + e2.getMessage());
					}
					throw new Exception(e.getMessage() + e2.getMessage());
				}
				throw new FileNotFoundException(e.getMessage());
			}
			throw e;
		}

		try {
			// ユーザー情報を取込
			readCsvFileToKss013();
		} catch (Exception e) {
			if (e instanceof FileNotFoundException) {
				try {
					// 組織所属情報を取込
					readCsvFileToKss014();
				} catch (Exception e2) {
					if (e2 instanceof FileNotFoundException) {
						throw new FileNotFoundException(e.getMessage() + e2.getMessage());
					}
					throw new Exception(e.getMessage() + e2.getMessage());
				}
				throw new FileNotFoundException(e.getMessage());
			}
			throw e;
		}

		// 組織所属情報を取込
		readCsvFileToKss014();

	}

	/**
	 * 組織マスタ情報を取込む
	 *
	 * @throws Exception
	 */
	private void readCsvFileToKss011() throws Exception {

		@SuppressWarnings("resource")
		BufferedReader reader = new BufferedReader(
				new InputStreamReader(new FileInputStream(nsdProperties.getBatchCsvFileKss011()), MOJI_ENCODE));

		String line = null;
		int lineNo = 0;

		while ((line = reader.readLine()) != null) {
			lineNo++;
			if (lineNo < dataStartLine) {
				continue;
			}

			if (lineNo == dataStartLine) {
				// 組織マスタ全件削除
				commMapper.deleteTable("Kss011");
			}

			Kss011 kss011 = new Kss011();

			try {
				String item[] = line.split(NSDConstant.STRING_KANMA);

				item = editArrayItem(item, 8);

				// 組織コード
				kss011.setSoshikiCd(getCsvItemValue(item[0]));
				// 適用開始日
				kss011.setTekiyoStartYmd(NSDDateUtils.stringToDate(getCsvItemValue(item[1]), DATE_FORMAT));
				// 無効化フラグ
				kss011.setDisabledFlg(getCsvItemValue(item[2]));
				// 組織名
				kss011.setSoshikiNm(getCsvItemValue(item[3]));
				// 組織連結名
				kss011.setSoshikiRenNm(getCsvItemValue(item[4]));
				// ソートキー
				kss011.setSortKey(Integer.valueOf(getCsvItemValue(item[5])));
				// 組織レベル
				kss011.setSoshikiLevel(Long.valueOf(getCsvItemValue(item[6])));
				// 親組織コード
				kss011.setOyaSoshikiCd(getCsvItemValue(item[7]));

				kss011Mapper.insert(kss011);

			} catch (Exception e) {
				throw new Exception("データ部：" + (lineNo - dataStartLine + 1) + "行目、" + e.getMessage());
			}
		}

		reader.close();

	}

	/**
	 * ユーザー情報を取込む
	 *
	 * @throws Exception
	 */
	private void readCsvFileToKss013() throws Exception {

		@SuppressWarnings("resource")
		BufferedReader reader = new BufferedReader(
				new InputStreamReader(new FileInputStream(nsdProperties.getBatchCsvFileKss013()), MOJI_ENCODE));

		String line = null;
		int lineNo = 0;

		while ((line = reader.readLine()) != null) {
			lineNo++;
			if (lineNo < dataStartLine) {
				continue;
			}

			if (lineNo == dataStartLine) {
				// ユーザー情報全件削除
				commMapper.deleteTable("Kss013");
			}

			Kss013 kss013 = new Kss013();

			try {
				String item[] = line.split(NSDConstant.STRING_KANMA);

				item = editArrayItem(item, 6);

				// ユーザーＩＤ
				kss013.setUserId(getCsvItemValue(item[0]));
				// 姓
				kss013.setSei(getCsvItemValue(item[1]));
				// 名
				kss013.setMei(getCsvItemValue(item[2]));
				// 入社日
				kss013.setNyushaYmd(NSDDateUtils.stringToDate(getCsvItemValue(item[3]), DATE_FORMAT));
				// 退職日
				kss013.setTaishokuYmd(NSDDateUtils.stringToDate(getCsvItemValue(item[4]), DATE_FORMAT));
				// 在籍区分
				kss013.setZaisekiKbn(getCsvItemValue(item[5]));

				kss013Mapper.insert(kss013);

			} catch (Exception e) {
				throw new Exception("データ部：" + (lineNo - dataStartLine + 1) + "行目、" + e.getMessage());
			}
		}

		reader.close();

	}

	/**
	 * 組織所属情報を取込む
	 *
	 * @throws Exception
	 */
	private void readCsvFileToKss014() throws Exception {

		@SuppressWarnings("resource")
		BufferedReader reader = new BufferedReader(
				new InputStreamReader(new FileInputStream(nsdProperties.getBatchCsvFileKss014()), MOJI_ENCODE));

		String line = null;
		int lineNo = 0;

		while ((line = reader.readLine()) != null) {
			lineNo++;
			if (lineNo < dataStartLine) {
				continue;
			}

			if (lineNo == dataStartLine) {
				// 組織所属情報全件削除
				commMapper.deleteTable("Kss014");
			}

			Kss014 kss014 = new Kss014();

			try {
				String item[] = line.split(NSDConstant.STRING_KANMA);

				item = editArrayItem(item, 4);

				// ユーザーＩＤ
				kss014.setUserId(getCsvItemValue(item[0]));
				// 組織コード
				kss014.setSoshikiCd(getCsvItemValue(item[1]));
				// 兼務順
				kss014.setKenmuJun(Long.valueOf(getCsvItemValue(item[2])));
				// 適用開始日
				kss014.setTekiyoStartYmd(NSDDateUtils.stringToDate(getCsvItemValue(item[3]), DATE_FORMAT));

				kss014Mapper.insert(kss014);

			} catch (Exception e) {
				throw new Exception("データ部：" + (lineNo - dataStartLine + 1) + "行目、" + e.getMessage());
			}
		}

		reader.close();

	}

	/**
	 * CSVファイルを取込んだ項目値処理
	 *
	 * @param item
	 * @return
	 */
	private String getCsvItemValue(String item) {

		if (StringUtils.isEmpty(item)) {
			return NSDConstant.BLANK_STRING;
		}

		// クォーテーション有りの場合、移除
		if (quotation) {
			if (NSDConstant.STRING_DOUBLE_QUOTATION.equals(item.substring(0, 1))
					|| NSDConstant.STRING_SINGLE_QUOTATION.equals(item.substring(0, 1))) {
				item = item.substring(1, item.length() - 1);
			}
		}

		return item.trim();
	}

	/**
	 *
	 * @param item
	 * @param arrayLength
	 * @throws Exception
	 */
	private String[] editArrayItem(String item[], int arrayLength) throws Exception {
		if (item.length != arrayLength) {
			if (item.length == arrayLength - 1) {
				item = Arrays.copyOf(item, item.length + 1);
				item[item.length - 1] = NSDConstant.BLANK_STRING;
			} else {
				throw new Exception("CSVファイルの項目数は間違った。(" + item.length + "/" + arrayLength + ")");
			}
		}

		return item;
	}
}
