package jp.co.nsd.nkssweb.dao;

public class Kss014Key {
    private String userId;

    private Long kenmuJun;

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId == null ? null : userId.trim();
    }

    public Long getKenmuJun() {
        return kenmuJun;
    }

    public void setKenmuJun(Long kenmuJun) {
        this.kenmuJun = kenmuJun;
    }
}