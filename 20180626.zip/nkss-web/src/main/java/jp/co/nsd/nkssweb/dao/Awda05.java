package jp.co.nsd.nkssweb.dao;

import java.util.Date;

public class Awda05 {
    private String aw5ShuCod;

    private String aw5KouCod;

    private String aw5SaiCod;

    private String aw5Shu4Cod;

    private String aw5Shu5Cod;

    private String aw5Shu5Knj;

    private Integer aw5UpdateCnt;

    private Date aw5TorokDh;

    private String aw5TorshaCod;

    private Date aw5UpdateDh;

    private String aw5UpdshaCod;

    public String getAw5ShuCod() {
        return aw5ShuCod;
    }

    public void setAw5ShuCod(String aw5ShuCod) {
        this.aw5ShuCod = aw5ShuCod == null ? null : aw5ShuCod.trim();
    }

    public String getAw5KouCod() {
        return aw5KouCod;
    }

    public void setAw5KouCod(String aw5KouCod) {
        this.aw5KouCod = aw5KouCod == null ? null : aw5KouCod.trim();
    }

    public String getAw5SaiCod() {
        return aw5SaiCod;
    }

    public void setAw5SaiCod(String aw5SaiCod) {
        this.aw5SaiCod = aw5SaiCod == null ? null : aw5SaiCod.trim();
    }

    public String getAw5Shu4Cod() {
        return aw5Shu4Cod;
    }

    public void setAw5Shu4Cod(String aw5Shu4Cod) {
        this.aw5Shu4Cod = aw5Shu4Cod == null ? null : aw5Shu4Cod.trim();
    }

    public String getAw5Shu5Cod() {
        return aw5Shu5Cod;
    }

    public void setAw5Shu5Cod(String aw5Shu5Cod) {
        this.aw5Shu5Cod = aw5Shu5Cod == null ? null : aw5Shu5Cod.trim();
    }

    public String getAw5Shu5Knj() {
        return aw5Shu5Knj;
    }

    public void setAw5Shu5Knj(String aw5Shu5Knj) {
        this.aw5Shu5Knj = aw5Shu5Knj == null ? null : aw5Shu5Knj.trim();
    }

    public Integer getAw5UpdateCnt() {
        return aw5UpdateCnt;
    }

    public void setAw5UpdateCnt(Integer aw5UpdateCnt) {
        this.aw5UpdateCnt = aw5UpdateCnt;
    }

    public Date getAw5TorokDh() {
        return aw5TorokDh;
    }

    public void setAw5TorokDh(Date aw5TorokDh) {
        this.aw5TorokDh = aw5TorokDh;
    }

    public String getAw5TorshaCod() {
        return aw5TorshaCod;
    }

    public void setAw5TorshaCod(String aw5TorshaCod) {
        this.aw5TorshaCod = aw5TorshaCod == null ? null : aw5TorshaCod.trim();
    }

    public Date getAw5UpdateDh() {
        return aw5UpdateDh;
    }

    public void setAw5UpdateDh(Date aw5UpdateDh) {
        this.aw5UpdateDh = aw5UpdateDh;
    }

    public String getAw5UpdshaCod() {
        return aw5UpdshaCod;
    }

    public void setAw5UpdshaCod(String aw5UpdshaCod) {
        this.aw5UpdshaCod = aw5UpdshaCod == null ? null : aw5UpdshaCod.trim();
    }
}