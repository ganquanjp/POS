package jp.co.nsd.nkssweb.dao;

import java.util.Date;
import java.util.List;

public class SeisanshoJokyaku {

	// 行番号
	private int rowNo;

	// 除却精算書ＩＤ
	private String jokyakuSeisanShoId;

	// 除却資産ＩＤ
	private String jokyakuShisanId;

	// 除却精算書番号
	private String jokyakuSeisanShoNo;

	// 件名名称
	private String kenmeiNm;

	// 除却予定年月日(FROM)
	private String jokyakuYoteYmdFrom;

	// 除却予定年月日(TO)
	private String jokyakuYoteYmdTo;

	// 除却予定年月日
	private String jokyakuYoteYmd;

	// 摘要
	private String tekiyo;

	// 精算箇所コード
	private String seisanSoshikiCd;

	// 組織連結略名
	private String soshikiRenNm;

	// 登録者コード
	private String seisanEntryUserId;

	// 固定資産情報
	private List<SeisanshoJokyakuKoteiSisan> koteiSisanLst;

	private String mw1JkkseiKbn;
	private Date mw1UpdateDh;
	private String mw1UpdshaCod;
	private String mw1KoteiCod;
	private String mw1RrkCod;

	public int getRowNo() {
		return rowNo;
	}

	public void setRowNo(int rowNo) {
		this.rowNo = rowNo;
	}

	public String getJokyakuSeisanShoId() {
		return jokyakuSeisanShoId;
	}

	public void setJokyakuSeisanShoId(String jokyakuSeisanShoId) {
		this.jokyakuSeisanShoId = jokyakuSeisanShoId;
	}

	public String getJokyakuShisanId() {
		return jokyakuShisanId;
	}

	public void setJokyakuShisanId(String jokyakuShisanId) {
		this.jokyakuShisanId = jokyakuShisanId;
	}

	public String getJokyakuSeisanShoNo() {
		return jokyakuSeisanShoNo;
	}

	public void setJokyakuSeisanShoNo(String jokyakuSeisanShoNo) {
		this.jokyakuSeisanShoNo = jokyakuSeisanShoNo;
	}

	public String getKenmeiNm() {
		return kenmeiNm;
	}

	public void setKenmeiNm(String kenmeiNm) {
		this.kenmeiNm = kenmeiNm;
	}

	public String getJokyakuYoteYmdFrom() {
		return jokyakuYoteYmdFrom;
	}

	public void setJokyakuYoteYmdFrom(String jokyakuYoteYmdFrom) {
		this.jokyakuYoteYmdFrom = jokyakuYoteYmdFrom;
	}

	public String getJokyakuYoteYmdTo() {
		return jokyakuYoteYmdTo;
	}

	public void setJokyakuYoteYmdTo(String jokyakuYoteYmdTo) {
		this.jokyakuYoteYmdTo = jokyakuYoteYmdTo;
	}

	public String getJokyakuYoteYmd() {
		return jokyakuYoteYmd;
	}

	public void setJokyakuYoteYmd(String jokyakuYoteYmd) {
		this.jokyakuYoteYmd = jokyakuYoteYmd;
	}

	public String getTekiyo() {
		return tekiyo;
	}

	public void setTekiyo(String tekiyo) {
		this.tekiyo = tekiyo;
	}

	public String getSeisanSoshikiCd() {
		return seisanSoshikiCd;
	}

	public void setSeisanSoshikiCd(String seisanSoshikiCd) {
		this.seisanSoshikiCd = seisanSoshikiCd;
	}

	public String getSoshikiRenNm() {
		return soshikiRenNm;
	}

	public void setSoshikiRenNm(String soshikiRenNm) {
		this.soshikiRenNm = soshikiRenNm;
	}

	public String getSeisanEntryUserId() {
		return seisanEntryUserId;
	}

	public void setSeisanEntryUserId(String seisanEntryUserId) {
		this.seisanEntryUserId = seisanEntryUserId;
	}

	public List<SeisanshoJokyakuKoteiSisan> getKoteiSisanLst() {
		return koteiSisanLst;
	}

	public void setKoteiSisanLst(List<SeisanshoJokyakuKoteiSisan> koteiSisanLst) {
		this.koteiSisanLst = koteiSisanLst;
	}

	public String getMw1JkkseiKbn() {
		return mw1JkkseiKbn;
	}

	public void setMw1JkkseiKbn(String mw1JkkseiKbn) {
		this.mw1JkkseiKbn = mw1JkkseiKbn;
	}

	public Date getMw1UpdateDh() {
		return mw1UpdateDh;
	}

	public void setMw1UpdateDh(Date mw1UpdateDh) {
		this.mw1UpdateDh = mw1UpdateDh;
	}

	public String getMw1UpdshaCod() {
		return mw1UpdshaCod;
	}

	public void setMw1UpdshaCod(String mw1UpdshaCod) {
		this.mw1UpdshaCod = mw1UpdshaCod;
	}

	public String getMw1KoteiCod() {
		return mw1KoteiCod;
	}

	public void setMw1KoteiCod(String mw1KoteiCod) {
		this.mw1KoteiCod = mw1KoteiCod;
	}

	public String getMw1RrkCod() {
		return mw1RrkCod;
	}

	public void setMw1RrkCod(String mw1RrkCod) {
		this.mw1RrkCod = mw1RrkCod;
	}



}