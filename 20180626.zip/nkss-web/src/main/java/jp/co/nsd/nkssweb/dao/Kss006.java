package jp.co.nsd.nkssweb.dao;

import java.math.BigDecimal;
import java.util.Date;

public class Kss006 {
    private String jokyakuSeisanShoId;

    private String jokyakuSeisanShoNo;

    private String kenmeiNm;

    private String seisanSoshikiCd;

    private Date tekiyoStartYmd;

    private Date jokyakuYoteYmd;

    private Date jokyakuYmd;

    private String seisanEntryUserId;

    private Date tantoTekiyoStartYmd;

    private String tekiyo;

    private String shoninStatus;

    private String riyu;

    private BigDecimal hansu;

    private String ksOldSoshikiCd;

    private Date entryDate;

    private String entryUserId;

    private Date updateDate;

    private String updateUserId;

    public String getJokyakuSeisanShoId() {
        return jokyakuSeisanShoId;
    }

    public void setJokyakuSeisanShoId(String jokyakuSeisanShoId) {
        this.jokyakuSeisanShoId = jokyakuSeisanShoId == null ? null : jokyakuSeisanShoId.trim();
    }

    public String getJokyakuSeisanShoNo() {
        return jokyakuSeisanShoNo;
    }

    public void setJokyakuSeisanShoNo(String jokyakuSeisanShoNo) {
        this.jokyakuSeisanShoNo = jokyakuSeisanShoNo == null ? null : jokyakuSeisanShoNo.trim();
    }

    public String getKenmeiNm() {
        return kenmeiNm;
    }

    public void setKenmeiNm(String kenmeiNm) {
        this.kenmeiNm = kenmeiNm == null ? null : kenmeiNm.trim();
    }

    public String getSeisanSoshikiCd() {
        return seisanSoshikiCd;
    }

    public void setSeisanSoshikiCd(String seisanSoshikiCd) {
        this.seisanSoshikiCd = seisanSoshikiCd == null ? null : seisanSoshikiCd.trim();
    }

    public Date getTekiyoStartYmd() {
        return tekiyoStartYmd;
    }

    public void setTekiyoStartYmd(Date tekiyoStartYmd) {
        this.tekiyoStartYmd = tekiyoStartYmd;
    }

    public Date getJokyakuYoteYmd() {
        return jokyakuYoteYmd;
    }

    public void setJokyakuYoteYmd(Date jokyakuYoteYmd) {
        this.jokyakuYoteYmd = jokyakuYoteYmd;
    }

    public Date getJokyakuYmd() {
        return jokyakuYmd;
    }

    public void setJokyakuYmd(Date jokyakuYmd) {
        this.jokyakuYmd = jokyakuYmd;
    }

    public String getSeisanEntryUserId() {
        return seisanEntryUserId;
    }

    public void setSeisanEntryUserId(String seisanEntryUserId) {
        this.seisanEntryUserId = seisanEntryUserId == null ? null : seisanEntryUserId.trim();
    }

    public Date getTantoTekiyoStartYmd() {
        return tantoTekiyoStartYmd;
    }

    public void setTantoTekiyoStartYmd(Date tantoTekiyoStartYmd) {
        this.tantoTekiyoStartYmd = tantoTekiyoStartYmd;
    }

    public String getTekiyo() {
        return tekiyo;
    }

    public void setTekiyo(String tekiyo) {
        this.tekiyo = tekiyo == null ? null : tekiyo.trim();
    }

    public String getShoninStatus() {
        return shoninStatus;
    }

    public void setShoninStatus(String shoninStatus) {
        this.shoninStatus = shoninStatus == null ? null : shoninStatus.trim();
    }

    public String getRiyu() {
        return riyu;
    }

    public void setRiyu(String riyu) {
        this.riyu = riyu == null ? null : riyu.trim();
    }

    public BigDecimal getHansu() {
        return hansu;
    }

    public void setHansu(BigDecimal hansu) {
        this.hansu = hansu;
    }

    public String getKsOldSoshikiCd() {
        return ksOldSoshikiCd;
    }

    public void setKsOldSoshikiCd(String ksOldSoshikiCd) {
        this.ksOldSoshikiCd = ksOldSoshikiCd == null ? null : ksOldSoshikiCd.trim();
    }

    public Date getEntryDate() {
        return entryDate;
    }

    public void setEntryDate(Date entryDate) {
        this.entryDate = entryDate;
    }

    public String getEntryUserId() {
        return entryUserId;
    }

    public void setEntryUserId(String entryUserId) {
        this.entryUserId = entryUserId == null ? null : entryUserId.trim();
    }

    public Date getUpdateDate() {
        return updateDate;
    }

    public void setUpdateDate(Date updateDate) {
        this.updateDate = updateDate;
    }

    public String getUpdateUserId() {
        return updateUserId;
    }

    public void setUpdateUserId(String updateUserId) {
        this.updateUserId = updateUserId == null ? null : updateUserId.trim();
    }
}