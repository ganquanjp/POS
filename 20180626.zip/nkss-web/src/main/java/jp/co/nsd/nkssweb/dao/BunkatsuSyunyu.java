package jp.co.nsd.nkssweb.dao;

import java.util.List;

public class BunkatsuSyunyu {

	// 行番号
	private int rowNo;

	// 精算書ID
	private String seisanShoId;

	// 固定資産ID
	private String koteiShisanId;

	// 工事件名コード
	private String kenmeiCd;

	// 工事件名
	private String kmouwkKnj;

	// 精算箇所
	private String soshikiRenNm;

	// 精算書番号
	private String seisanShoNo;

	// サービス開始年月日
	private String serviceStartYmd;

	// サービス開始年月日
	private String serviceStartYmdF;

	// サービス開始年月日
	private String serviceStartYmdT;

	// 承認状態
	private String shoninStatus;

	// 承認状態名称
	private String shoninStatusNm;

	// 経理審査否認理由
	private String riyu;

	// 使用開始年月日
	private String siyoStartYmd;

	// 使用開始年月日
	private String siyoStartYmdF;

	// 使用開始年月日
	private String siyoStartYmdT;

	// 契約開始年月日
	private String keiyakuStartYmd;

	// 契約終了年月日
	private String keiyakuEndYmd;

	// 版数
	private String hansu;

	// 更新年月日
	private String updateDate;

	// 精算書固定資産情報を取得
	private List<BunkatsuSyunyuKoteiInfo> bsKtInfoLst;

	public int getRowNo() {
		return rowNo;
	}

	public void setRowNo(int rowNo) {
		this.rowNo = rowNo;
	}

	public String getSeisanShoId() {
		return seisanShoId;
	}

	public void setSeisanShoId(String seisanShoId) {
		this.seisanShoId = seisanShoId;
	}

	public String getKoteiShisanId() {
		return koteiShisanId;
	}

	public void setKoteiShisanId(String koteiShisanId) {
		this.koteiShisanId = koteiShisanId;
	}

	public String getKenmeiCd() {
		return kenmeiCd;
	}

	public void setKenmeiCd(String kenmeiCd) {
		this.kenmeiCd = kenmeiCd;
	}

	public String getKmouwkKnj() {
		return kmouwkKnj;
	}

	public void setKmouwkKnj(String kmouwkKnj) {
		this.kmouwkKnj = kmouwkKnj;
	}

	public String getSoshikiRenNm() {
		return soshikiRenNm;
	}

	public void setSoshikiRenNm(String soshikiRenNm) {
		this.soshikiRenNm = soshikiRenNm;
	}

	public String getSeisanShoNo() {
		return seisanShoNo;
	}

	public void setSeisanShoNo(String seisanShoNo) {
		this.seisanShoNo = seisanShoNo;
	}

	public String getServiceStartYmd() {
		return serviceStartYmd;
	}

	public void setServiceStartYmd(String serviceStartYmd) {
		this.serviceStartYmd = serviceStartYmd;
	}

	public String getServiceStartYmdF() {
		return serviceStartYmdF;
	}

	public void setServiceStartYmdF(String serviceStartYmdF) {
		this.serviceStartYmdF = serviceStartYmdF;
	}

	public String getServiceStartYmdT() {
		return serviceStartYmdT;
	}

	public void setServiceStartYmdT(String serviceStartYmdT) {
		this.serviceStartYmdT = serviceStartYmdT;
	}

	public String getShoninStatus() {
		return shoninStatus;
	}

	public void setShoninStatus(String shoninStatus) {
		this.shoninStatus = shoninStatus;
	}

	public String getShoninStatusNm() {
		return shoninStatusNm;
	}

	public void setShoninStatusNm(String shoninStatusNm) {
		this.shoninStatusNm = shoninStatusNm;
	}

	public String getRiyu() {
		return riyu;
	}

	public void setRiyu(String riyu) {
		this.riyu = riyu;
	}

	public String getSiyoStartYmd() {
		return siyoStartYmd;
	}

	public void setSiyoStartYmd(String siyoStartYmd) {
		this.siyoStartYmd = siyoStartYmd;
	}

	public String getSiyoStartYmdF() {
		return siyoStartYmdF;
	}

	public void setSiyoStartYmdF(String siyoStartYmdF) {
		this.siyoStartYmdF = siyoStartYmdF;
	}

	public String getSiyoStartYmdT() {
		return siyoStartYmdT;
	}

	public void setSiyoStartYmdT(String siyoStartYmdT) {
		this.siyoStartYmdT = siyoStartYmdT;
	}

	public String getKeiyakuStartYmd() {
		return keiyakuStartYmd;
	}

	public void setKeiyakuStartYmd(String keiyakuStartYmd) {
		this.keiyakuStartYmd = keiyakuStartYmd;
	}

	public String getKeiyakuEndYmd() {
		return keiyakuEndYmd;
	}

	public void setKeiyakuEndYmd(String keiyakuEndYmd) {
		this.keiyakuEndYmd = keiyakuEndYmd;
	}

	public String getHansu() {
		return hansu;
	}

	public void setHansu(String hansu) {
		this.hansu = hansu;
	}

	public String getUpdateDate() {
		return updateDate;
	}

	public void setUpdateDate(String updateDate) {
		this.updateDate = updateDate;
	}

	public List<BunkatsuSyunyuKoteiInfo> getBsKtInfoLst() {
		return bsKtInfoLst;
	}

	public void setBsKtInfoLst(List<BunkatsuSyunyuKoteiInfo> bsKtInfoLst) {
		this.bsKtInfoLst = bsKtInfoLst;
	}

}