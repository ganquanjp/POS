/***********************************************************************
*
*業務名: 工事精算システム
*機能名: 除却（登録・修正・削除）(サービス処理)
*
*機能概要: 除却情報を処理する。
*
*JavaＶｅｒ：J2SE1.8.0準拠
*
*更新履歴: Ver.1.00 2018/03/06　NSD　新規作成
***********************************************************************/
package jp.co.nsd.nkssweb.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import jp.co.nsd.nkssweb.dao.KanriFutanhimodzuki;
import jp.co.nsd.nkssweb.dao.Kss015;
import jp.co.nsd.nkssweb.dao.mapper.KanriFutanhimodzukiMapper;
import jp.co.nsd.nkssweb.dao.mapper.Kss015Mapper;
import jp.co.nsd.nkssweb.service.KanriFutanhimodzukiService;

/**
 * 管理箇所/負担箇所紐付（検索・修正・新規）処理
 *
 * @see KanriFutanhimodzukiService
 * @version 1.00
 */
@Service
@Transactional(value = "postgresqlTransactionManager")
public class KanriFutanhimodzukiServiceImpl implements KanriFutanhimodzukiService {

	@Autowired
	private KanriFutanhimodzukiMapper kanriFutanhimodzukiMapper;

	@Autowired
	private Kss015Mapper kss015Mapper;

	/**
	 * 管理箇所/負担箇所（検索）処理
	 *
	 * @param kanriFutanhimodzuki
	 *            INPUTパラメータ
	 * @return kfhList 管理箇所/負担箇所情報データリスト
	 * @version 1.00
	 */
	public List<KanriFutanhimodzuki> getKanriFutanInfo(KanriFutanhimodzuki kanriFutanhimodzuki) {

		// 除却情報を取得する
		List<KanriFutanhimodzuki> kfhList = kanriFutanhimodzukiMapper.selectByWhere(kanriFutanhimodzuki);

		if (kfhList.size() > 0) {
			for (int i = 1; i <= kfhList.size(); i++) {
				// ROWNOを設定する
				kfhList.get(i - 1).setRowNo(i);
			}
		} else {
			kfhList = null;
		}

		return kfhList;
	}

	/**
	 * 管理箇所/負担箇所紐付（登録）処理
	 *
	 * @param kss015Lst
	 *            INPUTパラメータ
	 * @version 1.00
	 */
	public int insertInfo(List<Kss015> kss015Lst) {

		for (Kss015 kss015 : kss015Lst) {

			// 除却資産明細登録
			kss015Mapper.insertSelective(kss015);
		}

		return 0;
	}

	/**
	 * 管理箇所/負担箇所紐付（更新）処理
	 *
	 * @param kss015UpdLst
	 *            INPUTパラメータ
	 * @param kss015DelLst
	 *            INPUTパラメータ
	 * @version 1.00
	 */
	public int updateInfo(List<Kss015> kss015InsLst, List<Kss015> kss015DelLst, List<Kss015> kss015UpdLst){

		// 変更したデータを削除する
		for (Kss015 kss015 : kss015DelLst) {

			// 管理／負担箇所の情報を削除
			kss015Mapper.deleteByPrimaryKey(kss015);
		}
		// 入力したデータを登録する
		for (Kss015 kss015 : kss015InsLst) {

			// 管理／負担箇所の情報を登録
			kss015Mapper.insertSelective(kss015);
		}
		// チェックしたデータを更新する
		for (Kss015 kss015 : kss015UpdLst) {

			// 管理／負担箇所の情報を更新
			kss015Mapper.updateByPrimaryKeySelective(kss015);
		}
		return 0;
	}

}
