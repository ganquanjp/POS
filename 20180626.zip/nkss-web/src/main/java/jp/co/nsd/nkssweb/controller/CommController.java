/***********************************************************************
*
*業務名: 工事精算システム
*機能名: 除却（登録・修正・削除）(ログ出力処理)
*
*機能概要: 除却情報を処理する。
*
*JavaＶｅｒ：J2SE1.8.0準拠
*
*更新履歴: Ver.1.00 2018/03/06　NSD　新規作成
***********************************************************************/

package jp.co.nsd.nkssweb.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import jp.co.nsd.nkssweb.dao.Abda09;
import jp.co.nsd.nkssweb.dao.Awda01;
import jp.co.nsd.nkssweb.dao.Awda02;
import jp.co.nsd.nkssweb.dao.Awda03;
import jp.co.nsd.nkssweb.dao.Awda04;
import jp.co.nsd.nkssweb.dao.Awda05;
import jp.co.nsd.nkssweb.dao.Awda06;
import jp.co.nsd.nkssweb.dao.Awda15;
import jp.co.nsd.nkssweb.dao.Awda20;
import jp.co.nsd.nkssweb.dao.Awdv02;
import jp.co.nsd.nkssweb.dao.CodeShubetsu;
import jp.co.nsd.nkssweb.dao.Kss016;
import jp.co.nsd.nkssweb.service.CommService;
import jp.co.nsd.nkssweb.utils.NSDConstant;

/**
 * 固定資産検索処理
 *
 * @version 1.00
 */
@RestController
public class CommController extends BaseController {

	@Autowired
	protected CommService commService;

	/*
	 * 条件よりコードマスタにコード情報を取得
	 */
	@RequestMapping(value = "/comm-getCodeShubetsuList", method = RequestMethod.POST)
	public Map<String, Object> getCodeShubetsuList(@RequestParam Map<String, Object> reqMap) throws Exception {

		Map<String, Object> resultMap = new HashMap<String, Object>();

		List<Kss016> kss016List = new ArrayList<Kss016>();

		CodeShubetsu codeShubetsu = new CodeShubetsu();

		codeShubetsu.setCodeShubetsu(reqMap);

		// サービスを呼び出す
		kss016List = commService.getCodeShubetsuList(codeShubetsu);

		// 処理結果データ
		setDataToResultMap(resultMap, kss016List);

		return resultMap;
	}

	/**
	 * パワー経理の発行組織
	 *
	 * @param reqMap
	 * @return
	 */
	@RequestMapping(value = "/comm-getHakouSoshiki", method = RequestMethod.POST)
	public Map<String, Object> getHakouSoshiki(@RequestParam Map<String, Object> reqMap) throws Exception {

		Map<String, Object> resultMap = new HashMap<String, Object>();

		List<Abda09> abda09List = new ArrayList<Abda09>();

		Abda09 abda09 = new Abda09();

		abda09.setAb9SoshikCod((String) reqMap.get("soshikCod"));

		// サービスを呼び出す
		abda09List = commService.getHakouSoshiki(abda09);

		// 処理結果データ
		setDataToResultMap(resultMap, abda09List);

		return resultMap;
	}

	/**
	 * 種類名称を取得
	 *
	 * @param reqMap
	 * @return
	 */
	@RequestMapping(value = "/comm-getShuNmLst", method = RequestMethod.POST)
	public Map<String, Object> getShuNmLst(@RequestParam Map<String, Object> reqMap) throws Exception {

		Map<String, Object> resultMap = new HashMap<String, Object>();

		List<Awda01> awda01List = new ArrayList<Awda01>();

		Awda01 awda01 = new Awda01();

		// サービスを呼び出す
		awda01List = commService.getShuNmLst(awda01);

		// 処理結果データ
		setDataToResultMap(resultMap, awda01List);

		return resultMap;
	}

	/**
	 * 構造名称を取得
	 *
	 * @param reqMap
	 * @return
	 */
	@RequestMapping(value = "/comm-getKouNmLst", method = RequestMethod.POST)
	public Map<String, Object> getKouNmLst(@RequestParam Map<String, Object> reqMap) throws Exception {

		Map<String, Object> resultMap = new HashMap<String, Object>();

		List<Awda02> awda02List = new ArrayList<Awda02>();

		Awda02 awda02 = new Awda02();

		// 種類コード
		awda02.setAw2ShuCod((String) reqMap.get("shuCod"));

		// サービスを呼び出す
		awda02List = commService.getKouNmLst(awda02);

		// 処理結果データ
		setDataToResultMap(resultMap, awda02List);

		return resultMap;
	}

	/**
	 * 資産単位名称を取得
	 *
	 * @param reqMap
	 * @return
	 */
	@RequestMapping(value = "/comm-getSaiNmLst", method = RequestMethod.POST)
	public Map<String, Object> getSaiNmLst(@RequestParam Map<String, Object> reqMap) throws Exception {

		Map<String, Object> resultMap = new HashMap<String, Object>();

		List<Awda03> awda03List = new ArrayList<Awda03>();

		Awda03 awda03 = new Awda03();
		// 種類コード
		awda03.setAw3ShuCod((String) reqMap.get("shuCod"));
		// 構造コード
		awda03.setAw3KouCod((String) reqMap.get("kouzou"));

		// サービスを呼び出す
		awda03List = commService.getSaiNmLst(awda03);

		// 処理結果データ
		setDataToResultMap(resultMap, awda03List);

		return resultMap;
	}

	/**
	 * 科目１名称を取得
	 *
	 * @param reqMap
	 * @return
	 */
	@RequestMapping(value = "/comm-getShu4NmLst", method = RequestMethod.POST)
	public Map<String, Object> getShu4NmLst(@RequestParam Map<String, Object> reqMap) throws Exception {

		Map<String, Object> resultMap = new HashMap<String, Object>();

		List<Awda04> awda04List = new ArrayList<Awda04>();

		Awda04 awda04 = new Awda04();

		// 種類コード
		awda04.setAw4ShuCod((String) reqMap.get("shuCod"));
		// 構造コード
		awda04.setAw4KouCod((String) reqMap.get("kouzou"));
		// 資産単位コード
		awda04.setAw4SaiCod((String) reqMap.get("shisanTani"));

		// サービスを呼び出す
		awda04List = commService.getShu4NmLst(awda04);

		// 処理結果データ
		setDataToResultMap(resultMap, awda04List);

		return resultMap;
	}

	/**
	 * 科目２名称を取得
	 *
	 * @param reqMap
	 * @return
	 */
	@RequestMapping(value = "/comm-getShu5NmLst", method = RequestMethod.POST)
	public Map<String, Object> getShu5NmLst(@RequestParam Map<String, Object> reqMap) throws Exception {

		Map<String, Object> resultMap = new HashMap<String, Object>();

		List<Awda05> awda05List = new ArrayList<Awda05>();

		Awda05 awda05 = new Awda05();

		// 種類コード
		awda05.setAw5ShuCod((String) reqMap.get("shuCod"));
		// 構造コード
		awda05.setAw5KouCod((String) reqMap.get("kouzou"));
		// 資産単位コード
		awda05.setAw5SaiCod((String) reqMap.get("shisanTani"));
		// 種別４コード
		awda05.setAw5Shu4Cod((String) reqMap.get("kamoku1"));

		// サービスを呼び出す
		awda05List = commService.getShu5NmLst(awda05);

		// 処理結果データ
		setDataToResultMap(resultMap, awda05List);

		return resultMap;
	}

	/**
	 * 科目３名称を取得
	 *
	 * @param reqMap
	 * @return
	 */
	@RequestMapping(value = "/comm-getShu6NmLst", method = RequestMethod.POST)
	public Map<String, Object> getShu6NmLst(@RequestParam Map<String, Object> reqMap) throws Exception {

		Map<String, Object> resultMap = new HashMap<String, Object>();

		List<Awda06> awda06List = new ArrayList<Awda06>();

		Awda06 awda06 = new Awda06();

		// 種類コード
		awda06.setAw6ShuCod((String) reqMap.get("shuCod"));
		// 構造コード
		awda06.setAw6KouCod((String) reqMap.get("kouzou"));
		// 資産単位コード
		awda06.setAw6SaiCod((String) reqMap.get("shisanTani"));
		// 種別４コード
		awda06.setAw6Shu4Cod((String) reqMap.get("kamoku1"));
		// 種別５コード
		awda06.setAw6Shu5Cod((String) reqMap.get("kamoku2"));

		// サービスを呼び出す
		awda06List = commService.getShu6NmLst(awda06);

		// 処理結果データ
		setDataToResultMap(resultMap, awda06List);

		return resultMap;
	}

	/**
	 * 単位を取得
	 *
	 * @param reqMap
	 * @return
	 */
	@RequestMapping(value = "/comm-getTaniLst", method = RequestMethod.POST)
	public Map<String, Object> getTaniLst(@RequestParam Map<String, Object> reqMap) throws Exception {

		Map<String, Object> resultMap = new HashMap<String, Object>();

		List<Awda15> awda15List = new ArrayList<Awda15>();

		Awda15 awda15 = new Awda15();

		// サービスを呼び出す
		awda15List = commService.getTaniLst(awda15);

		// 処理結果データ
		setDataToResultMap(resultMap, awda15List);

		return resultMap;
	}

	/**
	 * 名称定数を取得
	 *
	 * @param reqMap
	 * @return
	 */
	@RequestMapping(value = "/comm-getMeiShouLst", method = RequestMethod.POST)
	public Map<String, Object> getMeiShouLst(@RequestParam Map<String, Object> reqMap) throws Exception {

		Map<String, Object> resultMap = new HashMap<String, Object>();

		List<Awda20> awda20List = new ArrayList<Awda20>();

		Awda20 awda20 = new Awda20();

		// 種別コード
		awda20.setAwkKomokSbt((String) reqMap.get("awkKomokSbt"));

		// サービスを呼び出す
		awda20List = commService.getMeiShouLst(awda20);

		// 処理結果データ
		setDataToResultMap(resultMap, awda20List);

		return resultMap;
	}

	/**
	 * 種構細４５６の情報を取得
	 *
	 * @param reqMap
	 * @return
	 */
	@RequestMapping(value = "/comm-getShuKouSaiInfo", method = RequestMethod.POST)
	public Map<String, Object> getShuKouSaiInfo(@RequestParam Map<String, Object> reqMap) throws Exception {

		Map<String, Object> resultMap = new HashMap<String, Object>();

		List<Awdv02> awdv02List = new ArrayList<Awdv02>();

		Awdv02 awdv02 = new Awdv02();
		// 種類コード
		awdv02.setShuCod(reqMap.get("shuCod").toString().trim());
		// 構造コード
		awdv02.setKouCod(reqMap.get("kouCod").toString().trim());
		// 資産単位コード
		awdv02.setSaiCod(reqMap.get("saiCod").toString().trim());
		// 項目１コード
		awdv02.setShu4Cod(reqMap.get("shu4Cod").toString().trim());
		// 項目２コード
		awdv02.setShu5Cod(reqMap.get("shu5Cod").toString().trim());
		// 項目３コード
		awdv02.setShu6Cod(reqMap.get("shu6Cod").toString().trim());

		// サービスを呼び出す
		awdv02List  = commService.getAwdv02(awdv02);

		if (awdv02List.size() > 0) {
			resultMap.put(NSDConstant.RESULT_DATA_NAME, awdv02List.get(0));
			return resultMap;
		}

		return resultMap;
	}
}
