package jp.co.nsd.nkssweb.dao;

public class Message {

	private String msgId;

	private String content;

	private String msgLevel;

	public String getMsgId() {
		return msgId;
	}

	public void setMsgId(String msgId) {
		this.msgId = msgId;
		this.msgLevel=msgId.substring(0,1);
	}

	public String getMsgLevel() {
		return msgLevel;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}


}