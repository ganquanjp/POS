package jp.co.nsd.nkssweb.service.seisanshotoroku.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import jp.co.nsd.nkssweb.dao.Kss002;
import jp.co.nsd.nkssweb.dao.Kss004;
import jp.co.nsd.nkssweb.dao.SeisanshoToroku;
import jp.co.nsd.nkssweb.dao.mapper.Kss002Mapper;
import jp.co.nsd.nkssweb.dao.mapper.Kss004Mapper;
import jp.co.nsd.nkssweb.dao.mapper.SeisanshoTorokuMapper;
import jp.co.nsd.nkssweb.service.CommService;
import jp.co.nsd.nkssweb.service.seisanshotoroku.SeisanshoTorokuService;
import jp.co.nsd.nkssweb.utils.NSDConstant;

@Service
@Transactional(value = "postgresqlTransactionManager")
public class SeisanshoTorokuServiceImpl implements SeisanshoTorokuService {

	@Autowired
	private SeisanshoTorokuMapper sssTrkMapper;

	@Autowired
	private Kss002Mapper kss002Mapper;

	@Autowired
	private Kss004Mapper kss004Mapper;

	@Autowired
	private CommService commService;

	@Override
	public List<SeisanshoToroku> getSeisanshoTorokuKensaku(SeisanshoToroku selectCondition) {

		List<SeisanshoToroku> sssTrkList = new ArrayList<SeisanshoToroku>();

		sssTrkList = sssTrkMapper.selectByWhere(selectCondition);

		if (sssTrkList.size() > 0) {
			for (int i = 1; i <= sssTrkList.size(); i++) {
				sssTrkList.get(i - 1).setRowNo(i);
			}
		} else {
			sssTrkList = null;
		}

		return sssTrkList;

	}

	@Override
	public List<SeisanshoToroku> getSeisanshoTorokuShokai(SeisanshoToroku selectCondition) {

		List<SeisanshoToroku> sssTrkList = new ArrayList<SeisanshoToroku>();

		sssTrkList = sssTrkMapper.selectByKey(selectCondition);

		if (sssTrkList.size() > 0) {
			for (int i = 1; i <= sssTrkList.size(); i++) {
				sssTrkList.get(i - 1).setRowNo(i);

				SeisanshoToroku sssTrkDto = sssTrkList.get(i - 1);

				// 連携対象
				sssTrkDto.setRenkeiStatusKnj(
						commService.getCodeName(NSDConstant.CD_RENKEI_STATUS, sssTrkDto.getRenkeiStatus()));

				if (NSDConstant.STRING_1.equals(sssTrkDto.getRenkeiStatus())
						&& (NSDConstant.SHONIN_STATUS_CODE_SHONIN.equals(sssTrkDto.getShoninStatus())
								|| NSDConstant.SHONIN_STATUS_CODE_RENKEI.equals(sssTrkDto.getShoninStatus())
								|| NSDConstant.SHONIN_STATUS_CODE_JYOKYA.equals(sssTrkDto.getShoninStatus()))) {
					sssTrkDto.setUpdDisabled(true);
					sssTrkDto.setDelDisabled(true);
				} else {
					sssTrkDto.setUpdDisabled(false);
					sssTrkDto.setDelDisabled(false);

					if (NSDConstant.SHONIN_STATUS_CODE_TOROKU.equals(sssTrkDto.getShoninStatus())) {

						// 取得資産明細に存在確認
						Map<String, Object> selectMap = new HashMap<String, Object>();
						selectMap.put("seisanShoId", sssTrkDto.getSeisanShoId());
						String cnt = sssTrkMapper.selectConut(selectMap);

						// 取得資産明細情報の判断
						if (!NSDConstant.STRING_0.equals(cnt)) {
							sssTrkDto.setDelDisabled(true);
						}
					}
				}

			}
		} else {
			sssTrkList = null;
		}

		return sssTrkList;

	}

	@Override
	public void deleteSeisansho(Long kenmeiId, String seisanShoId) {

		// 該当精算書の連携ステータスを取得
		Kss002 kss002 = kss002Mapper.selectByPrimaryKey(kenmeiId);
		String selectrenkeiStatus = kss002.getRenkeiStatus();

		// 該当精算書の承認ステータスを取得
		String shoninStatus = NSDConstant.BLANK_STRING;
		List<Kss004> kss004List = new ArrayList<Kss004>();
		kss004List = sssTrkMapper.selectKss004BySeisanShoId(seisanShoId);
		if (kss004List.size() > 0) {
			shoninStatus = kss004List.get(0).getShoninStatus();
		}

		if (NSDConstant.SHONIN_STATUS_CODE_TOROKU.equals(shoninStatus)) {

			if (NSDConstant.STRING_0.equals(selectrenkeiStatus)) {
				// 件名マスタ内容削除
				kss002Mapper.deleteByPrimaryKey(kenmeiId);
			}
			// 精算書内容削除
			sssTrkMapper.deleteKss004BySeisanShoId(seisanShoId);

			// 取得資産明細削除
			sssTrkMapper.deleteKss005BySeisanShoId(seisanShoId);

		} else if (NSDConstant.SHONIN_STATUS_CODE_HININ.equals(shoninStatus)) {
			// 精算書内容削除
			sssTrkMapper.deleteKss004BySeisanShoId(seisanShoId);

			// 取得資産明細削除
			sssTrkMapper.deleteKss005BySeisanShoId(seisanShoId);
		}

	}

	/**
	 * 精算書登録
	 *
	 * @param kss002
	 * @param kss004List
	 */
	public void insertSeisansho(Kss002 kss002, List<Kss004> kss004List) {

		// 件名ID
		Long kenmeiId = 0L;
		// 件名マスタ情報を取得
		Kss002 chkKss002 = sssTrkMapper.getKss002(kss002);
		if (null == chkKss002) {
			kenmeiId = new Long(commService.getSequence(NSDConstant.KSS_SEQ_KENMEI_ID));
			// 件名ID
			kss002.setKenmeiId(kenmeiId);
			// 件名マスタに登録する
			kss002Mapper.insert(kss002);
		} else {
			kenmeiId = chkKss002.getKenmeiId();
		}

		// 予約件数分で精算書テーブルに登録する
		for (Kss004 kss004 : kss004List) {
			// 件名ＩＤ
			kss004.setKenmeiId(kenmeiId);
			// 精算書情報を登録
			kss004Mapper.insert(kss004);
		}
	}

	/**
	 * 件名テーブルに未連携データを取得
	 *
	 * @param parameterMap
	 *            INPUTパラメータ
	 * @return 取得件数
	 */
	public int selectKenmeiCdCnt(Map<String, Object> parameterMap) {

		return sssTrkMapper.selectKenmeiCdCnt(parameterMap);
	}

	/**
	 * 科目内訳定数から入力した件名データを取得
	 *
	 * @param parameterMap
	 *            INPUTパラメータ
	 * @return 取得件数
	 */
	public int selectAb8KenmeiCdCnt(Map<String, Object> parameterMap) {

		return sssTrkMapper.selectAb8KenmeiCdCnt(parameterMap);
	}

	/**
	 * 件名コード及び適用期間Fromが同一のデータを取得
	 *
	 * @param parameterMap
	 *            INPUTパラメータ
	 * @return 取得件数
	 */
	public String selectAb8SameTekiyoFData(Map<String, Object> parameterMap) {

		return sssTrkMapper.selectAb8SameTekiyoFData(parameterMap);
	}

	/**
	 * 適用期間が重複するデータを取得
	 *
	 * @param parameterMap
	 *            INPUTパラメータ
	 * @return 取得件数
	 */
	public int selectAb8Kikan(Map<String, Object> parameterMap) {

		return sssTrkMapper.selectAb8Kikan(parameterMap);
	}

	/**
	 * 科目内訳定数廃止登録データの存在判定を取得
	 *
	 * @param parameterMap
	 *            INPUTパラメータ
	 * @return 取得件数
	 */
	public String selectAb8HaiciData(Map<String, Object> parameterMap) {

		return sssTrkMapper.selectAb8HaiciData(parameterMap);
	}

	/**
	 * 精算書修正
	 *
	 * @param kss002
	 * @param kss004
	 * @param kss004List
	 */
	public void modifySeisansho(Kss002 kss002, Kss004 kss004, List<Kss004> kss004List) {

		// 件名ID
		Long kenmeiId = 0L;

		Kss002 inParamKss002 = new Kss002();
		// 件名コード
		inParamKss002.setKenmeiCd(kss002.getKenmeiCd());
		// 件名マスタ情報を取得
		Kss002 chkKss002 = sssTrkMapper.getKss002(inParamKss002);
		if (null == chkKss002) {
			kenmeiId = new Long(commService.getSequence(NSDConstant.KSS_SEQ_KENMEI_ID));
			// 件名ID
			kss002.setKenmeiId(kenmeiId);
			// 件名マスタ登録データを設定する（画面に存在以外の項目を設定）
			kss002.setRenkeiStatus(NSDConstant.CODE_RENKEI_STATUS_0);
			// 登録ユーザーＩＤ
			kss002.setEntryUserId(kss002.getUpdateUserId());
			// 登録年月日
			kss002.setEntryDate(kss002.getUpdateDate());
			// 件名マスタに登録する
			kss002Mapper.insert(kss002);
		} else {

			kenmeiId = chkKss002.getKenmeiId();

			if (kss002.getKenmeiId().equals(chkKss002.getKenmeiId())) {
				// 件名マスタを更新する
				kss002Mapper.updateByPrimaryKeySelective(kss002);
			}
		}

		// 件名ID
		kss004.setKenmeiId(kenmeiId);
		// 承認ステータ
		String shoninStatus = kss004.getShoninStatus();
		// 承認ステータスが「20：経理審査否認」の場合、「00：登録中」を変更します
		if (NSDConstant.SHONIN_STATUS_CODE_HININ.equals(kss004.getShoninStatus())) {
			shoninStatus = NSDConstant.SHONIN_STATUS_CODE_TOROKU;
		}
		// 承認ステータ
		kss004.setShoninStatus(shoninStatus);
		// 精算書テーブルを更新する
		sssTrkMapper.updateSeisanshoInfo(kss004);

		// 追加予約件数分で精算書テーブルに登録する
		for (Kss004 kss004Loop : kss004List) {
			// 件名ID
			kss004Loop.setKenmeiId(kenmeiId);
			// 承認ステータ
			kss004Loop.setShoninStatus(shoninStatus);

			kss004Mapper.insert(kss004Loop);
		}
	}
}
