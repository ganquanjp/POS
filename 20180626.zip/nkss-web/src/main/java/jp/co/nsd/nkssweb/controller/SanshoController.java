/***********************************************************************
*
*業務名: 工事精算システム
*機能名: 各参照ボタン用検索処理
*
*機能概要: 各参照ボタン用検索処理
*
*JavaＶｅｒ：J2SE1.8.0準拠
*
*更新履歴: Ver.1.00 2018/03/06　NSD　新規作成
***********************************************************************/

package jp.co.nsd.nkssweb.controller;

import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import jp.co.nsd.nkssweb.dao.InputCheck;
import jp.co.nsd.nkssweb.dao.KanriFutanks;
import jp.co.nsd.nkssweb.dao.KoteiSisan;
import jp.co.nsd.nkssweb.dao.SechiBasho;
import jp.co.nsd.nkssweb.dao.TorihikiSaki;
import jp.co.nsd.nkssweb.service.SanshoService;
import jp.co.nsd.nkssweb.utils.NSDConstant;
import jp.co.nsd.nkssweb.utils.NSDDataCheck;

/**
 * 参照ボタン用コントロール
 *
 * @version 1.00
 */
@RestController
public class SanshoController extends BaseController {

	@Autowired
	private SanshoService sanshoService;

	@Autowired
	private NSDDataCheck nsdDataCheck;

	/**
	 * 固定資産（検索）処理
	 *
	 * @param reqMap
	 *            INPUTパラメータ
	 * @return 固定資産情報データ
	 * @version 1.00
	 */
	@RequestMapping(value = "/sansho-koteishisan", method = RequestMethod.POST)
	public Map<String, Object> getKoteiShisan(@RequestParam Map<String, Object> reqMap) throws Exception {

		Map<String, Object> resultMap = new HashMap<String, Object>();

		// 入力チェック
		String errStr = inputCheckForSearch(reqMap);
		if (StringUtils.isNotEmpty(errStr)) {
			return setMsgToResultMap(resultMap, NSDConstant.MSGID_INPUT_ERROR, errStr);
		}

		KoteiSisan koteiSisan = new KoteiSisan();

		List<KoteiSisan> ktssList = new ArrayList<KoteiSisan>();

		// Mapの情報をBeanのプロパティにセット
		BeanUtils.populate(koteiSisan, reqMap);
		// 検索条件が入力するはのチェックを行う
		if (!NSDConstant.STRING_1.equals(koteiSisan.getHanteFlg()) && !isInputForSearch(koteiSisan)) {
			return setMsgToResultMap(resultMap, NSDConstant.MSGID_REC_SEARCH);
		}
		// サービス呼び出し
		ktssList = sanshoService.getKoteiSisanInfo(koteiSisan);

		// 検索結果を返却Mapに設定する
		setDataToResultMap(resultMap, ktssList);

		return resultMap;
	}

	/**
	 * 検索条件が入力するはのチェック
	 *
	 * @param koteiSisan
	 *            INPUTパラメータ
	 * @return true : 検索条件あり、 false : 検索条件なし
	 * @version 1.00
	 */
	private boolean isInputForSearch(KoteiSisan koteiSisan) {
		// 固定資産番号
		if(StringUtils.isNotEmpty(koteiSisan.getKoteiNo())) {
			return true;
		}
		// 親固定資産番号
		if(StringUtils.isNotEmpty(koteiSisan.getKoteioyaNo())) {
			return true;
		}
		// 固定資産名称
		if(StringUtils.isNotEmpty(koteiSisan.getKoteiKnj())) {
			return true;
		}
		// 取得年月日
		if(StringUtils.isNotEmpty(koteiSisan.getGetYmdFrom())){
			return true;
		}
		if(StringUtils.isNotEmpty(koteiSisan.getGetYmdTo())){
			return true;
		}
		// 管理箇所名称
		if(StringUtils.isNotEmpty(koteiSisan.getKanriKnj())){
			return true;
		}
		// 種類
		if(StringUtils.isNotEmpty(koteiSisan.getSyurui())){
			return true;
		}
		// 構造
		if(StringUtils.isNotEmpty(koteiSisan.getKouzo())){
			return true;
		}
		// 資産単位
		if(StringUtils.isNotEmpty(koteiSisan.getSisanTani())){
			return true;
		}
		// 科目1
		if(StringUtils.isNotEmpty(koteiSisan.getKamoku1())){
			return true;
		}
		// 科目2
		if(StringUtils.isNotEmpty(koteiSisan.getKamoku2())){
			return true;
		}
		// 科目3
		if(StringUtils.isNotEmpty(koteiSisan.getKamoku3())){
			return true;
		}
		// 設置場所名称
		if(StringUtils.isNotEmpty(koteiSisan.getBashoKnj())){
			return true;
		}
		// 摘要(連結)
		if(StringUtils.isNotEmpty(koteiSisan.getKomkKnj())){
			return true;
		}
		// 親子資産区分
		if(StringUtils.isNotEmpty(koteiSisan.getOyakosisankubun())){
			return true;
		}
		// 精算書番号
		if(StringUtils.isNotEmpty(koteiSisan.getSeisanShoNo())){
			return true;
		}
		// 精算箇所
		if(StringUtils.isNotEmpty(koteiSisan.getSoshikiRenNm())){
			return true;
		}
		// 使用開始年月日
		if(StringUtils.isNotEmpty(koteiSisan.getUseYmdFrom())){
			return true;
		}
		if(StringUtils.isNotEmpty(koteiSisan.getUseYmdTo())){
			return true;
		}
		// 担当者コード
		if(StringUtils.isNotEmpty(koteiSisan.getSeisanEntryUserId())){
			return true;
		}
		// 登録者氏名
		if(StringUtils.isNotEmpty(koteiSisan.getTorokusyaNm())){
			return true;
		}
		// 工事件名
		if(StringUtils.isNotEmpty(koteiSisan.getKmouwkKnj())){
			return true;
		}
		// 工事担当箇所
		if(StringUtils.isNotEmpty(koteiSisan.getKojiTantokasyo())){
			return true;
		}
		// 工事担当者
		if(StringUtils.isNotEmpty(koteiSisan.getKojiTantosya())){
			return true;
		}

		return false;
	}

	/**
	 * 検索の入力データチェック
	 *
	 * @param reqMap
	 *            INPUTパラメータ
	 * @return エラーメッセージID
	 * @version 1.00
	 */
	private String inputCheckForSearch(Map<String, Object> reqMap) {

		List<InputCheck> inputCheckList = getCheckItemListForSearch(reqMap);
		return nsdDataCheck.dataCheck(inputCheckList);

	}

	/**
	 * 検索の入力チェックリストを定義
	 *
	 * @param reqMap
	 *            INPUTパラメータ
	 * @return
	 */
	private List<InputCheck> getCheckItemListForSearch(Map<String, Object> reqMap) {

		List<InputCheck> inputCheckList = new ArrayList<InputCheck>();
		Map<Integer, Object> args;

		// 取得年月日
		if (StringUtils.isNotEmpty((String) reqMap.get("getYmdFrom"))) {
			args = new HashMap<Integer, Object>();
			args.put(NSDConstant.CHECK_ITEM.DATE_FORMAT_CHECK.ordinal(), null);
			inputCheckList.add(setInputCheck(reqMap, "getYmdFrom", "取得年月日(From)：", args));
		}

		if (StringUtils.isNotEmpty((String) reqMap.get("getYmdTo"))) {
			args = new HashMap<Integer, Object>();
			args.put(NSDConstant.CHECK_ITEM.DATE_FORMAT_CHECK.ordinal(), null);
			inputCheckList.add(setInputCheck(reqMap, "getYmdTo", "取得年月日(To)：", args));
		}

		args = new HashMap<Integer, Object>();
		args.put(NSDConstant.CHECK_ITEM.DATE_COMPARE_CHECK.ordinal(), (String) reqMap.get("getYmdTo"));
		inputCheckList.add(setInputCheck(reqMap, "getYmdFrom", "取得年月日：", args));

		// 使用開始年月日
		if (StringUtils.isNotEmpty((String) reqMap.get("useYmdFrom"))) {
			args = new HashMap<Integer, Object>();
			args.put(NSDConstant.CHECK_ITEM.DATE_FORMAT_CHECK.ordinal(), null);
			inputCheckList.add(setInputCheck(reqMap, "useYmdFrom", "使用開始年月日(From)：", args));
		}

		if (StringUtils.isNotEmpty((String) reqMap.get("useYmdTo"))) {
			args = new HashMap<Integer, Object>();
			args.put(NSDConstant.CHECK_ITEM.DATE_FORMAT_CHECK.ordinal(), null);
			inputCheckList.add(setInputCheck(reqMap, "useYmdTo", "使用開始年月日(To)：", args));
		}

		args = new HashMap<Integer, Object>();
		args.put(NSDConstant.CHECK_ITEM.DATE_COMPARE_CHECK.ordinal(), (String) reqMap.get("useYmdTo"));
		inputCheckList.add(setInputCheck(reqMap, "useYmdFrom", "使用開始年月日：", args));

		return inputCheckList;
	}

	/**
	 * 取引先（検索）処理
	 *
	 * @param reqMap
	 * @return
	 */
	@RequestMapping(value = "/sansho-torihikisaki", method = RequestMethod.POST)
	public Map<String, Object> getTorihikiSaki(@RequestParam Map<String, Object> reqMap) throws Exception {

		Map<String, Object> resultMap = new HashMap<String, Object>();

		TorihikiSaki torihikiSaki = new TorihikiSaki();

		List<TorihikiSaki> trhksList = new ArrayList<TorihikiSaki>();

		// Mapの情報をBeanのプロパティにセット
		BeanUtils.populate(torihikiSaki, reqMap);

		// サービス呼び出し
		trhksList = sanshoService.getTorihikiSakiInfo(torihikiSaki);

		// 検索結果を返却Mapに設定する
		setDataToResultMap(resultMap, trhksList);

		return resultMap;
	}

	/**
	 * 管理箇所/負担箇所検索処理
	 *
	 * @param reqMap
	 *            INPUTパラメータ
	 * @return 管理箇所/負担箇所情報データ
	 * @exception IllegalAccessException
	 * @exception InvocationTargetException
	 * @version 1.00
	 */
	@RequestMapping(value = "/sansho-kanrifutanks", method = RequestMethod.POST)
	public Map<String, Object> getKanriFutanks(@RequestParam Map<String, Object> reqMap) throws Exception {

		Map<String, Object> resultMap = new HashMap<String, Object>();

		KanriFutanks kanriFutanks = new KanriFutanks();

		List<KanriFutanks> krftList = new ArrayList<KanriFutanks>();

		// Mapの情報をBeanのプロパティにセット
		BeanUtils.populate(kanriFutanks, reqMap);

		// サービス呼び出し
		krftList = sanshoService.getKanriFutanInfo(kanriFutanks);

		// 検索結果を返却Mapに設定する
		setDataToResultMap(resultMap, krftList);

		return resultMap;
	}

	/**
	 * 設置場所（検索）処理
	 *
	 * @param reqMap
	 * @return
	 */
	@RequestMapping(value = "/sansho-sechibasho", method = RequestMethod.POST)
	public Map<String, Object> getSechiBasho(@RequestParam Map<String, Object> reqMap) throws Exception {

		Map<String, Object> resultMap = new HashMap<String, Object>();

		SechiBasho sechiBasho = new SechiBasho();

		List<SechiBasho> scbsList = new ArrayList<SechiBasho>();

		// Mapの情報をBeanのプロパティにセット
		BeanUtils.populate(sechiBasho, reqMap);

		// サービス呼び出し
		scbsList = sanshoService.getSechiBashoInfo(sechiBasho);

		// 検索結果を返却Mapに設定する
		setDataToResultMap(resultMap, scbsList);

		return resultMap;
	}

}
