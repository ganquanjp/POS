package jp.co.nsd.nkssweb.service;

import java.util.List;

import jp.co.nsd.nkssweb.dao.KoteshisanDaityo;
import jp.co.nsd.nkssweb.dao.KoteshisanDaityoFileInfo;

public interface KoteshisanDaityoService {

	/**
	 * 固定資産台帳ファイル情報取得
	 *
	 * @param userId
	 *            オペレータID バッチ："BATCH"、画面：ログインユーザーID
	 * @return
	 * @throws Exception
	 */
	List<KoteshisanDaityo> getKoteshisanDaityo(String userId) throws Exception;

	/**
	 * 固定資産台帳ファイル生成日時取得
	 *
	 *
	 */
	String getSakuseiTimestamp();

	/**
	 * 固定資産台帳ファイル情報取得
	 *
	 * @return
	 */
	List<KoteshisanDaityoFileInfo> getKoteishisanDaityoFileInfo();

}
