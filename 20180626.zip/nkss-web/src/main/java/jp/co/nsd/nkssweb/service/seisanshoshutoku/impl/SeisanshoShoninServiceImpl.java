/***********************************************************************
*
*業務名: 工事精算システム
*機能名: 除却（登録・修正・削除）(サービス処理)
*
*機能概要: 除却情報を処理する。
*
*JavaＶｅｒ：J2SE1.8.0準拠
*
*更新履歴: Ver.1.00 2018/03/06　NSD　新規作成
***********************************************************************/
package jp.co.nsd.nkssweb.service.seisanshoshutoku.impl;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import jp.co.nsd.nkssweb.dao.Kss004;
import jp.co.nsd.nkssweb.dao.SeisanshoShonin;
import jp.co.nsd.nkssweb.dao.SeisanshoShoninPrint;
import jp.co.nsd.nkssweb.dao.SeisanshoShoninShokai;
import jp.co.nsd.nkssweb.dao.SeisanshoShoninshutokuSisan;
import jp.co.nsd.nkssweb.dao.ShutokuKojiSeisansho;
import jp.co.nsd.nkssweb.dao.ShutokuSeisanDaityo;
import jp.co.nsd.nkssweb.dao.mapper.SeisanshoShoninMapper;
import jp.co.nsd.nkssweb.service.CommService;
import jp.co.nsd.nkssweb.service.seisanshoshutoku.SeisanshoShoninService;
import jp.co.nsd.nkssweb.utils.NSDConstant;
import jp.co.nsd.nkssweb.utils.NSDFileExporter;
import jp.co.nsd.nkssweb.utils.NSDProperties;
import net.sf.jasperreports.engine.data.JRBeanCollectionDataSource;

/**
 * 承認（検索・照会・更新）処理
 *
 * @see SeisanshoShoninService
 * @version 1.00
 */
@Service
@Transactional(value = "postgresqlTransactionManager")
public class SeisanshoShoninServiceImpl implements SeisanshoShoninService {

	@Autowired
	private SeisanshoShoninMapper seisanshoShoninMapper;

	@Autowired
	private CommService commService;

	@Autowired
	private NSDProperties nsdProperties;

	@Autowired
	private NSDFileExporter nsdFileExporter;

	/**
	 * 承認（検索）処理
	 *
	 * @param seisanshoShonin
	 *            INPUTパラメータ
	 * @return sssSNList 承認情報データリスト
	 * @version 1.00
	 */
	public List<SeisanshoShonin> getshoninInfo(SeisanshoShonin seisanshoShonin) {

		// 除却情報を取得する
		List<SeisanshoShonin> sssSNList = seisanshoShoninMapper.selectByWhere(seisanshoShonin);

		if (sssSNList.size() > 0) {
			for (int i = 0; i < sssSNList.size(); i++) {

				SeisanshoShonin sssSNSn = sssSNList.get(i);

				// ROWNOを設定する
				sssSNSn.setRowNo(i + 1);

				// 承認状態を設定する
				sssSNSn.setShoninStatusNm(
						commService.getCodeName(NSDConstant.CD_SHONIN_STATUS, sssSNSn.getShoninStatusCd()));

			}
		} else {
			sssSNList = null;
		}

		return sssSNList;
	}

	/**
	 * 取得承認（照会）処理
	 *
	 * @param seisanshoShoninShokai
	 *            INPUTパラメータ
	 * @return List<SeisanshoShoninShokai> 取得承認情報データ
	 * @version 1.00
	 */
	public SeisanshoShoninShokai getshutokuInfoBySeisanShoNo(SeisanshoShoninShokai seisanshoShoninShokai) {

		// 取得情報
		SeisanshoShoninShokai resultDao = new SeisanshoShoninShokai();

		// 取得情報を取得する
		List<SeisanshoShoninShokai> sssSnSkList = seisanshoShoninMapper.selectBySeisanShoNo(seisanshoShoninShokai);

		if (sssSnSkList.size() > 0) {
			resultDao = sssSnSkList.get(0);

			// 承認状態名称を設定する
			resultDao.setShoninStatusNm(
					commService.getCodeName(NSDConstant.CD_SHONIN_STATUS, resultDao.getShoninStatusCd()));

			// 取得資産明細リストの初期化
			resultDao.setShutokuSisanLst(new ArrayList<SeisanshoShoninshutokuSisan>());

			// 取得資産明細情報
			for (int i = 0; i < sssSnSkList.size(); i++) {

				SeisanshoShoninshutokuSisan sssSnStkSs = new SeisanshoShoninshutokuSisan();

				sssSnStkSs.setRowNo(i + 1);

				sssSnStkSs.setKoteiShisanNo(sssSnSkList.get(i).getKoteiShisanNo());

				sssSnStkSs.setKoteiShisanNm(sssSnSkList.get(i).getKoteiShisanNm());

				sssSnStkSs.setShutokuKagaku(sssSnSkList.get(i).getShutokuKagaku());

				sssSnStkSs.setShutokuYmd(sssSnSkList.get(i).getShutokuYmd());

				resultDao.getShutokuSisanLst().add(sssSnStkSs);
			}
		} else {
			resultDao = null;
		}

		return resultDao;
	}

	/**
	 * 取得承認（更新）処理
	 *
	 * @param kss004
	 *            INPUTパラメータ
	 * @return 結果
	 * @throws Exception
	 * @version 1.00
	 */
	public int updateInfo(Kss004 kss004) throws Exception {

		// 更新処理を行う
		int cnt = seisanshoShoninMapper.updateByPrimaryKey(kss004);

		return cnt;
	}

	/**
	 * UPDATE処理の前に追加のエラーチェックを行います。
	 *
	 * @param kss004
	 *            INPUTパラメータ
	 * @return 結果
	 * @throws Exception
	 * @version 1.00
	 */
	public String checkUpdate(Kss004 kss004) throws Exception {
		// 固定資産混在チェック
		SeisanshoShoninShokai resultChkKouCnt = seisanshoShoninMapper.getChkKouCnt(kss004);
		if (null != resultChkKouCnt) {
			// 取得してデータがあるの場合
			if (resultChkKouCnt.getKouCnt() > 1) {
				// 混在有りの場合
				return NSDConstant.MSGID_KOTEI_LEASE_KONZAI;
			}
		} else {
			// 上記以外の場合
			// TODO E00000
			return NSDConstant.MSGID_SYSTEM_ERROR;
		}
		// 種別がリースかを判定
		List<SeisanshoShoninShokai> resultChkLiaseFlg = seisanshoShoninMapper.getChkLiaseFlg(kss004);
		List<SeisanshoShoninShokai> resultChkToriTaiCnt = new ArrayList<>();
		if (resultChkLiaseFlg.size() > 0) {
			// 取得してデータがあるの場合
			if (NSDConstant.STRING_1.equals(resultChkLiaseFlg.get(0).getLeaseFlg())) {
				// 種別がリースの場合

				// 固定資産の取引先・耐用年数混在チェック
				resultChkToriTaiCnt = seisanshoShoninMapper.getChkToriTaiCnt(kss004);
				if (resultChkToriTaiCnt.size() > 0) {
					// 取得してデータがあるの場合
					if (resultChkToriTaiCnt.get(0).getToriTaiCnt() > 1) {
						// 混在有り
						return NSDConstant.MSGID_TAIYOU_NOT_EQUALS;
					}
				} else {
					// 上記以外の場合
					return NSDConstant.MSGID_SYSTEM_ERROR;
				}
			}
		} else {
			// 上記以外の場合
			return NSDConstant.MSGID_SYSTEM_ERROR;
		}

		return null;
	}

	/**
	 * 取得承認情報印刷
	 *
	 * @param seisanShoId
	 *            INPUTパラメータ
	 * @return 結果
	 * @throws Exception
	 */
	@Override
	public List<String> printing(String seisanShoId) throws Exception {

		List<Map<String, Object>> pdfMap = new ArrayList<>();

		Map<String, Object> map = null;

		// ファイル名
		String fileName = "工事精算書";

		// 工事精算書ＰＤＦのデータを設定
		List<ShutokuKojiSeisansho> printSeisanshoLst = setKojiSeisanshoPdf(seisanShoId);
		map = new HashMap<>();
		map.put("jrbcds", new JRBeanCollectionDataSource(printSeisanshoLst));
		map.put("templateFile",
				nsdProperties.getTemplateFilePath().concat(nsdProperties.getTemplatePdfNameKSS031P040()));
		// 工事精算書PDF
		pdfMap.add(map);

		// 資産台帳別内訳ＰＤＦのデータを設定
		List<ShutokuSeisanDaityo> printSeisanDaityoLst = setSeisanDaityoPdf(seisanShoId);
		map = new HashMap<>();
		map.put("jrbcds", new JRBeanCollectionDataSource(printSeisanDaityoLst));
		map.put("templateFile",
				nsdProperties.getTemplateFilePath().concat(nsdProperties.getTemplatePdfNameKSS031P050()));
		// 工事精算書PDF
		pdfMap.add(map);

		nsdFileExporter.exportPdf(pdfMap, fileName);

		// 帳票名称の保存
		List<String> pdfFileNameLst = new ArrayList<>();
		pdfFileNameLst.add(fileName);

		return pdfFileNameLst;
	}

	/**
	 * 工事精算書ＰＤＦのデータを設定
	 *
	 * @param seisanShoId
	 *            INPUTパラメータ
	 * @return 結果
	 */
	private List<ShutokuKojiSeisansho> setKojiSeisanshoPdf(String seisanShoId) {

		List<ShutokuKojiSeisansho> printLst = new ArrayList<>();

		SeisanshoShoninPrint seisanshoInfo = seisanshoShoninMapper.getSeisanShoInfo(seisanShoId);

		ShutokuKojiSeisansho printInfo = null;
		Date date = new Date();
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd");
		String nowDate = sdf.format(date);

		// 固定資産情報
		List<SeisanshoShoninPrint> koteiShisanInfoLst = seisanshoShoninMapper.getKoteiInfo(seisanShoId);

		for (SeisanshoShoninPrint koteiShisanInfo : koteiShisanInfoLst) {

			printInfo = new ShutokuKojiSeisansho();
			// 処理No.
			printInfo.setHansu(seisanshoInfo.getHansu());
			// 作成日
			printInfo.setSakuseiDate(nowDate);
			// 工事件名
			printInfo.setKenmei("[".concat(seisanshoInfo.getKenmeiCd()).concat("]").concat("：")
					.concat(seisanshoInfo.getKenmeiNm()));
			// 精算箇所
			printInfo.setSeisanSoshiki("[".concat(seisanshoInfo.getSoshikiCd()).concat("]").concat("：")
					.concat(seisanshoInfo.getSoshikiRenNm()));
			// 精算書番号
			printInfo.setSeisanShoNo(seisanshoInfo.getSeisanShoNo());
			// 使用開始年月日
			printInfo.setSiyoStartYmd(seisanshoInfo.getSiyoStartYmd());
			// 摘要
			printInfo.setTekiyo(seisanshoInfo.getTekiyo());
			// 総件数
			printInfo.setShutokuSisanCnt(seisanshoInfo.getShutokuSisanCnt());
			// 総額
			printInfo.setShutokuKagaku(seisanshoInfo.getShutokuKagaku());
			// 種類
			String shurui = "[".concat(koteiShisanInfo.getShuruiCd()).concat("]").concat("：")
					.concat(koteiShisanInfo.getShuKnj());
			// 構造
			String kouzou = "[".concat(koteiShisanInfo.getKouzouCd()).concat("]").concat("：")
					.concat(koteiShisanInfo.getKouKnj());
			// 資産単位
			String shisanTani = "[".concat(koteiShisanInfo.getShisanTaniCd()).concat("]").concat("：")
					.concat(koteiShisanInfo.getSaiKnj());
			// 科目1
			String kamoku1 = "[".concat(koteiShisanInfo.getKamokuCd1()).concat("]").concat("：")
					.concat(koteiShisanInfo.getShu4Knj());
			// 科目2
			String kamoku2 = "[".concat(koteiShisanInfo.getKamokuCd2()).concat("]").concat("：")
					.concat(koteiShisanInfo.getShu5Knj());
			// 科目3
			String kamoku3 = "[".concat(koteiShisanInfo.getKamokuCd3()).concat("]").concat("：")
					.concat(koteiShisanInfo.getShu6Knj());
			String shubetsuCode = shurui.concat("/").concat(kouzou).concat("/").concat(shisanTani).concat("/")
					.concat(kamoku1).concat("/").concat(kamoku2).concat("/").concat(kamoku3);
			// 種類・構造・資産単位・科目1・科目2・科目3（種構資１２３）
			printInfo.setShubetsuCode(shubetsuCode);
			String torihikiSaki = "[".concat(koteiShisanInfo.getTorihikiSakiCd()).concat("]").concat("：")
					.concat(koteiShisanInfo.getTorihikiSakiNm());
			// 取引先
			printInfo.setTorihikiSaki(torihikiSaki);
			// 件数
			printInfo.setKenSu(koteiShisanInfo.getKenSu());
			// 取得価額
			printInfo.setRwgGetkgkYen(koteiShisanInfo.getRwgGetkgkYen());

			printLst.add(printInfo);
		}

		return printLst;
	}

	/**
	 * 資産台帳別内訳ＰＤＦのデータを設定
	 *
	 * @param seisanShoId
	 *            INPUTパラメータ
	 * @return 結果
	 */
	private List<ShutokuSeisanDaityo> setSeisanDaityoPdf(String seisanShoId) {

		List<ShutokuSeisanDaityo> printLst = new ArrayList<>();

		List<SeisanshoShoninPrint> seisanDaityoInfoLst = seisanshoShoninMapper.getSeisanDaityoInfo(seisanShoId);

		ShutokuSeisanDaityo printInfo = null;
		for (SeisanshoShoninPrint seisanDaityoInfo : seisanDaityoInfoLst) {
			printInfo = new ShutokuSeisanDaityo();

			// 固定資産
			String koteiShisan = "[".concat(seisanDaityoInfo.getKoteiShisanNo()).concat("]").concat("：")
					.concat(seisanDaityoInfo.getKoteiShisanNm());
			printInfo.setKoteiShisan(koteiShisan);
			// 取得年月日
			printInfo.setShutokuYmd(seisanDaityoInfo.getShutokuYmd());
			// 取引先
			String torihikiSaki = "[".concat(seisanDaityoInfo.getTorihikiSakiCd()).concat("]").concat("：")
					.concat(seisanDaityoInfo.getTorihikiSakiNm());
			printInfo.setTorihikiSaki(torihikiSaki);
			// 親固定資産番号
			printInfo.setOyaKoteiShisanNo(seisanDaityoInfo.getOyaKoteiShisanNo());
			// 枝番
			printInfo.setEdaNo(seisanDaityoInfo.getEdaNo());
			// 種類
			String shurui = "[".concat(seisanDaityoInfo.getShuruiCd()).concat("]").concat("：")
					.concat(seisanDaityoInfo.getShuKnj());
			// 構造
			String kouzou = "[".concat(seisanDaityoInfo.getKouzouCd()).concat("]").concat("：")
					.concat(seisanDaityoInfo.getKouKnj());
			// 資産単位
			String shisanTani = "[".concat(seisanDaityoInfo.getShisanTaniCd()).concat("]").concat("：")
					.concat(seisanDaityoInfo.getSaiKnj());
			// 科目1
			String kamoku1 = "[".concat(seisanDaityoInfo.getKamokuCd1()).concat("]").concat("：")
					.concat(seisanDaityoInfo.getShu4Knj());
			// 科目2
			String kamoku2 = "[".concat(seisanDaityoInfo.getKamokuCd2()).concat("]").concat("：")
					.concat(seisanDaityoInfo.getShu5Knj());
			// 科目3
			String kamoku3 = "[".concat(seisanDaityoInfo.getKamokuCd3()).concat("]").concat("：")
					.concat(seisanDaityoInfo.getShu6Knj());
			String shubetsuCode = shurui.concat("/").concat(kouzou).concat("/").concat(shisanTani).concat("/")
					.concat(kamoku1).concat("/").concat(kamoku2).concat("/").concat(kamoku3);
			// 種類・構造・資産単位・科目1・科目2・科目3（種構資１２３）
			printInfo.setShubetsuCode(shubetsuCode);
			// 耐用年数（税／商）
			String taiyoNensu = seisanDaityoInfo.getTaiyoNensuZei().concat("／")
					.concat(seisanDaityoInfo.getTaiyoNensuSho());
			printInfo.setTaiyoNensu(taiyoNensu);
			// 償却方法（税／商）
			String syokyakuHoho = seisanDaityoInfo.getSyokyakuMeishoKnjZei().concat("／")
					.concat(seisanDaityoInfo.getSyokyakuMeishoKnjSho());
			printInfo.setSyokyakuHoho(syokyakuHoho);
			// 物品
			printInfo.setBuppin(seisanDaityoInfo.getBuppin());
			// 工費
			printInfo.setKouhiGaku(seisanDaityoInfo.getKouhiGaku());
			// 総係費
			printInfo.setSouKeihiGaku(seisanDaityoInfo.getSouKeihiGaku());
			// 取得価額（合計）
			printInfo.setRwgGetkgkYenSum(seisanDaityoInfo.getRwgGetkgkYenSum());
			// 物品数量（単位）
			String suryoTani = seisanDaityoInfo.getSuryo().concat("(").concat(seisanDaityoInfo.getTaniKnj())
					.concat(")");
			printInfo.setSuryoTani(suryoTani);
			// 管理箇所
			String kanriSoshiki = "[".concat(seisanDaityoInfo.getKanriSoshikiCd()).concat("]").concat("：")
					.concat(seisanDaityoInfo.getKanriSoshikKnj());
			printInfo.setKanriSoshiki(kanriSoshiki);
			// 負担箇所
			String futanSoshiki = "[".concat(seisanDaityoInfo.getFutanSoshikiCd()).concat("]").concat("：")
					.concat(seisanDaityoInfo.getFutanSoshikKnj());
			printInfo.setFutanSoshiki(futanSoshiki);
			// 設置場所
			String sechiBasho = "[".concat(seisanDaityoInfo.getBashoCd()).concat("]").concat("：")
					.concat(seisanDaityoInfo.getBashoKnj());
			printInfo.setSechiBasho(sechiBasho);
			// 製品名/型番/製品会社名称
			printInfo.setSeihinKataSeizo(seisanDaityoInfo.getSeihinKataSeizo());
			// 摘要１
			printInfo.setTekiyo1(seisanDaityoInfo.getTekiyo1());
			// 摘要２
			printInfo.setTekiyo2(seisanDaityoInfo.getTekiyo2());
			// 摘要３
			printInfo.setTekiyo3(seisanDaityoInfo.getTekiyo3());
			// 摘要４
			printInfo.setTekiyo4(seisanDaityoInfo.getTekiyo4());
			// 摘要５
			printInfo.setTekiyo5(seisanDaityoInfo.getTekiyo5());
			// 工事担当箇所
			printInfo.setKojiTantoSoshiki(seisanDaityoInfo.getKojiTantoSoshikiCd());
			// 工事担当者
			printInfo.setKojiTantoUser(seisanDaityoInfo.getKojiTantoUserNm());

			printLst.add(printInfo);
		}

		return printLst;
	}

}
