/***********************************************************************
*
*業務名: 工事精算システム
*機能名: 除却（経理審査/連携）(ログ出力処理)
*
*機能概要: 除却情報を処理する。
*
*JavaＶｅｒ：J2SE1.8.0準拠
*
*更新履歴: Ver.1.00 2018/03/06　NSD　新規作成
***********************************************************************/

package jp.co.nsd.nkssweb.controller.seisanshoshutoku;

import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import jp.co.nsd.nkssweb.controller.BaseController;
import jp.co.nsd.nkssweb.dao.Abda09;
import jp.co.nsd.nkssweb.dao.InputCheck;
import jp.co.nsd.nkssweb.dao.Kss004;
import jp.co.nsd.nkssweb.dao.SeisanshoShutokuKeiri;
import jp.co.nsd.nkssweb.dao.SeisanshoShutokuKrsk;
import jp.co.nsd.nkssweb.service.CommService;
import jp.co.nsd.nkssweb.service.InputCheckService;
import jp.co.nsd.nkssweb.service.SystemService;
import jp.co.nsd.nkssweb.service.seisanshoshutoku.SeisanshoShutokuKeiriService;
import jp.co.nsd.nkssweb.utils.NSDCommUtils;
import jp.co.nsd.nkssweb.utils.NSDConstant;
import jp.co.nsd.nkssweb.utils.NSDDataCheck;
import jp.co.nsd.nkssweb.utils.NSDDateUtils;

/**
 * 取得（経理審査/連携）処理
 *
 * @version 1.00
 */
@RestController
public class SeisanshoShutokuKeiriController extends BaseController {

	@Autowired
	private SeisanshoShutokuKeiriService seisanshoShutokuKeiriService;

	@Autowired
	protected SystemService systemService;

	@Autowired
	protected InputCheckService inputCheckService;

	@Autowired
	private NSDDataCheck nsdDataCheck;

	@Autowired
	private CommService commService;

	/**
	 * 取得（経理審査/連携）検索処理
	 *
	 * @param reqMap
	 *            INPUTパラメータ
	 * @return 取得情報データ
	 * @exception IllegalAccessException
	 * @exception InvocationTargetException
	 * @version 1.00
	 */
	@RequestMapping(value = "/seisanshoShutokuKeiri-selectByWhere", method = RequestMethod.POST)
	public Map<String, Object> selectByWhere(@RequestParam Map<String, Object> reqMap) throws Exception {

		Map<String, Object> resultMap = new HashMap<String, Object>();

		// 入力チェック
		String errStr = inputCheckForSearch(reqMap);
		if (StringUtils.isNotEmpty(errStr)) {
			return setMsgToResultMap(resultMap, NSDConstant.MSGID_INPUT_ERROR, errStr);
		}

		SeisanshoShutokuKeiri seisanshoShutokuKeiri = new SeisanshoShutokuKeiri();

		List<SeisanshoShutokuKeiri> sssStkKrLst = new ArrayList<>();

		// Mapの情報をBeanのプロパティにセット
		BeanUtils.populate(seisanshoShutokuKeiri, reqMap);

		// サービス呼び出し
		sssStkKrLst = seisanshoShutokuKeiriService.getshutokuKeiriInfo(seisanshoShutokuKeiri);

		// 検索結果を返却Mapに設定する
		setDataToResultMap(resultMap, sssStkKrLst);

		// 画面へ返却値を返却する
		return resultMap;
	}

	/**
	 * 検索の入力データチェック
	 *
	 * @param reqMap
	 *            INPUTパラメータ
	 * @return エラーメッセージID
	 * @version 1.00
	 */
	private String inputCheckForSearch(Map<String, Object> reqMap) {

		List<InputCheck> inputCheckList = getCheckItemListForSearch(reqMap);
		return nsdDataCheck.dataCheck(inputCheckList);

	}

	/**
	 * 検索の入力チェックリストを定義
	 *
	 * @param reqMap
	 *            INPUTパラメータ
	 * @return
	 */
	private List<InputCheck> getCheckItemListForSearch(Map<String, Object> reqMap) {

		List<InputCheck> inputCheckList = new ArrayList<InputCheck>();
		Map<Integer, Object> args;

		// 使用開始年月日
		if (StringUtils.isNotEmpty((String) reqMap.get("siyoStartYmdFrom"))) {
			args = new HashMap<Integer, Object>();
			args.put(NSDConstant.CHECK_ITEM.DATE_FORMAT_CHECK.ordinal(), null);
			inputCheckList.add(setInputCheck(reqMap, "siyoStartYmdFrom", "使用開始年月日(From)：", args));
		}

		if (StringUtils.isNotEmpty((String) reqMap.get("siyoStartYmdTo"))) {
			args = new HashMap<Integer, Object>();
			args.put(NSDConstant.CHECK_ITEM.DATE_FORMAT_CHECK.ordinal(), null);
			inputCheckList.add(setInputCheck(reqMap, "siyoStartYmdTo", "使用開始年月日(To)：", args));
		}

		args = new HashMap<Integer, Object>();
		args.put(NSDConstant.CHECK_ITEM.DATE_COMPARE_CHECK.ordinal(), (String) reqMap.get("siyoStartYmdTo"));
		inputCheckList.add(setInputCheck(reqMap, "siyoStartYmdFrom", "使用開始年月日：", args));

		return inputCheckList;
	}

	/**
	 * 取得（経理審査/連携）照会処理
	 *
	 * @param reqMap
	 *            INPUTパラメータ
	 * @return 取得情報データ
	 * @exception IllegalAccessException
	 * @exception InvocationTargetException
	 * @version 1.00
	 */
	@RequestMapping(value = "/seisanshoShutokuKrsk-selectBySeisanShoNo", method = RequestMethod.POST)
	public Map<String, Object> selectBySeisanShoNo(@RequestParam Map<String, Object> reqMap) throws Exception {

		Map<String, Object> resultMap = new HashMap<String, Object>();

		SeisanshoShutokuKrsk seisanshoShutokuKrsk = new SeisanshoShutokuKrsk();
		SeisanshoShutokuKrsk sssSNSkDto = new SeisanshoShutokuKrsk();

		// Mapの情報をBeanのプロパティにセット
		BeanUtils.populate(seisanshoShutokuKrsk, reqMap);

		// サービス呼び出し
		sssSNSkDto = seisanshoShutokuKeiriService.getshutokuInfoBySeisanShoNo(seisanshoShutokuKrsk);

		// 検索結果を返却Mapに設定する
		setDataToResultMap(resultMap, sssSNSkDto);

		// 画面へ返却値を返却する
		return resultMap;

	}

	/**
	 * 取得（経理審査/連携）更新処理
	 *
	 * @param reqMap
	 *            INPUTパラメータ
	 * @return 取得情報データ
	 * @exception IllegalAccessException
	 * @exception InvocationTargetException
	 * @version 1.00
	 * @throws Exception
	 */
	@RequestMapping(value = "/seisanshoShutokuKeiri-updateInfo", method = RequestMethod.POST)
	public Map<String, Object> updateInfo(HttpServletRequest request, @RequestParam Map<String, Object> reqMap)
			throws Exception {

		Map<String, Object> resultMap = new HashMap<String, Object>();

		// 入力チェック
		String errStr = inputCheckForUpdate(reqMap);
		if (StringUtils.isNotEmpty(errStr)) {
			return setMsgToResultMap(resultMap, NSDConstant.MSGID_INPUT_ERROR, errStr);
		}

		// 画面取得資産明細件数取得
		Set<String> set = countViewRecord(reqMap);

		// 会計整理年月
		String kaikeiSeiriYm = (String) reqMap.get("kaikeiSeiriYm");

		// 発行組織コード
		String hakouSoshikiCd = getHakouSoshikiCdBySoshikiNm(reqMap);

		Date date = new Date();
		// 更新チェック
		boolean updChk;
		List<Kss004> kss004UpdLst = new ArrayList<Kss004>();
		// 取得資産情報を取得
		for (int i = 0; i < set.size(); i++) {
			Kss004 kss004 = new Kss004();
			updChk = false;
			String keyUpd = "sisanInfoLst".concat("[" + i + "]").concat("[upd]");
			if (null != reqMap.get(keyUpd)) {
				updChk = Boolean.valueOf((String) reqMap.get(keyUpd));
			}
			if (!updChk) {
				continue;
			}

			// 承認状態
			String shoninStatus = (String) reqMap.get("sisanInfoLst".concat("[" + i + "]").concat("[shoninStatusCd]"));

			// 理由
			String riyu = (String) reqMap.get("sisanInfoLst".concat("[" + i + "]").concat("[riyu]"));
			// 取得資産書ＩＤ
			String seisanShoId = (String) reqMap.get("sisanInfoLst".concat("[" + i + "]").concat("[seisanShoId]"));

			// 取得資産書ＩＤ
			kss004.setSeisanShoId(seisanShoId);
			// 承認状態
			kss004.setShoninStatus(shoninStatus);
			// 理由
			kss004.setRiyu(riyu);
			// 更新年月日
			kss004.setUpdateDate(date);
			// 更新ユーザーＩＤ
			kss004.setUpdateUserId(this.getLoginUserInfo(request).getUserId());

			// 排他チェック
			String errId = commService.doHaita(kss004, (String) reqMap.get("sisanInfoLst".concat("[" + i + "]").concat("[updateDate]")));
			if (!NSDConstant.BLANK_STRING.equals(errId)) {
				return setMsgToResultMap(resultMap, errId);
			}

			kss004UpdLst.add(kss004);
		}

		if (kss004UpdLst.size() == 0) {
			errStr = NSDCommUtils
					.setKakoToStr(systemService.getMessage(NSDConstant.MSGID_RECORD_NOT_SELECTED).getContent());
			return setMsgToResultMap(resultMap, NSDConstant.MSGID_INPUT_ERROR, errStr);
		}

		// サービス呼び出し
		seisanshoShutokuKeiriService.updateInfo(kss004UpdLst, hakouSoshikiCd, kaikeiSeiriYm);

		// 処理結果データ
		resultMap.put(NSDConstant.RESULT_DATA_NAME, "");

		return setMsgToResultMapNoLog(resultMap, NSDConstant.MSGID_UPDATE_SUCCES);

	}

	/**
	 * 画面取得資産明細件数取得
	 *
	 * @param reqMap
	 * @return
	 */
	private Set<String> countViewRecord(Map<String, Object> reqMap) {

		Set<String> set = new HashSet<String>();

		for (Entry<String, Object> entry : reqMap.entrySet()) {
			String[] record = entry.getKey().replace("[", ",").replace("]", "").split(",");
			if (record.length == 3) {
				set.add(record[1]);
			}
		}
		return set;
	}

	/**
	 * 更新の入力データチェック
	 *
	 * @param reqMap
	 *            INPUTパラメータ
	 * @return エラーメッセージID
	 * @version 1.00
	 */
	private String inputCheckForUpdate(Map<String, Object> reqMap) {

		List<InputCheck> inputCheckList = getCheckItemListForUpdate(reqMap);
		return nsdDataCheck.dataCheck(inputCheckList);

	}

	/**
	 * 更新の入力チェックリストを定義
	 *
	 * @param reqMap
	 *            INPUTパラメータ
	 * @return
	 */
	private List<InputCheck> getCheckItemListForUpdate(Map<String, Object> reqMap) {

		List<InputCheck> inputCheckList = new ArrayList<InputCheck>();
		Map<Integer, Object> args;

		args = new HashMap<Integer, Object>();
		args.put(NSDConstant.CHECK_ITEM.EMPTY_CHECK.ordinal(), null);
		inputCheckList.add(setInputCheck(reqMap, "kaikeiSeiriYm", "会計整理年月：", args));

		// 画面取得資産明細件数取得
		Set<String> set = countViewRecord(reqMap);

		// 画面明細部
		String id, name;
		boolean updChk;
		boolean dataRenKeiFlag = false;

		for (int i = 0; i < set.size(); i++) {

			// 画面チェックしてないレコードは、入力チェックを行わない。
			updChk = false;
			String keyUpd = "sisanInfoLst".concat("[" + i + "]").concat("[upd]");
			if (null != reqMap.get(keyUpd)) {
				updChk = Boolean.valueOf((String) reqMap.get(keyUpd));
			}
			if (!updChk) {
				continue;
			}
			args = new HashMap<Integer, Object>();
			args.put(NSDConstant.CHECK_ITEM.EMPTY_CHECK.ordinal(), null);
			id = "sisanInfoLst".concat("[" + i + "]").concat("[shoninStatusCd]");
			name = "承認状態(行番号：".concat(String.valueOf(i + 1).concat(")："));
			inputCheckList.add(setInputCheck(reqMap, id, name, args));

			// 承認状態＝「データ連携済」の場合
			if (NSDConstant.SHONIN_STATUS_CODE_RENKEI.equals((String) reqMap.get(id))) {
				dataRenKeiFlag = true;
			}
		}

		// 承認状態＝「データ連携済」の場合、パワー経理の発行組織は必須入力チェックを行う
		if (dataRenKeiFlag) {
			args = new HashMap<Integer, Object>();
			args.put(NSDConstant.CHECK_ITEM.EMPTY_CHECK.ordinal(), null);
			args.put(NSDConstant.CHECK_ITEM.IS_EXIST_ABDA09.ordinal(), setSelectAbda09ByWhere(reqMap));
			inputCheckList.add(setInputCheck(reqMap, "hakouSoshikiNm", "パワー経理の発行組織：", args));
		}

		return inputCheckList;
	}

	/**
	 * 組織定数検索条件を作成する
	 *
	 * @param reqMap
	 * @return
	 */
	private Abda09 setSelectAbda09ByWhere(Map<String, Object> reqMap) {

		Abda09 abda09 = new Abda09();

		// 画面入力した組織名
		abda09.setAb9SoshikKnj((String) reqMap.get("hakouSoshikiNm"));
		// システム日付
		abda09.setAb9TekiyfYmd(NSDDateUtils.parseStrToCal(NSDDateUtils.Now()).getTime());

		return abda09;
	}

	/**
	 * 画面組織名より組織コードを取得する
	 *
	 * @param reqMap
	 * @return
	 */
	private String getHakouSoshikiCdBySoshikiNm(Map<String, Object> reqMap) {

		String soshikiCd = NSDConstant.BLANK_STRING;
		Abda09 abda09 = inputCheckService.getAbda09ForInputCheck(setSelectAbda09ByWhere(reqMap));

		if (abda09 != null) {
			soshikiCd = abda09.getAb9SoshikCod();
		}

		return soshikiCd;
	}
}
