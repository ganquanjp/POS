/***********************************************************************
*
*業務名: 工事精算システム
*機能名: 除却（登録・修正・削除）(サービス処理)
*
*機能概要: 除却情報を処理する。
*
*JavaＶｅｒ：J2SE1.8.0準拠
*
*更新履歴: Ver.1.00 2018/03/06　NSD　新規作成
***********************************************************************/
package jp.co.nsd.nkssweb.service.seisanshojokyaku.impl;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.beanutils.BeanUtils;
import org.postgresql.util.PSQLException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import jp.co.nsd.nkssweb.dao.JokyakuSeisanDaityo;
import jp.co.nsd.nkssweb.dao.JokyakuYoteCheckList;
import jp.co.nsd.nkssweb.dao.KosisanInfo;
import jp.co.nsd.nkssweb.dao.KoteiSisan;
import jp.co.nsd.nkssweb.dao.Kss007;
import jp.co.nsd.nkssweb.dao.Kss016;
import jp.co.nsd.nkssweb.dao.Kss016Key;
import jp.co.nsd.nkssweb.dao.SeisanshoJokyakuKoteiSisan;
import jp.co.nsd.nkssweb.dao.SeisanshoJokyakuNaiyo;
import jp.co.nsd.nkssweb.dao.SeisanshoJokyakuNaiyoPrint;
import jp.co.nsd.nkssweb.dao.SeisanshoJokyakuNaiyoShokai;
import jp.co.nsd.nkssweb.dao.mapper.Kss007Mapper;
import jp.co.nsd.nkssweb.dao.mapper.Kss016Mapper;
import jp.co.nsd.nkssweb.dao.mapper.SeisanshoJokyakuNaiyoMapper;
import jp.co.nsd.nkssweb.dao.mapper.StoredMapper;
import jp.co.nsd.nkssweb.oracle.mapper.KoteiSisanJyohoMapper;
import jp.co.nsd.nkssweb.oracle.mapper.OracleStoredMapper;
import jp.co.nsd.nkssweb.service.seisanshojokyaku.SeisanshoJokyakuNaiyoService;
import jp.co.nsd.nkssweb.utils.NSDConstant;
import jp.co.nsd.nkssweb.utils.NSDFileExporter;
import jp.co.nsd.nkssweb.utils.NSDProperties;
import net.sf.jasperreports.engine.data.JRBeanCollectionDataSource;

/**
 * 除却（内容入力）処理
 *
 * @see SeisanshoJokyakuNaiyoService
 * @version 1.00
 */
@Service
public class SeisanshoJokyakuNaiyoServiceImpl implements SeisanshoJokyakuNaiyoService {

	@Autowired
	private SeisanshoJokyakuNaiyoMapper seisanshoJokyakuNaiyoMapper;

	@Autowired
	private KoteiSisanJyohoMapper koteiSisanJyohoMapper;

	@Autowired
	private Kss007Mapper kss007Mapper;

	@Autowired
	private Kss016Mapper kss016Mapper;

	@Autowired
	private StoredMapper storedMapper;

	@Autowired
	private OracleStoredMapper oracleStoredMapper;

	@Autowired
	private NSDProperties nsdProperties;

	@Autowired
	private NSDFileExporter nsdFileExporter;

	/**
	 * 除却（内容入力）処理
	 *
	 * @param seisanshoJokyakuNaiyo
	 *            INPUTパラメータ
	 * @return sssJykList 除却情報データリスト
	 * @version 1.00
	 */
	public List<SeisanshoJokyakuNaiyo> getJokyakuNaiyoInfo(SeisanshoJokyakuNaiyo seisanshoJokyakuNaiyo) {

		// 除却情報を取得する
		List<SeisanshoJokyakuNaiyo> sssJykNyList = seisanshoJokyakuNaiyoMapper.selectByWhere(seisanshoJokyakuNaiyo);

		if (sssJykNyList.size() > 0) {
			for (int i = 1; i <= sssJykNyList.size(); i++) {
				// ROWNOを設定する
				sssJykNyList.get(i - 1).setRowNo(i);
			}

		} else {
			sssJykNyList = null;
		}

		return sssJykNyList;
	}

	/**
	 * 除却内容入力（照会）処理
	 *
	 * @param seisanshoJokyakuNaiyoShokai
	 *            INPUTパラメータ
	 * @return SeisanshoJokyakuNaiyoShokai 除却情報データ
	 * @throws Exception
	 * @version 1.00
	 */
	public SeisanshoJokyakuNaiyoShokai getJokyakuInfoBySeisanShoNo(
			SeisanshoJokyakuNaiyoShokai seisanshoJokyakuNaiyoShokai) throws Exception {

		// 除却情報
		SeisanshoJokyakuNaiyoShokai resultDto = new SeisanshoJokyakuNaiyoShokai();
		// 除却固定資産情報
		SeisanshoJokyakuKoteiSisan sssJykKsDto;

		// 除却資産情報を取得する
		List<SeisanshoJokyakuNaiyoShokai> sssJykNySkList = seisanshoJokyakuNaiyoMapper
				.selectBySeisanShoNo(seisanshoJokyakuNaiyoShokai);

		List<SeisanshoJokyakuKoteiSisan> sssJykKsLst = new ArrayList<>();

		for (int i = 0; i < sssJykNySkList.size(); i++) {
			// 除却資産情報
			SeisanshoJokyakuNaiyoShokai sssJykNySkDto = sssJykNySkList.get(i);

			// Mapの情報をBeanのプロパティにセット
			BeanUtils.copyProperties(resultDto, sssJykNySkDto);

			// 除却区分
			String jokyakuKbn = sssJykNySkDto.getJokyakuKbn();
			// 除却種別コード
			String jokyakuShubetsuCd = sssJykNySkDto.getJokyakuShubetsuCd();

			if (NSDConstant.STRING_1.equals(jokyakuKbn)) {
				if (NSDConstant.STRING_5.equals(jokyakuShubetsuCd)) {
					jokyakuShubetsuCd = NSDConstant.STRING_1;
				} else if (NSDConstant.STRING_6.equals(jokyakuShubetsuCd)) {
					jokyakuShubetsuCd = NSDConstant.STRING_2;
				} else if (NSDConstant.STRING_7.equals(jokyakuShubetsuCd)) {
					jokyakuShubetsuCd = NSDConstant.STRING_4;
				} else {
					jokyakuShubetsuCd = NSDConstant.BLANK_STRING;
				}
			}

			// 除却区分名称
			String jokyakuKbnNm = getKss016("CD0006", jokyakuKbn);

			// 除却種別名称
			String jokyakuShubetsuNm = getKss016("CD0008", jokyakuShubetsuCd);

			KoteiSisan koteiSisan = new KoteiSisan();
			// 固定ID
			koteiSisan.setKoteiCod(sssJykNySkDto.getMotoKoteiShisanId());
			// 履歴ID
			koteiSisan.setRrkCod(sssJykNySkDto.getRirekiNo());
			// 固定資産情報を取得する
			KoteiSisan ksDto = koteiSisanJyohoMapper.selectKoteiSisanByKoteiCod(koteiSisan);

			// 固定資産情報取得できるの場合
			if (null != ksDto) {

				sssJykKsDto = new SeisanshoJokyakuKoteiSisan();
				// ROWNO
				sssJykKsDto.setRowNo(i + 1);
				// 固定資産ID
				sssJykKsDto.setKoteiCod(ksDto.getKoteiCod());
				// 履歴ID
				sssJykKsDto.setRrkCod(ksDto.getRrkCod());
				// 除却精算書ID
				sssJykKsDto.setJokyakuSeisanShoId(sssJykNySkDto.getJokyakuSeisanShoId());
				// 除却資産ID
				sssJykKsDto.setJokyakuShisanId(sssJykNySkDto.getJokyakuShisanId());
				// 固定資産番号
				sssJykKsDto.setKoteiNo(ksDto.getKoteiNo());
				// 固定資産名称
				sssJykKsDto.setKoteiKnj(ksDto.getKoteiKnj());
				// 取得年月日
				sssJykKsDto.setGetYmd(ksDto.getGetYmd());
				// 元_数量
				sssJykKsDto.setMeiSu(ksDto.getMeiSu());
				// 単位
				sssJykKsDto.setTaniKnj(ksDto.getTaniKnj());
				// 元_取得価額
				sssJykKsDto.setGetkgkYen(ksDto.getGetkgkYen());
				// 除却区分名称
				sssJykKsDto.setJokyakuKbnNm(jokyakuKbnNm);
				// 除却区分コード
				sssJykKsDto.setJokyakuKbn(jokyakuKbn);
				// 除却種別コード
				sssJykKsDto.setJokyakuShubetsuCd(jokyakuShubetsuCd);
				// 除却種別名称
				sssJykKsDto.setJokyakuShubetsuNm(jokyakuShubetsuNm);
				// 除_数量
				sssJykKsDto.setJokyakuSuryo(sssJykNySkDto.getJokyakuSuryo());
				// 除_取得価額
				sssJykKsDto.setJokyakuGaku(sssJykNySkDto.getJokyakuGaku());
				// 更新時刻
				sssJykKsDto.setUpdateDate(sssJykNySkDto.getUpdateDate());
				// 固定資産情報を追加
				sssJykKsLst.add(sssJykKsDto);
			}

		}

		if (sssJykKsLst.size() > 0) {
			// 固定資産情報リスト
			resultDto.setKoteiSisanLst(sssJykKsLst);
		} else {
			return null;
		}

		return resultDto;
	}

	/**
	 * 除却（更新）処理
	 *
	 * @param kss007UpdLst
	 *            INPUTパラメータ
	 * @return cnt
	 * @version 1.00
	 * @throws Exception
	 */
	public int updateInfo(List<Kss007> kss007UpdLst) throws Exception {
		List<Kss007> kss007befList = new ArrayList<Kss007>();
		try {
			// 除却資産明細(更新)
			for (Kss007 kss007 : kss007UpdLst) {
				// 除却区分
				String jokyakuKbn = kss007.getJokyakuKbn();
				// 除却種別コード
				String jokyakuShubetsuCd = kss007.getJokyakuShubetsuCd();

				if (NSDConstant.STRING_1.equals(jokyakuKbn)) {
					if (NSDConstant.STRING_1.equals(jokyakuShubetsuCd)) {
						jokyakuShubetsuCd = NSDConstant.STRING_5;
					} else if (NSDConstant.STRING_2.equals(jokyakuShubetsuCd)) {
						jokyakuShubetsuCd = NSDConstant.STRING_6;
					} else if (NSDConstant.STRING_4.equals(jokyakuShubetsuCd)) {
						jokyakuShubetsuCd = NSDConstant.STRING_7;
					} else {
						jokyakuShubetsuCd = NSDConstant.BLANK_STRING;
					}
				}

				// 除却区分
				kss007.setJokyakuKbn(jokyakuKbn);
				// 除却種別コード
				kss007.setJokyakuShubetsuCd(jokyakuShubetsuCd);
				// ロールバイク用
				Kss007 kss007bef = kss007Mapper.selectByPrimaryKey(kss007);
				// 除却資産明細登録
				kss007Mapper.updateByPrimaryKeySelective(kss007);
				// ロールバイク 用
				kss007befList.add(kss007bef);

				// 除却内容入力（更新）ストアド処理
				try {
					Map<String, Object> map = new HashMap<String, Object>();
					map.put("jokyakuSeisanShoId", kss007.getJokyakuSeisanShoId());
					map.put("jokyakuShisanId", kss007.getJokyakuShisanId());
					map.put("shoriKbn", "0");
					// 更新後の処理
					doSetAllKs2030BefOra(map);
					doSetAllKs2030AftOra(map);
				} catch (Exception e) {
					throw new PSQLException("減価償却計算処理でエラーが発生しました. error=[" + e.getMessage() + "]", null, e);
				}
			}
		} catch (Exception e) {
			// 除却資産明細ロールバイク
			for (Kss007 kss007 : kss007befList) {
				kss007Mapper.updateByPrimaryKeySelective(kss007);
			}
			throw e;
		}

		return 0;
	}

	/**
	 * ストアド処理を行う
	 *
	 * @param map
	 *            INPUTパラメータ
	 * @throws Exception
	 */
	@Transactional(value = "postgresqlTransactionManager")
	private void doSetAllKs2030BefOra(Map<String, Object> map) throws Exception {

		storedMapper.setAllKs2030BefOra(map);
	}

	/**
	 * ストアド処理を行う
	 *
	 * @param map
	 *            INPUTパラメータ
	 * @throws Exception
	 */
	@Transactional(value = "postgresqlTransactionManager")
	private void doSetAllKs2030AftOra(Map<String, Object> map) throws Exception {

		String seisanshoNo = storedMapper.getSeisanshoNoAydm04((String) map.get("jokyakuSeisanShoId"));

		Map<String, Object> jkkymMap = new HashMap<String, Object>();
		jkkymMap.put("jsisanId", (String) map.get("jokyakuSeisanShoId"));
		jkkymMap.put("shoriKbn", (String) map.get("shoriKbn"));
		String jyokyakuYm = storedMapper.getJyokaykuYmKs2030(jkkymMap);

		String userCode = storedMapper.getUserIdKs0000();

		// パワー経理側処理
		Map<String, Object> oraMap = new HashMap<String, Object>();
		oraMap.put("seisanshoNo", seisanshoNo);
		oraMap.put("shoriKbn", map.get("shoriKbn"));
		oraMap.put("jyokyakuYm", jyokyakuYm);
		oraMap.put("userCode", userCode);
		oraMap.put("rc", 0);
		oraMap.put("errKoteiNo", "");
		oraMap.put("errMsg", "");
		oracleStoredMapper.aysp001ProcMain(oraMap);
		Object rc = oraMap.get("rc");
		String str = String.valueOf(rc);
		if (Integer.parseInt(str) != 0) {
			throw new Exception("償却費計算でエラーが発生しました. error=[" + "rc=[" + str + "]" + ",err_kotei_no=[" + (String) oraMap.get("errKoteiNo") + "]" + ", err_msg=[" + (String) oraMap.get("errMsg") + "]" );
		}

		storedMapper.setAllKs2030AftOra(map);
	}

	/**
	 * コードマスタ名称取得を処理
	 *
	 * @param cdShubetsu
	 *            INPUTパラメータ
	 * @param cd1
	 *            INPUTパラメータ
	 * @version 1.00
	 */
	protected String getKss016(String cdShubetsu, String cd1) {

		Kss016Key kss016Key = new Kss016Key();
		kss016Key.setCdShubetsu(cdShubetsu);
		kss016Key.setCd1(cd1);
		kss016Key.setCd2(NSDConstant.BLANK_STRING);
		Kss016 kss016 = kss016Mapper.selectByPrimaryKey(kss016Key);
		if (null == kss016) {
			return NSDConstant.BLANK_STRING;
		}
		return kss016.getCdKnj();
	}

	/**
	 * 除却内容入力（印刷）
	 *
	 * @param jokyakuSeisanShoId
	 *            INPUTパラメータ
	 * @return 結果
	 * @throws Exception
	 */
	@Override
	public List<String> printing(String jokyakuSeisanShoId) throws Exception {

		List<Map<String, Object>> pdfMap = new ArrayList<>();

		Map<String, Object> map = null;

		// ファイル名
		String fileName = "除却予定チェックリスト";

		// 子固定資産一覧
		List<String> kosisanNoLst = seisanshoJokyakuNaiyoMapper.getJokyakuOyakoteiInfo(jokyakuSeisanShoId);
		// 子固定資産：有無
		String oyakoteiFlg = NSDConstant.STRING_0;
		if (kosisanNoLst.size() > 0) {
			oyakoteiFlg = NSDConstant.STRING_1;
		}

		map = new HashMap<>();
		map.put("jrbcds", new JRBeanCollectionDataSource(setJokyakuYoteCheckPdf(jokyakuSeisanShoId, oyakoteiFlg)));
		map.put("templateFile",
				nsdProperties.getTemplateFilePath().concat(nsdProperties.getTemplatePdfNameKSS041P040()));
		// 除却予定チェックリストPDF
		pdfMap.add(map);

		map = new HashMap<>();
		map.put("jrbcds", new JRBeanCollectionDataSource(setJokyakuSeisanDaityoPdf(jokyakuSeisanShoId)));
		map.put("templateFile",
				nsdProperties.getTemplateFilePath().concat(nsdProperties.getTemplatePdfNameKSS041P050()));
		// 資産台帳別内訳PDF
		pdfMap.add(map);

		// 子固定資産：有
		if (NSDConstant.STRING_1.equals(oyakoteiFlg)) {
			map = new HashMap<>();
			map.put("jrbcds", new JRBeanCollectionDataSource(setJokyakuOyakoteiPdf(kosisanNoLst)));
			map.put("templateFile",
					nsdProperties.getTemplateFilePath().concat(nsdProperties.getTemplatePdfNameKSS041P060()));
			// 子固定資産一覧PDF
			pdfMap.add(map);
		}

		nsdFileExporter.exportPdf(pdfMap, fileName);

		// 帳票名称の保存
		List<String> pdfFileNameLst = new ArrayList<>();
		pdfFileNameLst.add(fileName);

		return pdfFileNameLst;
	}

	/**
	 * 除却予定チェックリストＰＤＦのデータを設定
	 *
	 * @param jokyakuSeisanShoId
	 *            INPUTパラメータ
	 * @param oyakoteiFlg
	 *            INPUTパラメータ
	 * @return 結果
	 */
	private List<JokyakuYoteCheckList> setJokyakuYoteCheckPdf(String jokyakuSeisanShoId, String oyakoteiFlg) {

		List<JokyakuYoteCheckList> printLst = new ArrayList<>();

		SeisanshoJokyakuNaiyoPrint sssJkkNyInfo = seisanshoJokyakuNaiyoMapper.getJokyakuSeisanInfo(jokyakuSeisanShoId);

		JokyakuYoteCheckList printInfo = null;
		String nowDate = new SimpleDateFormat("yyyy/MM/dd").format(new Date());
		// 子固定資産一覧判断
		String koSisanExists = NSDConstant.BLANK_STRING;
		if (NSDConstant.STRING_1.equals(oyakoteiFlg)) {
			koSisanExists = "(子固定資産一覧あり)";
		}
		// 固定資産情報
		List<SeisanshoJokyakuNaiyoPrint> koteiShisanInfoLst = seisanshoJokyakuNaiyoMapper
				.getKoteiInfo(jokyakuSeisanShoId);

		for (SeisanshoJokyakuNaiyoPrint koteiShisanInfo : koteiShisanInfoLst) {

			printInfo = new JokyakuYoteCheckList();

			// 子固定資産有無確認項目
			printInfo.setKoSisanExists(koSisanExists);
			// 作成日
			printInfo.setSakuseiDate(nowDate);
			// 工事件名
			printInfo.setKenmei(sssJkkNyInfo.getKenmei());
			// 精算箇所
			String seisanSoshiki = "[".concat(sssJkkNyInfo.getSeisanSoshikiCd()).concat("]").concat("：")
					.concat(sssJkkNyInfo.getSoshikiRenNm());
			printInfo.setSeisanSoshiki(seisanSoshiki);
			// 精算書番号
			printInfo.setSeisanShoNo(sssJkkNyInfo.getJokyakuSeisanShoNo());
			// 除却予定年月日
			printInfo.setJokyakuYoteYmd(sssJkkNyInfo.getJokyakuYoteYmd());
			// 摘要
			printInfo.setTekiyo(sssJkkNyInfo.getTekiyo());
			// 総件数
			printInfo.setShutokuSisanCnt(sssJkkNyInfo.getShutokuSisanCnt());
			// 取得原価（商法・合計）
			printInfo.setRwggetkgksYenSum(sssJkkNyInfo.getJokyakuGakuSum());
			// 取得原価（税法・合計）
			printInfo.setRwggetkgkzYenSum(sssJkkNyInfo.getJokyakuGakuSum());
			// 減価償却累計額（商法・合計）
			printInfo.setKsJkgnrsYenSum(sssJkkNyInfo.getKsJkgnrsYenSum());
			// 減価償却累計額（税法・合計）
			printInfo.setKsJkgnrzYenSum(sssJkkNyInfo.getKsJkgnrzYenSum());
			// 減損損失累計額（商法・合計）
			printInfo.setRwgSonruisYenSum(sssJkkNyInfo.getRwgSonruisYenSum());
			// 減損損失累計額（税法・合計）
			printInfo.setRwgSonruizYenSum(sssJkkNyInfo.getRwgSonruizYenSum());
			// 帳簿価額（商法・合計）
			printInfo.setTyoBosYenSum(sssJkkNyInfo.getTyoBosYenSum());
			// 帳簿価額（税法・合計）
			printInfo.setTyoBozYenSum(sssJkkNyInfo.getTyoBozYenSum());
			// 除却損（商法・合計）
			printInfo.setKsJksonsYenSum(sssJkkNyInfo.getKsJksonsYenSum());
			// 除却損（税法・合計）
			printInfo.setKsJksonzYenSum(sssJkkNyInfo.getKsJksonzYenSum());
			// 種類
			String shurui = "[".concat(koteiShisanInfo.getShuruiCd()).concat("]").concat("：")
					.concat(koteiShisanInfo.getShuKnj());
			// 構造
			String kouzou = "[".concat(koteiShisanInfo.getKouzouCd()).concat("]").concat("：")
					.concat(koteiShisanInfo.getKouKnj());
			// 資産単位
			String shisanTani = "[".concat(koteiShisanInfo.getShisanTaniCd()).concat("]").concat("：")
					.concat(koteiShisanInfo.getSaiKnj());
			// 科目1
			String kamoku1 = "[".concat(koteiShisanInfo.getKamokuCd1()).concat("]").concat("：")
					.concat(koteiShisanInfo.getShu4Knj());
			// 科目2
			String kamoku2 = "[".concat(koteiShisanInfo.getKamokuCd2()).concat("]").concat("：")
					.concat(koteiShisanInfo.getShu5Knj());
			// 科目3
			String kamoku3 = "[".concat(koteiShisanInfo.getKamokuCd3()).concat("]").concat("：")
					.concat(koteiShisanInfo.getShu6Knj());
			String shubetsuCode = shurui.concat("/").concat(kouzou).concat("/").concat(shisanTani).concat("/")
					.concat(kamoku1).concat("/").concat(kamoku2).concat("/").concat(kamoku3);
			// 種類・構造・資産単位・科目1・科目2・科目3（種構資１２３）
			printInfo.setShubetsuCode(shubetsuCode);
			String torihikiSaki = "[".concat(koteiShisanInfo.getTorihikiSakiCd()).concat("]").concat("：")
					.concat(koteiShisanInfo.getTorihikiSakiNm());
			// 取引先
			printInfo.setTorihikiSaki(torihikiSaki);
			// 件数
			printInfo.setKenSu(koteiShisanInfo.getKenSu());
			// 取得原価（商法）
			printInfo.setRwggetkgksYen(koteiShisanInfo.getJokyakuGaku());
			// 取得原価（税法）
			printInfo.setRwggetkgkzYen(koteiShisanInfo.getJokyakuGaku());
			// 減価償却累計額（商法）
			printInfo.setKsJkgnrsYen(koteiShisanInfo.getKsJkgnrsYen());
			// 減価償却累計額（税法）
			printInfo.setKsJkgnrzYen(koteiShisanInfo.getKsJkgnrzYen());
			// 減損損失累計額（商法）
			printInfo.setRwgSonruisYen(koteiShisanInfo.getRwgSonruisYen());
			// 減損損失累計額（税法）
			printInfo.setRwgSonruiYen(koteiShisanInfo.getRwgSonruiYen());
			// 帳簿価額（商法）
			printInfo.setTyoBosYen(koteiShisanInfo.getTyoBosYen());
			// 帳簿価額（税法）
			printInfo.setTyoBozYen(koteiShisanInfo.getTyoBozYen());
			// 除却損（商法）
			printInfo.setKsJksonsYen(koteiShisanInfo.getKsJksonsYen());
			// 除却損（税法）
			printInfo.setKsJksonzYen(koteiShisanInfo.getKsJksonzYen());

			printLst.add(printInfo);
		}

		return printLst;
	}

	/**
	 * 資産台帳別内訳ＰＤＦのデータを設定
	 *
	 * @param jokyakuSeisanShoId
	 *            INPUTパラメータ
	 * @return 結果
	 */
	private List<JokyakuSeisanDaityo> setJokyakuSeisanDaityoPdf(String jokyakuSeisanShoId) {

		List<JokyakuSeisanDaityo> printLst = new ArrayList<>();

		JokyakuSeisanDaityo printInfo = null;

		// 固定資産情報
		List<SeisanshoJokyakuNaiyoPrint> jokyakuDaityoInfoLst = seisanshoJokyakuNaiyoMapper
				.getJokyakuDaityoInfo(jokyakuSeisanShoId);

		for (SeisanshoJokyakuNaiyoPrint jokyakuDaityoInfo : jokyakuDaityoInfoLst) {
			printInfo = new JokyakuSeisanDaityo();
			// 固定資産
			String koteiShisan = "[".concat(jokyakuDaityoInfo.getKoteiNo()).concat("]").concat("：")
					.concat(jokyakuDaityoInfo.getKoteiKnj());
			printInfo.setKoteiShisan(koteiShisan);
			// 取得年月日
			printInfo.setShutokuYmd(jokyakuDaityoInfo.getShutokuYmd());
			// 使用開始年月日
			printInfo.setSiyoStartYmd(jokyakuDaityoInfo.getSiyoStartYmd());
			// 管理箇所
			String kanriSoshiki = "[".concat(jokyakuDaityoInfo.getKanriCod()).concat("]").concat("：")
					.concat(jokyakuDaityoInfo.getKanriKnj());
			printInfo.setKanriSoshiki(kanriSoshiki);
			// 設置場所
			String sechiBasho = "[".concat(jokyakuDaityoInfo.getBashoCod()).concat("]").concat("：")
					.concat(jokyakuDaityoInfo.getBashoKnj());
			printInfo.setSechiBasho(sechiBasho);
			// 種類
			String shurui = "[".concat(jokyakuDaityoInfo.getShuruiCd()).concat("]").concat("：")
					.concat(jokyakuDaityoInfo.getShuKnj());
			// 構造
			String kouzou = "[".concat(jokyakuDaityoInfo.getKouzouCd()).concat("]").concat("：")
					.concat(jokyakuDaityoInfo.getKouKnj());
			// 資産単位
			String shisanTani = "[".concat(jokyakuDaityoInfo.getShisanTaniCd()).concat("]").concat("：")
					.concat(jokyakuDaityoInfo.getSaiKnj());
			// 科目1
			String kamoku1 = "[".concat(jokyakuDaityoInfo.getKamokuCd1()).concat("]").concat("：")
					.concat(jokyakuDaityoInfo.getShu4Knj());
			// 科目2
			String kamoku2 = "[".concat(jokyakuDaityoInfo.getKamokuCd2()).concat("]").concat("：")
					.concat(jokyakuDaityoInfo.getShu5Knj());
			// 科目3
			String kamoku3 = "[".concat(jokyakuDaityoInfo.getKamokuCd3()).concat("]").concat("：")
					.concat(jokyakuDaityoInfo.getShu6Knj());
			String shubetsuCode = shurui.concat("/").concat(kouzou).concat("/").concat(shisanTani).concat("/")
					.concat(kamoku1).concat("/").concat(kamoku2).concat("/").concat(kamoku3);
			// 種類・構造・資産単位・科目1・科目2・科目3（種構資１２３）
			printInfo.setShubetsuCode(shubetsuCode);
			String torihikiSaki = "[".concat(jokyakuDaityoInfo.getTorihikiSakiCd()).concat("]").concat("：")
					.concat(jokyakuDaityoInfo.getTorihikiSakiNm());
			// 取引先
			printInfo.setTorihikiSaki(torihikiSaki);
			// 摘要１
			printInfo.setTekiyo1(jokyakuDaityoInfo.getTekiyo1());
			// 摘要２
			printInfo.setTekiyo2(jokyakuDaityoInfo.getTekiyo2());
			// 摘要３
			printInfo.setTekiyo3(jokyakuDaityoInfo.getTekiyo3());
			// 摘要４
			printInfo.setTekiyo4(jokyakuDaityoInfo.getTekiyo4());
			// 摘要５
			printInfo.setTekiyo5(jokyakuDaityoInfo.getTekiyo5());
			// 子資産残
			if (NSDConstant.STRING_0.equals(jokyakuDaityoInfo.getKoshiKbn())) {

				// 子資産残
				printInfo.setKoshiZan("[無]");
			} else if (NSDConstant.STRING_1.equals(jokyakuDaityoInfo.getKoshiKbn())) {

				// 子資産残
				printInfo.setKoshiZan("[有]");
			} else {
				// 処理なし
			}
			String motoSuryoTani = String.valueOf(jokyakuDaityoInfo.getMotoMeiSu()).concat("(")
					.concat(jokyakuDaityoInfo.getTaniKnj()).concat(")");
			// 除却元数量(単位)
			printInfo.setMotoSuryoTani(motoSuryoTani);
			// 除却元取得原価
			printInfo.setMotoRwggetkgksyen(jokyakuDaityoInfo.getMotoGetkgkYen());
			String suryoTani = String.valueOf(jokyakuDaityoInfo.getJokyakuSuryo()).concat("(")
					.concat(jokyakuDaityoInfo.getTaniKnj()).concat(")");
			// 除却数量(単位)
			printInfo.setSuryoTani(suryoTani);
			// 除却取得原価
			printInfo.setRwggetkgksYen(jokyakuDaityoInfo.getJokyakuGaku());
			String aftSuryoTani = String
					.valueOf(jokyakuDaityoInfo.getMotoMeiSu().subtract(jokyakuDaityoInfo.getJokyakuSuryo())).concat("(")
					.concat(jokyakuDaityoInfo.getTaniKnj()).concat(")");
			// 除却後数量(単位)
			printInfo.setAftSuryoTani(aftSuryoTani);
			// 除却後取得原価
			printInfo.setAftRwggetkgksYen(
					jokyakuDaityoInfo.getMotoGetkgkYen().subtract(jokyakuDaityoInfo.getJokyakuGaku()));
			// 除却原価(物品)
			printInfo.setBuppinGaku(jokyakuDaityoInfo.getBuppinGaku());
			// 除却簿価(工費)
			printInfo.setKouhiGaku(jokyakuDaityoInfo.getKouhiGaku());
			// 除却簿価(合計)
			printInfo.setBokaSum(jokyakuDaityoInfo.getBokaSum());
			// 除却損
			printInfo.setKsJksonYen(jokyakuDaityoInfo.getKsJksonYen());

			printLst.add(printInfo);
		}

		return printLst;
	}

	/**
	 * 子固定資産一覧ＰＤＦのデータを設定
	 *
	 * @param jokyakuSeisanShoId
	 *            INPUTパラメータ
	 * @return 結果
	 */
	private List<KosisanInfo> setJokyakuOyakoteiPdf(List<String> kosisanNoLst) {

		// 固定資産番号
		StringBuffer sb = new StringBuffer();
		for (int i = 0; i < kosisanNoLst.size(); i++) {
			String koteiShisanNo = kosisanNoLst.get(i);
			if (i == 0) {
				// 固定資産番号
				sb.append(koteiShisanNo);
			} else {
				if (i >= 50) {
					sb.append(NSDConstant.HALF_SPACE);
					sb.append("他".concat(String.valueOf(kosisanNoLst.size() - 50)).concat("件あり"));
					break;
				} else {
					// 固定資産番号
					sb.append(NSDConstant.STRING_KANMA);
					sb.append(koteiShisanNo);
				}
			}
		}
		List<KosisanInfo> printLst = new ArrayList<>();

		KosisanInfo printKosisanInfo = new KosisanInfo();
		// 固定資産番号
		printKosisanInfo.setKoteiShisanNo(sb.toString());
		// 総件数
		printKosisanInfo.setShutokuSisanCnt(Long.valueOf(kosisanNoLst.size()));

		printLst.add(printKosisanInfo);

		return printLst;
	}
}
