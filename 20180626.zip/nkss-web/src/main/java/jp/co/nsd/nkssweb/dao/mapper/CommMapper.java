package jp.co.nsd.nkssweb.dao.mapper;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Param;

import jp.co.nsd.nkssweb.dao.Abda09;
import jp.co.nsd.nkssweb.dao.Awda01;
import jp.co.nsd.nkssweb.dao.Awda02;
import jp.co.nsd.nkssweb.dao.Awda03;
import jp.co.nsd.nkssweb.dao.Awda04;
import jp.co.nsd.nkssweb.dao.Awda05;
import jp.co.nsd.nkssweb.dao.Awda06;
import jp.co.nsd.nkssweb.dao.Awda15;
import jp.co.nsd.nkssweb.dao.Awda20;
import jp.co.nsd.nkssweb.dao.Awdm12;
import jp.co.nsd.nkssweb.dao.Awdv02;
import jp.co.nsd.nkssweb.dao.CodeShubetsu;
import jp.co.nsd.nkssweb.dao.Kss004;
import jp.co.nsd.nkssweb.dao.Kss016;

public interface CommMapper {

	/**
	 * 精算書ＩＤ（新規項目、除却精算書IDも兼ねる）採番処理
	 *
	 * @return　 精算書ＩＤ
	 */
	String getSequence(Map<String, Object> map);

	/**
	 * 条件よりコードマスタにコード情報を取得
	 *
	 * @param codeShubetsu
	 *
	 * @return コードマスタ
	 */
	List<Kss016> getCodeShubetsuList(CodeShubetsu codeShubetsu);

	/**
	 * 条件よりパワー経理の発行組織を取得
	 *
	 * @param abda09
	 * @return
	 */
	List<Abda09> getHakouSoshiki(Abda09 abda09);


	/**
	 * 条件より種類定数を取得
	 *
	 * @return
	 */
	List<Awda01> getShuNmLst(Awda01 awda01);

	/**
	 * 条件より構造を取得
	 *
	 * @return
	 */
	List<Awda02> getKouNmLst(Awda02 awda02);

	/**
	 * 条件より細目を取得
	 *
	 * @return
	 */
	List<Awda03> getSaiNmLst(Awda03 awda03);

	/**
	 * 条件より種別４定数を取得
	 *
	 * @return
	 */
	List<Awda04> getShu4NmLst(Awda04 awda04);

	/**
	 * 条件より種別５定数を取得
	 *
	 * @return
	 */
	List<Awda05> getShu5NmLst(Awda05 awda05);

	/**
	 * 条件より種別６定数を取得
	 *
	 * @return
	 */
	List<Awda06> getShu6NmLst(Awda06 awda06);

	/**
	 * 条件より単位を取得
	 *
	 * @return
	 */
	List<Awda15> getTaniLst(Awda15 awda15);

	/**
	 * 条件より名称定数を取得
	 *
	 * @return
	 */
	List<Awda20> getMeiShouLst(Awda20 awda20);

	/**
	 * 設置場所より申告先・市町村を取得
	 *
	 * @return
	 */
	Awdm12 getAwdm12(Awdm12 awdm12);


	/**
	 * 条件より種構細４５６の情報を取得
	 *
	 * @return
	 */
	List<Awdv02> getAwdv02(Awdv02 awdv02);

	/**
	 * 承認状態の更新
	 *
	 * @return
	 */
	int updateStatus(Kss004 kss004);


	/**
	 * 精算書テーブル排他チェック
	 *
	 * @param kss004
	 *            INPUTパラメータ
	 */
	Kss004 selectBySeisanShoId(Kss004 kss004);

	/**
	 * テーブルデータ全件削除
	 *
	 * @param tableName
	 * @return
	 */
	int deleteTable(@Param("tableName") String tableName);

	/**
	 * テーブルデータ全件削除
	 *
	 * @param tableName
	 * @return
	 */
	int truncateTable(@Param("tableName") String tableName);
}