/***********************************************************************
*
*業務名: 工事精算システム
*機能名: 除却（登録・修正・削除）(ログ出力処理)
*
*機能概要: 除却情報を処理する。
*
*JavaＶｅｒ：J2SE1.8.0準拠
*
*更新履歴: Ver.1.00 2018/03/06　NSD　新規作成
***********************************************************************/

package jp.co.nsd.nkssweb.controller;

import java.lang.reflect.InvocationTargetException;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.Map;

import javax.naming.AuthenticationException;
import javax.naming.Context;
import javax.naming.directory.DirContext;
import javax.naming.directory.InitialDirContext;
import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import jp.co.nsd.nkssweb.dao.LoginUserInfo;
import jp.co.nsd.nkssweb.service.SystemService;
import jp.co.nsd.nkssweb.utils.NSDConstant;
import jp.co.nsd.nkssweb.utils.NSDProperties;

/**
 * 固定資産検索処理
 *
 * @version 1.00
 */
@RestController
public class SystemController extends BaseController {

	@Autowired
	protected SystemService systemService;

	@Autowired
	private NSDProperties nsdProperties;

	/**
	 * ユーザーログイン処理
	 *
	 * @param reqMap
	 * @return
	 * @throws InvocationTargetException
	 * @throws IllegalAccessException
	 */
	@RequestMapping(value = "/system-userlogin", method = RequestMethod.POST)
	public Map<String, Object> userLogin(HttpServletRequest request, @RequestParam Map<String, Object> reqMap)
			throws Exception {

		Map<String, Object> resultMap = new HashMap<String, Object>();

		String userId = (String) reqMap.get("userId");
		String pwd = (String) reqMap.get("password");

		// AD認証を実施する
		String errMsgId = ADAuthenticate(userId, pwd);

		if (!errMsgId.equals(NSDConstant.BLANK_STRING)) {
			// AD認証失敗
			this.setLoginUserInfo(request, null);
			return setMsgToResultMap(resultMap, errMsgId);
		}

		LoginUserInfo loginUserInfo = systemService.userLogin(userId);
		if (null == loginUserInfo) {
			// ユーザー情報取得できない場合、セッションの古いユーザー情報をクリアする。
			this.setLoginUserInfo(request, null);
			return setMsgToResultMap(resultMap, NSDConstant.MSGID_USER_NOT_EXIST);
		} else if (null == loginUserInfo.getUmgList()) {
			// ユーザー権限取得できない場合
			this.setLoginUserInfo(request, null);
			return setMsgToResultMap(resultMap, NSDConstant.MSGID_LOGIN_FAILED);
		} else {
			// ログインユーザー情報をセッションに書込
			this.setLoginUserInfo(request, loginUserInfo);
		}

		// 検索結果を返却Mapに設定する
		setDataToResultMap(resultMap, loginUserInfo.getUmgList());
		setMsgToResultMapNoLog(resultMap, NSDConstant.MSGID_LOGIN_SUCCES);

		return resultMap;
	}

	/**
	 * AD認証を実施
	 *
	 * @param userId
	 * @param pwd
	 * @return
	 * @throws Exception
	 */
	private String ADAuthenticate(String userId, String pwd) throws Exception {

		String authResult = NSDConstant.BLANK_STRING;

		if (NSDConstant.STRING_1.equals(nsdProperties.getDoAuthFlag())) {
			// 認証不要
			return authResult;
		}

		// ホスト名
		String host = nsdProperties.getADAuthHost();
		// 接続先ポート番号
		String port = nsdProperties.getADAuthPort();
		// ドメイン名
		String domain = nsdProperties.getADAuthDomain();
		// 接続先 URL
		String url = host.concat(":").concat(port);

		// ハッシュに詰め込む
		Hashtable<String, String> env = new Hashtable<String, String>();
		// Contextファクトリ
		env.put(Context.INITIAL_CONTEXT_FACTORY, "com.sun.jndi.ldap.LdapCtxFactory");
		// 接続先URL・・・形式は、ldap://xxx.xxx.xxx.xxx:ポート番号
		env.put(Context.PROVIDER_URL, url);
		// セキュリティレベル
		env.put(Context.SECURITY_AUTHENTICATION, "simple");
		// ユーザーID、ドメイン・・・形式は、uid@domain
		env.put(Context.SECURITY_PRINCIPAL, userId.concat("@").concat(domain));
		// パスワード
		env.put(Context.SECURITY_CREDENTIALS, pwd);

		DirContext context = null;

		try {
			// 認証の実施
			context = new InitialDirContext(env);
		} catch (AuthenticationException e) {
			// 認証失敗
			return NSDConstant.MSGID_LOGIN_FAILED;
		} catch (javax.naming.CommunicationException e) {
			// ADドメイン接続失敗
			return NSDConstant.MSGID_SYSTEM_ERROR;
		} catch (Exception e) {
			// その他エラー
			return NSDConstant.MSGID_SYSTEM_ERROR;
		} finally {
			if (null != context) {
				try {
					context.close();
					context = null;
				} catch (Exception e) {
					return NSDConstant.MSGID_SYSTEM_ERROR;
				}
			}
		}

		return authResult;

	}
}
