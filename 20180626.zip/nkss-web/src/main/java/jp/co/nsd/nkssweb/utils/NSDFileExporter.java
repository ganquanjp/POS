package jp.co.nsd.nkssweb.utils;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JRPrintPage;
import net.sf.jasperreports.engine.JasperCompileManager;
import net.sf.jasperreports.engine.JasperExportManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.data.JRBeanCollectionDataSource;
import net.sf.jasperreports.engine.export.ooxml.JRXlsxExporter;
import net.sf.jasperreports.export.SimpleExporterInput;
import net.sf.jasperreports.export.SimpleOutputStreamExporterOutput;
import net.sf.jasperreports.export.SimpleXlsxReportConfiguration;

/**
 * 帳票出力共通処理
 *
 */
@Component
public class NSDFileExporter {

	@Autowired
	private NSDProperties nsdProperties;

	/**
	 * PDF帳票を出力する
	 *
	 * @param ds
	 *            出力情報
	 * @param fileName
	 *            出力ファイル名
	 * @throws JRException
	 */
	// public void exportPdf(JRBeanCollectionDataSource ds, String templateFile,
	// String outputFile) throws JRException {
	public void exportPdf(List<Map<String, Object>> template, String outputFile) throws JRException {

		// 出力ファイルのパス＋ファイル名
		String outputfile = nsdProperties.getPdfPath().concat(outputFile).concat(NSDConstant.FILE_TYPE_PDF);

		List<JasperPrint> jasperPrintLst = new ArrayList<>();
		for (Map<String, Object> templateMap : template) {

			String templateFile = String.valueOf(templateMap.get("templateFile"));
			String jrxmlFile = templateFile.concat(NSDConstant.FILE_TEMPLATE_JRXML);
			String jasperFile = templateFile.concat(NSDConstant.FILE_TEMPLATE_JASPER);

			JasperCompileManager.compileReportToFile(jrxmlFile, jasperFile);
			JasperPrint jasperPrint = (JasperPrint) JasperFillManager.fillReport(jasperFile, null, (JRBeanCollectionDataSource)templateMap.get("jrbcds"));

			jasperPrintLst.add(jasperPrint);
		}
		JasperPrint jasperPrint = null;
		for (int i = 0; i < jasperPrintLst.size(); i++) {
			JasperPrint jPrint = jasperPrintLst.get(i);
			if (i > 0) {
				// 追加する帳票をメイン帳票に追加
				for(JRPrintPage page : jPrint.getPages() ){
					jasperPrint.addPage(page);
				}
			} else {
				jasperPrint = jPrint;
			}
		}

		JasperExportManager.exportReportToPdfFile(jasperPrint, outputfile);

	}

	/**
	 * Excel帳票を出力する
	 *
	 * @param ds
	 *            出力情報
	 * @param fileName
	 *            出力ファイル名
	 * @throws JRException
	 */
	public void exportXlsx(JRBeanCollectionDataSource ds, String templateFile, String outputFile) throws JRException {

		String jrxmlFile = templateFile.concat(NSDConstant.FILE_TEMPLATE_JRXML);
		String jasperFile = templateFile.concat(NSDConstant.FILE_TEMPLATE_JASPER);

		String outputfile = outputFile.concat(NSDConstant.FILE_TYPE_XLSX);

		JasperCompileManager.compileReportToFile(jrxmlFile, jasperFile);
		JasperPrint jasperPrint = (JasperPrint) JasperFillManager.fillReport(jasperFile, null, ds);
		JRXlsxExporter exporter = new JRXlsxExporter();
		exporter.setExporterInput(new SimpleExporterInput(jasperPrint));
		exporter.setExporterOutput(new SimpleOutputStreamExporterOutput(outputfile));
		SimpleXlsxReportConfiguration configuration = new SimpleXlsxReportConfiguration();
		configuration.setOnePagePerSheet(true);
		configuration.setDetectCellType(true);
		configuration.setCollapseRowSpan(false);
		exporter.setConfiguration(configuration);
		exporter.exportReport();

	}
}
