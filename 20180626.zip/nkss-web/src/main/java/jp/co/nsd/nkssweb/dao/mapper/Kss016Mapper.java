package jp.co.nsd.nkssweb.dao.mapper;

import jp.co.nsd.nkssweb.dao.Kss016;
import jp.co.nsd.nkssweb.dao.Kss016Key;

public interface Kss016Mapper {
    int deleteByPrimaryKey(Kss016Key key);

    int insert(Kss016 record);

    int insertSelective(Kss016 record);

    Kss016 selectByPrimaryKey(Kss016Key key);

    int updateByPrimaryKeySelective(Kss016 record);

    int updateByPrimaryKey(Kss016 record);
}