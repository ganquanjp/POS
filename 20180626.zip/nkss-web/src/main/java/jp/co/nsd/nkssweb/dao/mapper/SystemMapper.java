package jp.co.nsd.nkssweb.dao.mapper;

import java.util.List;

import jp.co.nsd.nkssweb.dao.LoginUserInfo;
import jp.co.nsd.nkssweb.dao.UserPrivilegeInfo;

public interface SystemMapper {

	/**
	 * ユーザー・ロール・組織情報取得
	 *
	 * @param userId
	 *            INPUTパラメータ
	 * @return　検索結果
	 */
	List<LoginUserInfo> selectUserInfo(String userId);

	/**
	 * ユーザー権限取得
	 *
	 * @param roleId
	 *            INPUTパラメータ
	 * @return　検索結果
	 */
	List<UserPrivilegeInfo> selectUserPrivilege(String roleId);

}