package jp.co.nsd.nkssweb.service.impl;

import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import jp.co.nsd.nkssweb.service.PdfGeneratorService;

@Service
public class PdfGeneratorServiceImpl implements PdfGeneratorService {

	private static final Logger logger = LoggerFactory.getLogger(PdfGeneratorService.class);

	public void CreatePDF() {

		logger.info("createPDF start!");

		// String jrxmlfile = "C:\\Temp\\report1.jrxml";
		// String jasperFile = "C:\\Temp\\report1.jasper";
		// String pdfPath = "C:\\temp\\test.pdf";

		// try {
		// File file = new File(jasperFile);
		// JasperReport report = (JasperReport) JRLoader.loadObject(file);
		// JasperPrint jasPrint = JasperFillManager.fillReport(report, data());
		// jasPrint.
		// } catch (Exception e) {
		// e.printStackTrace();
		// }
	}

	public Map<String, Object> data() {
		Map<String, Object> data = new HashMap<String, Object>();
		data.put("user_id", "0001");
		data.put("user_name", "ganquan");
		return data;
	}
}
