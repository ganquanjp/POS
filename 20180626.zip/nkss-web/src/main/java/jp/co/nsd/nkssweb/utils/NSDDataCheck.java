package jp.co.nsd.nkssweb.utils;

import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import jp.co.nsd.nkssweb.dao.Abda09;
import jp.co.nsd.nkssweb.dao.Awdv02;
import jp.co.nsd.nkssweb.dao.InputCheck;
import jp.co.nsd.nkssweb.dao.Kss011;
import jp.co.nsd.nkssweb.dao.Kss013;
import jp.co.nsd.nkssweb.dao.Kss015;
import jp.co.nsd.nkssweb.dao.Kss015Key;
import jp.co.nsd.nkssweb.dao.mapper.Kss015Mapper;
import jp.co.nsd.nkssweb.dao.mapper.SeisanshoShutokuMapper;
import jp.co.nsd.nkssweb.service.InputCheckService;
import jp.co.nsd.nkssweb.service.SystemService;

@Component
public class NSDDataCheck {

	@Autowired
	protected SystemService systemService;

	@Autowired
	private InputCheckService inputCheckService;

	@Autowired
	private SeisanshoShutokuMapper seisanshoShutokuMapper;

	@Autowired
	private Kss015Mapper kss015Mapper;

	/**
	 * 項目チェック
	 *
	 * @param checkItemList
	 *            チェックをしたい項目リスト
	 * @return
	 */
	public String dataCheck(List<InputCheck> checkItemList) {

		for (int i = 0; i < checkItemList.size(); i++) {
			InputCheck inputCheck = checkItemList.get(i);

			Iterator<Entry<Integer, Object>> iter = inputCheck.getArgs().entrySet().iterator();

			while (iter.hasNext()) {
				Entry<Integer, Object> entry = iter.next();
				int key = entry.getKey();
				Object args = entry.getValue();

				String errStr = NSDConstant.BLANK_STRING;

				if (key == NSDConstant.CHECK_ITEM.EMPTY_CHECK.ordinal()) {
					// 空文字チェック
					if (!checkEmpty(inputCheck.getItemValue())) {
						errStr = systemService.getMessage(NSDConstant.MSGID_CHECK_EMPTY).getContent();
					}
				} else if (key == NSDConstant.CHECK_ITEM.MSGID_CHECK_IS_ZENKAKU.ordinal()) {
					// 全角判定チェック
					if (!NSDCommUtils.isZenkakuOnly(inputCheck.getItemValue())) {
						errStr = systemService.getMessage(NSDConstant.MSGID_CHECK_IS_ZENKAKU).getContent();
					}
				}  else if (key == NSDConstant.CHECK_ITEM.NUMERIC_CHECK.ordinal()) {
					// 整数判定チェック
					if (!StringUtils.isNumeric(inputCheck.getItemValue())) {
						errStr = systemService.getMessage(NSDConstant.MSGID_CHECK_IS_NUMERIC).getContent();
					}
				} else if (key == NSDConstant.CHECK_ITEM.NUMERIC_RANGE_CHECK.ordinal()) {
					// 数値範囲チェック
					int checkResult = checkNumericRange(inputCheck.getItemValue(), args);
					if (checkResult == 9) {
						errStr = systemService.getMessage(NSDConstant.MSGID_CHECK_IS_NUMERIC).getContent();
					} else if (checkResult == 0) {
						errStr = systemService.getMessage(NSDConstant.MSGID_CHECK_FLOAT_COMPARE).getContent();
					}
				} else if (key == NSDConstant.CHECK_ITEM.LENGTH_CHECK.ordinal()) {
					// 桁数のチェック
					if (!checkLength(inputCheck.getItemValue(), args)) {
						errStr = systemService.getMessage(NSDConstant.MSGID_CHECK_LENGTH).getContent();
					}
				} else if (key == NSDConstant.CHECK_ITEM.FLOAT_LENGTH_CHECK.ordinal()) {
					// Floatの桁数チェック
					if (!checkFloatLength(inputCheck.getItemValue(), args)) {
						errStr = systemService.getMessage(NSDConstant.MSGID_CHECK_FLOAT_COMPARE).getContent();
					}
				} else if (key == NSDConstant.CHECK_ITEM.DATE_YYYYMM_CHECK.ordinal()) {
					// 年月の妥当性チェック
					if (!checkDateYYYYMM(inputCheck.getItemValue())) {
						errStr = systemService.getMessage(NSDConstant.MSGID_CHECK_DATE_FORMAT).getContent();
					}
				} else if (key == NSDConstant.CHECK_ITEM.DATE_FORMAT_CHECK.ordinal()) {
					// 日付の妥当性チェック
					if (!checkDateFormat(inputCheck.getItemValue())) {
						errStr = systemService.getMessage(NSDConstant.MSGID_CHECK_DATE_FORMAT).getContent();
					}
				} else if (key == NSDConstant.CHECK_ITEM.DATE_COMPARE_CHECK.ordinal()) {
					// 日付From-To大小比較チェック
					if (NSDDateUtils.compareDate(inputCheck.getItemValue(), args) == 1) {
						errStr = systemService.getMessage(NSDConstant.MSGID_CHECK_DATE_COMPARE).getContent();
					}
				} else if (key == NSDConstant.CHECK_ITEM.DATE_KIKAN_CHECK.ordinal()) {
					// 日付は期間範囲内に設定チェック
					if (!checkDateKikan(inputCheck.getItemValue(), args)) {
						errStr = systemService.getMessage(NSDConstant.MSGID_CHECK_DATE_KIKAN).getContent();
					}
				} else if (key == NSDConstant.CHECK_ITEM.ONLYONE_SELECT.ordinal()) {
					// 一つのみ選択チェック
					if (!checkOnlyOneSelected(inputCheck.getItemValue(), args)) {
						errStr = systemService.getMessage(NSDConstant.MSGID_ONLYONE_SELECT_ERROR).getContent();
					}
				} else if (key == NSDConstant.CHECK_ITEM.IS_EXIST_SOSHIKIRENNM.ordinal()) {
					// 該当組織連結名はDBに存在チェック
					if (!isExistSoshikiRenNm(inputCheck.getItemValue())) {
						errStr = systemService.getMessage(NSDConstant.MSGID_NOT_EXIST_DATA).getContent();
					}
				} else if (key == NSDConstant.CHECK_ITEM.IS_EXIST_SEIMEI.ordinal()) {
					// 該当姓名はDBに存在チェック
					if (!isExistUser(inputCheck.getItemValue())) {
						errStr = systemService.getMessage(NSDConstant.MSGID_NOT_EXIST_DATA).getContent();
					}
				} else if (key == NSDConstant.CHECK_ITEM.IS_EXIST_USER_SOSHIKI.ordinal()) {
					// ユーザー名、組織コードで、DBを検索、ユーザーは該当組織に属してるのチェック
					if (!isExistUserSoshiki(inputCheck.getItemValue(), args)) {
						errStr = systemService.getMessage(NSDConstant.MSGID_NOT_USER_SOSHIKI).getContent();
					}
				} else if (key == NSDConstant.CHECK_ITEM.IS_EXIST_KOTEI.ordinal()) {
					// 該当固定資産番号はDBに存在チェック
					if (!isExistKoteiNo(inputCheck.getItemValue(), args)) {
						errStr = systemService.getMessage(NSDConstant.MSGID_CHECK_KOTEI_ERROR).getContent();
					}
				} else if (key == NSDConstant.CHECK_ITEM.IS_EXIST_AWDV02.ordinal()) {
					// 類、構造、細目コードは種類構造細目２テーブルに存在確認
					if (!isExistShuKouSai(args)) {
						errStr = systemService.getMessage(NSDConstant.MSGID_NOT_EXIST_DATA).getContent();
					}
				} else if (key == NSDConstant.CHECK_ITEM.IS_EXIST_KSS015.ordinal()) {
					// 管理負担箇所存在チェック
					if (isExistKss015(args)) {
						errStr = systemService.getMessage(NSDConstant.MSGID_EXIST_DATA).getContent();
					}
				} else if (key == NSDConstant.CHECK_ITEM.IS_EXIST_ABDA09.ordinal()) {
					// 組織定数に存在チェック
					if (!isExistAbda09(args)) {
						errStr = systemService.getMessage(NSDConstant.MSGID_NOT_EXIST_DATA).getContent();
					}
				} else {

				}

				if (!NSDConstant.BLANK_STRING.equals(errStr)) {
					return NSDCommUtils.setKakoToStr(inputCheck.getItemName().concat(errStr));
				}

			}
		}

		return NSDConstant.BLANK_STRING;
	}

	/**
	 * 空文字のチェック
	 *
	 * @param str
	 * @return
	 */
	private boolean checkEmpty(String str) {
		if (StringUtils.isEmpty(str)) {
			return false;
		}
		return true;
	}

	/**
	 * Floatの判定チェック
	 *
	 * @param str
	 * @return
	 */
	private boolean isFloat(String floatStr) {

		if (StringUtils.isEmpty(floatStr)) {
			return false;
		}

		try {
			Float.valueOf(floatStr);
		} catch (NumberFormatException e) {
			return false;
		}
		return true;
	}

	/**
	 * 数値範囲チェック
	 *
	 * @param numStr
	 * @param rangeNum
	 *            [startValue: 開始値], [endValue: 終了値] , [compareWay: 比較方法]
	 *            [compareWay: 比較方法
	 *                1: numStr ＝ startValue
	 *                2: numStr ≧ startValue
	 *                3: numStr ＞ startValue
	 *                4: numStr ＜ startValue
	 *                5: numStr ≦ startValue
	 *                6: startValue ≦ numStr ≦ endValue
	 *                7: startValue ＜ numStr ≦ endValue
	 *                8: startValue ＜ numStr ＜ endValue
	 *            ]
	 *
	 * @return [9: 入力パラメータエラー], [0: 範囲外] , [1: 範囲内]
	 */
	private int checkNumericRange(String numStr, Object rangeNum) {

		@SuppressWarnings("unchecked")
		Map<String, String> map = (HashMap<String, String>) rangeNum;
		String startValue = map.get("startValue");
		String endValue = map.get("endValue");
		String compareWay = map.get("compareWay");

		if (!isFloat(numStr) || !isFloat(startValue) || StringUtils.isEmpty(compareWay)) {
			return 9;
		}

		float checkNum = Float.valueOf(numStr);
		float numFrom = Float.valueOf((String) startValue);
		float numTo = 0;

		// 比較方法＞５の場合、終了値endValue必要
		if (Integer.parseInt(compareWay) > 5) {
			if (!isFloat(endValue)) {
				return 9;
			}else{
				numTo = Float.valueOf((String) endValue);
			}
		}

		switch (Integer.parseInt(compareWay)) {
		case 1:
			if (checkNum == numFrom) {
				return 1;
			}
			break;
		case 2:
			if (checkNum >= numFrom) {
				return 1;
			}
			break;
		case 3:
			if (checkNum > numFrom) {
				return 1;
			}
			break;
		case 4:
			if (checkNum < numFrom) {
				return 1;
			}
			break;
		case 5:
			if (checkNum <= numFrom) {
				return 1;
			}
			break;
		case 6:
			if (checkNum >= numFrom && checkNum <= numTo) {
				return 1;
			}
			break;
		case 7:
			if (checkNum > numFrom && checkNum <= numTo) {
				return 1;
			}
			break;
		case 8:
			if (checkNum > numFrom && checkNum < numTo) {
				return 1;
			}
			break;
		default:
			return 0;
		}

		return 0;
	}

	/**
	 * 桁数のチェック
	 *
	 * @param str
	 * @param value
	 * @return
	 */
	private boolean checkLength(String str, Object value) {

		int maxLength = (Integer) value;

		if(StringUtils.isEmpty(str)){
			return true;
		}

		if (str.length() > maxLength) {
			return false;
		}
		return true;
	}

	/**
	 * Floatの桁数チェック
	 *
	 * @param str
	 * @param value
	 * @return
	 */
	private boolean checkFloatLength(String floatStr, Object value) {

		if (StringUtils.isEmpty(floatStr)) {
			return true;
		}

		@SuppressWarnings("unchecked")
		Map<String, Integer> map = (HashMap<String, Integer>) value;

		// 小数部最大桁数
		int maxDec = map.get("decimal");
		// 整数部最大桁数
		int maxInt = map.get("integer") - maxDec;


		int dotPos = floatStr.indexOf(NSDConstant.STRING_DOT);
		if (dotPos == -1) {
			// 小数部なし
			if (floatStr.length() > maxInt) {
				return false;
			}
		} else {
			String intStr = floatStr.substring(0, dotPos);
			String decStr = floatStr.substring(dotPos + 1);

			if (intStr.length() > maxInt || decStr.length() > maxDec) {
				return false;
			}
		}

		return true;
	}

	/**
	 * 年月の妥当性チェック
	 *
	 * @param dateStr
	 *            yyyy-MM or yyyy/MM
	 * @return
	 */
	private boolean checkDateYYYYMM(String dateStr) {

		String wkDate = dateStr.replace('-', '/');
		wkDate = wkDate.length() == 10 ? wkDate : wkDate.concat("/01");
		if (!NSDCommUtils.checkDate(wkDate)) {
			return false;
		}
		return true;
	}

	/**
	 * 日付の妥当性チェック
	 *
	 * @param dateStr
	 * @return
	 */
	private boolean checkDateFormat(String dateStr) {

		if (!NSDCommUtils.checkDate(dateStr)) {
			return false;
		}
		return true;
	}

	/**
	 * 日付は期間内に設定チェック
	 *
	 * @param date
	 * @param kikan
	 * @return
	 */
	private boolean checkDateKikan(String date, Object kikan) {

		@SuppressWarnings("unchecked")
		Map<String, String> map = (HashMap<String, String>) kikan;
		String kikanFrom = map.get("startDate");
		String kikanTo = map.get("endDate");

		if (NSDDateUtils.compareDate(date, kikanFrom) == -1 || NSDDateUtils.compareDate(kikanTo, date) == -1) {
			return false;

		}
		return true;
	}

	/**
	 * 同時に選択チェック
	 *
	 * @param str
	 * @param value
	 * @return
	 */
	private boolean checkOnlyOneSelected(String str, Object value) {

		if ("true".equals(str) && str.equals((String) value)) {
			return false;
		}
		return true;
	}

	/**
	 * 入力した精算箇所はDBに存在チェック
	 *
	 * @param soshikiRenNm
	 * @return
	 */
	private boolean isExistSoshikiRenNm(String soshikiRenNm) {

		Kss011 kss011 = inputCheckService.getSoshikiInfoForInputCheck(soshikiRenNm);
		if (null == kss011) {
			return false;
		}
		return true;
	}

	/**
	 * 入力した姓名はDBに存在チェック
	 *
	 * @param seimei
	 * @return
	 */
	private boolean isExistUser(String seimei) {

		Kss013 kss013 = inputCheckService.getUserInfoForInputCheck(seimei);
		if (null == kss013) {
			return false;
		}
		return true;
	}

	/**
	 * ユーザー名、組織コードで、DBを検索、ユーザーは該当組織に属してるを確認
	 *
	 * @param seiMei
	 * @param value
	 * @return
	 */
	private boolean isExistUserSoshiki(String seiMei, Object value) {

		Map<String, String> sqlWhere = new HashMap<String, String>();
		sqlWhere.put("seiMei", seiMei);
		sqlWhere.put("soshikiRenNm", ((String) value).trim());
		return inputCheckService.isExistUserSoshikiForInputCheck(sqlWhere);
	}

	/**
	 * 選択した固定資産はDBに存在チェック
	 *
	 * @param koteiNo
	 *            固定資産番号
	 * @param value
	 *            登録(0)、更新(1)、削除(2)フラグ
	 * @return
	 */
	private boolean isExistKoteiNo(String koteiNo, Object value) {
		Map<String, String> sqlWhere = new HashMap<String, String>();
		sqlWhere.put("koteiNo", koteiNo);
		sqlWhere.put("jkkseiKbn", ((String) value).trim());
		return inputCheckService.isExistKoteiSisanInfoForInputCheck(sqlWhere);
	}

	/**
	 * 種類、構造、細目コードは種類構造細目２テーブルに存在確認
	 *
	 * @param args
	 * @return
	 */
	private boolean isExistShuKouSai(Object args) {
		Awdv02 awdv02 = (Awdv02) args;
		Integer cnt = seisanshoShutokuMapper.getChkAwdv02(awdv02);
		if (cnt == 0) {
			return false;
		}
		return true;
	}

	/**
	 * 管理負担箇所に存在チェック
	 *
	 * @param args
	 * @return
	 */
	private boolean isExistKss015(Object args) {
		Kss015Key kss015Key = (Kss015Key) args;
		Kss015 kss015 = kss015Mapper.selectByPrimaryKey(kss015Key);
		if (kss015 != null) {
			return true;
		}
		return false;
	}

	/**
	 * 組織定数に存在チェック
	 *
	 * @param args
	 * @return
	 */
	private boolean isExistAbda09(Object args) {
		Abda09 abda09Where = (Abda09) args;
		Abda09 abda09 = inputCheckService.getAbda09ForInputCheck(abda09Where);

		if (abda09 != null) {
			return true;
		}
		return false;

	}

}