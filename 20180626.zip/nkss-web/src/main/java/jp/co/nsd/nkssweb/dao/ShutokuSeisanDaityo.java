package jp.co.nsd.nkssweb.dao;

import java.math.BigDecimal;

/**
 * 資産台帳別内訳（取得）
 *
 * @version 1.00
 */
public class ShutokuSeisanDaityo {
	// 資産台帳別内訳（取得）情報
	// 固定資産
	private String koteiShisan;
	// 取得年月日
	private String shutokuYmd;
	// 取引先
	private String torihikiSaki;
	// 親固定資産番号
	private String oyaKoteiShisanNo;
	// 枝番
	private String edaNo;
	// 種類・構造・資産単位・科目1・科目2・科目3（種構資１２３）
	private String shubetsuCode;
	// 耐用年数（税／商）
	private String taiyoNensu;
	// 償却方法（税／商）
	private String syokyakuHoho;
	// 物品
	private BigDecimal buppin;
	// 工費
	private BigDecimal kouhiGaku;
	// 総係費
	private BigDecimal souKeihiGaku;
	// 取得価額（合計）
	private BigDecimal rwgGetkgkYenSum;
	// 物品数量（単位）
	private String suryoTani;
	// 管理箇所
	private String kanriSoshiki;
	// 負担箇所
	private String futanSoshiki;
	// 設置場所
	private String sechiBasho;
	// 製品名/型番/製品会社名称
	private String seihinKataSeizo;
	// 摘要１
	private String tekiyo1;
	// 摘要２
	private String tekiyo2;
	// 摘要３
	private String tekiyo3;
	// 摘要４
	private String tekiyo4;
	// 摘要５
	private String tekiyo5;
	// 工事担当箇所
	private String kojiTantoSoshiki;
	// 工事担当者
	private String kojiTantoUser;

	public String getKoteiShisan() {
		return koteiShisan;
	}
	public void setKoteiShisan(String koteiShisan) {
		this.koteiShisan = koteiShisan;
	}
	/**
	 * @return shutokuYmd
	 */
	public String getShutokuYmd() {
		return shutokuYmd;
	}
	/**
	 * @param shutokuYmd セットする shutokuYmd
	 */
	public void setShutokuYmd(String shutokuYmd) {
		this.shutokuYmd = shutokuYmd;
	}
	/**
	 * @return torihikiSaki
	 */
	public String getTorihikiSaki() {
		return torihikiSaki;
	}
	/**
	 * @param torihikiSaki セットする torihikiSaki
	 */
	public void setTorihikiSaki(String torihikiSaki) {
		this.torihikiSaki = torihikiSaki;
	}
	/**
	 * @return oyaKoteiShisanNo
	 */
	public String getOyaKoteiShisanNo() {
		return oyaKoteiShisanNo;
	}
	/**
	 * @param oyaKoteiShisanNo セットする oyaKoteiShisanNo
	 */
	public void setOyaKoteiShisanNo(String oyaKoteiShisanNo) {
		this.oyaKoteiShisanNo = oyaKoteiShisanNo;
	}
	/**
	 * @return edaNo
	 */
	public String getEdaNo() {
		return edaNo;
	}
	/**
	 * @param edaNo セットする edaNo
	 */
	public void setEdaNo(String edaNo) {
		this.edaNo = edaNo;
	}
	/**
	 * @return shubetsuCode
	 */
	public String getShubetsuCode() {
		return shubetsuCode;
	}
	/**
	 * @param shubetsuCode セットする shubetsuCode
	 */
	public void setShubetsuCode(String shubetsuCode) {
		this.shubetsuCode = shubetsuCode;
	}
	/**
	 * @return taiyoNensu
	 */
	public String getTaiyoNensu() {
		return taiyoNensu;
	}
	/**
	 * @param taiyoNensu セットする taiyoNensu
	 */
	public void setTaiyoNensu(String taiyoNensu) {
		this.taiyoNensu = taiyoNensu;
	}
	/**
	 * @return syokyakuHoho
	 */
	public String getSyokyakuHoho() {
		return syokyakuHoho;
	}
	/**
	 * @param syokyakuHoho セットする syokyakuHoho
	 */
	public void setSyokyakuHoho(String syokyakuHoho) {
		this.syokyakuHoho = syokyakuHoho;
	}
	/**
	 * @return buppin
	 */
	public BigDecimal getBuppin() {
		return buppin;
	}
	/**
	 * @param buppin セットする buppin
	 */
	public void setBuppin(BigDecimal buppin) {
		this.buppin = buppin;
	}
	/**
	 * @return kouhiGaku
	 */
	public BigDecimal getKouhiGaku() {
		return kouhiGaku;
	}
	/**
	 * @param kouhiGaku セットする kouhiGaku
	 */
	public void setKouhiGaku(BigDecimal kouhiGaku) {
		this.kouhiGaku = kouhiGaku;
	}
	/**
	 * @return souKeihiGaku
	 */
	public BigDecimal getSouKeihiGaku() {
		return souKeihiGaku;
	}
	/**
	 * @param souKeihiGaku セットする souKeihiGaku
	 */
	public void setSouKeihiGaku(BigDecimal souKeihiGaku) {
		this.souKeihiGaku = souKeihiGaku;
	}
	/**
	 * @return rwgGetkgkYenSum
	 */
	public BigDecimal getRwgGetkgkYenSum() {
		return rwgGetkgkYenSum;
	}
	/**
	 * @param rwgGetkgkYenSum セットする rwgGetkgkYenSum
	 */
	public void setRwgGetkgkYenSum(BigDecimal rwgGetkgkYenSum) {
		this.rwgGetkgkYenSum = rwgGetkgkYenSum;
	}
	/**
	 * @return suryoTani
	 */
	public String getSuryoTani() {
		return suryoTani;
	}
	/**
	 * @param suryoTani セットする suryoTani
	 */
	public void setSuryoTani(String suryoTani) {
		this.suryoTani = suryoTani;
	}
	/**
	 * @return kanriSoshiki
	 */
	public String getKanriSoshiki() {
		return kanriSoshiki;
	}
	/**
	 * @param kanriSoshiki セットする kanriSoshiki
	 */
	public void setKanriSoshiki(String kanriSoshiki) {
		this.kanriSoshiki = kanriSoshiki;
	}
	/**
	 * @return futanSoshiki
	 */
	public String getFutanSoshiki() {
		return futanSoshiki;
	}
	/**
	 * @param futanSoshiki セットする futanSoshiki
	 */
	public void setFutanSoshiki(String futanSoshiki) {
		this.futanSoshiki = futanSoshiki;
	}
	/**
	 * @return sechiBasho
	 */
	public String getSechiBasho() {
		return sechiBasho;
	}
	/**
	 * @param sechiBasho セットする sechiBasho
	 */
	public void setSechiBasho(String sechiBasho) {
		this.sechiBasho = sechiBasho;
	}
	/**
	 * @return seihinKataSeizo
	 */
	public String getSeihinKataSeizo() {
		return seihinKataSeizo;
	}
	/**
	 * @param seihinKataSeizo セットする seihinKataSeizo
	 */
	public void setSeihinKataSeizo(String seihinKataSeizo) {
		this.seihinKataSeizo = seihinKataSeizo;
	}
	/**
	 * @return tekiyo1
	 */
	public String getTekiyo1() {
		return tekiyo1;
	}
	/**
	 * @param tekiyo1 セットする tekiyo1
	 */
	public void setTekiyo1(String tekiyo1) {
		this.tekiyo1 = tekiyo1;
	}
	/**
	 * @return tekiyo2
	 */
	public String getTekiyo2() {
		return tekiyo2;
	}
	/**
	 * @param tekiyo2 セットする tekiyo2
	 */
	public void setTekiyo2(String tekiyo2) {
		this.tekiyo2 = tekiyo2;
	}
	/**
	 * @return tekiyo3
	 */
	public String getTekiyo3() {
		return tekiyo3;
	}
	/**
	 * @param tekiyo3 セットする tekiyo3
	 */
	public void setTekiyo3(String tekiyo3) {
		this.tekiyo3 = tekiyo3;
	}
	/**
	 * @return tekiyo4
	 */
	public String getTekiyo4() {
		return tekiyo4;
	}
	/**
	 * @param tekiyo4 セットする tekiyo4
	 */
	public void setTekiyo4(String tekiyo4) {
		this.tekiyo4 = tekiyo4;
	}
	/**
	 * @return tekiyo5
	 */
	public String getTekiyo5() {
		return tekiyo5;
	}
	/**
	 * @param tekiyo5 セットする tekiyo5
	 */
	public void setTekiyo5(String tekiyo5) {
		this.tekiyo5 = tekiyo5;
	}
	/**
	 * @return kojiTantoSoshiki
	 */
	public String getKojiTantoSoshiki() {
		return kojiTantoSoshiki;
	}
	/**
	 * @param kojiTantoSoshiki セットする kojiTantoSoshiki
	 */
	public void setKojiTantoSoshiki(String kojiTantoSoshiki) {
		this.kojiTantoSoshiki = kojiTantoSoshiki;
	}
	/**
	 * @return kojiTantoUser
	 */
	public String getKojiTantoUser() {
		return kojiTantoUser;
	}
	/**
	 * @param kojiTantoUser セットする kojiTantoUser
	 */
	public void setKojiTantoUser(String kojiTantoUser) {
		this.kojiTantoUser = kojiTantoUser;
	}

}