package jp.co.nsd.nkssweb.config;

import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.tomcat.jdbc.pool.DataSource;
import org.mybatis.spring.SqlSessionFactoryBean;
import org.mybatis.spring.annotation.MapperScan;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.support.PathMatchingResourcePatternResolver;
import org.springframework.jdbc.datasource.DataSourceTransactionManager;

@Configuration
@MapperScan(basePackages = OracleDataSourceConfig.Package, sqlSessionFactoryRef = "oracleSqlSessionFactory")
public class OracleDataSourceConfig {

    static final String Package = "jp.co.nsd.nkssweb.oracle.mapper";

    static final String MAPPER_LOCATION = "classpath:oramapper/*.xml";

    @Value("${spring.datasource.ora.url}")
    private String url;

    @Value("${spring.datasource.ora.username}")
    private String user;

    @Value("${spring.datasource.ora.password}")
    private String password;

    @Value("${spring.datasource.ora.driver-class-name}")
    private String driverClass;

    @Bean(name = "oracleDataSource")
    @ConfigurationProperties(prefix="spring.datasource.ora")
	public DataSource oracleDataSource(){
    	DataSource dataSource = new DataSource();
        dataSource.setDriverClassName(this.driverClass);
        dataSource.setUrl(this.url);
        dataSource.setUsername(this.user);
        dataSource.setPassword(this.password);
	    return dataSource;
	}

    @Bean(name = "oracleTransactionManager")
    public DataSourceTransactionManager oracleTransactionManager(){
        return new DataSourceTransactionManager((oracleDataSource()));
    }

    @Bean(name="oracleSqlSessionFactory")
    public SqlSessionFactory oracleSqlSessionFactory(@Qualifier("oracleDataSource") DataSource oracleDataSource) throws Exception {
    	final SqlSessionFactoryBean sessionFactoryBean = new SqlSessionFactoryBean();
        sessionFactoryBean.setDataSource(oracleDataSource);
        sessionFactoryBean.setMapperLocations(new PathMatchingResourcePatternResolver()
        .getResources(OracleDataSourceConfig.MAPPER_LOCATION));
        return sessionFactoryBean.getObject();
    }
}
