package jp.co.nsd.nkssweb.controller.seisanshoshutoku;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import jp.co.nsd.nkssweb.controller.BaseController;
import jp.co.nsd.nkssweb.dao.Awdv02;
import jp.co.nsd.nkssweb.dao.InputCheck;
import jp.co.nsd.nkssweb.dao.Kss005;
import jp.co.nsd.nkssweb.dao.SeisanshoShutokuKensaku;
import jp.co.nsd.nkssweb.dao.SeisanshoShutokuShokai;
import jp.co.nsd.nkssweb.service.CommService;
import jp.co.nsd.nkssweb.service.seisanshoshutoku.SeisanshoShutokuService;
import jp.co.nsd.nkssweb.utils.NSDCommUtils;
import jp.co.nsd.nkssweb.utils.NSDConstant;
import jp.co.nsd.nkssweb.utils.NSDDataCheck;
import jp.co.nsd.nkssweb.utils.NSDDateUtils;

@RestController
public class SeisanshoShutokuController extends BaseController {

	@Autowired
	private SeisanshoShutokuService seisanshoShutokuService;

	@Autowired
	private NSDDataCheck nsdDataCheck;

	@Autowired
	private CommService commService;

	/*
	 * 精算書取得・検索
	 */
	@RequestMapping(value = "/seisanshoShutoku-kensaku", method = RequestMethod.POST)
	public Map<String, Object> getSeisanshoShutokuKensaku(@RequestParam Map<String, Object> reqMap) throws Exception {

		Map<String, Object> resultMap = new HashMap<String, Object>();

		// 入力チェック
		String errStr = inputCheckForSearch(reqMap);
		if (StringUtils.isNotEmpty(errStr)) {
			return setMsgToResultMap(resultMap, NSDConstant.MSGID_INPUT_ERROR, errStr);
		}

		SeisanshoShutokuKensaku selectCondition = new SeisanshoShutokuKensaku();
		List<SeisanshoShutokuKensaku> stkKsList = new ArrayList<SeisanshoShutokuKensaku>();

		// 画面入力した検索条件をBeanのプロパティにセット
		BeanUtils.populate(selectCondition, reqMap);

		// サービスを呼び出す
		stkKsList = seisanshoShutokuService.getSeisanshoShutokuKensaku(selectCondition);

		// 検索結果を返却Mapに設定する
		setDataToResultMap(resultMap, stkKsList);

		return resultMap;

	}

	/**
	 * 検索の入力データチェック
	 *
	 * @param reqMap
	 *            INPUTパラメータ
	 * @return エラーメッセージID
	 * @version 1.00
	 */
	private String inputCheckForSearch(Map<String, Object> reqMap) {

		List<InputCheck> inputCheckList = getCheckItemListForSearch(reqMap);
		return nsdDataCheck.dataCheck(inputCheckList);

	}

	/**
	 * 検索の入力チェックリストを定義
	 *
	 * @param reqMap
	 *            INPUTパラメータ
	 * @return
	 */
	private List<InputCheck> getCheckItemListForSearch(Map<String, Object> reqMap) {

		List<InputCheck> inputCheckList = new ArrayList<InputCheck>();
		Map<Integer, Object> args;

		// 使用開始年月日
		if (StringUtils.isNotEmpty((String) reqMap.get("siyoStartYmdFrom"))) {
			args = new HashMap<Integer, Object>();
			args.put(NSDConstant.CHECK_ITEM.DATE_FORMAT_CHECK.ordinal(), null);
			inputCheckList.add(setInputCheck(reqMap, "siyoStartYmdFrom", "使用開始年月日(From)：", args));
		}

		if (StringUtils.isNotEmpty((String) reqMap.get("siyoStartYmdTo"))) {
			args = new HashMap<Integer, Object>();
			args.put(NSDConstant.CHECK_ITEM.DATE_FORMAT_CHECK.ordinal(), null);
			inputCheckList.add(setInputCheck(reqMap, "siyoStartYmdTo", "使用開始年月日(To)：", args));
		}

		args = new HashMap<Integer, Object>();
		args.put(NSDConstant.CHECK_ITEM.DATE_COMPARE_CHECK.ordinal(), (String) reqMap.get("siyoStartYmdTo"));
		inputCheckList.add(setInputCheck(reqMap, "siyoStartYmdFrom", "使用開始年月日：", args));

		// 取得年月日
		if (StringUtils.isNotEmpty((String) reqMap.get("shutokuYmdFrom"))) {
			args = new HashMap<Integer, Object>();
			args.put(NSDConstant.CHECK_ITEM.DATE_FORMAT_CHECK.ordinal(), null);
			inputCheckList.add(setInputCheck(reqMap, "shutokuYmdFrom", "取得年月日(From)：", args));
		}

		if (StringUtils.isNotEmpty((String) reqMap.get("shutokuYmdTo"))) {
			args = new HashMap<Integer, Object>();
			args.put(NSDConstant.CHECK_ITEM.DATE_FORMAT_CHECK.ordinal(), null);
			inputCheckList.add(setInputCheck(reqMap, "shutokuYmdTo", "取得年月日(To)：", args));
		}

		args = new HashMap<Integer, Object>();
		args.put(NSDConstant.CHECK_ITEM.DATE_COMPARE_CHECK.ordinal(), (String) reqMap.get("shutokuYmdTo"));
		inputCheckList.add(setInputCheck(reqMap, "shutokuYmdFrom", "取得年月日：", args));

		return inputCheckList;
	}

	/*
	 * 精算書取得・照会
	 */
	@RequestMapping(value = "/seisanshoShutoku-shokai", method = RequestMethod.POST)
	public Map<String, Object> getSeisanshoShutokuShokai(@RequestParam Map<String, Object> reqMap) throws Exception {

		Map<String, Object> resultMap = new HashMap<String, Object>();

		SeisanshoShutokuShokai selectCondition = new SeisanshoShutokuShokai();
		List<SeisanshoShutokuShokai> stkskList = new ArrayList<SeisanshoShutokuShokai>();

		// 画面入力した検索条件をBeanのプロパティにセット
		BeanUtils.populate(selectCondition, reqMap);

		// サービスを呼び出す
		stkskList = seisanshoShutokuService.getSeisanshoShutokuShokai(selectCondition);

		// 検索結果を返却Mapに設定する
		setDataToResultMap(resultMap, stkskList);

		return resultMap;
	}

	/**
	 * 精算書取得・削除
	 *
	 * @param reqMap
	 *            INPUTパラメータ
	 * @return 除却情報データ
	 * @throws Exception
	 * @version 1.00
	 */
	@RequestMapping(value = "/seisanshoShutoku-delByPyKey", method = RequestMethod.POST)
	public Map<String, Object> delByPyKey(@RequestParam Map<String, Object> reqMap) {

		Map<String, Object> resultMap = new HashMap<String, Object>();

		// 精算書ＩＤ
		String seisanShoId = (String) reqMap.get("seisanShoId");
		// 固定資産ＩＤ
		String koteiShisanId = (String) reqMap.get("koteiShisanId");

		// サービス呼び出し
		seisanshoShutokuService.delByPyKey(seisanShoId, koteiShisanId);

		// 処理結果データ
		resultMap.put(NSDConstant.RESULT_DATA_NAME, "");

		return setMsgToResultMapNoLog(resultMap, NSDConstant.MSGID_DELETE_SUCCES);
	}

	/**
	 * 精算書取得・新規
	 *
	 * @param reqMap
	 *            INPUTパラメータ
	 * @return 除却情報データ
	 * @throws Exception
	 * @version 1.00
	 */
	@RequestMapping(value = "/seisanshoShutoku-insert", method = RequestMethod.POST)
	public Map<String, Object> insert(HttpServletRequest request, @RequestParam Map<String, Object> reqMap)
			throws Exception {

		Map<String, Object> resultMap = new HashMap<String, Object>();

		// 入力チェック
		String errStr = inputCheckForInsertUpdate(reqMap);
		if (StringUtils.isNotEmpty(errStr)) {
			return setMsgToResultMap(resultMap, NSDConstant.MSGID_INPUT_ERROR, errStr);
		}

		Kss005 kss005 = setKss005(request, reqMap, NSDConstant.ACTION_INSERT);

		// サービスを呼び出す
		seisanshoShutokuService.insert(kss005);

		// 登録正常完了
		setMsgToResultMap(resultMap, NSDConstant.MSGID_INSERT_SUCCES);

		return resultMap;
	}

	/**
	 * 精算書取得・修正
	 *
	 * @param reqMap
	 *            INPUTパラメータ
	 * @return 除却情報データ
	 * @throws Exception
	 * @version 1.00
	 */
	@RequestMapping(value = "/seisanshoShutoku-update", method = RequestMethod.POST)
	public Map<String, Object> update(HttpServletRequest request, @RequestParam Map<String, Object> reqMap)
			throws Exception {
		Map<String, Object> resultMap = new HashMap<String, Object>();

		// 入力チェック
		String errStr = inputCheckForInsertUpdate(reqMap);
		if (StringUtils.isNotEmpty(errStr)) {
			return setMsgToResultMap(resultMap, NSDConstant.MSGID_INPUT_ERROR, errStr);
		}

		Kss005 kss005 = setKss005(request, reqMap, NSDConstant.ACTION_UPDATE);

		// 排他チェック
		String errId = commService.doHaita(kss005, (String)reqMap.get("updateDate"));
		if (!NSDConstant.BLANK_STRING.equals(errId)){
			return setMsgToResultMap(resultMap, errId);
		}

		// サービスを呼び出す
		seisanshoShutokuService.update(kss005);

		return setMsgToResultMap(resultMap, NSDConstant.MSGID_UPDATE_SUCCES);
	}

	/**
	 * 精算書取得・画面入力内容取得
	 *
	 * @param request
	 * @param reqMap
	 * @param actionFlag
	 *            登録・更新フラグ 0:登録 1:更新
	 * @return
	 * @throws Exception
	 */
	private Kss005 setKss005(HttpServletRequest request, Map<String, Object> reqMap, int actionFlag) throws Exception {

		Kss005 kss005 = new Kss005();

		// 画面情報を設定
		for (Entry<String, Object> itReq : reqMap.entrySet()) {

			// 日付型の項目は、Dateに変換する。
			if (itReq.getKey().equals("shutokuYmd") || itReq.getKey().equals("updateDate")
					|| itReq.getKey().equals("torihikiSakiTekiyoYmdF") || itReq.getKey().equals("kanriSoshikiF")
					|| itReq.getKey().equals("futanSoshikiF")) {

				if (StringUtils.isNotEmpty((String) itReq.getValue())) {

					Date dd = NSDDateUtils.parseStrToCal((String) itReq.getValue()).getTime();

					if (itReq.getKey().equals("torihikiSakiTekiyoYmdF")) {
						kss005.setTorihikiSakiTekiyoYmd(dd);
					} else if (itReq.getKey().equals("kanriSoshikiF")) {
						kss005.setKanriTekiyoStartYmd(dd);
					} else if (itReq.getKey().equals("futanSoshikiF")) {
						kss005.setFutanTekiyoStartYmd(dd);
					} else {
						BeanUtils.copyProperty(kss005, itReq.getKey(), dd);
					}
				}

			} else {
				BeanUtils.copyProperty(kss005, itReq.getKey(), itReq.getValue());

				// 取引先名称入力しない場合
				if (StringUtils.isEmpty(NSDCommUtils.nullToBlankStr((String) reqMap.get("torihikiSakiNm")))) {
					kss005.setTorihikiSakiCd(null);
					kss005.setTorihikiSakiTekiyoYmd(null);
				}
			}
		}

		// 項目7
		kss005.setKomoku07(kss005.getOyaKoteiShisanEda());
		// 項目14
		kss005.setKomoku14(kss005.getKojiTantoUserNm());
		// 項目15
		kss005.setKomoku15(kss005.getKojiTantoSoshikiCd());

		Date date = new Date();

		String loginUserId = getLoginUserInfo(request).getUserId();

		if (NSDConstant.ACTION_INSERT == actionFlag) {
			// 親固定資産番号
			kss005.setOyaKoteiShisanNo(NSDConstant.BLANK_STRING);
			// 登録ユーザーＩＤ
			kss005.setEntryUserId(loginUserId);
			// 登録年月日
			kss005.setEntryDate(date);
		}

		// 更新ユーザーＩＤ
		kss005.setUpdateUserId(loginUserId);
		// 更新年月日
		kss005.setUpdateDate(date);

		return kss005;
	}

	/**
	 * 取得登録、更新の入力データチェック
	 *
	 * @param reqMap
	 *            INPUTパラメータ
	 * @return エラーメッセージID
	 * @version 1.00
	 */
	private String inputCheckForInsertUpdate(Map<String, Object> reqMap) {

		List<InputCheck> inputCheckList = new ArrayList<InputCheck>();

		Map<Integer, Object> args;

		args = new HashMap<Integer, Object>();
		args.put(NSDConstant.CHECK_ITEM.EMPTY_CHECK.ordinal(), null);
		inputCheckList.add(setInputCheck(reqMap, "koteiShisanId", "固定資産番号：", args));

		args = new HashMap<Integer, Object>();
		args.put(NSDConstant.CHECK_ITEM.EMPTY_CHECK.ordinal(), null);
		inputCheckList.add(setInputCheck(reqMap, "komoku06", "親固定資産番号：", args));

		if (StringUtils.isNotEmpty((String) reqMap.get("oyaKoteiShisanEda"))) {
			args = new HashMap<Integer, Object>();
			args.put(NSDConstant.CHECK_ITEM.NUMERIC_CHECK.ordinal(), null);
			inputCheckList.add(setInputCheck(reqMap, "oyaKoteiShisanEda", "枝番：", args));
		}

		args = new HashMap<Integer, Object>();
		args.put(NSDConstant.CHECK_ITEM.EMPTY_CHECK.ordinal(), null);
		args.put(NSDConstant.CHECK_ITEM.DATE_FORMAT_CHECK.ordinal(), null);
		inputCheckList.add(setInputCheck(reqMap, "shutokuYmd", "取得年月日：", args));

		args = new HashMap<Integer, Object>();
		args.put(NSDConstant.CHECK_ITEM.EMPTY_CHECK.ordinal(), null);
		args.put(NSDConstant.CHECK_ITEM.DATE_FORMAT_CHECK.ordinal(), null);
		inputCheckList.add(setInputCheck(reqMap, "useYmd", "使用開始年月日：", args));

		args = new HashMap<Integer, Object>();
		args.put(NSDConstant.CHECK_ITEM.DATE_COMPARE_CHECK.ordinal(), (String) reqMap.get("useYmd"));
		inputCheckList.add(setInputCheck(reqMap, "shutokuYmd", "取得年月日：", args));

		args = new HashMap<Integer, Object>();
		args.put(NSDConstant.CHECK_ITEM.EMPTY_CHECK.ordinal(), null);
		inputCheckList.add(setInputCheck(reqMap, "koteiShisanNm", "固定資産名称：", args));

		args = new HashMap<Integer, Object>();
		args.put(NSDConstant.CHECK_ITEM.EMPTY_CHECK.ordinal(), null);
		inputCheckList.add(setInputCheck(reqMap, "shuruiCd", "種類：", args));

		args = new HashMap<Integer, Object>();
		args.put(NSDConstant.CHECK_ITEM.EMPTY_CHECK.ordinal(), null);
		Map<String, Integer> intDec = new HashMap<String, Integer>();
		intDec.put("integer", 14);
		intDec.put("decimal", 2);
		args.put(NSDConstant.CHECK_ITEM.FLOAT_LENGTH_CHECK.ordinal(), intDec);
		inputCheckList.add(setInputCheck(reqMap, "suryo", "物品数量：", args));

		args = new HashMap<Integer, Object>();
		args.put(NSDConstant.CHECK_ITEM.EMPTY_CHECK.ordinal(), null);
		inputCheckList.add(setInputCheck(reqMap, "taniCd", "単位：", args));

		args = new HashMap<Integer, Object>();
		args.put(NSDConstant.CHECK_ITEM.EMPTY_CHECK.ordinal(), null);
		args.put(NSDConstant.CHECK_ITEM.LENGTH_CHECK.ordinal(), 13);
		inputCheckList.add(setInputCheck(reqMap, "buppinGaku", "物品：", args));

		args = new HashMap<Integer, Object>();
		args.put(NSDConstant.CHECK_ITEM.EMPTY_CHECK.ordinal(), null);
		args.put(NSDConstant.CHECK_ITEM.LENGTH_CHECK.ordinal(), 13);
		inputCheckList.add(setInputCheck(reqMap, "kouhiGaku", "工費：", args));

		args = new HashMap<Integer, Object>();
		args.put(NSDConstant.CHECK_ITEM.LENGTH_CHECK.ordinal(), 13);
		inputCheckList.add(setInputCheck(reqMap, "souKeihiGaku", "総係費：", args));

		args = new HashMap<Integer, Object>();
		args.put(NSDConstant.CHECK_ITEM.EMPTY_CHECK.ordinal(), null);
		inputCheckList.add(setInputCheck(reqMap, "kanriSoshikiNm", "管理箇所名称：", args));

		args = new HashMap<Integer, Object>();
		args.put(NSDConstant.CHECK_ITEM.EMPTY_CHECK.ordinal(), null);
		inputCheckList.add(setInputCheck(reqMap, "futanSoshikiNm", "負担箇所：", args));

		args = new HashMap<Integer, Object>();
		args.put(NSDConstant.CHECK_ITEM.EMPTY_CHECK.ordinal(), null);
		inputCheckList.add(setInputCheck(reqMap, "sechiBashoNm", "設置場所名称：", args));

		args = new HashMap<Integer, Object>();
		args.put(NSDConstant.CHECK_ITEM.EMPTY_CHECK.ordinal(), null);
		inputCheckList.add(setInputCheck(reqMap, "shutokuRiyuCd", "取得事由：", args));

		args = new HashMap<Integer, Object>();
		Awdv02 awdv02 = new Awdv02();
		// 種類コード
		awdv02.setShuCod(reqMap.get("shuruiCd").toString().trim());
		// 構造コード
		awdv02.setKouCod(reqMap.get("kouzouCd").toString().trim());
		// 資産単位コード
		awdv02.setSaiCod(reqMap.get("shisanTaniCd").toString().trim());
		// 項目１コード
		awdv02.setShu4Cod(reqMap.get("kamokuCd1").toString().trim());
		// 項目２コード
		awdv02.setShu5Cod(reqMap.get("kamokuCd2").toString().trim());
		// 項目３コード
		awdv02.setShu6Cod(reqMap.get("kamokuCd3").toString().trim());
		args.put(NSDConstant.CHECK_ITEM.IS_EXIST_AWDV02.ordinal(), awdv02);
		inputCheckList.add(setInputCheck(reqMap, "", "種類、構造、細目コードは種類構造細目２テーブルに", args));

		// 取引先の判断
		if ("12".equals(awdv02.getShuCod()) || "42".equals(awdv02.getShuCod()) || "43".equals(awdv02.getShuCod())
				|| "51".equals(awdv02.getShuCod()) || "61".equals(awdv02.getShuCod())
				|| "305".equals(awdv02.getShu4Cod()) || "99".equals(awdv02.getShu6Cod())) {

			args = new HashMap<Integer, Object>();
			args.put(NSDConstant.CHECK_ITEM.EMPTY_CHECK.ordinal(), null);
			args.put(NSDConstant.CHECK_ITEM.NUMERIC_CHECK.ordinal(), null);
			inputCheckList.add(setInputCheck(reqMap, "taiyoNensuZei", "耐用月数：", args));

			args = new HashMap<Integer, Object>();
			args.put(NSDConstant.CHECK_ITEM.EMPTY_CHECK.ordinal(), null);
			inputCheckList.add(setInputCheck(reqMap, "torihikiSakiNm", "取引先名称：", args));

			args = new HashMap<Integer, Object>();
			args.put(NSDConstant.CHECK_ITEM.EMPTY_CHECK.ordinal(), null);
			args.put(NSDConstant.CHECK_ITEM.DATE_FORMAT_CHECK.ordinal(), null);
			inputCheckList.add(setInputCheck(reqMap, "torihikiSakiTekiyoYmdF", "取引先適用期間(From)：", args));

			args = new HashMap<Integer, Object>();
			args.put(NSDConstant.CHECK_ITEM.EMPTY_CHECK.ordinal(), null);
			args.put(NSDConstant.CHECK_ITEM.DATE_FORMAT_CHECK.ordinal(), null);
			inputCheckList.add(setInputCheck(reqMap, "torihikiSakiTekiyoYmdT", "取引先適用期間(To)：", args));

			args = new HashMap<Integer, Object>();
			Map<String, String> kikan = new HashMap<String, String>();
			kikan.put("startDate", (String) reqMap.get("torihikiSakiTekiyoYmdF"));
			kikan.put("endDate", (String) reqMap.get("torihikiSakiTekiyoYmdT"));
			args.put(NSDConstant.CHECK_ITEM.DATE_KIKAN_CHECK.ordinal(), kikan);
			inputCheckList.add(setInputCheck(reqMap, "useYmd", "固定資産の使用開始日：取引先適用期間内で", args));

		} else {
			args = new HashMap<Integer, Object>();
			args.put(NSDConstant.CHECK_ITEM.EMPTY_CHECK.ordinal(), null);
			inputCheckList.add(setInputCheck(reqMap, "taiyoNensuZei", "耐用年数：", args));
		}

		args = new HashMap<Integer, Object>();
		args.put(NSDConstant.CHECK_ITEM.EMPTY_CHECK.ordinal(), null);
		args.put(NSDConstant.CHECK_ITEM.DATE_FORMAT_CHECK.ordinal(), null);
		inputCheckList.add(setInputCheck(reqMap, "kanriSoshikiF", "管理箇所適用期間(From)：", args));

		args = new HashMap<Integer, Object>();
		args.put(NSDConstant.CHECK_ITEM.EMPTY_CHECK.ordinal(), null);
		args.put(NSDConstant.CHECK_ITEM.DATE_FORMAT_CHECK.ordinal(), null);
		inputCheckList.add(setInputCheck(reqMap, "kanriSoshikiT", "管理箇所適用期間(To)：", args));

		args = new HashMap<Integer, Object>();
		Map<String, String> kikan = new HashMap<String, String>();
		kikan.put("startDate", (String) reqMap.get("kanriSoshikiF"));
		kikan.put("endDate", (String) reqMap.get("kanriSoshikiT"));
		args.put(NSDConstant.CHECK_ITEM.DATE_KIKAN_CHECK.ordinal(), kikan);
		inputCheckList.add(setInputCheck(reqMap, "useYmd", "固定資産の使用開始日：管理箇所適用期間内で", args));

		args = new HashMap<Integer, Object>();
		args.put(NSDConstant.CHECK_ITEM.EMPTY_CHECK.ordinal(), null);
		args.put(NSDConstant.CHECK_ITEM.DATE_FORMAT_CHECK.ordinal(), null);
		inputCheckList.add(setInputCheck(reqMap, "futanSoshikiF", "負担箇所適用期間(From)：", args));

		args = new HashMap<Integer, Object>();
		args.put(NSDConstant.CHECK_ITEM.EMPTY_CHECK.ordinal(), null);
		args.put(NSDConstant.CHECK_ITEM.DATE_FORMAT_CHECK.ordinal(), null);
		inputCheckList.add(setInputCheck(reqMap, "futanSoshikiT", "負担箇所適用期間(To)：", args));

		args = new HashMap<Integer, Object>();
		kikan = new HashMap<String, String>();
		kikan.put("startDate", (String) reqMap.get("futanSoshikiF"));
		kikan.put("endDate", (String) reqMap.get("futanSoshikiT"));
		args.put(NSDConstant.CHECK_ITEM.DATE_KIKAN_CHECK.ordinal(), kikan);
		inputCheckList.add(setInputCheck(reqMap, "useYmd", "固定資産の使用開始日：負担箇所適用期間内で", args));

		args = new HashMap<Integer, Object>();
		args.put(NSDConstant.CHECK_ITEM.EMPTY_CHECK.ordinal(), null);
		args.put(NSDConstant.CHECK_ITEM.DATE_FORMAT_CHECK.ordinal(), null);
		inputCheckList.add(setInputCheck(reqMap, "tekiyoStartYmd", "科目内訳適用期間(From)：", args));

		args = new HashMap<Integer, Object>();
		args.put(NSDConstant.CHECK_ITEM.EMPTY_CHECK.ordinal(), null);
		args.put(NSDConstant.CHECK_ITEM.DATE_FORMAT_CHECK.ordinal(), null);
		inputCheckList.add(setInputCheck(reqMap, "tekiyoEndYmd", "科目内訳適用期間(To)：", args));

		args = new HashMap<Integer, Object>();
		kikan = new HashMap<String, String>();
		kikan.put("startDate", (String) reqMap.get("tekiyoStartYmd"));
		kikan.put("endDate", (String) reqMap.get("tekiyoEndYmd"));
		args.put(NSDConstant.CHECK_ITEM.DATE_KIKAN_CHECK.ordinal(), kikan);
		inputCheckList.add(setInputCheck(reqMap, "shutokuYmd", "取得年月日：科目内訳適用期間内で", args));

		String errStr = nsdDataCheck.dataCheck(inputCheckList);

		return errStr;

	}
}
