package jp.co.nsd.nkssweb;

import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import net.sf.jasperreports.engine.JREmptyDataSource;
import net.sf.jasperreports.engine.JasperCompileManager;
import net.sf.jasperreports.engine.JasperExportManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;

public class NSDTest {

	private static final Logger logger = LoggerFactory.getLogger(NSDTest.class);

	public static void main(String[] args) throws Exception {
		// TODO 自動生成されたメソッド・スタブ
		logger.info("NSDTest.main start!");

		try {
			try {
				@SuppressWarnings("unused")
				int bb = 2 / 0;
			} catch (Exception e) {
				throw new Exception("error");
			}
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
	}

	public static void createPDF() {

		String path = "C:\\workspace\\nkss\\nkss-web\\src\\main\\resources\\reports\\";
		String jrxmlFile = path.concat("SamplePDF.jrxml");
		String jasperFile = path.concat("SamplePDF.jasper");
		String outputfile = path.concat("SamplePDF.pdf");

		try {
			// InputStream employeeReportStream =
			// getClass().getResourceAsStream(jrxmlFile);
			// JasperReport jasperReport
			// = JasperCompileManager.compileReport(employeeReportStream);
			JasperCompileManager.compileReportToFile(jrxmlFile, jasperFile);
			// JRPdfExporter exporter = new JRPdfExporter();
			JasperPrint jasperPrint = (JasperPrint) JasperFillManager.fillReport(jasperFile, data(),
					new JREmptyDataSource());
			// JasperRunManager.runReportToPdf(jasperFile, data());
			JasperExportManager.exportReportToPdfFile(jasperPrint, outputfile);

		} catch (Exception e) {
			// TODO 自動生成された catch ブロック
			e.printStackTrace();
		}

	}

	public static Map<String, Object> data() {
		Map<String, Object> data = new HashMap<String, Object>();
		data.put("user_id", "0001");
		return data;
	}

}
