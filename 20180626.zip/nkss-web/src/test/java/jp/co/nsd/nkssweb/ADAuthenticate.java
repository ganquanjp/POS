package jp.co.nsd.nkssweb;

import java.util.Hashtable;

import javax.naming.AuthenticationException;
import javax.naming.Context;
import javax.naming.directory.DirContext;
import javax.naming.directory.InitialDirContext;

public class ADAuthenticate {

	public static void main(String[] args) {
		String userName = "username";
		String password = "";
		String host = "xxx.xxx.xxx.xxx";
		String domain = "@xxx.xx"; // 例.@noker.cn.com
		String port = "389";
		String url = new String("ldap://" + host + ":" + port);
		String user = userName.indexOf(domain) > 0 ? userName : userName + domain;
		Hashtable<String, String> env = new Hashtable<String, String>();
		DirContext ctx = null;
		env.put(Context.SECURITY_AUTHENTICATION, "simple");
		env.put(Context.SECURITY_PRINCIPAL, user);
		env.put(Context.SECURITY_CREDENTIALS, password);
		env.put(Context.INITIAL_CONTEXT_FACTORY, "com.sun.jndi.ldap.LdapCtxFactory");
		env.put(Context.PROVIDER_URL, url);
		try {
			ctx = new InitialDirContext(env);
			System.out.println("認証正常");
		} catch (AuthenticationException e) {
			System.out.println("認証失敗");
			e.printStackTrace();
		} catch (javax.naming.CommunicationException e) {
			System.out.println("ADドメイン接続失敗");
			e.printStackTrace();
		} catch (Exception e) {
			System.out.println("その他エラー");
			e.printStackTrace();
		} finally {
			if (null != ctx) {
				try {
					ctx.close();
					ctx = null;
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		}

	}

}
